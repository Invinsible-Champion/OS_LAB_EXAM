#include "types.h"
#include "stat.h"
#include "user.h"

// CPU-bound task that runs for some time
void cpu_task(void)
{
    volatile int x = 0;
    for (int i = 0; i < 50000000; i++)
    {
        x += (i * 3) % 7;
    }
    (void)x;
}

// Delay function to stagger process creation times
void delay(int count)
{
    for (volatile int j = 0; j < count; j++)
        ;
}

int main(void)
{
    int n = 3;
    int pid;

    printf(1, "Starting FCFS test with %d processes...\n", n);

    for (int i = 0; i < n; i++)
    {
        // Delay before fork so that ticks increment and creation times are staggered
        delay(5000000);

        pid = fork();
        if (pid < 0)
        {
            printf(1, "fork failed\n");
            exit();
        }
        else if (pid == 0)
        {
            // Child process: execute CPU task and print completion
            int mypid = getpid();
            printf(1, "Child %d (PID %d) started\n", i + 1, mypid);
            cpu_task();
            printf(1, "Child %d (PID %d) finished\n", i + 1, mypid);
            exit();
        }
        // Parent continues loop to fork next child
    }

    // Parent waits for all children and records completion order
    for (int i = 0; i < n; i++)
    {
        int wpid = wait();
        printf(1, "Completion order %d: PID %d finished\n", i + 1, wpid);
    }

    printf(1, "FCFS test completed successfully!\n");
    exit();
}   