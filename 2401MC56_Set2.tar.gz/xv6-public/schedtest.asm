
_schedtest:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:
#include "types.h"
#include "stat.h"
#include "user.h"

int main(void)
{
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	push   -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	53                   	push   %ebx
    int i;
    volatile int j;

    set_priority(getpid(), 1);

    for (i = 0; i < 3; i++)
   e:	31 db                	xor    %ebx,%ebx
{
  10:	51                   	push   %ecx
  11:	83 ec 18             	sub    $0x18,%esp
    printf(1, "Roll no : 2401MC56\n");
  14:	68 68 08 00 00       	push   $0x868
  19:	6a 01                	push   $0x1
  1b:	e8 a0 04 00 00       	call   4c0 <printf>
    int priorities[3] = {5, 10, 15};
  20:	c7 45 ec 05 00 00 00 	movl   $0x5,-0x14(%ebp)
  27:	c7 45 f0 0a 00 00 00 	movl   $0xa,-0x10(%ebp)
  2e:	c7 45 f4 0f 00 00 00 	movl   $0xf,-0xc(%ebp)
    set_priority(getpid(), 1);
  35:	e8 7d 03 00 00       	call   3b7 <getpid>
  3a:	5a                   	pop    %edx
  3b:	59                   	pop    %ecx
  3c:	6a 01                	push   $0x1
  3e:	50                   	push   %eax
  3f:	e8 93 03 00 00       	call   3d7 <set_priority>
  44:	83 c4 10             	add    $0x10,%esp
    {
        pids[i] = fork();
  47:	e8 e3 02 00 00       	call   32f <fork>

        if (pids[i] < 0)
  4c:	85 c0                	test   %eax,%eax
  4e:	78 2d                	js     7d <main+0x7d>
        {
            printf(1, "Fork failed\n");
            exit();
        }

        if (pids[i] == 0)
  50:	74 3e                	je     90 <main+0x90>
    for (i = 0; i < 3; i++)
  52:	83 c3 01             	add    $0x1,%ebx
  55:	83 fb 03             	cmp    $0x3,%ebx
  58:	75 ed                	jne    47 <main+0x47>
            exit();
        }
    }

    for (i = 0; i < 3; i++)
        wait();
  5a:	e8 e0 02 00 00       	call   33f <wait>
  5f:	e8 db 02 00 00       	call   33f <wait>
  64:	e8 d6 02 00 00       	call   33f <wait>

    printf(1, "Done\n");
  69:	83 ec 08             	sub    $0x8,%esp
  6c:	68 9f 08 00 00       	push   $0x89f
  71:	6a 01                	push   $0x1
  73:	e8 48 04 00 00       	call   4c0 <printf>

    exit();
  78:	e8 ba 02 00 00       	call   337 <exit>
            printf(1, "Fork failed\n");
  7d:	53                   	push   %ebx
  7e:	53                   	push   %ebx
  7f:	68 7c 08 00 00       	push   $0x87c
  84:	6a 01                	push   $0x1
  86:	e8 35 04 00 00       	call   4c0 <printf>
            exit();
  8b:	e8 a7 02 00 00       	call   337 <exit>
            set_priority(getpid(), priorities[i]);
  90:	8b 5c 9d ec          	mov    -0x14(%ebp,%ebx,4),%ebx
  94:	e8 1e 03 00 00       	call   3b7 <getpid>
  99:	52                   	push   %edx
  9a:	52                   	push   %edx
  9b:	53                   	push   %ebx
  9c:	50                   	push   %eax
  9d:	e8 35 03 00 00       	call   3d7 <set_priority>
            for (j = 0; j < 100000000; j++)
  a2:	31 c9                	xor    %ecx,%ecx
  a4:	83 c4 10             	add    $0x10,%esp
  a7:	89 4d e8             	mov    %ecx,-0x18(%ebp)
  aa:	81 7d e8 ff e0 f5 05 	cmpl   $0x5f5e0ff,-0x18(%ebp)
  b1:	7f 1a                	jg     cd <main+0xcd>
  b3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  b8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
  bf:	00 
  c0:	83 45 e8 01          	addl   $0x1,-0x18(%ebp)
  c4:	81 7d e8 ff e0 f5 05 	cmpl   $0x5f5e0ff,-0x18(%ebp)
  cb:	7e f3                	jle    c0 <main+0xc0>
            printf(1, "Priority %d finished\n", priorities[i]);
  cd:	50                   	push   %eax
  ce:	53                   	push   %ebx
  cf:	68 89 08 00 00       	push   $0x889
  d4:	6a 01                	push   $0x1
  d6:	e8 e5 03 00 00       	call   4c0 <printf>
            exit();
  db:	e8 57 02 00 00       	call   337 <exit>

000000e0 <strcpy>:
#include "user.h"
#include "x86.h"

char*
strcpy(char *s, const char *t)
{
  e0:	55                   	push   %ebp
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  e1:	31 c0                	xor    %eax,%eax
{
  e3:	89 e5                	mov    %esp,%ebp
  e5:	53                   	push   %ebx
  e6:	8b 4d 08             	mov    0x8(%ebp),%ecx
  e9:	8b 5d 0c             	mov    0xc(%ebp),%ebx
  ec:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  while((*s++ = *t++) != 0)
  f0:	0f b6 14 03          	movzbl (%ebx,%eax,1),%edx
  f4:	88 14 01             	mov    %dl,(%ecx,%eax,1)
  f7:	83 c0 01             	add    $0x1,%eax
  fa:	84 d2                	test   %dl,%dl
  fc:	75 f2                	jne    f0 <strcpy+0x10>
    ;
  return os;
}
  fe:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 101:	89 c8                	mov    %ecx,%eax
 103:	c9                   	leave
 104:	c3                   	ret
 105:	8d 76 00             	lea    0x0(%esi),%esi
 108:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 10f:	00 

00000110 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 110:	55                   	push   %ebp
 111:	89 e5                	mov    %esp,%ebp
 113:	53                   	push   %ebx
 114:	8b 55 08             	mov    0x8(%ebp),%edx
 117:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  while(*p && *p == *q)
 11a:	0f b6 02             	movzbl (%edx),%eax
 11d:	84 c0                	test   %al,%al
 11f:	75 2d                	jne    14e <strcmp+0x3e>
 121:	eb 3d                	jmp    160 <strcmp+0x50>
 123:	eb 1b                	jmp    140 <strcmp+0x30>
 125:	8d 76 00             	lea    0x0(%esi),%esi
 128:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 12f:	00 
 130:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 137:	00 
 138:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 13f:	00 
 140:	0f b6 42 01          	movzbl 0x1(%edx),%eax
    p++, q++;
 144:	83 c2 01             	add    $0x1,%edx
 147:	83 c1 01             	add    $0x1,%ecx
  while(*p && *p == *q)
 14a:	84 c0                	test   %al,%al
 14c:	74 12                	je     160 <strcmp+0x50>
 14e:	0f b6 19             	movzbl (%ecx),%ebx
 151:	38 c3                	cmp    %al,%bl
 153:	74 eb                	je     140 <strcmp+0x30>
  return (uchar)*p - (uchar)*q;
 155:	29 d8                	sub    %ebx,%eax
}
 157:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 15a:	c9                   	leave
 15b:	c3                   	ret
 15c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  return (uchar)*p - (uchar)*q;
 160:	0f b6 19             	movzbl (%ecx),%ebx
 163:	31 c0                	xor    %eax,%eax
 165:	29 d8                	sub    %ebx,%eax
}
 167:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 16a:	c9                   	leave
 16b:	c3                   	ret
 16c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000170 <strlen>:

uint
strlen(const char *s)
{
 170:	55                   	push   %ebp
 171:	89 e5                	mov    %esp,%ebp
 173:	8b 55 08             	mov    0x8(%ebp),%edx
  int n;

  for(n = 0; s[n]; n++)
 176:	80 3a 00             	cmpb   $0x0,(%edx)
 179:	74 15                	je     190 <strlen+0x20>
 17b:	31 c0                	xor    %eax,%eax
 17d:	8d 76 00             	lea    0x0(%esi),%esi
 180:	83 c0 01             	add    $0x1,%eax
 183:	89 c1                	mov    %eax,%ecx
 185:	80 3c 02 00          	cmpb   $0x0,(%edx,%eax,1)
 189:	75 f5                	jne    180 <strlen+0x10>
    ;
  return n;
}
 18b:	89 c8                	mov    %ecx,%eax
 18d:	5d                   	pop    %ebp
 18e:	c3                   	ret
 18f:	90                   	nop
  for(n = 0; s[n]; n++)
 190:	31 c9                	xor    %ecx,%ecx
}
 192:	5d                   	pop    %ebp
 193:	89 c8                	mov    %ecx,%eax
 195:	c3                   	ret
 196:	66 90                	xchg   %ax,%ax
 198:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 19f:	00 

000001a0 <memset>:

void*
memset(void *dst, int c, uint n)
{
 1a0:	55                   	push   %ebp
 1a1:	89 e5                	mov    %esp,%ebp
 1a3:	57                   	push   %edi
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
 1a4:	8b 4d 10             	mov    0x10(%ebp),%ecx
 1a7:	8b 45 0c             	mov    0xc(%ebp),%eax
 1aa:	8b 7d 08             	mov    0x8(%ebp),%edi
 1ad:	fc                   	cld
 1ae:	f3 aa                	rep stos %al,%es:(%edi)
  stosb(dst, c, n);
  return dst;
}
 1b0:	8b 45 08             	mov    0x8(%ebp),%eax
 1b3:	8b 7d fc             	mov    -0x4(%ebp),%edi
 1b6:	c9                   	leave
 1b7:	c3                   	ret
 1b8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 1bf:	00 

000001c0 <strchr>:

char*
strchr(const char *s, char c)
{
 1c0:	55                   	push   %ebp
 1c1:	89 e5                	mov    %esp,%ebp
 1c3:	8b 45 08             	mov    0x8(%ebp),%eax
 1c6:	0f b6 4d 0c          	movzbl 0xc(%ebp),%ecx
  for(; *s; s++)
 1ca:	0f b6 10             	movzbl (%eax),%edx
 1cd:	84 d2                	test   %dl,%dl
 1cf:	75 1a                	jne    1eb <strchr+0x2b>
 1d1:	eb 25                	jmp    1f8 <strchr+0x38>
 1d3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
 1d8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 1df:	00 
 1e0:	0f b6 50 01          	movzbl 0x1(%eax),%edx
 1e4:	83 c0 01             	add    $0x1,%eax
 1e7:	84 d2                	test   %dl,%dl
 1e9:	74 0d                	je     1f8 <strchr+0x38>
    if(*s == c)
 1eb:	38 d1                	cmp    %dl,%cl
 1ed:	75 f1                	jne    1e0 <strchr+0x20>
      return (char*)s;
  return 0;
}
 1ef:	5d                   	pop    %ebp
 1f0:	c3                   	ret
 1f1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  return 0;
 1f8:	31 c0                	xor    %eax,%eax
}
 1fa:	5d                   	pop    %ebp
 1fb:	c3                   	ret
 1fc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000200 <gets>:

char*
gets(char *buf, int max)
{
 200:	55                   	push   %ebp
 201:	89 e5                	mov    %esp,%ebp
 203:	57                   	push   %edi
 204:	56                   	push   %esi
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
    cc = read(0, &c, 1);
 205:	8d 7d e7             	lea    -0x19(%ebp),%edi
{
 208:	53                   	push   %ebx
  for(i=0; i+1 < max; ){
 209:	31 db                	xor    %ebx,%ebx
{
 20b:	83 ec 1c             	sub    $0x1c,%esp
  for(i=0; i+1 < max; ){
 20e:	eb 27                	jmp    237 <gets+0x37>
    cc = read(0, &c, 1);
 210:	83 ec 04             	sub    $0x4,%esp
 213:	6a 01                	push   $0x1
 215:	57                   	push   %edi
 216:	6a 00                	push   $0x0
 218:	e8 32 01 00 00       	call   34f <read>
    if(cc < 1)
 21d:	83 c4 10             	add    $0x10,%esp
 220:	85 c0                	test   %eax,%eax
 222:	7e 1d                	jle    241 <gets+0x41>
      break;
    buf[i++] = c;
 224:	0f b6 45 e7          	movzbl -0x19(%ebp),%eax
 228:	8b 55 08             	mov    0x8(%ebp),%edx
 22b:	88 44 1a ff          	mov    %al,-0x1(%edx,%ebx,1)
    if(c == '\n' || c == '\r')
 22f:	3c 0a                	cmp    $0xa,%al
 231:	74 1d                	je     250 <gets+0x50>
 233:	3c 0d                	cmp    $0xd,%al
 235:	74 19                	je     250 <gets+0x50>
  for(i=0; i+1 < max; ){
 237:	89 de                	mov    %ebx,%esi
 239:	83 c3 01             	add    $0x1,%ebx
 23c:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 23f:	7c cf                	jl     210 <gets+0x10>
      break;
  }
  buf[i] = '\0';
 241:	8b 45 08             	mov    0x8(%ebp),%eax
 244:	c6 04 30 00          	movb   $0x0,(%eax,%esi,1)
  return buf;
}
 248:	8d 65 f4             	lea    -0xc(%ebp),%esp
 24b:	5b                   	pop    %ebx
 24c:	5e                   	pop    %esi
 24d:	5f                   	pop    %edi
 24e:	5d                   	pop    %ebp
 24f:	c3                   	ret
  buf[i] = '\0';
 250:	8b 45 08             	mov    0x8(%ebp),%eax
    buf[i++] = c;
 253:	89 de                	mov    %ebx,%esi
  buf[i] = '\0';
 255:	c6 04 30 00          	movb   $0x0,(%eax,%esi,1)
}
 259:	8d 65 f4             	lea    -0xc(%ebp),%esp
 25c:	5b                   	pop    %ebx
 25d:	5e                   	pop    %esi
 25e:	5f                   	pop    %edi
 25f:	5d                   	pop    %ebp
 260:	c3                   	ret
 261:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 268:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 26f:	00 

00000270 <stat>:

int
stat(const char *n, struct stat *st)
{
 270:	55                   	push   %ebp
 271:	89 e5                	mov    %esp,%ebp
 273:	83 ec 10             	sub    $0x10,%esp
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 276:	6a 00                	push   $0x0
 278:	ff 75 08             	push   0x8(%ebp)
{
 27b:	89 75 fc             	mov    %esi,-0x4(%ebp)
  fd = open(n, O_RDONLY);
 27e:	e8 f4 00 00 00       	call   377 <open>
  if(fd < 0)
 283:	83 c4 10             	add    $0x10,%esp
 286:	85 c0                	test   %eax,%eax
 288:	78 2e                	js     2b8 <stat+0x48>
    return -1;
  r = fstat(fd, st);
 28a:	83 ec 08             	sub    $0x8,%esp
 28d:	ff 75 0c             	push   0xc(%ebp)
 290:	50                   	push   %eax
 291:	89 5d f8             	mov    %ebx,-0x8(%ebp)
 294:	89 c3                	mov    %eax,%ebx
 296:	e8 f4 00 00 00       	call   38f <fstat>
  close(fd);
 29b:	89 1c 24             	mov    %ebx,(%esp)
  r = fstat(fd, st);
 29e:	89 c6                	mov    %eax,%esi
  close(fd);
 2a0:	e8 ba 00 00 00       	call   35f <close>
  return r;
 2a5:	8b 5d f8             	mov    -0x8(%ebp),%ebx
 2a8:	83 c4 10             	add    $0x10,%esp
}
 2ab:	89 f0                	mov    %esi,%eax
 2ad:	8b 75 fc             	mov    -0x4(%ebp),%esi
 2b0:	c9                   	leave
 2b1:	c3                   	ret
 2b2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    return -1;
 2b8:	be ff ff ff ff       	mov    $0xffffffff,%esi
 2bd:	eb ec                	jmp    2ab <stat+0x3b>
 2bf:	90                   	nop

000002c0 <atoi>:

int
atoi(const char *s)
{
 2c0:	55                   	push   %ebp
 2c1:	89 e5                	mov    %esp,%ebp
 2c3:	53                   	push   %ebx
 2c4:	8b 55 08             	mov    0x8(%ebp),%edx
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 2c7:	0f be 02             	movsbl (%edx),%eax
 2ca:	8d 48 d0             	lea    -0x30(%eax),%ecx
 2cd:	80 f9 09             	cmp    $0x9,%cl
  n = 0;
 2d0:	b9 00 00 00 00       	mov    $0x0,%ecx
  while('0' <= *s && *s <= '9')
 2d5:	77 1e                	ja     2f5 <atoi+0x35>
 2d7:	90                   	nop
 2d8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 2df:	00 
    n = n*10 + *s++ - '0';
 2e0:	83 c2 01             	add    $0x1,%edx
 2e3:	8d 0c 89             	lea    (%ecx,%ecx,4),%ecx
 2e6:	8d 4c 48 d0          	lea    -0x30(%eax,%ecx,2),%ecx
  while('0' <= *s && *s <= '9')
 2ea:	0f be 02             	movsbl (%edx),%eax
 2ed:	8d 58 d0             	lea    -0x30(%eax),%ebx
 2f0:	80 fb 09             	cmp    $0x9,%bl
 2f3:	76 eb                	jbe    2e0 <atoi+0x20>
  return n;
}
 2f5:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 2f8:	89 c8                	mov    %ecx,%eax
 2fa:	c9                   	leave
 2fb:	c3                   	ret
 2fc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000300 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 300:	55                   	push   %ebp
 301:	89 e5                	mov    %esp,%ebp
 303:	83 ec 08             	sub    $0x8,%esp
 306:	8b 45 10             	mov    0x10(%ebp),%eax
 309:	8b 55 08             	mov    0x8(%ebp),%edx
 30c:	89 75 f8             	mov    %esi,-0x8(%ebp)
 30f:	8b 75 0c             	mov    0xc(%ebp),%esi
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  while(n-- > 0)
 312:	85 c0                	test   %eax,%eax
 314:	7e 12                	jle    328 <memmove+0x28>
 316:	89 7d fc             	mov    %edi,-0x4(%ebp)
 319:	01 d0                	add    %edx,%eax
  dst = vdst;
 31b:	89 d7                	mov    %edx,%edi
 31d:	8d 76 00             	lea    0x0(%esi),%esi
    *dst++ = *src++;
 320:	a4                   	movsb  %ds:(%esi),%es:(%edi)
  while(n-- > 0)
 321:	39 f8                	cmp    %edi,%eax
 323:	75 fb                	jne    320 <memmove+0x20>
 325:	8b 7d fc             	mov    -0x4(%ebp),%edi
  return vdst;
}
 328:	8b 75 f8             	mov    -0x8(%ebp),%esi
 32b:	89 d0                	mov    %edx,%eax
 32d:	c9                   	leave
 32e:	c3                   	ret

0000032f <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 32f:	b8 01 00 00 00       	mov    $0x1,%eax
 334:	cd 40                	int    $0x40
 336:	c3                   	ret

00000337 <exit>:
SYSCALL(exit)
 337:	b8 02 00 00 00       	mov    $0x2,%eax
 33c:	cd 40                	int    $0x40
 33e:	c3                   	ret

0000033f <wait>:
SYSCALL(wait)
 33f:	b8 03 00 00 00       	mov    $0x3,%eax
 344:	cd 40                	int    $0x40
 346:	c3                   	ret

00000347 <pipe>:
SYSCALL(pipe)
 347:	b8 04 00 00 00       	mov    $0x4,%eax
 34c:	cd 40                	int    $0x40
 34e:	c3                   	ret

0000034f <read>:
SYSCALL(read)
 34f:	b8 05 00 00 00       	mov    $0x5,%eax
 354:	cd 40                	int    $0x40
 356:	c3                   	ret

00000357 <write>:
SYSCALL(write)
 357:	b8 10 00 00 00       	mov    $0x10,%eax
 35c:	cd 40                	int    $0x40
 35e:	c3                   	ret

0000035f <close>:
SYSCALL(close)
 35f:	b8 15 00 00 00       	mov    $0x15,%eax
 364:	cd 40                	int    $0x40
 366:	c3                   	ret

00000367 <kill>:
SYSCALL(kill)
 367:	b8 06 00 00 00       	mov    $0x6,%eax
 36c:	cd 40                	int    $0x40
 36e:	c3                   	ret

0000036f <exec>:
SYSCALL(exec)
 36f:	b8 07 00 00 00       	mov    $0x7,%eax
 374:	cd 40                	int    $0x40
 376:	c3                   	ret

00000377 <open>:
SYSCALL(open)
 377:	b8 0f 00 00 00       	mov    $0xf,%eax
 37c:	cd 40                	int    $0x40
 37e:	c3                   	ret

0000037f <mknod>:
SYSCALL(mknod)
 37f:	b8 11 00 00 00       	mov    $0x11,%eax
 384:	cd 40                	int    $0x40
 386:	c3                   	ret

00000387 <unlink>:
SYSCALL(unlink)
 387:	b8 12 00 00 00       	mov    $0x12,%eax
 38c:	cd 40                	int    $0x40
 38e:	c3                   	ret

0000038f <fstat>:
SYSCALL(fstat)
 38f:	b8 08 00 00 00       	mov    $0x8,%eax
 394:	cd 40                	int    $0x40
 396:	c3                   	ret

00000397 <link>:
SYSCALL(link)
 397:	b8 13 00 00 00       	mov    $0x13,%eax
 39c:	cd 40                	int    $0x40
 39e:	c3                   	ret

0000039f <mkdir>:
SYSCALL(mkdir)
 39f:	b8 14 00 00 00       	mov    $0x14,%eax
 3a4:	cd 40                	int    $0x40
 3a6:	c3                   	ret

000003a7 <chdir>:
SYSCALL(chdir)
 3a7:	b8 09 00 00 00       	mov    $0x9,%eax
 3ac:	cd 40                	int    $0x40
 3ae:	c3                   	ret

000003af <dup>:
SYSCALL(dup)
 3af:	b8 0a 00 00 00       	mov    $0xa,%eax
 3b4:	cd 40                	int    $0x40
 3b6:	c3                   	ret

000003b7 <getpid>:
SYSCALL(getpid)
 3b7:	b8 0b 00 00 00       	mov    $0xb,%eax
 3bc:	cd 40                	int    $0x40
 3be:	c3                   	ret

000003bf <sbrk>:
SYSCALL(sbrk)
 3bf:	b8 0c 00 00 00       	mov    $0xc,%eax
 3c4:	cd 40                	int    $0x40
 3c6:	c3                   	ret

000003c7 <sleep>:
SYSCALL(sleep)
 3c7:	b8 0d 00 00 00       	mov    $0xd,%eax
 3cc:	cd 40                	int    $0x40
 3ce:	c3                   	ret

000003cf <uptime>:
SYSCALL(uptime)
 3cf:	b8 0e 00 00 00       	mov    $0xe,%eax
 3d4:	cd 40                	int    $0x40
 3d6:	c3                   	ret

000003d7 <set_priority>:
SYSCALL(set_priority)
 3d7:	b8 16 00 00 00       	mov    $0x16,%eax
 3dc:	cd 40                	int    $0x40
 3de:	c3                   	ret

000003df <mprotect>:
SYSCALL(mprotect)
 3df:	b8 17 00 00 00       	mov    $0x17,%eax
 3e4:	cd 40                	int    $0x40
 3e6:	c3                   	ret

000003e7 <munprotect>:
 3e7:	b8 18 00 00 00       	mov    $0x18,%eax
 3ec:	cd 40                	int    $0x40
 3ee:	c3                   	ret
 3ef:	66 90                	xchg   %ax,%ax
 3f1:	66 90                	xchg   %ax,%ax
 3f3:	66 90                	xchg   %ax,%ax
 3f5:	66 90                	xchg   %ax,%ax
 3f7:	66 90                	xchg   %ax,%ax
 3f9:	66 90                	xchg   %ax,%ax
 3fb:	66 90                	xchg   %ax,%ax
 3fd:	66 90                	xchg   %ax,%ax
 3ff:	90                   	nop

00000400 <printint>:
  write(fd, &c, 1);
}

static void
printint(int fd, int xx, int base, int sgn)
{
 400:	55                   	push   %ebp
 401:	89 e5                	mov    %esp,%ebp
 403:	57                   	push   %edi
 404:	56                   	push   %esi
 405:	53                   	push   %ebx
 406:	89 cb                	mov    %ecx,%ebx
 408:	83 ec 3c             	sub    $0x3c,%esp
 40b:	89 45 c4             	mov    %eax,-0x3c(%ebp)
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 40e:	85 d2                	test   %edx,%edx
 410:	0f 89 9a 00 00 00    	jns    4b0 <printint+0xb0>
 416:	f6 45 08 01          	testb  $0x1,0x8(%ebp)
 41a:	0f 84 90 00 00 00    	je     4b0 <printint+0xb0>
    neg = 1;
    x = -xx;
 420:	f7 da                	neg    %edx
    neg = 1;
 422:	b8 01 00 00 00       	mov    $0x1,%eax
 427:	89 45 c0             	mov    %eax,-0x40(%ebp)
 42a:	89 d1                	mov    %edx,%ecx
  } else {
    x = xx;
  }

  i = 0;
 42c:	31 f6                	xor    %esi,%esi
 42e:	66 90                	xchg   %ax,%ax
 430:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 437:	00 
 438:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 43f:	00 
  do{
    buf[i++] = digits[x % base];
 440:	89 c8                	mov    %ecx,%eax
 442:	31 d2                	xor    %edx,%edx
 444:	89 f7                	mov    %esi,%edi
 446:	f7 f3                	div    %ebx
 448:	8d 76 01             	lea    0x1(%esi),%esi
  }while((x /= base) != 0);
 44b:	39 d9                	cmp    %ebx,%ecx
    buf[i++] = digits[x % base];
 44d:	0f b6 92 04 09 00 00 	movzbl 0x904(%edx),%edx
  }while((x /= base) != 0);
 454:	89 c1                	mov    %eax,%ecx
    buf[i++] = digits[x % base];
 456:	88 54 35 d7          	mov    %dl,-0x29(%ebp,%esi,1)
  }while((x /= base) != 0);
 45a:	73 e4                	jae    440 <printint+0x40>
  if(neg)
 45c:	8b 45 c0             	mov    -0x40(%ebp),%eax
 45f:	85 c0                	test   %eax,%eax
 461:	74 07                	je     46a <printint+0x6a>
    buf[i++] = '-';
 463:	c6 44 35 d8 2d       	movb   $0x2d,-0x28(%ebp,%esi,1)
 468:	89 f7                	mov    %esi,%edi

  while(--i >= 0)
 46a:	8d 74 3d d8          	lea    -0x28(%ebp,%edi,1),%esi
 46e:	8b 7d c4             	mov    -0x3c(%ebp),%edi
 471:	8d 5d d7             	lea    -0x29(%ebp),%ebx
 474:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
 478:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 47f:	00 
    putc(fd, buf[i]);
 480:	0f b6 06             	movzbl (%esi),%eax
  write(fd, &c, 1);
 483:	83 ec 04             	sub    $0x4,%esp
  while(--i >= 0)
 486:	83 ee 01             	sub    $0x1,%esi
 489:	88 45 d7             	mov    %al,-0x29(%ebp)
  write(fd, &c, 1);
 48c:	8d 45 d7             	lea    -0x29(%ebp),%eax
 48f:	6a 01                	push   $0x1
 491:	50                   	push   %eax
 492:	57                   	push   %edi
 493:	e8 bf fe ff ff       	call   357 <write>
  while(--i >= 0)
 498:	83 c4 10             	add    $0x10,%esp
 49b:	39 f3                	cmp    %esi,%ebx
 49d:	75 e1                	jne    480 <printint+0x80>
}
 49f:	8d 65 f4             	lea    -0xc(%ebp),%esp
 4a2:	5b                   	pop    %ebx
 4a3:	5e                   	pop    %esi
 4a4:	5f                   	pop    %edi
 4a5:	5d                   	pop    %ebp
 4a6:	c3                   	ret
 4a7:	90                   	nop
 4a8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 4af:	00 
  neg = 0;
 4b0:	31 c0                	xor    %eax,%eax
 4b2:	e9 70 ff ff ff       	jmp    427 <printint+0x27>
 4b7:	90                   	nop
 4b8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 4bf:	00 

000004c0 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 4c0:	55                   	push   %ebp
 4c1:	89 e5                	mov    %esp,%ebp
 4c3:	83 ec 38             	sub    $0x38,%esp
 4c6:	89 5d f4             	mov    %ebx,-0xc(%ebp)
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
  for(i = 0; fmt[i]; i++){
 4c9:	8b 5d 0c             	mov    0xc(%ebp),%ebx
{
 4cc:	89 75 f8             	mov    %esi,-0x8(%ebp)
 4cf:	8b 75 08             	mov    0x8(%ebp),%esi
  for(i = 0; fmt[i]; i++){
 4d2:	0f b6 03             	movzbl (%ebx),%eax
 4d5:	84 c0                	test   %al,%al
 4d7:	0f 84 b6 00 00 00    	je     593 <printf+0xd3>
  ap = (uint*)(void*)&fmt + 1;
 4dd:	8d 4d 10             	lea    0x10(%ebp),%ecx
 4e0:	89 7d fc             	mov    %edi,-0x4(%ebp)
 4e3:	83 c3 01             	add    $0x1,%ebx
 4e6:	89 4d d4             	mov    %ecx,-0x2c(%ebp)
    c = fmt[i] & 0xff;
 4e9:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 4ec:	0f b6 d0             	movzbl %al,%edx
    if(state == 0){
 4ef:	eb 2a                	jmp    51b <printf+0x5b>
 4f1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  write(fd, &c, 1);
 4f8:	83 ec 04             	sub    $0x4,%esp
 4fb:	88 45 e7             	mov    %al,-0x19(%ebp)
 4fe:	8d 45 e7             	lea    -0x19(%ebp),%eax
  for(i = 0; fmt[i]; i++){
 501:	83 c3 01             	add    $0x1,%ebx
  write(fd, &c, 1);
 504:	6a 01                	push   $0x1
 506:	50                   	push   %eax
 507:	56                   	push   %esi
 508:	e8 4a fe ff ff       	call   357 <write>
  for(i = 0; fmt[i]; i++){
 50d:	0f b6 43 ff          	movzbl -0x1(%ebx),%eax
 511:	83 c4 10             	add    $0x10,%esp
 514:	84 c0                	test   %al,%al
 516:	74 78                	je     590 <printf+0xd0>
    c = fmt[i] & 0xff;
 518:	0f b6 d0             	movzbl %al,%edx
      if(c == '%'){
 51b:	83 fa 25             	cmp    $0x25,%edx
 51e:	75 d8                	jne    4f8 <printf+0x38>
  for(i = 0; fmt[i]; i++){
 520:	0f b6 13             	movzbl (%ebx),%edx
 523:	84 d2                	test   %dl,%dl
 525:	74 69                	je     590 <printf+0xd0>
    c = fmt[i] & 0xff;
 527:	0f b6 c2             	movzbl %dl,%eax
        state = '%';
      } else {
        putc(fd, c);
      }
    } else if(state == '%'){
      if(c == 'd'){
 52a:	80 fa 25             	cmp    $0x25,%dl
 52d:	0f 84 25 01 00 00    	je     658 <printf+0x198>
 533:	83 e8 63             	sub    $0x63,%eax
 536:	83 f8 15             	cmp    $0x15,%eax
 539:	77 0d                	ja     548 <printf+0x88>
 53b:	ff 24 85 ac 08 00 00 	jmp    *0x8ac(,%eax,4)
 542:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  write(fd, &c, 1);
 548:	83 ec 04             	sub    $0x4,%esp
 54b:	8d 4d e7             	lea    -0x19(%ebp),%ecx
 54e:	88 55 d0             	mov    %dl,-0x30(%ebp)
 551:	6a 01                	push   $0x1
 553:	51                   	push   %ecx
 554:	56                   	push   %esi
 555:	89 4d d4             	mov    %ecx,-0x2c(%ebp)
 558:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
 55c:	e8 f6 fd ff ff       	call   357 <write>
      } else if(c == '%'){
        putc(fd, c);
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
 561:	0f b6 55 d0          	movzbl -0x30(%ebp),%edx
  write(fd, &c, 1);
 565:	83 c4 0c             	add    $0xc,%esp
 568:	8b 4d d4             	mov    -0x2c(%ebp),%ecx
 56b:	6a 01                	push   $0x1
 56d:	88 55 e7             	mov    %dl,-0x19(%ebp)
 570:	51                   	push   %ecx
  for(i = 0; fmt[i]; i++){
 571:	83 c3 02             	add    $0x2,%ebx
  write(fd, &c, 1);
 574:	56                   	push   %esi
 575:	e8 dd fd ff ff       	call   357 <write>
  for(i = 0; fmt[i]; i++){
 57a:	0f b6 43 ff          	movzbl -0x1(%ebx),%eax
 57e:	83 c4 10             	add    $0x10,%esp
 581:	84 c0                	test   %al,%al
 583:	75 93                	jne    518 <printf+0x58>
 585:	8d 76 00             	lea    0x0(%esi),%esi
 588:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 58f:	00 
 590:	8b 7d fc             	mov    -0x4(%ebp),%edi
      }
      state = 0;
    }
  }
}
 593:	8b 5d f4             	mov    -0xc(%ebp),%ebx
 596:	8b 75 f8             	mov    -0x8(%ebp),%esi
 599:	c9                   	leave
 59a:	c3                   	ret
 59b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
        printint(fd, *ap, 16, 0);
 5a0:	83 ec 0c             	sub    $0xc,%esp
 5a3:	8b 17                	mov    (%edi),%edx
 5a5:	b9 10 00 00 00       	mov    $0x10,%ecx
 5aa:	89 f0                	mov    %esi,%eax
 5ac:	6a 00                	push   $0x0
 5ae:	e8 4d fe ff ff       	call   400 <printint>
  for(i = 0; fmt[i]; i++){
 5b3:	0f b6 43 01          	movzbl 0x1(%ebx),%eax
 5b7:	83 c3 02             	add    $0x2,%ebx
 5ba:	83 c4 10             	add    $0x10,%esp
 5bd:	84 c0                	test   %al,%al
 5bf:	74 cf                	je     590 <printf+0xd0>
        ap++;
 5c1:	83 c7 04             	add    $0x4,%edi
 5c4:	e9 4f ff ff ff       	jmp    518 <printf+0x58>
 5c9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
        printint(fd, *ap, 10, 1);
 5d0:	83 ec 0c             	sub    $0xc,%esp
 5d3:	8b 17                	mov    (%edi),%edx
 5d5:	b9 0a 00 00 00       	mov    $0xa,%ecx
 5da:	89 f0                	mov    %esi,%eax
 5dc:	6a 01                	push   $0x1
 5de:	e8 1d fe ff ff       	call   400 <printint>
  for(i = 0; fmt[i]; i++){
 5e3:	eb ce                	jmp    5b3 <printf+0xf3>
 5e5:	8d 76 00             	lea    0x0(%esi),%esi
  write(fd, &c, 1);
 5e8:	83 ec 04             	sub    $0x4,%esp
 5eb:	8d 4d e7             	lea    -0x19(%ebp),%ecx
        putc(fd, *ap);
 5ee:	8b 07                	mov    (%edi),%eax
  write(fd, &c, 1);
 5f0:	6a 01                	push   $0x1
 5f2:	51                   	push   %ecx
 5f3:	56                   	push   %esi
        putc(fd, *ap);
 5f4:	88 45 e7             	mov    %al,-0x19(%ebp)
  write(fd, &c, 1);
 5f7:	e8 5b fd ff ff       	call   357 <write>
 5fc:	eb b5                	jmp    5b3 <printf+0xf3>
 5fe:	66 90                	xchg   %ax,%ax
        s = (char*)*ap;
 600:	8b 07                	mov    (%edi),%eax
        ap++;
 602:	83 c7 04             	add    $0x4,%edi
        if(s == 0)
 605:	85 c0                	test   %eax,%eax
 607:	74 67                	je     670 <printf+0x1b0>
        while(*s != 0){
 609:	0f b6 10             	movzbl (%eax),%edx
 60c:	84 d2                	test   %dl,%dl
 60e:	74 6f                	je     67f <printf+0x1bf>
 610:	89 7d d4             	mov    %edi,-0x2c(%ebp)
 613:	89 c7                	mov    %eax,%edi
 615:	89 d0                	mov    %edx,%eax
 617:	89 5d d0             	mov    %ebx,-0x30(%ebp)
 61a:	89 fb                	mov    %edi,%ebx
 61c:	8d 7d e7             	lea    -0x19(%ebp),%edi
 61f:	90                   	nop
  write(fd, &c, 1);
 620:	83 ec 04             	sub    $0x4,%esp
          s++;
 623:	83 c3 01             	add    $0x1,%ebx
 626:	88 45 e7             	mov    %al,-0x19(%ebp)
  write(fd, &c, 1);
 629:	6a 01                	push   $0x1
 62b:	57                   	push   %edi
 62c:	56                   	push   %esi
 62d:	e8 25 fd ff ff       	call   357 <write>
        while(*s != 0){
 632:	0f b6 03             	movzbl (%ebx),%eax
 635:	83 c4 10             	add    $0x10,%esp
 638:	84 c0                	test   %al,%al
 63a:	75 e4                	jne    620 <printf+0x160>
 63c:	8b 5d d0             	mov    -0x30(%ebp),%ebx
  for(i = 0; fmt[i]; i++){
 63f:	0f b6 43 01          	movzbl 0x1(%ebx),%eax
 643:	83 c3 02             	add    $0x2,%ebx
 646:	84 c0                	test   %al,%al
 648:	0f 85 9b fe ff ff    	jne    4e9 <printf+0x29>
 64e:	e9 3d ff ff ff       	jmp    590 <printf+0xd0>
 653:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  write(fd, &c, 1);
 658:	83 ec 04             	sub    $0x4,%esp
 65b:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
 65f:	8d 4d e7             	lea    -0x19(%ebp),%ecx
 662:	6a 01                	push   $0x1
 664:	e9 07 ff ff ff       	jmp    570 <printf+0xb0>
 669:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
          s = "(null)";
 670:	89 7d d4             	mov    %edi,-0x2c(%ebp)
        if(s == 0)
 673:	b8 28 00 00 00       	mov    $0x28,%eax
          s = "(null)";
 678:	bf a5 08 00 00       	mov    $0x8a5,%edi
 67d:	eb 98                	jmp    617 <printf+0x157>
  for(i = 0; fmt[i]; i++){
 67f:	0f b6 43 01          	movzbl 0x1(%ebx),%eax
 683:	83 c3 02             	add    $0x2,%ebx
 686:	84 c0                	test   %al,%al
 688:	0f 85 8a fe ff ff    	jne    518 <printf+0x58>
 68e:	e9 fd fe ff ff       	jmp    590 <printf+0xd0>
 693:	66 90                	xchg   %ax,%ax
 695:	66 90                	xchg   %ax,%ax
 697:	66 90                	xchg   %ax,%ax
 699:	66 90                	xchg   %ax,%ax
 69b:	66 90                	xchg   %ax,%ax
 69d:	66 90                	xchg   %ax,%ax
 69f:	90                   	nop

000006a0 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 6a0:	55                   	push   %ebp
  Header *bp, *p;

  bp = (Header*)ap - 1;
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 6a1:	a1 f8 0b 00 00       	mov    0xbf8,%eax
{
 6a6:	89 e5                	mov    %esp,%ebp
 6a8:	57                   	push   %edi
 6a9:	56                   	push   %esi
 6aa:	53                   	push   %ebx
 6ab:	8b 5d 08             	mov    0x8(%ebp),%ebx
  bp = (Header*)ap - 1;
 6ae:	8d 4b f8             	lea    -0x8(%ebx),%ecx
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 6b1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 6b8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 6bf:	00 
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 6c0:	8b 10                	mov    (%eax),%edx
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 6c2:	39 c8                	cmp    %ecx,%eax
 6c4:	73 32                	jae    6f8 <free+0x58>
 6c6:	39 d1                	cmp    %edx,%ecx
 6c8:	72 04                	jb     6ce <free+0x2e>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 6ca:	39 d0                	cmp    %edx,%eax
 6cc:	72 32                	jb     700 <free+0x60>
      break;
  if(bp + bp->s.size == p->s.ptr){
 6ce:	8b 73 fc             	mov    -0x4(%ebx),%esi
 6d1:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 6d4:	39 fa                	cmp    %edi,%edx
 6d6:	74 30                	je     708 <free+0x68>
 6d8:	89 53 f8             	mov    %edx,-0x8(%ebx)
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 6db:	8b 50 04             	mov    0x4(%eax),%edx
 6de:	8d 34 d0             	lea    (%eax,%edx,8),%esi
 6e1:	39 f1                	cmp    %esi,%ecx
 6e3:	74 3a                	je     71f <free+0x7f>
 6e5:	89 08                	mov    %ecx,(%eax)
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
  } else
    p->s.ptr = bp;
  freep = p;
}
 6e7:	5b                   	pop    %ebx
  freep = p;
 6e8:	a3 f8 0b 00 00       	mov    %eax,0xbf8
}
 6ed:	5e                   	pop    %esi
 6ee:	5f                   	pop    %edi
 6ef:	5d                   	pop    %ebp
 6f0:	c3                   	ret
 6f1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 6f8:	39 d0                	cmp    %edx,%eax
 6fa:	72 04                	jb     700 <free+0x60>
 6fc:	39 d1                	cmp    %edx,%ecx
 6fe:	72 ce                	jb     6ce <free+0x2e>
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 700:	89 d0                	mov    %edx,%eax
 702:	eb bc                	jmp    6c0 <free+0x20>
 704:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    bp->s.size += p->s.ptr->s.size;
 708:	03 72 04             	add    0x4(%edx),%esi
 70b:	89 73 fc             	mov    %esi,-0x4(%ebx)
    bp->s.ptr = p->s.ptr->s.ptr;
 70e:	8b 10                	mov    (%eax),%edx
 710:	8b 12                	mov    (%edx),%edx
 712:	89 53 f8             	mov    %edx,-0x8(%ebx)
  if(p + p->s.size == bp){
 715:	8b 50 04             	mov    0x4(%eax),%edx
 718:	8d 34 d0             	lea    (%eax,%edx,8),%esi
 71b:	39 f1                	cmp    %esi,%ecx
 71d:	75 c6                	jne    6e5 <free+0x45>
    p->s.size += bp->s.size;
 71f:	03 53 fc             	add    -0x4(%ebx),%edx
  freep = p;
 722:	a3 f8 0b 00 00       	mov    %eax,0xbf8
    p->s.size += bp->s.size;
 727:	89 50 04             	mov    %edx,0x4(%eax)
    p->s.ptr = bp->s.ptr;
 72a:	8b 4b f8             	mov    -0x8(%ebx),%ecx
 72d:	89 08                	mov    %ecx,(%eax)
}
 72f:	5b                   	pop    %ebx
 730:	5e                   	pop    %esi
 731:	5f                   	pop    %edi
 732:	5d                   	pop    %ebp
 733:	c3                   	ret
 734:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
 738:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 73f:	00 

00000740 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 740:	55                   	push   %ebp
 741:	89 e5                	mov    %esp,%ebp
 743:	83 ec 18             	sub    $0x18,%esp
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 746:	8b 45 08             	mov    0x8(%ebp),%eax
{
 749:	89 7d fc             	mov    %edi,-0x4(%ebp)
  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 74c:	8d 78 07             	lea    0x7(%eax),%edi
  if((prevp = freep) == 0){
 74f:	a1 f8 0b 00 00       	mov    0xbf8,%eax
  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 754:	c1 ef 03             	shr    $0x3,%edi
 757:	83 c7 01             	add    $0x1,%edi
  if((prevp = freep) == 0){
 75a:	85 c0                	test   %eax,%eax
 75c:	0f 84 c6 00 00 00    	je     828 <malloc+0xe8>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 762:	8b 10                	mov    (%eax),%edx
    if(p->s.size >= nunits){
 764:	8b 4a 04             	mov    0x4(%edx),%ecx
 767:	39 f9                	cmp    %edi,%ecx
 769:	0f 83 87 00 00 00    	jae    7f6 <malloc+0xb6>
 76f:	89 5d f4             	mov    %ebx,-0xc(%ebp)
 772:	89 75 f8             	mov    %esi,-0x8(%ebp)
  if(nu < 4096)
 775:	bb 00 10 00 00       	mov    $0x1000,%ebx
 77a:	39 df                	cmp    %ebx,%edi
 77c:	0f 43 df             	cmovae %edi,%ebx
  p = sbrk(nu * sizeof(Header));
 77f:	8d 34 dd 00 00 00 00 	lea    0x0(,%ebx,8),%esi
 786:	eb 21                	jmp    7a9 <malloc+0x69>
 788:	eb 16                	jmp    7a0 <malloc+0x60>
 78a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
 790:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 797:	00 
 798:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 79f:	00 
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 7a0:	8b 10                	mov    (%eax),%edx
    if(p->s.size >= nunits){
 7a2:	8b 4a 04             	mov    0x4(%edx),%ecx
 7a5:	39 f9                	cmp    %edi,%ecx
 7a7:	73 47                	jae    7f0 <malloc+0xb0>
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 7a9:	89 d0                	mov    %edx,%eax
 7ab:	39 15 f8 0b 00 00    	cmp    %edx,0xbf8
 7b1:	75 ed                	jne    7a0 <malloc+0x60>
  p = sbrk(nu * sizeof(Header));
 7b3:	83 ec 0c             	sub    $0xc,%esp
 7b6:	56                   	push   %esi
 7b7:	e8 03 fc ff ff       	call   3bf <sbrk>
  if(p == (char*)-1)
 7bc:	83 c4 10             	add    $0x10,%esp
 7bf:	83 f8 ff             	cmp    $0xffffffff,%eax
 7c2:	74 54                	je     818 <malloc+0xd8>
  hp->s.size = nu;
 7c4:	89 58 04             	mov    %ebx,0x4(%eax)
  free((void*)(hp + 1));
 7c7:	83 ec 0c             	sub    $0xc,%esp
 7ca:	83 c0 08             	add    $0x8,%eax
 7cd:	50                   	push   %eax
 7ce:	e8 cd fe ff ff       	call   6a0 <free>
  return freep;
 7d3:	a1 f8 0b 00 00       	mov    0xbf8,%eax
      if((p = morecore(nunits)) == 0)
 7d8:	83 c4 10             	add    $0x10,%esp
 7db:	85 c0                	test   %eax,%eax
 7dd:	75 c1                	jne    7a0 <malloc+0x60>
 7df:	8b 5d f4             	mov    -0xc(%ebp),%ebx
 7e2:	8b 75 f8             	mov    -0x8(%ebp),%esi
 7e5:	eb 26                	jmp    80d <malloc+0xcd>
 7e7:	90                   	nop
 7e8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 7ef:	00 
 7f0:	8b 5d f4             	mov    -0xc(%ebp),%ebx
 7f3:	8b 75 f8             	mov    -0x8(%ebp),%esi
      if(p->s.size == nunits)
 7f6:	39 cf                	cmp    %ecx,%edi
 7f8:	74 66                	je     860 <malloc+0x120>
        p->s.size -= nunits;
 7fa:	29 f9                	sub    %edi,%ecx
 7fc:	89 4a 04             	mov    %ecx,0x4(%edx)
        p += p->s.size;
 7ff:	8d 14 ca             	lea    (%edx,%ecx,8),%edx
        p->s.size = nunits;
 802:	89 7a 04             	mov    %edi,0x4(%edx)
      freep = prevp;
 805:	a3 f8 0b 00 00       	mov    %eax,0xbf8
      return (void*)(p + 1);
 80a:	8d 42 08             	lea    0x8(%edx),%eax
        return 0;
  }
}
 80d:	8b 7d fc             	mov    -0x4(%ebp),%edi
 810:	c9                   	leave
 811:	c3                   	ret
 812:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
        return 0;
 818:	8b 5d f4             	mov    -0xc(%ebp),%ebx
 81b:	8b 75 f8             	mov    -0x8(%ebp),%esi
 81e:	31 c0                	xor    %eax,%eax
}
 820:	8b 7d fc             	mov    -0x4(%ebp),%edi
 823:	c9                   	leave
 824:	c3                   	ret
 825:	8d 76 00             	lea    0x0(%esi),%esi
 828:	89 5d f4             	mov    %ebx,-0xc(%ebp)
    base.s.size = 0;
 82b:	ba fc 0b 00 00       	mov    $0xbfc,%edx
 830:	89 75 f8             	mov    %esi,-0x8(%ebp)
    base.s.ptr = freep = prevp = &base;
 833:	c7 05 f8 0b 00 00 fc 	movl   $0xbfc,0xbf8
 83a:	0b 00 00 
 83d:	c7 05 fc 0b 00 00 fc 	movl   $0xbfc,0xbfc
 844:	0b 00 00 
    base.s.size = 0;
 847:	c7 05 00 0c 00 00 00 	movl   $0x0,0xc00
 84e:	00 00 00 
    if(p->s.size >= nunits){
 851:	e9 1f ff ff ff       	jmp    775 <malloc+0x35>
 856:	66 90                	xchg   %ax,%ax
 858:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 85f:	00 
        prevp->s.ptr = p->s.ptr;
 860:	8b 0a                	mov    (%edx),%ecx
 862:	89 08                	mov    %ecx,(%eax)
 864:	eb 9f                	jmp    805 <malloc+0xc5>
