
_prottest:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:
#include "types.h"
#include "stat.h"
#include "user.h"

int main(void)
{
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	push   -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	53                   	push   %ebx
   e:	51                   	push   %ecx
    printf(1,"Roll : 2401MC56\n");
   f:	83 ec 08             	sub    $0x8,%esp
  12:	68 28 09 00 00       	push   $0x928
  17:	6a 01                	push   $0x1
  19:	e8 62 05 00 00       	call   580 <printf>
    char *p;
    int pid;

    p = sbrk(4096);
  1e:	c7 04 24 00 10 00 00 	movl   $0x1000,(%esp)
  25:	e8 55 04 00 00       	call   47f <sbrk>

    if (p == (char *)-1)
  2a:	83 c4 10             	add    $0x10,%esp
  2d:	83 f8 ff             	cmp    $0xffffffff,%eax
  30:	0f 84 fe 00 00 00    	je     134 <main+0x134>
        exit();
    }

    p[0] = 'A';

    printf(1, "Initial value: %c\n", p[0]);
  36:	83 ec 04             	sub    $0x4,%esp
    p[0] = 'A';
  39:	c6 00 41             	movb   $0x41,(%eax)
  3c:	89 c3                	mov    %eax,%ebx
    printf(1, "Initial value: %c\n", p[0]);
  3e:	6a 41                	push   $0x41
  40:	68 46 09 00 00       	push   $0x946
  45:	6a 01                	push   $0x1
  47:	e8 34 05 00 00       	call   580 <printf>

    if (mprotect(p, 1) < 0)
  4c:	58                   	pop    %eax
  4d:	5a                   	pop    %edx
  4e:	6a 01                	push   $0x1
  50:	53                   	push   %ebx
  51:	e8 49 04 00 00       	call   49f <mprotect>
  56:	83 c4 10             	add    $0x10,%esp
  59:	85 c0                	test   %eax,%eax
  5b:	0f 88 c0 00 00 00    	js     121 <main+0x121>
    {
        printf(1, "mprotect failed\n");
        exit();
    }

    printf(1, "After mprotect, read: %c\n", p[0]);
  61:	50                   	push   %eax
  62:	0f be 03             	movsbl (%ebx),%eax
  65:	50                   	push   %eax
  66:	68 6a 09 00 00       	push   $0x96a
  6b:	6a 01                	push   $0x1
  6d:	e8 0e 05 00 00       	call   580 <printf>

    pid = fork();
  72:	e8 78 03 00 00       	call   3ef <fork>

    if (pid < 0)
  77:	83 c4 10             	add    $0x10,%esp
  7a:	85 c0                	test   %eax,%eax
  7c:	0f 88 db 00 00 00    	js     15d <main+0x15d>
    {
        printf(1, "fork failed\n");
        exit();
    }

    if (pid == 0)
  82:	0f 84 bf 00 00 00    	je     147 <main+0x147>
        p[0] = 'B';
        printf(1, "Child write unexpectedly succeeded\n");
        exit();
    }

    wait();
  88:	e8 72 03 00 00       	call   3ff <wait>

    printf(1, "After child termination, parent reads: %c\n", p[0]);
  8d:	50                   	push   %eax
  8e:	0f be 03             	movsbl (%ebx),%eax
  91:	50                   	push   %eax
  92:	68 18 0a 00 00       	push   $0xa18
  97:	6a 01                	push   $0x1
  99:	e8 e2 04 00 00       	call   580 <printf>

    if (munprotect(p, 1) < 0)
  9e:	58                   	pop    %eax
  9f:	5a                   	pop    %edx
  a0:	6a 01                	push   $0x1
  a2:	53                   	push   %ebx
  a3:	e8 ff 03 00 00       	call   4a7 <munprotect>
  a8:	83 c4 10             	add    $0x10,%esp
  ab:	85 c0                	test   %eax,%eax
  ad:	0f 88 bd 00 00 00    	js     170 <main+0x170>
    {
        printf(1, "munprotect failed\n");
        exit();
    }

    p[0] = 'C';
  b3:	c6 03 43             	movb   $0x43,(%ebx)

    printf(1, "After munprotect, write succeeded: %c\n", p[0]);
  b6:	50                   	push   %eax
  b7:	6a 43                	push   $0x43
  b9:	68 44 0a 00 00       	push   $0xa44
  be:	6a 01                	push   $0x1
  c0:	e8 bb 04 00 00       	call   580 <printf>

    printf(1, "Unaligned address test: %d\n", mprotect(p + 1, 1));
  c5:	8d 43 01             	lea    0x1(%ebx),%eax
  c8:	5a                   	pop    %edx
  c9:	59                   	pop    %ecx
  ca:	6a 01                	push   $0x1
  cc:	50                   	push   %eax
  cd:	e8 cd 03 00 00       	call   49f <mprotect>
  d2:	83 c4 0c             	add    $0xc,%esp
  d5:	50                   	push   %eax
  d6:	68 a4 09 00 00       	push   $0x9a4
  db:	6a 01                	push   $0x1
  dd:	e8 9e 04 00 00       	call   580 <printf>

    printf(1, "Zero length test: %d\n", mprotect(p, 0));
  e2:	58                   	pop    %eax
  e3:	5a                   	pop    %edx
  e4:	6a 00                	push   $0x0
  e6:	53                   	push   %ebx

    printf(1, "Out of range test: %d\n", mprotect(p + 4096, 1));
  e7:	81 c3 00 10 00 00    	add    $0x1000,%ebx
    printf(1, "Zero length test: %d\n", mprotect(p, 0));
  ed:	e8 ad 03 00 00       	call   49f <mprotect>
  f2:	83 c4 0c             	add    $0xc,%esp
  f5:	50                   	push   %eax
  f6:	68 c0 09 00 00       	push   $0x9c0
  fb:	6a 01                	push   $0x1
  fd:	e8 7e 04 00 00       	call   580 <printf>
    printf(1, "Out of range test: %d\n", mprotect(p + 4096, 1));
 102:	59                   	pop    %ecx
 103:	58                   	pop    %eax
 104:	6a 01                	push   $0x1
 106:	53                   	push   %ebx
 107:	e8 93 03 00 00       	call   49f <mprotect>
 10c:	83 c4 0c             	add    $0xc,%esp
 10f:	50                   	push   %eax
 110:	68 d6 09 00 00       	push   $0x9d6
 115:	6a 01                	push   $0x1
 117:	e8 64 04 00 00       	call   580 <printf>

    exit();
 11c:	e8 d6 02 00 00       	call   3f7 <exit>
        printf(1, "mprotect failed\n");
 121:	50                   	push   %eax
 122:	50                   	push   %eax
 123:	68 59 09 00 00       	push   $0x959
 128:	6a 01                	push   $0x1
 12a:	e8 51 04 00 00       	call   580 <printf>
        exit();
 12f:	e8 c3 02 00 00       	call   3f7 <exit>
        printf(1, "sbrk failed\n");
 134:	51                   	push   %ecx
 135:	51                   	push   %ecx
 136:	68 39 09 00 00       	push   $0x939
 13b:	6a 01                	push   $0x1
 13d:	e8 3e 04 00 00       	call   580 <printf>
        exit();
 142:	e8 b0 02 00 00       	call   3f7 <exit>
        p[0] = 'B';
 147:	c6 03 42             	movb   $0x42,(%ebx)
        printf(1, "Child write unexpectedly succeeded\n");
 14a:	51                   	push   %ecx
 14b:	51                   	push   %ecx
 14c:	68 f4 09 00 00       	push   $0x9f4
 151:	6a 01                	push   $0x1
 153:	e8 28 04 00 00       	call   580 <printf>
        exit();
 158:	e8 9a 02 00 00       	call   3f7 <exit>
        printf(1, "fork failed\n");
 15d:	53                   	push   %ebx
 15e:	53                   	push   %ebx
 15f:	68 84 09 00 00       	push   $0x984
 164:	6a 01                	push   $0x1
 166:	e8 15 04 00 00       	call   580 <printf>
        exit();
 16b:	e8 87 02 00 00       	call   3f7 <exit>
        printf(1, "munprotect failed\n");
 170:	50                   	push   %eax
 171:	50                   	push   %eax
 172:	68 91 09 00 00       	push   $0x991
 177:	6a 01                	push   $0x1
 179:	e8 02 04 00 00       	call   580 <printf>
        exit();
 17e:	e8 74 02 00 00       	call   3f7 <exit>
 183:	66 90                	xchg   %ax,%ax
 185:	66 90                	xchg   %ax,%ax
 187:	66 90                	xchg   %ax,%ax
 189:	66 90                	xchg   %ax,%ax
 18b:	66 90                	xchg   %ax,%ax
 18d:	66 90                	xchg   %ax,%ax
 18f:	66 90                	xchg   %ax,%ax
 191:	66 90                	xchg   %ax,%ax
 193:	66 90                	xchg   %ax,%ax
 195:	66 90                	xchg   %ax,%ax
 197:	66 90                	xchg   %ax,%ax
 199:	66 90                	xchg   %ax,%ax
 19b:	66 90                	xchg   %ax,%ax
 19d:	66 90                	xchg   %ax,%ax
 19f:	90                   	nop

000001a0 <strcpy>:
#include "user.h"
#include "x86.h"

char*
strcpy(char *s, const char *t)
{
 1a0:	55                   	push   %ebp
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 1a1:	31 c0                	xor    %eax,%eax
{
 1a3:	89 e5                	mov    %esp,%ebp
 1a5:	53                   	push   %ebx
 1a6:	8b 4d 08             	mov    0x8(%ebp),%ecx
 1a9:	8b 5d 0c             	mov    0xc(%ebp),%ebx
 1ac:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  while((*s++ = *t++) != 0)
 1b0:	0f b6 14 03          	movzbl (%ebx,%eax,1),%edx
 1b4:	88 14 01             	mov    %dl,(%ecx,%eax,1)
 1b7:	83 c0 01             	add    $0x1,%eax
 1ba:	84 d2                	test   %dl,%dl
 1bc:	75 f2                	jne    1b0 <strcpy+0x10>
    ;
  return os;
}
 1be:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 1c1:	89 c8                	mov    %ecx,%eax
 1c3:	c9                   	leave
 1c4:	c3                   	ret
 1c5:	8d 76 00             	lea    0x0(%esi),%esi
 1c8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 1cf:	00 

000001d0 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 1d0:	55                   	push   %ebp
 1d1:	89 e5                	mov    %esp,%ebp
 1d3:	53                   	push   %ebx
 1d4:	8b 55 08             	mov    0x8(%ebp),%edx
 1d7:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  while(*p && *p == *q)
 1da:	0f b6 02             	movzbl (%edx),%eax
 1dd:	84 c0                	test   %al,%al
 1df:	75 2d                	jne    20e <strcmp+0x3e>
 1e1:	eb 3d                	jmp    220 <strcmp+0x50>
 1e3:	eb 1b                	jmp    200 <strcmp+0x30>
 1e5:	8d 76 00             	lea    0x0(%esi),%esi
 1e8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 1ef:	00 
 1f0:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 1f7:	00 
 1f8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 1ff:	00 
 200:	0f b6 42 01          	movzbl 0x1(%edx),%eax
    p++, q++;
 204:	83 c2 01             	add    $0x1,%edx
 207:	83 c1 01             	add    $0x1,%ecx
  while(*p && *p == *q)
 20a:	84 c0                	test   %al,%al
 20c:	74 12                	je     220 <strcmp+0x50>
 20e:	0f b6 19             	movzbl (%ecx),%ebx
 211:	38 c3                	cmp    %al,%bl
 213:	74 eb                	je     200 <strcmp+0x30>
  return (uchar)*p - (uchar)*q;
 215:	29 d8                	sub    %ebx,%eax
}
 217:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 21a:	c9                   	leave
 21b:	c3                   	ret
 21c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  return (uchar)*p - (uchar)*q;
 220:	0f b6 19             	movzbl (%ecx),%ebx
 223:	31 c0                	xor    %eax,%eax
 225:	29 d8                	sub    %ebx,%eax
}
 227:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 22a:	c9                   	leave
 22b:	c3                   	ret
 22c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000230 <strlen>:

uint
strlen(const char *s)
{
 230:	55                   	push   %ebp
 231:	89 e5                	mov    %esp,%ebp
 233:	8b 55 08             	mov    0x8(%ebp),%edx
  int n;

  for(n = 0; s[n]; n++)
 236:	80 3a 00             	cmpb   $0x0,(%edx)
 239:	74 15                	je     250 <strlen+0x20>
 23b:	31 c0                	xor    %eax,%eax
 23d:	8d 76 00             	lea    0x0(%esi),%esi
 240:	83 c0 01             	add    $0x1,%eax
 243:	89 c1                	mov    %eax,%ecx
 245:	80 3c 02 00          	cmpb   $0x0,(%edx,%eax,1)
 249:	75 f5                	jne    240 <strlen+0x10>
    ;
  return n;
}
 24b:	89 c8                	mov    %ecx,%eax
 24d:	5d                   	pop    %ebp
 24e:	c3                   	ret
 24f:	90                   	nop
  for(n = 0; s[n]; n++)
 250:	31 c9                	xor    %ecx,%ecx
}
 252:	5d                   	pop    %ebp
 253:	89 c8                	mov    %ecx,%eax
 255:	c3                   	ret
 256:	66 90                	xchg   %ax,%ax
 258:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 25f:	00 

00000260 <memset>:

void*
memset(void *dst, int c, uint n)
{
 260:	55                   	push   %ebp
 261:	89 e5                	mov    %esp,%ebp
 263:	57                   	push   %edi
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
 264:	8b 4d 10             	mov    0x10(%ebp),%ecx
 267:	8b 45 0c             	mov    0xc(%ebp),%eax
 26a:	8b 7d 08             	mov    0x8(%ebp),%edi
 26d:	fc                   	cld
 26e:	f3 aa                	rep stos %al,%es:(%edi)
  stosb(dst, c, n);
  return dst;
}
 270:	8b 45 08             	mov    0x8(%ebp),%eax
 273:	8b 7d fc             	mov    -0x4(%ebp),%edi
 276:	c9                   	leave
 277:	c3                   	ret
 278:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 27f:	00 

00000280 <strchr>:

char*
strchr(const char *s, char c)
{
 280:	55                   	push   %ebp
 281:	89 e5                	mov    %esp,%ebp
 283:	8b 45 08             	mov    0x8(%ebp),%eax
 286:	0f b6 4d 0c          	movzbl 0xc(%ebp),%ecx
  for(; *s; s++)
 28a:	0f b6 10             	movzbl (%eax),%edx
 28d:	84 d2                	test   %dl,%dl
 28f:	75 1a                	jne    2ab <strchr+0x2b>
 291:	eb 25                	jmp    2b8 <strchr+0x38>
 293:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
 298:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 29f:	00 
 2a0:	0f b6 50 01          	movzbl 0x1(%eax),%edx
 2a4:	83 c0 01             	add    $0x1,%eax
 2a7:	84 d2                	test   %dl,%dl
 2a9:	74 0d                	je     2b8 <strchr+0x38>
    if(*s == c)
 2ab:	38 d1                	cmp    %dl,%cl
 2ad:	75 f1                	jne    2a0 <strchr+0x20>
      return (char*)s;
  return 0;
}
 2af:	5d                   	pop    %ebp
 2b0:	c3                   	ret
 2b1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  return 0;
 2b8:	31 c0                	xor    %eax,%eax
}
 2ba:	5d                   	pop    %ebp
 2bb:	c3                   	ret
 2bc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

000002c0 <gets>:

char*
gets(char *buf, int max)
{
 2c0:	55                   	push   %ebp
 2c1:	89 e5                	mov    %esp,%ebp
 2c3:	57                   	push   %edi
 2c4:	56                   	push   %esi
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
    cc = read(0, &c, 1);
 2c5:	8d 7d e7             	lea    -0x19(%ebp),%edi
{
 2c8:	53                   	push   %ebx
  for(i=0; i+1 < max; ){
 2c9:	31 db                	xor    %ebx,%ebx
{
 2cb:	83 ec 1c             	sub    $0x1c,%esp
  for(i=0; i+1 < max; ){
 2ce:	eb 27                	jmp    2f7 <gets+0x37>
    cc = read(0, &c, 1);
 2d0:	83 ec 04             	sub    $0x4,%esp
 2d3:	6a 01                	push   $0x1
 2d5:	57                   	push   %edi
 2d6:	6a 00                	push   $0x0
 2d8:	e8 32 01 00 00       	call   40f <read>
    if(cc < 1)
 2dd:	83 c4 10             	add    $0x10,%esp
 2e0:	85 c0                	test   %eax,%eax
 2e2:	7e 1d                	jle    301 <gets+0x41>
      break;
    buf[i++] = c;
 2e4:	0f b6 45 e7          	movzbl -0x19(%ebp),%eax
 2e8:	8b 55 08             	mov    0x8(%ebp),%edx
 2eb:	88 44 1a ff          	mov    %al,-0x1(%edx,%ebx,1)
    if(c == '\n' || c == '\r')
 2ef:	3c 0a                	cmp    $0xa,%al
 2f1:	74 1d                	je     310 <gets+0x50>
 2f3:	3c 0d                	cmp    $0xd,%al
 2f5:	74 19                	je     310 <gets+0x50>
  for(i=0; i+1 < max; ){
 2f7:	89 de                	mov    %ebx,%esi
 2f9:	83 c3 01             	add    $0x1,%ebx
 2fc:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 2ff:	7c cf                	jl     2d0 <gets+0x10>
      break;
  }
  buf[i] = '\0';
 301:	8b 45 08             	mov    0x8(%ebp),%eax
 304:	c6 04 30 00          	movb   $0x0,(%eax,%esi,1)
  return buf;
}
 308:	8d 65 f4             	lea    -0xc(%ebp),%esp
 30b:	5b                   	pop    %ebx
 30c:	5e                   	pop    %esi
 30d:	5f                   	pop    %edi
 30e:	5d                   	pop    %ebp
 30f:	c3                   	ret
  buf[i] = '\0';
 310:	8b 45 08             	mov    0x8(%ebp),%eax
    buf[i++] = c;
 313:	89 de                	mov    %ebx,%esi
  buf[i] = '\0';
 315:	c6 04 30 00          	movb   $0x0,(%eax,%esi,1)
}
 319:	8d 65 f4             	lea    -0xc(%ebp),%esp
 31c:	5b                   	pop    %ebx
 31d:	5e                   	pop    %esi
 31e:	5f                   	pop    %edi
 31f:	5d                   	pop    %ebp
 320:	c3                   	ret
 321:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 328:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 32f:	00 

00000330 <stat>:

int
stat(const char *n, struct stat *st)
{
 330:	55                   	push   %ebp
 331:	89 e5                	mov    %esp,%ebp
 333:	83 ec 10             	sub    $0x10,%esp
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 336:	6a 00                	push   $0x0
 338:	ff 75 08             	push   0x8(%ebp)
{
 33b:	89 75 fc             	mov    %esi,-0x4(%ebp)
  fd = open(n, O_RDONLY);
 33e:	e8 f4 00 00 00       	call   437 <open>
  if(fd < 0)
 343:	83 c4 10             	add    $0x10,%esp
 346:	85 c0                	test   %eax,%eax
 348:	78 2e                	js     378 <stat+0x48>
    return -1;
  r = fstat(fd, st);
 34a:	83 ec 08             	sub    $0x8,%esp
 34d:	ff 75 0c             	push   0xc(%ebp)
 350:	50                   	push   %eax
 351:	89 5d f8             	mov    %ebx,-0x8(%ebp)
 354:	89 c3                	mov    %eax,%ebx
 356:	e8 f4 00 00 00       	call   44f <fstat>
  close(fd);
 35b:	89 1c 24             	mov    %ebx,(%esp)
  r = fstat(fd, st);
 35e:	89 c6                	mov    %eax,%esi
  close(fd);
 360:	e8 ba 00 00 00       	call   41f <close>
  return r;
 365:	8b 5d f8             	mov    -0x8(%ebp),%ebx
 368:	83 c4 10             	add    $0x10,%esp
}
 36b:	89 f0                	mov    %esi,%eax
 36d:	8b 75 fc             	mov    -0x4(%ebp),%esi
 370:	c9                   	leave
 371:	c3                   	ret
 372:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    return -1;
 378:	be ff ff ff ff       	mov    $0xffffffff,%esi
 37d:	eb ec                	jmp    36b <stat+0x3b>
 37f:	90                   	nop

00000380 <atoi>:

int
atoi(const char *s)
{
 380:	55                   	push   %ebp
 381:	89 e5                	mov    %esp,%ebp
 383:	53                   	push   %ebx
 384:	8b 55 08             	mov    0x8(%ebp),%edx
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 387:	0f be 02             	movsbl (%edx),%eax
 38a:	8d 48 d0             	lea    -0x30(%eax),%ecx
 38d:	80 f9 09             	cmp    $0x9,%cl
  n = 0;
 390:	b9 00 00 00 00       	mov    $0x0,%ecx
  while('0' <= *s && *s <= '9')
 395:	77 1e                	ja     3b5 <atoi+0x35>
 397:	90                   	nop
 398:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 39f:	00 
    n = n*10 + *s++ - '0';
 3a0:	83 c2 01             	add    $0x1,%edx
 3a3:	8d 0c 89             	lea    (%ecx,%ecx,4),%ecx
 3a6:	8d 4c 48 d0          	lea    -0x30(%eax,%ecx,2),%ecx
  while('0' <= *s && *s <= '9')
 3aa:	0f be 02             	movsbl (%edx),%eax
 3ad:	8d 58 d0             	lea    -0x30(%eax),%ebx
 3b0:	80 fb 09             	cmp    $0x9,%bl
 3b3:	76 eb                	jbe    3a0 <atoi+0x20>
  return n;
}
 3b5:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 3b8:	89 c8                	mov    %ecx,%eax
 3ba:	c9                   	leave
 3bb:	c3                   	ret
 3bc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

000003c0 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 3c0:	55                   	push   %ebp
 3c1:	89 e5                	mov    %esp,%ebp
 3c3:	83 ec 08             	sub    $0x8,%esp
 3c6:	8b 45 10             	mov    0x10(%ebp),%eax
 3c9:	8b 55 08             	mov    0x8(%ebp),%edx
 3cc:	89 75 f8             	mov    %esi,-0x8(%ebp)
 3cf:	8b 75 0c             	mov    0xc(%ebp),%esi
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  while(n-- > 0)
 3d2:	85 c0                	test   %eax,%eax
 3d4:	7e 12                	jle    3e8 <memmove+0x28>
 3d6:	89 7d fc             	mov    %edi,-0x4(%ebp)
 3d9:	01 d0                	add    %edx,%eax
  dst = vdst;
 3db:	89 d7                	mov    %edx,%edi
 3dd:	8d 76 00             	lea    0x0(%esi),%esi
    *dst++ = *src++;
 3e0:	a4                   	movsb  %ds:(%esi),%es:(%edi)
  while(n-- > 0)
 3e1:	39 f8                	cmp    %edi,%eax
 3e3:	75 fb                	jne    3e0 <memmove+0x20>
 3e5:	8b 7d fc             	mov    -0x4(%ebp),%edi
  return vdst;
}
 3e8:	8b 75 f8             	mov    -0x8(%ebp),%esi
 3eb:	89 d0                	mov    %edx,%eax
 3ed:	c9                   	leave
 3ee:	c3                   	ret

000003ef <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 3ef:	b8 01 00 00 00       	mov    $0x1,%eax
 3f4:	cd 40                	int    $0x40
 3f6:	c3                   	ret

000003f7 <exit>:
SYSCALL(exit)
 3f7:	b8 02 00 00 00       	mov    $0x2,%eax
 3fc:	cd 40                	int    $0x40
 3fe:	c3                   	ret

000003ff <wait>:
SYSCALL(wait)
 3ff:	b8 03 00 00 00       	mov    $0x3,%eax
 404:	cd 40                	int    $0x40
 406:	c3                   	ret

00000407 <pipe>:
SYSCALL(pipe)
 407:	b8 04 00 00 00       	mov    $0x4,%eax
 40c:	cd 40                	int    $0x40
 40e:	c3                   	ret

0000040f <read>:
SYSCALL(read)
 40f:	b8 05 00 00 00       	mov    $0x5,%eax
 414:	cd 40                	int    $0x40
 416:	c3                   	ret

00000417 <write>:
SYSCALL(write)
 417:	b8 10 00 00 00       	mov    $0x10,%eax
 41c:	cd 40                	int    $0x40
 41e:	c3                   	ret

0000041f <close>:
SYSCALL(close)
 41f:	b8 15 00 00 00       	mov    $0x15,%eax
 424:	cd 40                	int    $0x40
 426:	c3                   	ret

00000427 <kill>:
SYSCALL(kill)
 427:	b8 06 00 00 00       	mov    $0x6,%eax
 42c:	cd 40                	int    $0x40
 42e:	c3                   	ret

0000042f <exec>:
SYSCALL(exec)
 42f:	b8 07 00 00 00       	mov    $0x7,%eax
 434:	cd 40                	int    $0x40
 436:	c3                   	ret

00000437 <open>:
SYSCALL(open)
 437:	b8 0f 00 00 00       	mov    $0xf,%eax
 43c:	cd 40                	int    $0x40
 43e:	c3                   	ret

0000043f <mknod>:
SYSCALL(mknod)
 43f:	b8 11 00 00 00       	mov    $0x11,%eax
 444:	cd 40                	int    $0x40
 446:	c3                   	ret

00000447 <unlink>:
SYSCALL(unlink)
 447:	b8 12 00 00 00       	mov    $0x12,%eax
 44c:	cd 40                	int    $0x40
 44e:	c3                   	ret

0000044f <fstat>:
SYSCALL(fstat)
 44f:	b8 08 00 00 00       	mov    $0x8,%eax
 454:	cd 40                	int    $0x40
 456:	c3                   	ret

00000457 <link>:
SYSCALL(link)
 457:	b8 13 00 00 00       	mov    $0x13,%eax
 45c:	cd 40                	int    $0x40
 45e:	c3                   	ret

0000045f <mkdir>:
SYSCALL(mkdir)
 45f:	b8 14 00 00 00       	mov    $0x14,%eax
 464:	cd 40                	int    $0x40
 466:	c3                   	ret

00000467 <chdir>:
SYSCALL(chdir)
 467:	b8 09 00 00 00       	mov    $0x9,%eax
 46c:	cd 40                	int    $0x40
 46e:	c3                   	ret

0000046f <dup>:
SYSCALL(dup)
 46f:	b8 0a 00 00 00       	mov    $0xa,%eax
 474:	cd 40                	int    $0x40
 476:	c3                   	ret

00000477 <getpid>:
SYSCALL(getpid)
 477:	b8 0b 00 00 00       	mov    $0xb,%eax
 47c:	cd 40                	int    $0x40
 47e:	c3                   	ret

0000047f <sbrk>:
SYSCALL(sbrk)
 47f:	b8 0c 00 00 00       	mov    $0xc,%eax
 484:	cd 40                	int    $0x40
 486:	c3                   	ret

00000487 <sleep>:
SYSCALL(sleep)
 487:	b8 0d 00 00 00       	mov    $0xd,%eax
 48c:	cd 40                	int    $0x40
 48e:	c3                   	ret

0000048f <uptime>:
SYSCALL(uptime)
 48f:	b8 0e 00 00 00       	mov    $0xe,%eax
 494:	cd 40                	int    $0x40
 496:	c3                   	ret

00000497 <set_priority>:
SYSCALL(set_priority)
 497:	b8 16 00 00 00       	mov    $0x16,%eax
 49c:	cd 40                	int    $0x40
 49e:	c3                   	ret

0000049f <mprotect>:
SYSCALL(mprotect)
 49f:	b8 17 00 00 00       	mov    $0x17,%eax
 4a4:	cd 40                	int    $0x40
 4a6:	c3                   	ret

000004a7 <munprotect>:
 4a7:	b8 18 00 00 00       	mov    $0x18,%eax
 4ac:	cd 40                	int    $0x40
 4ae:	c3                   	ret
 4af:	66 90                	xchg   %ax,%ax
 4b1:	66 90                	xchg   %ax,%ax
 4b3:	66 90                	xchg   %ax,%ax
 4b5:	66 90                	xchg   %ax,%ax
 4b7:	66 90                	xchg   %ax,%ax
 4b9:	66 90                	xchg   %ax,%ax
 4bb:	66 90                	xchg   %ax,%ax
 4bd:	66 90                	xchg   %ax,%ax
 4bf:	90                   	nop

000004c0 <printint>:
  write(fd, &c, 1);
}

static void
printint(int fd, int xx, int base, int sgn)
{
 4c0:	55                   	push   %ebp
 4c1:	89 e5                	mov    %esp,%ebp
 4c3:	57                   	push   %edi
 4c4:	56                   	push   %esi
 4c5:	53                   	push   %ebx
 4c6:	89 cb                	mov    %ecx,%ebx
 4c8:	83 ec 3c             	sub    $0x3c,%esp
 4cb:	89 45 c4             	mov    %eax,-0x3c(%ebp)
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 4ce:	85 d2                	test   %edx,%edx
 4d0:	0f 89 9a 00 00 00    	jns    570 <printint+0xb0>
 4d6:	f6 45 08 01          	testb  $0x1,0x8(%ebp)
 4da:	0f 84 90 00 00 00    	je     570 <printint+0xb0>
    neg = 1;
    x = -xx;
 4e0:	f7 da                	neg    %edx
    neg = 1;
 4e2:	b8 01 00 00 00       	mov    $0x1,%eax
 4e7:	89 45 c0             	mov    %eax,-0x40(%ebp)
 4ea:	89 d1                	mov    %edx,%ecx
  } else {
    x = xx;
  }

  i = 0;
 4ec:	31 f6                	xor    %esi,%esi
 4ee:	66 90                	xchg   %ax,%ax
 4f0:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 4f7:	00 
 4f8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 4ff:	00 
  do{
    buf[i++] = digits[x % base];
 500:	89 c8                	mov    %ecx,%eax
 502:	31 d2                	xor    %edx,%edx
 504:	89 f7                	mov    %esi,%edi
 506:	f7 f3                	div    %ebx
 508:	8d 76 01             	lea    0x1(%esi),%esi
  }while((x /= base) != 0);
 50b:	39 d9                	cmp    %ebx,%ecx
    buf[i++] = digits[x % base];
 50d:	0f b6 92 c4 0a 00 00 	movzbl 0xac4(%edx),%edx
  }while((x /= base) != 0);
 514:	89 c1                	mov    %eax,%ecx
    buf[i++] = digits[x % base];
 516:	88 54 35 d7          	mov    %dl,-0x29(%ebp,%esi,1)
  }while((x /= base) != 0);
 51a:	73 e4                	jae    500 <printint+0x40>
  if(neg)
 51c:	8b 45 c0             	mov    -0x40(%ebp),%eax
 51f:	85 c0                	test   %eax,%eax
 521:	74 07                	je     52a <printint+0x6a>
    buf[i++] = '-';
 523:	c6 44 35 d8 2d       	movb   $0x2d,-0x28(%ebp,%esi,1)
 528:	89 f7                	mov    %esi,%edi

  while(--i >= 0)
 52a:	8d 74 3d d8          	lea    -0x28(%ebp,%edi,1),%esi
 52e:	8b 7d c4             	mov    -0x3c(%ebp),%edi
 531:	8d 5d d7             	lea    -0x29(%ebp),%ebx
 534:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
 538:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 53f:	00 
    putc(fd, buf[i]);
 540:	0f b6 06             	movzbl (%esi),%eax
  write(fd, &c, 1);
 543:	83 ec 04             	sub    $0x4,%esp
  while(--i >= 0)
 546:	83 ee 01             	sub    $0x1,%esi
 549:	88 45 d7             	mov    %al,-0x29(%ebp)
  write(fd, &c, 1);
 54c:	8d 45 d7             	lea    -0x29(%ebp),%eax
 54f:	6a 01                	push   $0x1
 551:	50                   	push   %eax
 552:	57                   	push   %edi
 553:	e8 bf fe ff ff       	call   417 <write>
  while(--i >= 0)
 558:	83 c4 10             	add    $0x10,%esp
 55b:	39 f3                	cmp    %esi,%ebx
 55d:	75 e1                	jne    540 <printint+0x80>
}
 55f:	8d 65 f4             	lea    -0xc(%ebp),%esp
 562:	5b                   	pop    %ebx
 563:	5e                   	pop    %esi
 564:	5f                   	pop    %edi
 565:	5d                   	pop    %ebp
 566:	c3                   	ret
 567:	90                   	nop
 568:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 56f:	00 
  neg = 0;
 570:	31 c0                	xor    %eax,%eax
 572:	e9 70 ff ff ff       	jmp    4e7 <printint+0x27>
 577:	90                   	nop
 578:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 57f:	00 

00000580 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 580:	55                   	push   %ebp
 581:	89 e5                	mov    %esp,%ebp
 583:	83 ec 38             	sub    $0x38,%esp
 586:	89 5d f4             	mov    %ebx,-0xc(%ebp)
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
  for(i = 0; fmt[i]; i++){
 589:	8b 5d 0c             	mov    0xc(%ebp),%ebx
{
 58c:	89 75 f8             	mov    %esi,-0x8(%ebp)
 58f:	8b 75 08             	mov    0x8(%ebp),%esi
  for(i = 0; fmt[i]; i++){
 592:	0f b6 03             	movzbl (%ebx),%eax
 595:	84 c0                	test   %al,%al
 597:	0f 84 b6 00 00 00    	je     653 <printf+0xd3>
  ap = (uint*)(void*)&fmt + 1;
 59d:	8d 4d 10             	lea    0x10(%ebp),%ecx
 5a0:	89 7d fc             	mov    %edi,-0x4(%ebp)
 5a3:	83 c3 01             	add    $0x1,%ebx
 5a6:	89 4d d4             	mov    %ecx,-0x2c(%ebp)
    c = fmt[i] & 0xff;
 5a9:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 5ac:	0f b6 d0             	movzbl %al,%edx
    if(state == 0){
 5af:	eb 2a                	jmp    5db <printf+0x5b>
 5b1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  write(fd, &c, 1);
 5b8:	83 ec 04             	sub    $0x4,%esp
 5bb:	88 45 e7             	mov    %al,-0x19(%ebp)
 5be:	8d 45 e7             	lea    -0x19(%ebp),%eax
  for(i = 0; fmt[i]; i++){
 5c1:	83 c3 01             	add    $0x1,%ebx
  write(fd, &c, 1);
 5c4:	6a 01                	push   $0x1
 5c6:	50                   	push   %eax
 5c7:	56                   	push   %esi
 5c8:	e8 4a fe ff ff       	call   417 <write>
  for(i = 0; fmt[i]; i++){
 5cd:	0f b6 43 ff          	movzbl -0x1(%ebx),%eax
 5d1:	83 c4 10             	add    $0x10,%esp
 5d4:	84 c0                	test   %al,%al
 5d6:	74 78                	je     650 <printf+0xd0>
    c = fmt[i] & 0xff;
 5d8:	0f b6 d0             	movzbl %al,%edx
      if(c == '%'){
 5db:	83 fa 25             	cmp    $0x25,%edx
 5de:	75 d8                	jne    5b8 <printf+0x38>
  for(i = 0; fmt[i]; i++){
 5e0:	0f b6 13             	movzbl (%ebx),%edx
 5e3:	84 d2                	test   %dl,%dl
 5e5:	74 69                	je     650 <printf+0xd0>
    c = fmt[i] & 0xff;
 5e7:	0f b6 c2             	movzbl %dl,%eax
        state = '%';
      } else {
        putc(fd, c);
      }
    } else if(state == '%'){
      if(c == 'd'){
 5ea:	80 fa 25             	cmp    $0x25,%dl
 5ed:	0f 84 25 01 00 00    	je     718 <printf+0x198>
 5f3:	83 e8 63             	sub    $0x63,%eax
 5f6:	83 f8 15             	cmp    $0x15,%eax
 5f9:	77 0d                	ja     608 <printf+0x88>
 5fb:	ff 24 85 6c 0a 00 00 	jmp    *0xa6c(,%eax,4)
 602:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  write(fd, &c, 1);
 608:	83 ec 04             	sub    $0x4,%esp
 60b:	8d 4d e7             	lea    -0x19(%ebp),%ecx
 60e:	88 55 d0             	mov    %dl,-0x30(%ebp)
 611:	6a 01                	push   $0x1
 613:	51                   	push   %ecx
 614:	56                   	push   %esi
 615:	89 4d d4             	mov    %ecx,-0x2c(%ebp)
 618:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
 61c:	e8 f6 fd ff ff       	call   417 <write>
      } else if(c == '%'){
        putc(fd, c);
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
 621:	0f b6 55 d0          	movzbl -0x30(%ebp),%edx
  write(fd, &c, 1);
 625:	83 c4 0c             	add    $0xc,%esp
 628:	8b 4d d4             	mov    -0x2c(%ebp),%ecx
 62b:	6a 01                	push   $0x1
 62d:	88 55 e7             	mov    %dl,-0x19(%ebp)
 630:	51                   	push   %ecx
  for(i = 0; fmt[i]; i++){
 631:	83 c3 02             	add    $0x2,%ebx
  write(fd, &c, 1);
 634:	56                   	push   %esi
 635:	e8 dd fd ff ff       	call   417 <write>
  for(i = 0; fmt[i]; i++){
 63a:	0f b6 43 ff          	movzbl -0x1(%ebx),%eax
 63e:	83 c4 10             	add    $0x10,%esp
 641:	84 c0                	test   %al,%al
 643:	75 93                	jne    5d8 <printf+0x58>
 645:	8d 76 00             	lea    0x0(%esi),%esi
 648:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 64f:	00 
 650:	8b 7d fc             	mov    -0x4(%ebp),%edi
      }
      state = 0;
    }
  }
}
 653:	8b 5d f4             	mov    -0xc(%ebp),%ebx
 656:	8b 75 f8             	mov    -0x8(%ebp),%esi
 659:	c9                   	leave
 65a:	c3                   	ret
 65b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
        printint(fd, *ap, 16, 0);
 660:	83 ec 0c             	sub    $0xc,%esp
 663:	8b 17                	mov    (%edi),%edx
 665:	b9 10 00 00 00       	mov    $0x10,%ecx
 66a:	89 f0                	mov    %esi,%eax
 66c:	6a 00                	push   $0x0
 66e:	e8 4d fe ff ff       	call   4c0 <printint>
  for(i = 0; fmt[i]; i++){
 673:	0f b6 43 01          	movzbl 0x1(%ebx),%eax
 677:	83 c3 02             	add    $0x2,%ebx
 67a:	83 c4 10             	add    $0x10,%esp
 67d:	84 c0                	test   %al,%al
 67f:	74 cf                	je     650 <printf+0xd0>
        ap++;
 681:	83 c7 04             	add    $0x4,%edi
 684:	e9 4f ff ff ff       	jmp    5d8 <printf+0x58>
 689:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
        printint(fd, *ap, 10, 1);
 690:	83 ec 0c             	sub    $0xc,%esp
 693:	8b 17                	mov    (%edi),%edx
 695:	b9 0a 00 00 00       	mov    $0xa,%ecx
 69a:	89 f0                	mov    %esi,%eax
 69c:	6a 01                	push   $0x1
 69e:	e8 1d fe ff ff       	call   4c0 <printint>
  for(i = 0; fmt[i]; i++){
 6a3:	eb ce                	jmp    673 <printf+0xf3>
 6a5:	8d 76 00             	lea    0x0(%esi),%esi
  write(fd, &c, 1);
 6a8:	83 ec 04             	sub    $0x4,%esp
 6ab:	8d 4d e7             	lea    -0x19(%ebp),%ecx
        putc(fd, *ap);
 6ae:	8b 07                	mov    (%edi),%eax
  write(fd, &c, 1);
 6b0:	6a 01                	push   $0x1
 6b2:	51                   	push   %ecx
 6b3:	56                   	push   %esi
        putc(fd, *ap);
 6b4:	88 45 e7             	mov    %al,-0x19(%ebp)
  write(fd, &c, 1);
 6b7:	e8 5b fd ff ff       	call   417 <write>
 6bc:	eb b5                	jmp    673 <printf+0xf3>
 6be:	66 90                	xchg   %ax,%ax
        s = (char*)*ap;
 6c0:	8b 07                	mov    (%edi),%eax
        ap++;
 6c2:	83 c7 04             	add    $0x4,%edi
        if(s == 0)
 6c5:	85 c0                	test   %eax,%eax
 6c7:	74 67                	je     730 <printf+0x1b0>
        while(*s != 0){
 6c9:	0f b6 10             	movzbl (%eax),%edx
 6cc:	84 d2                	test   %dl,%dl
 6ce:	74 6f                	je     73f <printf+0x1bf>
 6d0:	89 7d d4             	mov    %edi,-0x2c(%ebp)
 6d3:	89 c7                	mov    %eax,%edi
 6d5:	89 d0                	mov    %edx,%eax
 6d7:	89 5d d0             	mov    %ebx,-0x30(%ebp)
 6da:	89 fb                	mov    %edi,%ebx
 6dc:	8d 7d e7             	lea    -0x19(%ebp),%edi
 6df:	90                   	nop
  write(fd, &c, 1);
 6e0:	83 ec 04             	sub    $0x4,%esp
          s++;
 6e3:	83 c3 01             	add    $0x1,%ebx
 6e6:	88 45 e7             	mov    %al,-0x19(%ebp)
  write(fd, &c, 1);
 6e9:	6a 01                	push   $0x1
 6eb:	57                   	push   %edi
 6ec:	56                   	push   %esi
 6ed:	e8 25 fd ff ff       	call   417 <write>
        while(*s != 0){
 6f2:	0f b6 03             	movzbl (%ebx),%eax
 6f5:	83 c4 10             	add    $0x10,%esp
 6f8:	84 c0                	test   %al,%al
 6fa:	75 e4                	jne    6e0 <printf+0x160>
 6fc:	8b 5d d0             	mov    -0x30(%ebp),%ebx
  for(i = 0; fmt[i]; i++){
 6ff:	0f b6 43 01          	movzbl 0x1(%ebx),%eax
 703:	83 c3 02             	add    $0x2,%ebx
 706:	84 c0                	test   %al,%al
 708:	0f 85 9b fe ff ff    	jne    5a9 <printf+0x29>
 70e:	e9 3d ff ff ff       	jmp    650 <printf+0xd0>
 713:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  write(fd, &c, 1);
 718:	83 ec 04             	sub    $0x4,%esp
 71b:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
 71f:	8d 4d e7             	lea    -0x19(%ebp),%ecx
 722:	6a 01                	push   $0x1
 724:	e9 07 ff ff ff       	jmp    630 <printf+0xb0>
 729:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
          s = "(null)";
 730:	89 7d d4             	mov    %edi,-0x2c(%ebp)
        if(s == 0)
 733:	b8 28 00 00 00       	mov    $0x28,%eax
          s = "(null)";
 738:	bf ed 09 00 00       	mov    $0x9ed,%edi
 73d:	eb 98                	jmp    6d7 <printf+0x157>
  for(i = 0; fmt[i]; i++){
 73f:	0f b6 43 01          	movzbl 0x1(%ebx),%eax
 743:	83 c3 02             	add    $0x2,%ebx
 746:	84 c0                	test   %al,%al
 748:	0f 85 8a fe ff ff    	jne    5d8 <printf+0x58>
 74e:	e9 fd fe ff ff       	jmp    650 <printf+0xd0>
 753:	66 90                	xchg   %ax,%ax
 755:	66 90                	xchg   %ax,%ax
 757:	66 90                	xchg   %ax,%ax
 759:	66 90                	xchg   %ax,%ax
 75b:	66 90                	xchg   %ax,%ax
 75d:	66 90                	xchg   %ax,%ax
 75f:	90                   	nop

00000760 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 760:	55                   	push   %ebp
  Header *bp, *p;

  bp = (Header*)ap - 1;
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 761:	a1 b8 0d 00 00       	mov    0xdb8,%eax
{
 766:	89 e5                	mov    %esp,%ebp
 768:	57                   	push   %edi
 769:	56                   	push   %esi
 76a:	53                   	push   %ebx
 76b:	8b 5d 08             	mov    0x8(%ebp),%ebx
  bp = (Header*)ap - 1;
 76e:	8d 4b f8             	lea    -0x8(%ebx),%ecx
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 771:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 778:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 77f:	00 
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 780:	8b 10                	mov    (%eax),%edx
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 782:	39 c8                	cmp    %ecx,%eax
 784:	73 32                	jae    7b8 <free+0x58>
 786:	39 d1                	cmp    %edx,%ecx
 788:	72 04                	jb     78e <free+0x2e>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 78a:	39 d0                	cmp    %edx,%eax
 78c:	72 32                	jb     7c0 <free+0x60>
      break;
  if(bp + bp->s.size == p->s.ptr){
 78e:	8b 73 fc             	mov    -0x4(%ebx),%esi
 791:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 794:	39 fa                	cmp    %edi,%edx
 796:	74 30                	je     7c8 <free+0x68>
 798:	89 53 f8             	mov    %edx,-0x8(%ebx)
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 79b:	8b 50 04             	mov    0x4(%eax),%edx
 79e:	8d 34 d0             	lea    (%eax,%edx,8),%esi
 7a1:	39 f1                	cmp    %esi,%ecx
 7a3:	74 3a                	je     7df <free+0x7f>
 7a5:	89 08                	mov    %ecx,(%eax)
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
  } else
    p->s.ptr = bp;
  freep = p;
}
 7a7:	5b                   	pop    %ebx
  freep = p;
 7a8:	a3 b8 0d 00 00       	mov    %eax,0xdb8
}
 7ad:	5e                   	pop    %esi
 7ae:	5f                   	pop    %edi
 7af:	5d                   	pop    %ebp
 7b0:	c3                   	ret
 7b1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 7b8:	39 d0                	cmp    %edx,%eax
 7ba:	72 04                	jb     7c0 <free+0x60>
 7bc:	39 d1                	cmp    %edx,%ecx
 7be:	72 ce                	jb     78e <free+0x2e>
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 7c0:	89 d0                	mov    %edx,%eax
 7c2:	eb bc                	jmp    780 <free+0x20>
 7c4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    bp->s.size += p->s.ptr->s.size;
 7c8:	03 72 04             	add    0x4(%edx),%esi
 7cb:	89 73 fc             	mov    %esi,-0x4(%ebx)
    bp->s.ptr = p->s.ptr->s.ptr;
 7ce:	8b 10                	mov    (%eax),%edx
 7d0:	8b 12                	mov    (%edx),%edx
 7d2:	89 53 f8             	mov    %edx,-0x8(%ebx)
  if(p + p->s.size == bp){
 7d5:	8b 50 04             	mov    0x4(%eax),%edx
 7d8:	8d 34 d0             	lea    (%eax,%edx,8),%esi
 7db:	39 f1                	cmp    %esi,%ecx
 7dd:	75 c6                	jne    7a5 <free+0x45>
    p->s.size += bp->s.size;
 7df:	03 53 fc             	add    -0x4(%ebx),%edx
  freep = p;
 7e2:	a3 b8 0d 00 00       	mov    %eax,0xdb8
    p->s.size += bp->s.size;
 7e7:	89 50 04             	mov    %edx,0x4(%eax)
    p->s.ptr = bp->s.ptr;
 7ea:	8b 4b f8             	mov    -0x8(%ebx),%ecx
 7ed:	89 08                	mov    %ecx,(%eax)
}
 7ef:	5b                   	pop    %ebx
 7f0:	5e                   	pop    %esi
 7f1:	5f                   	pop    %edi
 7f2:	5d                   	pop    %ebp
 7f3:	c3                   	ret
 7f4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
 7f8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 7ff:	00 

00000800 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 800:	55                   	push   %ebp
 801:	89 e5                	mov    %esp,%ebp
 803:	83 ec 18             	sub    $0x18,%esp
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 806:	8b 45 08             	mov    0x8(%ebp),%eax
{
 809:	89 7d fc             	mov    %edi,-0x4(%ebp)
  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 80c:	8d 78 07             	lea    0x7(%eax),%edi
  if((prevp = freep) == 0){
 80f:	a1 b8 0d 00 00       	mov    0xdb8,%eax
  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 814:	c1 ef 03             	shr    $0x3,%edi
 817:	83 c7 01             	add    $0x1,%edi
  if((prevp = freep) == 0){
 81a:	85 c0                	test   %eax,%eax
 81c:	0f 84 c6 00 00 00    	je     8e8 <malloc+0xe8>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 822:	8b 10                	mov    (%eax),%edx
    if(p->s.size >= nunits){
 824:	8b 4a 04             	mov    0x4(%edx),%ecx
 827:	39 f9                	cmp    %edi,%ecx
 829:	0f 83 87 00 00 00    	jae    8b6 <malloc+0xb6>
 82f:	89 5d f4             	mov    %ebx,-0xc(%ebp)
 832:	89 75 f8             	mov    %esi,-0x8(%ebp)
  if(nu < 4096)
 835:	bb 00 10 00 00       	mov    $0x1000,%ebx
 83a:	39 df                	cmp    %ebx,%edi
 83c:	0f 43 df             	cmovae %edi,%ebx
  p = sbrk(nu * sizeof(Header));
 83f:	8d 34 dd 00 00 00 00 	lea    0x0(,%ebx,8),%esi
 846:	eb 21                	jmp    869 <malloc+0x69>
 848:	eb 16                	jmp    860 <malloc+0x60>
 84a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
 850:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 857:	00 
 858:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 85f:	00 
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 860:	8b 10                	mov    (%eax),%edx
    if(p->s.size >= nunits){
 862:	8b 4a 04             	mov    0x4(%edx),%ecx
 865:	39 f9                	cmp    %edi,%ecx
 867:	73 47                	jae    8b0 <malloc+0xb0>
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 869:	89 d0                	mov    %edx,%eax
 86b:	39 15 b8 0d 00 00    	cmp    %edx,0xdb8
 871:	75 ed                	jne    860 <malloc+0x60>
  p = sbrk(nu * sizeof(Header));
 873:	83 ec 0c             	sub    $0xc,%esp
 876:	56                   	push   %esi
 877:	e8 03 fc ff ff       	call   47f <sbrk>
  if(p == (char*)-1)
 87c:	83 c4 10             	add    $0x10,%esp
 87f:	83 f8 ff             	cmp    $0xffffffff,%eax
 882:	74 54                	je     8d8 <malloc+0xd8>
  hp->s.size = nu;
 884:	89 58 04             	mov    %ebx,0x4(%eax)
  free((void*)(hp + 1));
 887:	83 ec 0c             	sub    $0xc,%esp
 88a:	83 c0 08             	add    $0x8,%eax
 88d:	50                   	push   %eax
 88e:	e8 cd fe ff ff       	call   760 <free>
  return freep;
 893:	a1 b8 0d 00 00       	mov    0xdb8,%eax
      if((p = morecore(nunits)) == 0)
 898:	83 c4 10             	add    $0x10,%esp
 89b:	85 c0                	test   %eax,%eax
 89d:	75 c1                	jne    860 <malloc+0x60>
 89f:	8b 5d f4             	mov    -0xc(%ebp),%ebx
 8a2:	8b 75 f8             	mov    -0x8(%ebp),%esi
 8a5:	eb 26                	jmp    8cd <malloc+0xcd>
 8a7:	90                   	nop
 8a8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 8af:	00 
 8b0:	8b 5d f4             	mov    -0xc(%ebp),%ebx
 8b3:	8b 75 f8             	mov    -0x8(%ebp),%esi
      if(p->s.size == nunits)
 8b6:	39 cf                	cmp    %ecx,%edi
 8b8:	74 66                	je     920 <malloc+0x120>
        p->s.size -= nunits;
 8ba:	29 f9                	sub    %edi,%ecx
 8bc:	89 4a 04             	mov    %ecx,0x4(%edx)
        p += p->s.size;
 8bf:	8d 14 ca             	lea    (%edx,%ecx,8),%edx
        p->s.size = nunits;
 8c2:	89 7a 04             	mov    %edi,0x4(%edx)
      freep = prevp;
 8c5:	a3 b8 0d 00 00       	mov    %eax,0xdb8
      return (void*)(p + 1);
 8ca:	8d 42 08             	lea    0x8(%edx),%eax
        return 0;
  }
}
 8cd:	8b 7d fc             	mov    -0x4(%ebp),%edi
 8d0:	c9                   	leave
 8d1:	c3                   	ret
 8d2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
        return 0;
 8d8:	8b 5d f4             	mov    -0xc(%ebp),%ebx
 8db:	8b 75 f8             	mov    -0x8(%ebp),%esi
 8de:	31 c0                	xor    %eax,%eax
}
 8e0:	8b 7d fc             	mov    -0x4(%ebp),%edi
 8e3:	c9                   	leave
 8e4:	c3                   	ret
 8e5:	8d 76 00             	lea    0x0(%esi),%esi
 8e8:	89 5d f4             	mov    %ebx,-0xc(%ebp)
    base.s.size = 0;
 8eb:	ba bc 0d 00 00       	mov    $0xdbc,%edx
 8f0:	89 75 f8             	mov    %esi,-0x8(%ebp)
    base.s.ptr = freep = prevp = &base;
 8f3:	c7 05 b8 0d 00 00 bc 	movl   $0xdbc,0xdb8
 8fa:	0d 00 00 
 8fd:	c7 05 bc 0d 00 00 bc 	movl   $0xdbc,0xdbc
 904:	0d 00 00 
    base.s.size = 0;
 907:	c7 05 c0 0d 00 00 00 	movl   $0x0,0xdc0
 90e:	00 00 00 
    if(p->s.size >= nunits){
 911:	e9 1f ff ff ff       	jmp    835 <malloc+0x35>
 916:	66 90                	xchg   %ax,%ax
 918:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 91f:	00 
        prevp->s.ptr = p->s.ptr;
 920:	8b 0a                	mov    (%edx),%ecx
 922:	89 08                	mov    %ecx,(%eax)
 924:	eb 9f                	jmp    8c5 <malloc+0xc5>
