#include "types.h"
#include "stat.h"
#include "user.h"

void cpu_task(void)
{
    volatile int x = 0;
    for (int i = 0; i < 5000000; i++)
    {
        x += (i * 89);
    }
    (void)x;
}

int main(void)
{
    int pid;
    int burst_time[4] = {100, 200, 40, 45};
    int n = 4;
    for (int i = 0; i < n; i++)
    {
        pid = fork();
        if(pid < 0){
            printf(1,"Fork failed\n");
            exit();
        }
        else if(pid == 0){
            int val = getpid();
            printf(1,"Child %d with pid %d started\n",i+1,val);
            cpu_task();
            printf(1,"Child %d with pid %d completed!\n",i+1,val);
            exit();
        }
        set_burst(pid,burst_time[i]);

    }
    for(int i = 0;i<n;i++){
        wait();

    }
    printf(1,"Finished \n");
    exit();
}