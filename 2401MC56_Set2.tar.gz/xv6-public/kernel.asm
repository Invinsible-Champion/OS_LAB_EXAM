
kernel:     file format elf32-i386


Disassembly of section .text:

80100000 <multiboot_header>:
80100000:	02 b0 ad 1b 00 00    	add    0x1bad(%eax),%dh
80100006:	00 00                	add    %al,(%eax)
80100008:	fe 4f 52             	decb   0x52(%edi)
8010000b:	e4                   	.byte 0xe4

8010000c <entry>:

# Entering xv6 on boot processor, with paging off.
.globl entry
entry:
  # Turn on page size extension for 4Mbyte pages
  movl    %cr4, %eax
8010000c:	0f 20 e0             	mov    %cr4,%eax
  orl     $(CR4_PSE), %eax
8010000f:	83 c8 10             	or     $0x10,%eax
  movl    %eax, %cr4
80100012:	0f 22 e0             	mov    %eax,%cr4
  # Set page directory
  movl    $(V2P_WO(entrypgdir)), %eax
80100015:	b8 00 a0 10 00       	mov    $0x10a000,%eax
  movl    %eax, %cr3
8010001a:	0f 22 d8             	mov    %eax,%cr3
  # Turn on paging.
  movl    %cr0, %eax
8010001d:	0f 20 c0             	mov    %cr0,%eax
  orl     $(CR0_PG|CR0_WP), %eax
80100020:	0d 00 00 01 80       	or     $0x80010000,%eax
  movl    %eax, %cr0
80100025:	0f 22 c0             	mov    %eax,%cr0

  # Set up the stack pointer.
  movl $(stack + KSTACKSIZE), %esp
80100028:	bc f0 65 11 80       	mov    $0x801165f0,%esp

  # Jump to main(), and switch to executing at
  # high addresses. The indirect call is needed because
  # the assembler produces a PC-relative instruction
  # for a direct jump.
  mov $main, %eax
8010002d:	b8 30 32 10 80       	mov    $0x80103230,%eax
  jmp *%eax
80100032:	ff e0                	jmp    *%eax
80100034:	66 90                	xchg   %ax,%ax
80100036:	66 90                	xchg   %ax,%ax
80100038:	66 90                	xchg   %ax,%ax
8010003a:	66 90                	xchg   %ax,%ax
8010003c:	66 90                	xchg   %ax,%ax
8010003e:	66 90                	xchg   %ax,%ax

80100040 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
80100040:	55                   	push   %ebp
80100041:	89 e5                	mov    %esp,%ebp
80100043:	53                   	push   %ebx

//PAGEBREAK!
  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
  bcache.head.next = &bcache.head;
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
80100044:	bb 74 b5 10 80       	mov    $0x8010b574,%ebx
{
80100049:	83 ec 0c             	sub    $0xc,%esp
  initlock(&bcache.lock, "bcache");
8010004c:	68 40 79 10 80       	push   $0x80107940
80100051:	68 40 b5 10 80       	push   $0x8010b540
80100056:	e8 c5 46 00 00       	call   80104720 <initlock>
  bcache.head.next = &bcache.head;
8010005b:	83 c4 10             	add    $0x10,%esp
8010005e:	b8 3c fc 10 80       	mov    $0x8010fc3c,%eax
  bcache.head.prev = &bcache.head;
80100063:	c7 05 8c fc 10 80 3c 	movl   $0x8010fc3c,0x8010fc8c
8010006a:	fc 10 80 
  bcache.head.next = &bcache.head;
8010006d:	c7 05 90 fc 10 80 3c 	movl   $0x8010fc3c,0x8010fc90
80100074:	fc 10 80 
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
80100077:	eb 0d                	jmp    80100086 <binit+0x46>
80100079:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80100080:	81 c3 5c 02 00 00    	add    $0x25c,%ebx
    b->next = bcache.head.next;
80100086:	89 43 54             	mov    %eax,0x54(%ebx)
    b->prev = &bcache.head;
    initsleeplock(&b->lock, "buffer");
80100089:	83 ec 08             	sub    $0x8,%esp
8010008c:	8d 43 0c             	lea    0xc(%ebx),%eax
    b->prev = &bcache.head;
8010008f:	c7 43 50 3c fc 10 80 	movl   $0x8010fc3c,0x50(%ebx)
    initsleeplock(&b->lock, "buffer");
80100096:	68 47 79 10 80       	push   $0x80107947
8010009b:	50                   	push   %eax
8010009c:	e8 4f 45 00 00       	call   801045f0 <initsleeplock>
    bcache.head.next->prev = b;
801000a1:	a1 90 fc 10 80       	mov    0x8010fc90,%eax
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
801000a6:	83 c4 10             	add    $0x10,%esp
    bcache.head.next->prev = b;
801000a9:	89 58 50             	mov    %ebx,0x50(%eax)
    bcache.head.next = b;
801000ac:	89 d8                	mov    %ebx,%eax
801000ae:	89 1d 90 fc 10 80    	mov    %ebx,0x8010fc90
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
801000b4:	81 fb e0 f9 10 80    	cmp    $0x8010f9e0,%ebx
801000ba:	75 c4                	jne    80100080 <binit+0x40>
  }
}
801000bc:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801000bf:	c9                   	leave
801000c0:	c3                   	ret
801000c1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
801000c8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801000cf:	00 

801000d0 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
801000d0:	55                   	push   %ebp
801000d1:	89 e5                	mov    %esp,%ebp
801000d3:	57                   	push   %edi
801000d4:	56                   	push   %esi
801000d5:	53                   	push   %ebx
801000d6:	83 ec 18             	sub    $0x18,%esp
801000d9:	8b 75 08             	mov    0x8(%ebp),%esi
801000dc:	8b 7d 0c             	mov    0xc(%ebp),%edi
  acquire(&bcache.lock);
801000df:	68 40 b5 10 80       	push   $0x8010b540
801000e4:	e8 57 48 00 00       	call   80104940 <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
801000e9:	8b 1d 90 fc 10 80    	mov    0x8010fc90,%ebx
801000ef:	83 c4 10             	add    $0x10,%esp
801000f2:	81 fb 3c fc 10 80    	cmp    $0x8010fc3c,%ebx
801000f8:	75 11                	jne    8010010b <bread+0x3b>
801000fa:	eb 24                	jmp    80100120 <bread+0x50>
801000fc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80100100:	8b 5b 54             	mov    0x54(%ebx),%ebx
80100103:	81 fb 3c fc 10 80    	cmp    $0x8010fc3c,%ebx
80100109:	74 15                	je     80100120 <bread+0x50>
    if(b->dev == dev && b->blockno == blockno){
8010010b:	3b 73 04             	cmp    0x4(%ebx),%esi
8010010e:	75 f0                	jne    80100100 <bread+0x30>
80100110:	3b 7b 08             	cmp    0x8(%ebx),%edi
80100113:	75 eb                	jne    80100100 <bread+0x30>
      b->refcnt++;
80100115:	83 43 4c 01          	addl   $0x1,0x4c(%ebx)
      release(&bcache.lock);
80100119:	eb 4f                	jmp    8010016a <bread+0x9a>
8010011b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
80100120:	8b 1d 8c fc 10 80    	mov    0x8010fc8c,%ebx
80100126:	81 fb 3c fc 10 80    	cmp    $0x8010fc3c,%ebx
8010012c:	75 1d                	jne    8010014b <bread+0x7b>
8010012e:	eb 7e                	jmp    801001ae <bread+0xde>
80100130:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80100137:	00 
80100138:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010013f:	00 
80100140:	8b 5b 50             	mov    0x50(%ebx),%ebx
80100143:	81 fb 3c fc 10 80    	cmp    $0x8010fc3c,%ebx
80100149:	74 63                	je     801001ae <bread+0xde>
    if(b->refcnt == 0 && (b->flags & B_DIRTY) == 0) {
8010014b:	8b 43 4c             	mov    0x4c(%ebx),%eax
8010014e:	85 c0                	test   %eax,%eax
80100150:	75 ee                	jne    80100140 <bread+0x70>
80100152:	f6 03 04             	testb  $0x4,(%ebx)
80100155:	75 e9                	jne    80100140 <bread+0x70>
      b->dev = dev;
80100157:	89 73 04             	mov    %esi,0x4(%ebx)
      b->blockno = blockno;
8010015a:	89 7b 08             	mov    %edi,0x8(%ebx)
      b->flags = 0;
8010015d:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
      b->refcnt = 1;
80100163:	c7 43 4c 01 00 00 00 	movl   $0x1,0x4c(%ebx)
      release(&bcache.lock);
8010016a:	83 ec 0c             	sub    $0xc,%esp
8010016d:	68 40 b5 10 80       	push   $0x8010b540
80100172:	e8 69 47 00 00       	call   801048e0 <release>
      acquiresleep(&b->lock);
80100177:	8d 43 0c             	lea    0xc(%ebx),%eax
8010017a:	89 04 24             	mov    %eax,(%esp)
8010017d:	e8 ae 44 00 00       	call   80104630 <acquiresleep>
      return b;
80100182:	83 c4 10             	add    $0x10,%esp
  struct buf *b;

  b = bget(dev, blockno);
  if((b->flags & B_VALID) == 0) {
80100185:	f6 03 02             	testb  $0x2,(%ebx)
80100188:	74 0e                	je     80100198 <bread+0xc8>
    iderw(b);
  }
  return b;
}
8010018a:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010018d:	89 d8                	mov    %ebx,%eax
8010018f:	5b                   	pop    %ebx
80100190:	5e                   	pop    %esi
80100191:	5f                   	pop    %edi
80100192:	5d                   	pop    %ebp
80100193:	c3                   	ret
80100194:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    iderw(b);
80100198:	83 ec 0c             	sub    $0xc,%esp
8010019b:	53                   	push   %ebx
8010019c:	e8 8f 22 00 00       	call   80102430 <iderw>
801001a1:	83 c4 10             	add    $0x10,%esp
}
801001a4:	8d 65 f4             	lea    -0xc(%ebp),%esp
801001a7:	89 d8                	mov    %ebx,%eax
801001a9:	5b                   	pop    %ebx
801001aa:	5e                   	pop    %esi
801001ab:	5f                   	pop    %edi
801001ac:	5d                   	pop    %ebp
801001ad:	c3                   	ret
  panic("bget: no buffers");
801001ae:	83 ec 0c             	sub    $0xc,%esp
801001b1:	68 4e 79 10 80       	push   $0x8010794e
801001b6:	e8 e5 01 00 00       	call   801003a0 <panic>
801001bb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

801001c0 <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
801001c0:	55                   	push   %ebp
801001c1:	89 e5                	mov    %esp,%ebp
801001c3:	53                   	push   %ebx
801001c4:	83 ec 10             	sub    $0x10,%esp
801001c7:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(!holdingsleep(&b->lock))
801001ca:	8d 43 0c             	lea    0xc(%ebx),%eax
801001cd:	50                   	push   %eax
801001ce:	e8 fd 44 00 00       	call   801046d0 <holdingsleep>
801001d3:	83 c4 10             	add    $0x10,%esp
801001d6:	85 c0                	test   %eax,%eax
801001d8:	74 0f                	je     801001e9 <bwrite+0x29>
    panic("bwrite");
  b->flags |= B_DIRTY;
801001da:	83 0b 04             	orl    $0x4,(%ebx)
  iderw(b);
801001dd:	89 5d 08             	mov    %ebx,0x8(%ebp)
}
801001e0:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801001e3:	c9                   	leave
  iderw(b);
801001e4:	e9 47 22 00 00       	jmp    80102430 <iderw>
    panic("bwrite");
801001e9:	83 ec 0c             	sub    $0xc,%esp
801001ec:	68 5f 79 10 80       	push   $0x8010795f
801001f1:	e8 aa 01 00 00       	call   801003a0 <panic>
801001f6:	66 90                	xchg   %ax,%ax
801001f8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801001ff:	00 

80100200 <brelse>:

// Release a locked buffer.
// Move to the head of the MRU list.
void
brelse(struct buf *b)
{
80100200:	55                   	push   %ebp
80100201:	89 e5                	mov    %esp,%ebp
80100203:	56                   	push   %esi
80100204:	53                   	push   %ebx
80100205:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(!holdingsleep(&b->lock))
80100208:	8d 73 0c             	lea    0xc(%ebx),%esi
8010020b:	83 ec 0c             	sub    $0xc,%esp
8010020e:	56                   	push   %esi
8010020f:	e8 bc 44 00 00       	call   801046d0 <holdingsleep>
80100214:	83 c4 10             	add    $0x10,%esp
80100217:	85 c0                	test   %eax,%eax
80100219:	74 63                	je     8010027e <brelse+0x7e>
    panic("brelse");

  releasesleep(&b->lock);
8010021b:	83 ec 0c             	sub    $0xc,%esp
8010021e:	56                   	push   %esi
8010021f:	e8 6c 44 00 00       	call   80104690 <releasesleep>

  acquire(&bcache.lock);
80100224:	c7 04 24 40 b5 10 80 	movl   $0x8010b540,(%esp)
8010022b:	e8 10 47 00 00       	call   80104940 <acquire>
  b->refcnt--;
80100230:	8b 43 4c             	mov    0x4c(%ebx),%eax
  if (b->refcnt == 0) {
80100233:	83 c4 10             	add    $0x10,%esp
  b->refcnt--;
80100236:	83 e8 01             	sub    $0x1,%eax
80100239:	89 43 4c             	mov    %eax,0x4c(%ebx)
  if (b->refcnt == 0) {
8010023c:	85 c0                	test   %eax,%eax
8010023e:	75 2c                	jne    8010026c <brelse+0x6c>
    // no one is waiting for it.
    b->next->prev = b->prev;
80100240:	8b 53 54             	mov    0x54(%ebx),%edx
80100243:	8b 43 50             	mov    0x50(%ebx),%eax
80100246:	89 42 50             	mov    %eax,0x50(%edx)
    b->prev->next = b->next;
80100249:	8b 53 54             	mov    0x54(%ebx),%edx
8010024c:	89 50 54             	mov    %edx,0x54(%eax)
    b->next = bcache.head.next;
8010024f:	a1 90 fc 10 80       	mov    0x8010fc90,%eax
    b->prev = &bcache.head;
80100254:	c7 43 50 3c fc 10 80 	movl   $0x8010fc3c,0x50(%ebx)
    b->next = bcache.head.next;
8010025b:	89 43 54             	mov    %eax,0x54(%ebx)
    bcache.head.next->prev = b;
8010025e:	a1 90 fc 10 80       	mov    0x8010fc90,%eax
80100263:	89 58 50             	mov    %ebx,0x50(%eax)
    bcache.head.next = b;
80100266:	89 1d 90 fc 10 80    	mov    %ebx,0x8010fc90
  }
  
  release(&bcache.lock);
8010026c:	c7 45 08 40 b5 10 80 	movl   $0x8010b540,0x8(%ebp)
}
80100273:	8d 65 f8             	lea    -0x8(%ebp),%esp
80100276:	5b                   	pop    %ebx
80100277:	5e                   	pop    %esi
80100278:	5d                   	pop    %ebp
  release(&bcache.lock);
80100279:	e9 62 46 00 00       	jmp    801048e0 <release>
    panic("brelse");
8010027e:	83 ec 0c             	sub    $0xc,%esp
80100281:	68 66 79 10 80       	push   $0x80107966
80100286:	e8 15 01 00 00       	call   801003a0 <panic>
8010028b:	66 90                	xchg   %ax,%ax
8010028d:	66 90                	xchg   %ax,%ax
8010028f:	66 90                	xchg   %ax,%ax
80100291:	66 90                	xchg   %ax,%ax
80100293:	66 90                	xchg   %ax,%ax
80100295:	66 90                	xchg   %ax,%ax
80100297:	66 90                	xchg   %ax,%ax
80100299:	66 90                	xchg   %ax,%ax
8010029b:	66 90                	xchg   %ax,%ax
8010029d:	66 90                	xchg   %ax,%ax
8010029f:	90                   	nop

801002a0 <consoleread>:
  }
}

int
consoleread(struct inode *ip, char *dst, int n)
{
801002a0:	55                   	push   %ebp
801002a1:	89 e5                	mov    %esp,%ebp
801002a3:	57                   	push   %edi
801002a4:	56                   	push   %esi
801002a5:	53                   	push   %ebx
801002a6:	83 ec 18             	sub    $0x18,%esp
801002a9:	8b 5d 10             	mov    0x10(%ebp),%ebx
801002ac:	8b 75 0c             	mov    0xc(%ebp),%esi
  uint target;
  int c;

  iunlock(ip);
801002af:	ff 75 08             	push   0x8(%ebp)
  target = n;
801002b2:	89 df                	mov    %ebx,%edi
  iunlock(ip);
801002b4:	e8 87 16 00 00       	call   80101940 <iunlock>
  acquire(&cons.lock);
801002b9:	c7 04 24 40 ff 10 80 	movl   $0x8010ff40,(%esp)
801002c0:	e8 7b 46 00 00       	call   80104940 <acquire>
  while(n > 0){
801002c5:	83 c4 10             	add    $0x10,%esp
801002c8:	85 db                	test   %ebx,%ebx
801002ca:	0f 8e 94 00 00 00    	jle    80100364 <consoleread+0xc4>
    while(input.r == input.w){
801002d0:	a1 20 ff 10 80       	mov    0x8010ff20,%eax
801002d5:	39 05 24 ff 10 80    	cmp    %eax,0x8010ff24
801002db:	74 25                	je     80100302 <consoleread+0x62>
801002dd:	eb 59                	jmp    80100338 <consoleread+0x98>
801002df:	90                   	nop
      if(myproc()->killed){
        release(&cons.lock);
        ilock(ip);
        return -1;
      }
      sleep(&input.r, &cons.lock);
801002e0:	83 ec 08             	sub    $0x8,%esp
801002e3:	68 40 ff 10 80       	push   $0x8010ff40
801002e8:	68 20 ff 10 80       	push   $0x8010ff20
801002ed:	e8 1e 40 00 00       	call   80104310 <sleep>
    while(input.r == input.w){
801002f2:	a1 20 ff 10 80       	mov    0x8010ff20,%eax
801002f7:	83 c4 10             	add    $0x10,%esp
801002fa:	3b 05 24 ff 10 80    	cmp    0x8010ff24,%eax
80100300:	75 36                	jne    80100338 <consoleread+0x98>
      if(myproc()->killed){
80100302:	e8 99 38 00 00       	call   80103ba0 <myproc>
80100307:	8b 48 24             	mov    0x24(%eax),%ecx
8010030a:	85 c9                	test   %ecx,%ecx
8010030c:	74 d2                	je     801002e0 <consoleread+0x40>
        release(&cons.lock);
8010030e:	83 ec 0c             	sub    $0xc,%esp
80100311:	68 40 ff 10 80       	push   $0x8010ff40
80100316:	e8 c5 45 00 00       	call   801048e0 <release>
        ilock(ip);
8010031b:	5a                   	pop    %edx
8010031c:	ff 75 08             	push   0x8(%ebp)
8010031f:	e8 3c 15 00 00       	call   80101860 <ilock>
        return -1;
80100324:	83 c4 10             	add    $0x10,%esp
  }
  release(&cons.lock);
  ilock(ip);

  return target - n;
}
80100327:	8d 65 f4             	lea    -0xc(%ebp),%esp
        return -1;
8010032a:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
8010032f:	5b                   	pop    %ebx
80100330:	5e                   	pop    %esi
80100331:	5f                   	pop    %edi
80100332:	5d                   	pop    %ebp
80100333:	c3                   	ret
80100334:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    c = input.buf[input.r++ % INPUT_BUF];
80100338:	8d 50 01             	lea    0x1(%eax),%edx
8010033b:	89 15 20 ff 10 80    	mov    %edx,0x8010ff20
80100341:	89 c2                	mov    %eax,%edx
80100343:	83 e2 7f             	and    $0x7f,%edx
80100346:	0f be 8a a0 fe 10 80 	movsbl -0x7fef0160(%edx),%ecx
    if(c == C('D')){  // EOF
8010034d:	80 f9 04             	cmp    $0x4,%cl
80100350:	74 37                	je     80100389 <consoleread+0xe9>
    *dst++ = c;
80100352:	83 c6 01             	add    $0x1,%esi
    --n;
80100355:	83 eb 01             	sub    $0x1,%ebx
    *dst++ = c;
80100358:	88 4e ff             	mov    %cl,-0x1(%esi)
    if(c == '\n')
8010035b:	83 f9 0a             	cmp    $0xa,%ecx
8010035e:	0f 85 64 ff ff ff    	jne    801002c8 <consoleread+0x28>
  release(&cons.lock);
80100364:	83 ec 0c             	sub    $0xc,%esp
80100367:	68 40 ff 10 80       	push   $0x8010ff40
8010036c:	e8 6f 45 00 00       	call   801048e0 <release>
  ilock(ip);
80100371:	58                   	pop    %eax
80100372:	ff 75 08             	push   0x8(%ebp)
80100375:	e8 e6 14 00 00       	call   80101860 <ilock>
  return target - n;
8010037a:	89 f8                	mov    %edi,%eax
8010037c:	83 c4 10             	add    $0x10,%esp
}
8010037f:	8d 65 f4             	lea    -0xc(%ebp),%esp
  return target - n;
80100382:	29 d8                	sub    %ebx,%eax
}
80100384:	5b                   	pop    %ebx
80100385:	5e                   	pop    %esi
80100386:	5f                   	pop    %edi
80100387:	5d                   	pop    %ebp
80100388:	c3                   	ret
      if(n < target){
80100389:	39 fb                	cmp    %edi,%ebx
8010038b:	73 d7                	jae    80100364 <consoleread+0xc4>
        input.r--;
8010038d:	a3 20 ff 10 80       	mov    %eax,0x8010ff20
80100392:	eb d0                	jmp    80100364 <consoleread+0xc4>
80100394:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80100398:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010039f:	00 

801003a0 <panic>:
{
801003a0:	55                   	push   %ebp
801003a1:	89 e5                	mov    %esp,%ebp
801003a3:	53                   	push   %ebx
801003a4:	83 ec 34             	sub    $0x34,%esp
}

static inline void
cli(void)
{
  asm volatile("cli");
801003a7:	fa                   	cli
  cons.locking = 0;
801003a8:	c7 05 74 ff 10 80 00 	movl   $0x0,0x8010ff74
801003af:	00 00 00 
  getcallerpcs(&s, pcs);
801003b2:	8d 5d d0             	lea    -0x30(%ebp),%ebx
  cprintf("lapicid %d: panic: ", lapicid());
801003b5:	e8 b6 26 00 00       	call   80102a70 <lapicid>
801003ba:	83 ec 08             	sub    $0x8,%esp
801003bd:	50                   	push   %eax
801003be:	68 6d 79 10 80       	push   $0x8010796d
801003c3:	e8 28 03 00 00       	call   801006f0 <cprintf>
  cprintf(s);
801003c8:	58                   	pop    %eax
801003c9:	ff 75 08             	push   0x8(%ebp)
801003cc:	e8 1f 03 00 00       	call   801006f0 <cprintf>
  cprintf("\n");
801003d1:	c7 04 24 ef 7d 10 80 	movl   $0x80107def,(%esp)
801003d8:	e8 13 03 00 00       	call   801006f0 <cprintf>
  getcallerpcs(&s, pcs);
801003dd:	8d 45 08             	lea    0x8(%ebp),%eax
801003e0:	5a                   	pop    %edx
801003e1:	59                   	pop    %ecx
801003e2:	53                   	push   %ebx
801003e3:	50                   	push   %eax
801003e4:	e8 57 43 00 00       	call   80104740 <getcallerpcs>
  for(i=0; i<10; i++)
801003e9:	83 c4 10             	add    $0x10,%esp
801003ec:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    cprintf(" %p", pcs[i]);
801003f0:	83 ec 08             	sub    $0x8,%esp
801003f3:	ff 33                	push   (%ebx)
  for(i=0; i<10; i++)
801003f5:	83 c3 04             	add    $0x4,%ebx
    cprintf(" %p", pcs[i]);
801003f8:	68 81 79 10 80       	push   $0x80107981
801003fd:	e8 ee 02 00 00       	call   801006f0 <cprintf>
  for(i=0; i<10; i++)
80100402:	8d 45 f8             	lea    -0x8(%ebp),%eax
80100405:	83 c4 10             	add    $0x10,%esp
80100408:	39 c3                	cmp    %eax,%ebx
8010040a:	75 e4                	jne    801003f0 <panic+0x50>
  panicked = 1; // freeze other CPU
8010040c:	c7 05 78 ff 10 80 01 	movl   $0x1,0x8010ff78
80100413:	00 00 00 
80100416:	66 90                	xchg   %ax,%ax
80100418:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010041f:	00 
  for(;;)
80100420:	eb fe                	jmp    80100420 <panic+0x80>
80100422:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80100428:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010042f:	00 

80100430 <consputc.part.0>:
consputc(int c)
80100430:	55                   	push   %ebp
80100431:	89 e5                	mov    %esp,%ebp
80100433:	57                   	push   %edi
80100434:	56                   	push   %esi
80100435:	53                   	push   %ebx
80100436:	83 ec 0c             	sub    $0xc,%esp
  if(c == BACKSPACE){
80100439:	3d 00 01 00 00       	cmp    $0x100,%eax
8010043e:	0f 84 cc 00 00 00    	je     80100510 <consputc.part.0+0xe0>
    uartputc(c);
80100444:	83 ec 0c             	sub    $0xc,%esp
80100447:	89 c3                	mov    %eax,%ebx
80100449:	50                   	push   %eax
8010044a:	e8 f1 5e 00 00       	call   80106340 <uartputc>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
8010044f:	b8 0e 00 00 00       	mov    $0xe,%eax
80100454:	ba d4 03 00 00       	mov    $0x3d4,%edx
80100459:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
8010045a:	ba d5 03 00 00       	mov    $0x3d5,%edx
8010045f:	ec                   	in     (%dx),%al
  pos = inb(CRTPORT+1) << 8;
80100460:	0f b6 c8             	movzbl %al,%ecx
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80100463:	ba d4 03 00 00       	mov    $0x3d4,%edx
80100468:	b8 0f 00 00 00       	mov    $0xf,%eax
8010046d:	c1 e1 08             	shl    $0x8,%ecx
80100470:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80100471:	ba d5 03 00 00       	mov    $0x3d5,%edx
80100476:	ec                   	in     (%dx),%al
  pos |= inb(CRTPORT+1);
80100477:	0f b6 c0             	movzbl %al,%eax
  if(c == '\n')
8010047a:	83 c4 10             	add    $0x10,%esp
  pos |= inb(CRTPORT+1);
8010047d:	09 c8                	or     %ecx,%eax
  if(c == '\n')
8010047f:	83 fb 0a             	cmp    $0xa,%ebx
80100482:	75 74                	jne    801004f8 <consputc.part.0+0xc8>
    pos += 80 - pos%80;
80100484:	ba cd cc cc cc       	mov    $0xcccccccd,%edx
80100489:	f7 e2                	mul    %edx
8010048b:	c1 ea 06             	shr    $0x6,%edx
8010048e:	8d 04 92             	lea    (%edx,%edx,4),%eax
80100491:	c1 e0 04             	shl    $0x4,%eax
80100494:	8d 78 50             	lea    0x50(%eax),%edi
  if(pos < 0 || pos > 25*80)
80100497:	81 ff d0 07 00 00    	cmp    $0x7d0,%edi
8010049d:	0f 8f 23 01 00 00    	jg     801005c6 <consputc.part.0+0x196>
  if((pos/80) >= 24){  // Scroll up.
801004a3:	81 ff 7f 07 00 00    	cmp    $0x77f,%edi
801004a9:	0f 8f c1 00 00 00    	jg     80100570 <consputc.part.0+0x140>
  outb(CRTPORT+1, pos>>8);
801004af:	89 f8                	mov    %edi,%eax
  outb(CRTPORT+1, pos);
801004b1:	89 fb                	mov    %edi,%ebx
  crt[pos] = ' ' | 0x0700;
801004b3:	8d bc 3f 00 80 0b 80 	lea    -0x7ff48000(%edi,%edi,1),%edi
  outb(CRTPORT+1, pos>>8);
801004ba:	0f b6 f4             	movzbl %ah,%esi
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801004bd:	b8 0e 00 00 00       	mov    $0xe,%eax
801004c2:	ba d4 03 00 00       	mov    $0x3d4,%edx
801004c7:	ee                   	out    %al,(%dx)
801004c8:	ba d5 03 00 00       	mov    $0x3d5,%edx
801004cd:	89 f0                	mov    %esi,%eax
801004cf:	ee                   	out    %al,(%dx)
801004d0:	b8 0f 00 00 00       	mov    $0xf,%eax
801004d5:	ba d4 03 00 00       	mov    $0x3d4,%edx
801004da:	ee                   	out    %al,(%dx)
801004db:	ba d5 03 00 00       	mov    $0x3d5,%edx
801004e0:	89 d8                	mov    %ebx,%eax
801004e2:	ee                   	out    %al,(%dx)
  crt[pos] = ' ' | 0x0700;
801004e3:	b8 20 07 00 00       	mov    $0x720,%eax
801004e8:	66 89 07             	mov    %ax,(%edi)
}
801004eb:	8d 65 f4             	lea    -0xc(%ebp),%esp
801004ee:	5b                   	pop    %ebx
801004ef:	5e                   	pop    %esi
801004f0:	5f                   	pop    %edi
801004f1:	5d                   	pop    %ebp
801004f2:	c3                   	ret
801004f3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    crt[pos++] = (c&0xff) | 0x0700;  // black on white
801004f8:	0f b6 db             	movzbl %bl,%ebx
801004fb:	8d 78 01             	lea    0x1(%eax),%edi
801004fe:	80 cf 07             	or     $0x7,%bh
80100501:	66 89 9c 00 00 80 0b 	mov    %bx,-0x7ff48000(%eax,%eax,1)
80100508:	80 
80100509:	eb 8c                	jmp    80100497 <consputc.part.0+0x67>
8010050b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    uartputc('\b'); uartputc(' '); uartputc('\b');
80100510:	83 ec 0c             	sub    $0xc,%esp
80100513:	6a 08                	push   $0x8
80100515:	e8 26 5e 00 00       	call   80106340 <uartputc>
8010051a:	c7 04 24 20 00 00 00 	movl   $0x20,(%esp)
80100521:	e8 1a 5e 00 00       	call   80106340 <uartputc>
80100526:	c7 04 24 08 00 00 00 	movl   $0x8,(%esp)
8010052d:	e8 0e 5e 00 00       	call   80106340 <uartputc>
80100532:	b8 0e 00 00 00       	mov    $0xe,%eax
80100537:	ba d4 03 00 00       	mov    $0x3d4,%edx
8010053c:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
8010053d:	ba d5 03 00 00       	mov    $0x3d5,%edx
80100542:	ec                   	in     (%dx),%al
  pos = inb(CRTPORT+1) << 8;
80100543:	0f b6 d8             	movzbl %al,%ebx
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80100546:	ba d4 03 00 00       	mov    $0x3d4,%edx
8010054b:	b8 0f 00 00 00       	mov    $0xf,%eax
80100550:	c1 e3 08             	shl    $0x8,%ebx
80100553:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80100554:	ba d5 03 00 00       	mov    $0x3d5,%edx
80100559:	ec                   	in     (%dx),%al
  pos |= inb(CRTPORT+1);
8010055a:	0f b6 c8             	movzbl %al,%ecx
    if(pos > 0) --pos;
8010055d:	83 c4 10             	add    $0x10,%esp
80100560:	09 d9                	or     %ebx,%ecx
80100562:	74 54                	je     801005b8 <consputc.part.0+0x188>
80100564:	8d 79 ff             	lea    -0x1(%ecx),%edi
80100567:	e9 2b ff ff ff       	jmp    80100497 <consputc.part.0+0x67>
8010056c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    memmove(crt, crt+80, sizeof(crt[0])*23*80);
80100570:	83 ec 04             	sub    $0x4,%esp
    pos -= 80;
80100573:	8d 5f b0             	lea    -0x50(%edi),%ebx
    memset(crt+pos, 0, sizeof(crt[0])*(24*80 - pos));
80100576:	8d bc 3f 60 7f 0b 80 	lea    -0x7ff480a0(%edi,%edi,1),%edi
  outb(CRTPORT+1, pos);
8010057d:	be 07 00 00 00       	mov    $0x7,%esi
    memmove(crt, crt+80, sizeof(crt[0])*23*80);
80100582:	68 60 0e 00 00       	push   $0xe60
80100587:	68 a0 80 0b 80       	push   $0x800b80a0
8010058c:	68 00 80 0b 80       	push   $0x800b8000
80100591:	e8 6a 45 00 00       	call   80104b00 <memmove>
    memset(crt+pos, 0, sizeof(crt[0])*(24*80 - pos));
80100596:	b8 80 07 00 00       	mov    $0x780,%eax
8010059b:	83 c4 0c             	add    $0xc,%esp
8010059e:	29 d8                	sub    %ebx,%eax
801005a0:	01 c0                	add    %eax,%eax
801005a2:	50                   	push   %eax
801005a3:	6a 00                	push   $0x0
801005a5:	57                   	push   %edi
801005a6:	e8 b5 44 00 00       	call   80104a60 <memset>
  outb(CRTPORT+1, pos);
801005ab:	83 c4 10             	add    $0x10,%esp
801005ae:	e9 0a ff ff ff       	jmp    801004bd <consputc.part.0+0x8d>
801005b3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    if(pos > 0) --pos;
801005b8:	bf 00 80 0b 80       	mov    $0x800b8000,%edi
801005bd:	31 db                	xor    %ebx,%ebx
801005bf:	31 f6                	xor    %esi,%esi
801005c1:	e9 f7 fe ff ff       	jmp    801004bd <consputc.part.0+0x8d>
    panic("pos under/overflow");
801005c6:	83 ec 0c             	sub    $0xc,%esp
801005c9:	68 85 79 10 80       	push   $0x80107985
801005ce:	e8 cd fd ff ff       	call   801003a0 <panic>
801005d3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
801005d8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801005df:	00 

801005e0 <consolewrite>:

int
consolewrite(struct inode *ip, char *buf, int n)
{
801005e0:	55                   	push   %ebp
801005e1:	89 e5                	mov    %esp,%ebp
801005e3:	83 ec 24             	sub    $0x24,%esp
  int i;

  iunlock(ip);
801005e6:	ff 75 08             	push   0x8(%ebp)
{
801005e9:	89 75 f8             	mov    %esi,-0x8(%ebp)
801005ec:	8b 75 10             	mov    0x10(%ebp),%esi
  iunlock(ip);
801005ef:	e8 4c 13 00 00       	call   80101940 <iunlock>
  acquire(&cons.lock);
801005f4:	c7 04 24 40 ff 10 80 	movl   $0x8010ff40,(%esp)
801005fb:	e8 40 43 00 00       	call   80104940 <acquire>
  for(i = 0; i < n; i++)
80100600:	83 c4 10             	add    $0x10,%esp
80100603:	85 f6                	test   %esi,%esi
80100605:	7e 30                	jle    80100637 <consolewrite+0x57>
80100607:	89 5d f4             	mov    %ebx,-0xc(%ebp)
8010060a:	8b 5d 0c             	mov    0xc(%ebp),%ebx
8010060d:	89 7d fc             	mov    %edi,-0x4(%ebp)
80100610:	8d 3c 33             	lea    (%ebx,%esi,1),%edi
  if(panicked){
80100613:	8b 15 78 ff 10 80    	mov    0x8010ff78,%edx
80100619:	85 d2                	test   %edx,%edx
8010061b:	74 05                	je     80100622 <consolewrite+0x42>
  asm volatile("cli");
8010061d:	fa                   	cli
8010061e:	66 90                	xchg   %ax,%ax
    for(;;)
80100620:	eb fe                	jmp    80100620 <consolewrite+0x40>
    consputc(buf[i] & 0xff);
80100622:	0f b6 03             	movzbl (%ebx),%eax
  for(i = 0; i < n; i++)
80100625:	83 c3 01             	add    $0x1,%ebx
80100628:	e8 03 fe ff ff       	call   80100430 <consputc.part.0>
8010062d:	39 fb                	cmp    %edi,%ebx
8010062f:	75 e2                	jne    80100613 <consolewrite+0x33>
80100631:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80100634:	8b 7d fc             	mov    -0x4(%ebp),%edi
  release(&cons.lock);
80100637:	83 ec 0c             	sub    $0xc,%esp
8010063a:	68 40 ff 10 80       	push   $0x8010ff40
8010063f:	e8 9c 42 00 00       	call   801048e0 <release>
  ilock(ip);
80100644:	58                   	pop    %eax
80100645:	ff 75 08             	push   0x8(%ebp)
80100648:	e8 13 12 00 00       	call   80101860 <ilock>

  return n;
}
8010064d:	89 f0                	mov    %esi,%eax
8010064f:	8b 75 f8             	mov    -0x8(%ebp),%esi
80100652:	c9                   	leave
80100653:	c3                   	ret
80100654:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80100658:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010065f:	00 

80100660 <printint>:
{
80100660:	55                   	push   %ebp
80100661:	89 e5                	mov    %esp,%ebp
80100663:	57                   	push   %edi
80100664:	56                   	push   %esi
80100665:	53                   	push   %ebx
80100666:	89 d3                	mov    %edx,%ebx
80100668:	83 ec 2c             	sub    $0x2c,%esp
  if(sign && (sign = xx < 0))
8010066b:	85 c0                	test   %eax,%eax
8010066d:	79 05                	jns    80100674 <printint+0x14>
8010066f:	83 e1 01             	and    $0x1,%ecx
80100672:	75 5f                	jne    801006d3 <printint+0x73>
80100674:	c7 45 d4 00 00 00 00 	movl   $0x0,-0x2c(%ebp)
8010067b:	89 c1                	mov    %eax,%ecx
  i = 0;
8010067d:	31 f6                	xor    %esi,%esi
8010067f:	90                   	nop
    buf[i++] = digits[x % base];
80100680:	89 c8                	mov    %ecx,%eax
80100682:	31 d2                	xor    %edx,%edx
80100684:	89 f7                	mov    %esi,%edi
80100686:	f7 f3                	div    %ebx
80100688:	8d 76 01             	lea    0x1(%esi),%esi
  }while((x /= base) != 0);
8010068b:	39 d9                	cmp    %ebx,%ecx
    buf[i++] = digits[x % base];
8010068d:	0f b6 92 40 7e 10 80 	movzbl -0x7fef81c0(%edx),%edx
  }while((x /= base) != 0);
80100694:	89 c1                	mov    %eax,%ecx
    buf[i++] = digits[x % base];
80100696:	88 54 35 d7          	mov    %dl,-0x29(%ebp,%esi,1)
  }while((x /= base) != 0);
8010069a:	73 e4                	jae    80100680 <printint+0x20>
  if(sign)
8010069c:	8b 55 d4             	mov    -0x2c(%ebp),%edx
8010069f:	85 d2                	test   %edx,%edx
801006a1:	74 07                	je     801006aa <printint+0x4a>
    buf[i++] = '-';
801006a3:	c6 44 35 d8 2d       	movb   $0x2d,-0x28(%ebp,%esi,1)
801006a8:	89 f7                	mov    %esi,%edi
  while(--i >= 0)
801006aa:	8d 5d d8             	lea    -0x28(%ebp),%ebx
801006ad:	01 df                	add    %ebx,%edi
  if(panicked){
801006af:	a1 78 ff 10 80       	mov    0x8010ff78,%eax
801006b4:	85 c0                	test   %eax,%eax
801006b6:	74 0a                	je     801006c2 <printint+0x62>
801006b8:	fa                   	cli
801006b9:	90                   	nop
801006ba:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    for(;;)
801006c0:	eb fe                	jmp    801006c0 <printint+0x60>
    consputc(buf[i]);
801006c2:	0f be 07             	movsbl (%edi),%eax
801006c5:	e8 66 fd ff ff       	call   80100430 <consputc.part.0>
  while(--i >= 0)
801006ca:	39 fb                	cmp    %edi,%ebx
801006cc:	74 10                	je     801006de <printint+0x7e>
801006ce:	83 ef 01             	sub    $0x1,%edi
801006d1:	eb dc                	jmp    801006af <printint+0x4f>
  if(sign && (sign = xx < 0))
801006d3:	c7 45 d4 01 00 00 00 	movl   $0x1,-0x2c(%ebp)
    x = -xx;
801006da:	f7 d8                	neg    %eax
801006dc:	eb 9d                	jmp    8010067b <printint+0x1b>
}
801006de:	83 c4 2c             	add    $0x2c,%esp
801006e1:	5b                   	pop    %ebx
801006e2:	5e                   	pop    %esi
801006e3:	5f                   	pop    %edi
801006e4:	5d                   	pop    %ebp
801006e5:	c3                   	ret
801006e6:	66 90                	xchg   %ax,%ax
801006e8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801006ef:	00 

801006f0 <cprintf>:
{
801006f0:	55                   	push   %ebp
801006f1:	89 e5                	mov    %esp,%ebp
801006f3:	83 ec 28             	sub    $0x28,%esp
  locking = cons.locking;
801006f6:	8b 15 74 ff 10 80    	mov    0x8010ff74,%edx
{
801006fc:	89 75 f8             	mov    %esi,-0x8(%ebp)
  if (fmt == 0)
801006ff:	8b 75 08             	mov    0x8(%ebp),%esi
  if(locking)
80100702:	85 d2                	test   %edx,%edx
80100704:	0f 85 26 01 00 00    	jne    80100830 <cprintf+0x140>
  if (fmt == 0)
8010070a:	85 f6                	test   %esi,%esi
8010070c:	0f 84 e6 01 00 00    	je     801008f8 <cprintf+0x208>
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
80100712:	0f b6 06             	movzbl (%esi),%eax
80100715:	85 c0                	test   %eax,%eax
80100717:	74 6b                	je     80100784 <cprintf+0x94>
80100719:	89 55 e4             	mov    %edx,-0x1c(%ebp)
8010071c:	89 5d f4             	mov    %ebx,-0xc(%ebp)
8010071f:	31 db                	xor    %ebx,%ebx
80100721:	89 7d fc             	mov    %edi,-0x4(%ebp)
  argp = (uint*)(void*)(&fmt + 1);
80100724:	8d 7d 0c             	lea    0xc(%ebp),%edi
    if(c != '%'){
80100727:	83 f8 25             	cmp    $0x25,%eax
8010072a:	75 64                	jne    80100790 <cprintf+0xa0>
    c = fmt[++i] & 0xff;
8010072c:	83 c3 01             	add    $0x1,%ebx
8010072f:	0f b6 14 1e          	movzbl (%esi,%ebx,1),%edx
    if(c == 0)
80100733:	85 d2                	test   %edx,%edx
80100735:	74 3c                	je     80100773 <cprintf+0x83>
    switch(c){
80100737:	83 fa 70             	cmp    $0x70,%edx
8010073a:	0f 84 d2 00 00 00    	je     80100812 <cprintf+0x122>
80100740:	0f 8f 92 00 00 00    	jg     801007d8 <cprintf+0xe8>
80100746:	83 fa 25             	cmp    $0x25,%edx
80100749:	74 6c                	je     801007b7 <cprintf+0xc7>
8010074b:	83 fa 64             	cmp    $0x64,%edx
8010074e:	0f 85 92 00 00 00    	jne    801007e6 <cprintf+0xf6>
      printint(*argp++, 10, 1);
80100754:	8b 07                	mov    (%edi),%eax
80100756:	b9 01 00 00 00       	mov    $0x1,%ecx
8010075b:	ba 0a 00 00 00       	mov    $0xa,%edx
80100760:	83 c7 04             	add    $0x4,%edi
80100763:	e8 f8 fe ff ff       	call   80100660 <printint>
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
80100768:	83 c3 01             	add    $0x1,%ebx
8010076b:	0f b6 04 1e          	movzbl (%esi,%ebx,1),%eax
8010076f:	85 c0                	test   %eax,%eax
80100771:	75 b4                	jne    80100727 <cprintf+0x37>
  if(locking)
80100773:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80100776:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80100779:	8b 7d fc             	mov    -0x4(%ebp),%edi
8010077c:	85 c0                	test   %eax,%eax
8010077e:	0f 85 d5 00 00 00    	jne    80100859 <cprintf+0x169>
}
80100784:	8b 75 f8             	mov    -0x8(%ebp),%esi
80100787:	c9                   	leave
80100788:	c3                   	ret
80100789:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  if(panicked){
80100790:	8b 0d 78 ff 10 80    	mov    0x8010ff78,%ecx
80100796:	85 c9                	test   %ecx,%ecx
80100798:	74 16                	je     801007b0 <cprintf+0xc0>
8010079a:	fa                   	cli
8010079b:	90                   	nop
8010079c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    for(;;)
801007a0:	eb fe                	jmp    801007a0 <cprintf+0xb0>
  if(c == BACKSPACE){
801007a2:	8b 45 e0             	mov    -0x20(%ebp),%eax
801007a5:	8d 76 00             	lea    0x0(%esi),%esi
801007a8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801007af:	00 
801007b0:	e8 7b fc ff ff       	call   80100430 <consputc.part.0>
      break;
801007b5:	eb b1                	jmp    80100768 <cprintf+0x78>
  if(panicked){
801007b7:	a1 78 ff 10 80       	mov    0x8010ff78,%eax
801007bc:	85 c0                	test   %eax,%eax
801007be:	0f 84 1e 01 00 00    	je     801008e2 <cprintf+0x1f2>
801007c4:	fa                   	cli
801007c5:	90                   	nop
801007c6:	66 90                	xchg   %ax,%ax
801007c8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801007cf:	00 
    for(;;)
801007d0:	eb fe                	jmp    801007d0 <cprintf+0xe0>
801007d2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    switch(c){
801007d8:	83 fa 73             	cmp    $0x73,%edx
801007db:	0f 84 8d 00 00 00    	je     8010086e <cprintf+0x17e>
801007e1:	83 fa 78             	cmp    $0x78,%edx
801007e4:	74 2c                	je     80100812 <cprintf+0x122>
  if(panicked){
801007e6:	8b 0d 78 ff 10 80    	mov    0x8010ff78,%ecx
801007ec:	85 c9                	test   %ecx,%ecx
801007ee:	0f 85 e7 00 00 00    	jne    801008db <cprintf+0x1eb>
801007f4:	b8 25 00 00 00       	mov    $0x25,%eax
801007f9:	89 55 e0             	mov    %edx,-0x20(%ebp)
  if(c == BACKSPACE){
801007fc:	e8 2f fc ff ff       	call   80100430 <consputc.part.0>
  if(panicked){
80100801:	8b 15 78 ff 10 80    	mov    0x8010ff78,%edx
80100807:	85 d2                	test   %edx,%edx
80100809:	74 97                	je     801007a2 <cprintf+0xb2>
8010080b:	fa                   	cli
8010080c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    for(;;)
80100810:	eb fe                	jmp    80100810 <cprintf+0x120>
      printint(*argp++, 16, 0);
80100812:	8b 07                	mov    (%edi),%eax
80100814:	31 c9                	xor    %ecx,%ecx
80100816:	ba 10 00 00 00       	mov    $0x10,%edx
8010081b:	83 c7 04             	add    $0x4,%edi
8010081e:	e8 3d fe ff ff       	call   80100660 <printint>
      break;
80100823:	e9 40 ff ff ff       	jmp    80100768 <cprintf+0x78>
80100828:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010082f:	00 
    acquire(&cons.lock);
80100830:	83 ec 0c             	sub    $0xc,%esp
80100833:	89 55 e4             	mov    %edx,-0x1c(%ebp)
80100836:	68 40 ff 10 80       	push   $0x8010ff40
8010083b:	e8 00 41 00 00       	call   80104940 <acquire>
  if (fmt == 0)
80100840:	83 c4 10             	add    $0x10,%esp
80100843:	85 f6                	test   %esi,%esi
80100845:	0f 84 ad 00 00 00    	je     801008f8 <cprintf+0x208>
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
8010084b:	0f b6 06             	movzbl (%esi),%eax
8010084e:	8b 55 e4             	mov    -0x1c(%ebp),%edx
80100851:	85 c0                	test   %eax,%eax
80100853:	0f 85 c0 fe ff ff    	jne    80100719 <cprintf+0x29>
    release(&cons.lock);
80100859:	83 ec 0c             	sub    $0xc,%esp
8010085c:	68 40 ff 10 80       	push   $0x8010ff40
80100861:	e8 7a 40 00 00       	call   801048e0 <release>
80100866:	83 c4 10             	add    $0x10,%esp
}
80100869:	e9 16 ff ff ff       	jmp    80100784 <cprintf+0x94>
      if((s = (char*)*argp++) == 0)
8010086e:	8d 57 04             	lea    0x4(%edi),%edx
80100871:	8b 3f                	mov    (%edi),%edi
80100873:	85 ff                	test   %edi,%edi
80100875:	74 2b                	je     801008a2 <cprintf+0x1b2>
      for(; *s; s++)
80100877:	0f be 07             	movsbl (%edi),%eax
8010087a:	84 c0                	test   %al,%al
8010087c:	74 73                	je     801008f1 <cprintf+0x201>
8010087e:	89 5d e0             	mov    %ebx,-0x20(%ebp)
80100881:	89 fb                	mov    %edi,%ebx
80100883:	89 f7                	mov    %esi,%edi
80100885:	89 d6                	mov    %edx,%esi
  if(panicked){
80100887:	8b 15 78 ff 10 80    	mov    0x8010ff78,%edx
8010088d:	85 d2                	test   %edx,%edx
8010088f:	74 2c                	je     801008bd <cprintf+0x1cd>
80100891:	fa                   	cli
80100892:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80100898:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010089f:	00 
    for(;;)
801008a0:	eb fe                	jmp    801008a0 <cprintf+0x1b0>
        s = "(null)";
801008a2:	89 f7                	mov    %esi,%edi
801008a4:	89 d6                	mov    %edx,%esi
  if(panicked){
801008a6:	8b 15 78 ff 10 80    	mov    0x8010ff78,%edx
        s = "(null)";
801008ac:	89 5d e0             	mov    %ebx,-0x20(%ebp)
      if((s = (char*)*argp++) == 0)
801008af:	b8 28 00 00 00       	mov    $0x28,%eax
        s = "(null)";
801008b4:	bb 98 79 10 80       	mov    $0x80107998,%ebx
  if(panicked){
801008b9:	85 d2                	test   %edx,%edx
801008bb:	75 d4                	jne    80100891 <cprintf+0x1a1>
  if(c == BACKSPACE){
801008bd:	e8 6e fb ff ff       	call   80100430 <consputc.part.0>
      for(; *s; s++)
801008c2:	0f be 43 01          	movsbl 0x1(%ebx),%eax
801008c6:	83 c3 01             	add    $0x1,%ebx
801008c9:	84 c0                	test   %al,%al
801008cb:	75 ba                	jne    80100887 <cprintf+0x197>
      if((s = (char*)*argp++) == 0)
801008cd:	89 f2                	mov    %esi,%edx
801008cf:	8b 5d e0             	mov    -0x20(%ebp),%ebx
801008d2:	89 fe                	mov    %edi,%esi
801008d4:	89 d7                	mov    %edx,%edi
801008d6:	e9 8d fe ff ff       	jmp    80100768 <cprintf+0x78>
801008db:	fa                   	cli
801008dc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    for(;;)
801008e0:	eb fe                	jmp    801008e0 <cprintf+0x1f0>
  if(c == BACKSPACE){
801008e2:	b8 25 00 00 00       	mov    $0x25,%eax
801008e7:	e8 44 fb ff ff       	call   80100430 <consputc.part.0>
      break;
801008ec:	e9 77 fe ff ff       	jmp    80100768 <cprintf+0x78>
      if((s = (char*)*argp++) == 0)
801008f1:	89 d7                	mov    %edx,%edi
801008f3:	e9 70 fe ff ff       	jmp    80100768 <cprintf+0x78>
    panic("null fmt");
801008f8:	83 ec 0c             	sub    $0xc,%esp
801008fb:	89 5d f4             	mov    %ebx,-0xc(%ebp)
801008fe:	68 9f 79 10 80       	push   $0x8010799f
80100903:	89 7d fc             	mov    %edi,-0x4(%ebp)
80100906:	e8 95 fa ff ff       	call   801003a0 <panic>
8010090b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80100910 <consoleintr>:
{
80100910:	55                   	push   %ebp
80100911:	89 e5                	mov    %esp,%ebp
80100913:	83 ec 34             	sub    $0x34,%esp
  acquire(&cons.lock);
80100916:	68 40 ff 10 80       	push   $0x8010ff40
{
8010091b:	89 5d f4             	mov    %ebx,-0xc(%ebp)
8010091e:	8b 5d 08             	mov    0x8(%ebp),%ebx
80100921:	89 75 f8             	mov    %esi,-0x8(%ebp)
  int c, doprocdump = 0;
80100924:	31 f6                	xor    %esi,%esi
  acquire(&cons.lock);
80100926:	e8 15 40 00 00       	call   80104940 <acquire>
  while((c = getc()) >= 0){
8010092b:	83 c4 10             	add    $0x10,%esp
8010092e:	ff d3                	call   *%ebx
80100930:	85 c0                	test   %eax,%eax
80100932:	78 20                	js     80100954 <consoleintr+0x44>
    switch(c){
80100934:	83 f8 15             	cmp    $0x15,%eax
80100937:	74 45                	je     8010097e <consoleintr+0x6e>
80100939:	7f 7d                	jg     801009b8 <consoleintr+0xa8>
8010093b:	83 f8 08             	cmp    $0x8,%eax
8010093e:	74 7d                	je     801009bd <consoleintr+0xad>
80100940:	83 f8 10             	cmp    $0x10,%eax
80100943:	0f 85 12 01 00 00    	jne    80100a5b <consoleintr+0x14b>
80100949:	be 01 00 00 00       	mov    $0x1,%esi
  while((c = getc()) >= 0){
8010094e:	ff d3                	call   *%ebx
80100950:	85 c0                	test   %eax,%eax
80100952:	79 e0                	jns    80100934 <consoleintr+0x24>
  release(&cons.lock);
80100954:	83 ec 0c             	sub    $0xc,%esp
80100957:	68 40 ff 10 80       	push   $0x8010ff40
8010095c:	e8 7f 3f 00 00       	call   801048e0 <release>
  if(doprocdump) {
80100961:	83 c4 10             	add    $0x10,%esp
80100964:	85 f6                	test   %esi,%esi
80100966:	0f 85 6c 01 00 00    	jne    80100ad8 <consoleintr+0x1c8>
}
8010096c:	8b 5d f4             	mov    -0xc(%ebp),%ebx
8010096f:	8b 75 f8             	mov    -0x8(%ebp),%esi
80100972:	c9                   	leave
80100973:	c3                   	ret
  if(c == BACKSPACE){
80100974:	b8 00 01 00 00       	mov    $0x100,%eax
80100979:	e8 b2 fa ff ff       	call   80100430 <consputc.part.0>
      while(input.e != input.w &&
8010097e:	a1 28 ff 10 80       	mov    0x8010ff28,%eax
80100983:	3b 05 24 ff 10 80    	cmp    0x8010ff24,%eax
80100989:	74 a3                	je     8010092e <consoleintr+0x1e>
            input.buf[(input.e-1) % INPUT_BUF] != '\n'){
8010098b:	83 e8 01             	sub    $0x1,%eax
8010098e:	89 c2                	mov    %eax,%edx
80100990:	83 e2 7f             	and    $0x7f,%edx
      while(input.e != input.w &&
80100993:	80 ba a0 fe 10 80 0a 	cmpb   $0xa,-0x7fef0160(%edx)
8010099a:	74 92                	je     8010092e <consoleintr+0x1e>
  if(panicked){
8010099c:	8b 15 78 ff 10 80    	mov    0x8010ff78,%edx
        input.e--;
801009a2:	a3 28 ff 10 80       	mov    %eax,0x8010ff28
  if(panicked){
801009a7:	85 d2                	test   %edx,%edx
801009a9:	74 c9                	je     80100974 <consoleintr+0x64>
801009ab:	fa                   	cli
801009ac:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    for(;;)
801009b0:	eb fe                	jmp    801009b0 <consoleintr+0xa0>
801009b2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    switch(c){
801009b8:	83 f8 7f             	cmp    $0x7f,%eax
801009bb:	75 35                	jne    801009f2 <consoleintr+0xe2>
      if(input.e != input.w){
801009bd:	a1 28 ff 10 80       	mov    0x8010ff28,%eax
801009c2:	3b 05 24 ff 10 80    	cmp    0x8010ff24,%eax
801009c8:	0f 84 60 ff ff ff    	je     8010092e <consoleintr+0x1e>
        input.e--;
801009ce:	83 e8 01             	sub    $0x1,%eax
801009d1:	a3 28 ff 10 80       	mov    %eax,0x8010ff28
  if(panicked){
801009d6:	a1 78 ff 10 80       	mov    0x8010ff78,%eax
801009db:	85 c0                	test   %eax,%eax
801009dd:	0f 84 e6 00 00 00    	je     80100ac9 <consoleintr+0x1b9>
801009e3:	fa                   	cli
801009e4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
801009e8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801009ef:	00 
    for(;;)
801009f0:	eb fe                	jmp    801009f0 <consoleintr+0xe0>
      if(c != 0 && input.e-input.r < INPUT_BUF){
801009f2:	8b 15 28 ff 10 80    	mov    0x8010ff28,%edx
801009f8:	89 d1                	mov    %edx,%ecx
801009fa:	2b 0d 20 ff 10 80    	sub    0x8010ff20,%ecx
80100a00:	83 f9 7f             	cmp    $0x7f,%ecx
80100a03:	0f 87 25 ff ff ff    	ja     8010092e <consoleintr+0x1e>
80100a09:	89 7d fc             	mov    %edi,-0x4(%ebp)
  if(panicked){
80100a0c:	8b 3d 78 ff 10 80    	mov    0x8010ff78,%edi
        input.buf[input.e++ % INPUT_BUF] = c;
80100a12:	8d 4a 01             	lea    0x1(%edx),%ecx
80100a15:	83 e2 7f             	and    $0x7f,%edx
80100a18:	89 0d 28 ff 10 80    	mov    %ecx,0x8010ff28
80100a1e:	88 82 a0 fe 10 80    	mov    %al,-0x7fef0160(%edx)
  if(panicked){
80100a24:	85 ff                	test   %edi,%edi
80100a26:	0f 85 b8 00 00 00    	jne    80100ae4 <consoleintr+0x1d4>
  if(c == BACKSPACE){
80100a2c:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80100a2f:	e8 fc f9 ff ff       	call   80100430 <consputc.part.0>
        if(c == '\n' || c == C('D') || input.e == input.r+INPUT_BUF){
80100a34:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80100a37:	8b 15 28 ff 10 80    	mov    0x8010ff28,%edx
80100a3d:	83 f8 0a             	cmp    $0xa,%eax
80100a40:	74 69                	je     80100aab <consoleintr+0x19b>
80100a42:	83 f8 04             	cmp    $0x4,%eax
80100a45:	74 64                	je     80100aab <consoleintr+0x19b>
80100a47:	a1 20 ff 10 80       	mov    0x8010ff20,%eax
80100a4c:	83 e8 80             	sub    $0xffffff80,%eax
80100a4f:	39 d0                	cmp    %edx,%eax
80100a51:	74 58                	je     80100aab <consoleintr+0x19b>
80100a53:	8b 7d fc             	mov    -0x4(%ebp),%edi
80100a56:	e9 d3 fe ff ff       	jmp    8010092e <consoleintr+0x1e>
      if(c != 0 && input.e-input.r < INPUT_BUF){
80100a5b:	85 c0                	test   %eax,%eax
80100a5d:	0f 84 cb fe ff ff    	je     8010092e <consoleintr+0x1e>
80100a63:	8b 15 28 ff 10 80    	mov    0x8010ff28,%edx
80100a69:	89 7d fc             	mov    %edi,-0x4(%ebp)
80100a6c:	89 d1                	mov    %edx,%ecx
80100a6e:	2b 0d 20 ff 10 80    	sub    0x8010ff20,%ecx
80100a74:	83 f9 7f             	cmp    $0x7f,%ecx
80100a77:	77 da                	ja     80100a53 <consoleintr+0x143>
        input.buf[input.e++ % INPUT_BUF] = c;
80100a79:	8d 4a 01             	lea    0x1(%edx),%ecx
  if(panicked){
80100a7c:	8b 3d 78 ff 10 80    	mov    0x8010ff78,%edi
        input.buf[input.e++ % INPUT_BUF] = c;
80100a82:	83 e2 7f             	and    $0x7f,%edx
        c = (c == '\r') ? '\n' : c;
80100a85:	83 f8 0d             	cmp    $0xd,%eax
80100a88:	75 8e                	jne    80100a18 <consoleintr+0x108>
        input.buf[input.e++ % INPUT_BUF] = c;
80100a8a:	89 0d 28 ff 10 80    	mov    %ecx,0x8010ff28
80100a90:	c6 82 a0 fe 10 80 0a 	movb   $0xa,-0x7fef0160(%edx)
  if(panicked){
80100a97:	85 ff                	test   %edi,%edi
80100a99:	75 49                	jne    80100ae4 <consoleintr+0x1d4>
  if(c == BACKSPACE){
80100a9b:	b8 0a 00 00 00       	mov    $0xa,%eax
80100aa0:	e8 8b f9 ff ff       	call   80100430 <consputc.part.0>
          input.w = input.e;
80100aa5:	8b 15 28 ff 10 80    	mov    0x8010ff28,%edx
          wakeup(&input.r);
80100aab:	83 ec 0c             	sub    $0xc,%esp
          input.w = input.e;
80100aae:	89 15 24 ff 10 80    	mov    %edx,0x8010ff24
          wakeup(&input.r);
80100ab4:	68 20 ff 10 80       	push   $0x8010ff20
80100ab9:	e8 12 39 00 00       	call   801043d0 <wakeup>
80100abe:	8b 7d fc             	mov    -0x4(%ebp),%edi
80100ac1:	83 c4 10             	add    $0x10,%esp
80100ac4:	e9 65 fe ff ff       	jmp    8010092e <consoleintr+0x1e>
  if(c == BACKSPACE){
80100ac9:	b8 00 01 00 00       	mov    $0x100,%eax
80100ace:	e8 5d f9 ff ff       	call   80100430 <consputc.part.0>
80100ad3:	e9 56 fe ff ff       	jmp    8010092e <consoleintr+0x1e>
}
80100ad8:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80100adb:	8b 75 f8             	mov    -0x8(%ebp),%esi
80100ade:	c9                   	leave
    procdump();  // now call procdump() wo. cons.lock held
80100adf:	e9 cc 39 00 00       	jmp    801044b0 <procdump>
80100ae4:	fa                   	cli
80100ae5:	90                   	nop
80100ae6:	66 90                	xchg   %ax,%ax
80100ae8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80100aef:	00 
    for(;;)
80100af0:	eb fe                	jmp    80100af0 <consoleintr+0x1e0>
80100af2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80100af8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80100aff:	00 

80100b00 <consoleinit>:

void
consoleinit(void)
{
80100b00:	55                   	push   %ebp
80100b01:	89 e5                	mov    %esp,%ebp
80100b03:	83 ec 10             	sub    $0x10,%esp
  initlock(&cons.lock, "console");
80100b06:	68 a8 79 10 80       	push   $0x801079a8
80100b0b:	68 40 ff 10 80       	push   $0x8010ff40
80100b10:	e8 0b 3c 00 00       	call   80104720 <initlock>

  devsw[CONSOLE].write = consolewrite;
  devsw[CONSOLE].read = consoleread;
  cons.locking = 1;

  ioapicenable(IRQ_KBD, 0);
80100b15:	58                   	pop    %eax
80100b16:	5a                   	pop    %edx
80100b17:	6a 00                	push   $0x0
80100b19:	6a 01                	push   $0x1
  devsw[CONSOLE].write = consolewrite;
80100b1b:	c7 05 2c 09 11 80 e0 	movl   $0x801005e0,0x8011092c
80100b22:	05 10 80 
  devsw[CONSOLE].read = consoleread;
80100b25:	c7 05 28 09 11 80 a0 	movl   $0x801002a0,0x80110928
80100b2c:	02 10 80 
  cons.locking = 1;
80100b2f:	c7 05 74 ff 10 80 01 	movl   $0x1,0x8010ff74
80100b36:	00 00 00 
  ioapicenable(IRQ_KBD, 0);
80100b39:	e8 c2 1a 00 00       	call   80102600 <ioapicenable>
}
80100b3e:	83 c4 10             	add    $0x10,%esp
80100b41:	c9                   	leave
80100b42:	c3                   	ret
80100b43:	66 90                	xchg   %ax,%ax
80100b45:	66 90                	xchg   %ax,%ax
80100b47:	66 90                	xchg   %ax,%ax
80100b49:	66 90                	xchg   %ax,%ax
80100b4b:	66 90                	xchg   %ax,%ax
80100b4d:	66 90                	xchg   %ax,%ax
80100b4f:	90                   	nop

80100b50 <exec>:
#include "x86.h"
#include "elf.h"

int
exec(char *path, char **argv)
{
80100b50:	55                   	push   %ebp
80100b51:	89 e5                	mov    %esp,%ebp
80100b53:	81 ec 18 01 00 00    	sub    $0x118,%esp
  uint argc, sz, sp, ustack[3+MAXARG+1];
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pde_t *pgdir, *oldpgdir;
  struct proc *curproc = myproc();
80100b59:	e8 42 30 00 00       	call   80103ba0 <myproc>
80100b5e:	89 85 ec fe ff ff    	mov    %eax,-0x114(%ebp)

  begin_op();
80100b64:	e8 d7 23 00 00       	call   80102f40 <begin_op>

  if((ip = namei(path)) == 0){
80100b69:	83 ec 0c             	sub    $0xc,%esp
80100b6c:	ff 75 08             	push   0x8(%ebp)
80100b6f:	e8 7c 16 00 00       	call   801021f0 <namei>
80100b74:	83 c4 10             	add    $0x10,%esp
80100b77:	85 c0                	test   %eax,%eax
80100b79:	0f 84 19 03 00 00    	je     80100e98 <exec+0x348>
    end_op();
    cprintf("exec: fail\n");
    return -1;
  }
  ilock(ip);
80100b7f:	83 ec 0c             	sub    $0xc,%esp
80100b82:	89 5d f4             	mov    %ebx,-0xc(%ebp)
80100b85:	89 c3                	mov    %eax,%ebx
80100b87:	50                   	push   %eax
80100b88:	e8 d3 0c 00 00       	call   80101860 <ilock>
  pgdir = 0;

  // Check ELF header
  if(readi(ip, (char*)&elf, 0, sizeof(elf)) != sizeof(elf))
80100b8d:	8d 85 24 ff ff ff    	lea    -0xdc(%ebp),%eax
80100b93:	6a 34                	push   $0x34
80100b95:	6a 00                	push   $0x0
80100b97:	50                   	push   %eax
80100b98:	53                   	push   %ebx
80100b99:	e8 f2 0f 00 00       	call   80101b90 <readi>
80100b9e:	83 c4 20             	add    $0x20,%esp
80100ba1:	83 f8 34             	cmp    $0x34,%eax
80100ba4:	74 22                	je     80100bc8 <exec+0x78>

 bad:
  if(pgdir)
    freevm(pgdir);
  if(ip){
    iunlockput(ip);
80100ba6:	83 ec 0c             	sub    $0xc,%esp
80100ba9:	53                   	push   %ebx
80100baa:	e8 61 0f 00 00       	call   80101b10 <iunlockput>
    end_op();
80100baf:	e8 fc 23 00 00       	call   80102fb0 <end_op>
80100bb4:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80100bb7:	83 c4 10             	add    $0x10,%esp
  }
  return -1;
}
80100bba:	c9                   	leave
    return -1;
80100bbb:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80100bc0:	c3                   	ret
80100bc1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  if(elf.magic != ELF_MAGIC)
80100bc8:	81 bd 24 ff ff ff 7f 	cmpl   $0x464c457f,-0xdc(%ebp)
80100bcf:	45 4c 46 
80100bd2:	75 d2                	jne    80100ba6 <exec+0x56>
  if((pgdir = setupkvm()) == 0)
80100bd4:	e8 17 6a 00 00       	call   801075f0 <setupkvm>
80100bd9:	89 85 f4 fe ff ff    	mov    %eax,-0x10c(%ebp)
80100bdf:	85 c0                	test   %eax,%eax
80100be1:	74 c3                	je     80100ba6 <exec+0x56>
80100be3:	89 75 f8             	mov    %esi,-0x8(%ebp)
80100be6:	89 7d fc             	mov    %edi,-0x4(%ebp)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
80100be9:	66 83 bd 50 ff ff ff 	cmpw   $0x0,-0xb0(%ebp)
80100bf0:	00 
80100bf1:	0f 84 bb 02 00 00    	je     80100eb2 <exec+0x362>
  sz = 0;
80100bf7:	c7 85 f0 fe ff ff 00 	movl   $0x0,-0x110(%ebp)
80100bfe:	00 00 00 
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
80100c01:	8b b5 40 ff ff ff    	mov    -0xc0(%ebp),%esi
80100c07:	31 ff                	xor    %edi,%edi
80100c09:	e9 88 00 00 00       	jmp    80100c96 <exec+0x146>
80100c0e:	66 90                	xchg   %ax,%ax
    if(ph.type != ELF_PROG_LOAD)
80100c10:	83 bd 04 ff ff ff 01 	cmpl   $0x1,-0xfc(%ebp)
80100c17:	75 6c                	jne    80100c85 <exec+0x135>
    if(ph.memsz < ph.filesz)
80100c19:	8b 85 18 ff ff ff    	mov    -0xe8(%ebp),%eax
80100c1f:	3b 85 14 ff ff ff    	cmp    -0xec(%ebp),%eax
80100c25:	0f 82 87 00 00 00    	jb     80100cb2 <exec+0x162>
    if(ph.vaddr + ph.memsz < ph.vaddr)
80100c2b:	03 85 0c ff ff ff    	add    -0xf4(%ebp),%eax
80100c31:	72 7f                	jb     80100cb2 <exec+0x162>
    if((sz = allocuvm(pgdir, sz, ph.vaddr + ph.memsz)) == 0)
80100c33:	83 ec 04             	sub    $0x4,%esp
80100c36:	50                   	push   %eax
80100c37:	ff b5 f0 fe ff ff    	push   -0x110(%ebp)
80100c3d:	ff b5 f4 fe ff ff    	push   -0x10c(%ebp)
80100c43:	e8 b8 67 00 00       	call   80107400 <allocuvm>
80100c48:	83 c4 10             	add    $0x10,%esp
80100c4b:	89 85 f0 fe ff ff    	mov    %eax,-0x110(%ebp)
80100c51:	85 c0                	test   %eax,%eax
80100c53:	74 5d                	je     80100cb2 <exec+0x162>
    if(ph.vaddr % PGSIZE != 0)
80100c55:	8b 85 0c ff ff ff    	mov    -0xf4(%ebp),%eax
80100c5b:	a9 ff 0f 00 00       	test   $0xfff,%eax
80100c60:	75 50                	jne    80100cb2 <exec+0x162>
    if(loaduvm(pgdir, (char*)ph.vaddr, ip, ph.off, ph.filesz) < 0)
80100c62:	83 ec 0c             	sub    $0xc,%esp
80100c65:	ff b5 14 ff ff ff    	push   -0xec(%ebp)
80100c6b:	ff b5 08 ff ff ff    	push   -0xf8(%ebp)
80100c71:	53                   	push   %ebx
80100c72:	50                   	push   %eax
80100c73:	ff b5 f4 fe ff ff    	push   -0x10c(%ebp)
80100c79:	e8 a2 66 00 00       	call   80107320 <loaduvm>
80100c7e:	83 c4 20             	add    $0x20,%esp
80100c81:	85 c0                	test   %eax,%eax
80100c83:	78 2d                	js     80100cb2 <exec+0x162>
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
80100c85:	0f b7 85 50 ff ff ff 	movzwl -0xb0(%ebp),%eax
80100c8c:	83 c7 01             	add    $0x1,%edi
80100c8f:	83 c6 20             	add    $0x20,%esi
80100c92:	39 f8                	cmp    %edi,%eax
80100c94:	7e 3a                	jle    80100cd0 <exec+0x180>
    if(readi(ip, (char*)&ph, off, sizeof(ph)) != sizeof(ph))
80100c96:	8d 85 04 ff ff ff    	lea    -0xfc(%ebp),%eax
80100c9c:	6a 20                	push   $0x20
80100c9e:	56                   	push   %esi
80100c9f:	50                   	push   %eax
80100ca0:	53                   	push   %ebx
80100ca1:	e8 ea 0e 00 00       	call   80101b90 <readi>
80100ca6:	83 c4 10             	add    $0x10,%esp
80100ca9:	83 f8 20             	cmp    $0x20,%eax
80100cac:	0f 84 5e ff ff ff    	je     80100c10 <exec+0xc0>
    freevm(pgdir);
80100cb2:	83 ec 0c             	sub    $0xc,%esp
80100cb5:	ff b5 f4 fe ff ff    	push   -0x10c(%ebp)
80100cbb:	e8 b0 68 00 00       	call   80107570 <freevm>
  if(ip){
80100cc0:	8b 75 f8             	mov    -0x8(%ebp),%esi
80100cc3:	8b 7d fc             	mov    -0x4(%ebp),%edi
    freevm(pgdir);
80100cc6:	83 c4 10             	add    $0x10,%esp
80100cc9:	e9 d8 fe ff ff       	jmp    80100ba6 <exec+0x56>
80100cce:	66 90                	xchg   %ax,%ax
  sz = PGROUNDUP(sz);
80100cd0:	8b bd f0 fe ff ff    	mov    -0x110(%ebp),%edi
80100cd6:	81 c7 ff 0f 00 00    	add    $0xfff,%edi
80100cdc:	81 e7 00 f0 ff ff    	and    $0xfffff000,%edi
  if((sz = allocuvm(pgdir, sz, sz + 2*PGSIZE)) == 0)
80100ce2:	8d b7 00 20 00 00    	lea    0x2000(%edi),%esi
  iunlockput(ip);
80100ce8:	83 ec 0c             	sub    $0xc,%esp
80100ceb:	53                   	push   %ebx
80100cec:	e8 1f 0e 00 00       	call   80101b10 <iunlockput>
  end_op();
80100cf1:	e8 ba 22 00 00       	call   80102fb0 <end_op>
  if((sz = allocuvm(pgdir, sz, sz + 2*PGSIZE)) == 0)
80100cf6:	83 c4 0c             	add    $0xc,%esp
80100cf9:	56                   	push   %esi
80100cfa:	8b b5 f4 fe ff ff    	mov    -0x10c(%ebp),%esi
80100d00:	57                   	push   %edi
80100d01:	56                   	push   %esi
80100d02:	e8 f9 66 00 00       	call   80107400 <allocuvm>
80100d07:	83 c4 10             	add    $0x10,%esp
80100d0a:	89 c7                	mov    %eax,%edi
80100d0c:	85 c0                	test   %eax,%eax
80100d0e:	0f 84 9c 00 00 00    	je     80100db0 <exec+0x260>
  clearpteu(pgdir, (char*)(sz - 2*PGSIZE));
80100d14:	83 ec 08             	sub    $0x8,%esp
80100d17:	8d 80 00 e0 ff ff    	lea    -0x2000(%eax),%eax
  sp = sz;
80100d1d:	89 fb                	mov    %edi,%ebx
  clearpteu(pgdir, (char*)(sz - 2*PGSIZE));
80100d1f:	50                   	push   %eax
80100d20:	56                   	push   %esi
  for(argc = 0; argv[argc]; argc++) {
80100d21:	31 f6                	xor    %esi,%esi
  clearpteu(pgdir, (char*)(sz - 2*PGSIZE));
80100d23:	e8 68 69 00 00       	call   80107690 <clearpteu>
  for(argc = 0; argv[argc]; argc++) {
80100d28:	8b 45 0c             	mov    0xc(%ebp),%eax
80100d2b:	83 c4 10             	add    $0x10,%esp
80100d2e:	8d 95 58 ff ff ff    	lea    -0xa8(%ebp),%edx
80100d34:	8b 00                	mov    (%eax),%eax
80100d36:	85 c0                	test   %eax,%eax
80100d38:	0f 84 99 00 00 00    	je     80100dd7 <exec+0x287>
80100d3e:	89 bd f0 fe ff ff    	mov    %edi,-0x110(%ebp)
80100d44:	89 f7                	mov    %esi,%edi
80100d46:	8b b5 f4 fe ff ff    	mov    -0x10c(%ebp),%esi
80100d4c:	eb 21                	jmp    80100d6f <exec+0x21f>
80100d4e:	66 90                	xchg   %ax,%ax
80100d50:	8b 45 0c             	mov    0xc(%ebp),%eax
    ustack[3+argc] = sp;
80100d53:	89 9c bd 64 ff ff ff 	mov    %ebx,-0x9c(%ebp,%edi,4)
  for(argc = 0; argv[argc]; argc++) {
80100d5a:	83 c7 01             	add    $0x1,%edi
    ustack[3+argc] = sp;
80100d5d:	8d 95 58 ff ff ff    	lea    -0xa8(%ebp),%edx
  for(argc = 0; argv[argc]; argc++) {
80100d63:	8b 04 b8             	mov    (%eax,%edi,4),%eax
80100d66:	85 c0                	test   %eax,%eax
80100d68:	74 65                	je     80100dcf <exec+0x27f>
    if(argc >= MAXARG)
80100d6a:	83 ff 20             	cmp    $0x20,%edi
80100d6d:	74 41                	je     80100db0 <exec+0x260>
    sp = (sp - (strlen(argv[argc]) + 1)) & ~3;
80100d6f:	83 ec 0c             	sub    $0xc,%esp
80100d72:	50                   	push   %eax
80100d73:	e8 08 3f 00 00       	call   80104c80 <strlen>
80100d78:	29 c3                	sub    %eax,%ebx
    if(copyout(pgdir, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
80100d7a:	58                   	pop    %eax
80100d7b:	8b 45 0c             	mov    0xc(%ebp),%eax
    sp = (sp - (strlen(argv[argc]) + 1)) & ~3;
80100d7e:	83 eb 01             	sub    $0x1,%ebx
    if(copyout(pgdir, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
80100d81:	ff 34 b8             	push   (%eax,%edi,4)
    sp = (sp - (strlen(argv[argc]) + 1)) & ~3;
80100d84:	83 e3 fc             	and    $0xfffffffc,%ebx
    if(copyout(pgdir, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
80100d87:	e8 f4 3e 00 00       	call   80104c80 <strlen>
80100d8c:	83 c0 01             	add    $0x1,%eax
80100d8f:	50                   	push   %eax
80100d90:	8b 45 0c             	mov    0xc(%ebp),%eax
80100d93:	ff 34 b8             	push   (%eax,%edi,4)
80100d96:	53                   	push   %ebx
80100d97:	56                   	push   %esi
80100d98:	e8 c3 6a 00 00       	call   80107860 <copyout>
80100d9d:	83 c4 20             	add    $0x20,%esp
80100da0:	85 c0                	test   %eax,%eax
80100da2:	79 ac                	jns    80100d50 <exec+0x200>
80100da4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80100da8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80100daf:	00 
    freevm(pgdir);
80100db0:	83 ec 0c             	sub    $0xc,%esp
80100db3:	ff b5 f4 fe ff ff    	push   -0x10c(%ebp)
80100db9:	e8 b2 67 00 00       	call   80107570 <freevm>
  if(ip){
80100dbe:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80100dc1:	8b 75 f8             	mov    -0x8(%ebp),%esi
    freevm(pgdir);
80100dc4:	83 c4 10             	add    $0x10,%esp
80100dc7:	8b 7d fc             	mov    -0x4(%ebp),%edi
80100dca:	e9 eb fd ff ff       	jmp    80100bba <exec+0x6a>
80100dcf:	89 fe                	mov    %edi,%esi
80100dd1:	8b bd f0 fe ff ff    	mov    -0x110(%ebp),%edi
  ustack[2] = sp - (argc+1)*4;  // argv pointer
80100dd7:	8d 04 b5 04 00 00 00 	lea    0x4(,%esi,4),%eax
80100dde:	89 d9                	mov    %ebx,%ecx
  ustack[3+argc] = 0;
80100de0:	c7 84 b5 64 ff ff ff 	movl   $0x0,-0x9c(%ebp,%esi,4)
80100de7:	00 00 00 00 
  ustack[2] = sp - (argc+1)*4;  // argv pointer
80100deb:	29 c1                	sub    %eax,%ecx
  sp -= (3+argc+1) * 4;
80100ded:	83 c0 0c             	add    $0xc,%eax
  ustack[1] = argc;
80100df0:	89 b5 5c ff ff ff    	mov    %esi,-0xa4(%ebp)
  sp -= (3+argc+1) * 4;
80100df6:	29 c3                	sub    %eax,%ebx
  if(copyout(pgdir, sp, ustack, (3+argc+1)*4) < 0)
80100df8:	50                   	push   %eax
80100df9:	52                   	push   %edx
80100dfa:	53                   	push   %ebx
80100dfb:	ff b5 f4 fe ff ff    	push   -0x10c(%ebp)
  ustack[0] = 0xffffffff;  // fake return PC
80100e01:	c7 85 58 ff ff ff ff 	movl   $0xffffffff,-0xa8(%ebp)
80100e08:	ff ff ff 
  ustack[2] = sp - (argc+1)*4;  // argv pointer
80100e0b:	89 8d 60 ff ff ff    	mov    %ecx,-0xa0(%ebp)
  if(copyout(pgdir, sp, ustack, (3+argc+1)*4) < 0)
80100e11:	e8 4a 6a 00 00       	call   80107860 <copyout>
80100e16:	83 c4 10             	add    $0x10,%esp
80100e19:	85 c0                	test   %eax,%eax
80100e1b:	78 93                	js     80100db0 <exec+0x260>
  for(last=s=path; *s; s++)
80100e1d:	8b 45 08             	mov    0x8(%ebp),%eax
80100e20:	8b 55 08             	mov    0x8(%ebp),%edx
80100e23:	0f b6 00             	movzbl (%eax),%eax
80100e26:	84 c0                	test   %al,%al
80100e28:	74 15                	je     80100e3f <exec+0x2ef>
80100e2a:	89 d1                	mov    %edx,%ecx
80100e2c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
      last = s+1;
80100e30:	83 c1 01             	add    $0x1,%ecx
80100e33:	3c 2f                	cmp    $0x2f,%al
  for(last=s=path; *s; s++)
80100e35:	0f b6 01             	movzbl (%ecx),%eax
      last = s+1;
80100e38:	0f 44 d1             	cmove  %ecx,%edx
  for(last=s=path; *s; s++)
80100e3b:	84 c0                	test   %al,%al
80100e3d:	75 f1                	jne    80100e30 <exec+0x2e0>
  safestrcpy(curproc->name, last, sizeof(curproc->name));
80100e3f:	8b b5 ec fe ff ff    	mov    -0x114(%ebp),%esi
80100e45:	83 ec 04             	sub    $0x4,%esp
80100e48:	6a 10                	push   $0x10
80100e4a:	8d 46 6c             	lea    0x6c(%esi),%eax
80100e4d:	52                   	push   %edx
80100e4e:	50                   	push   %eax
80100e4f:	e8 dc 3d 00 00       	call   80104c30 <safestrcpy>
  curproc->pgdir = pgdir;
80100e54:	8b 8d f4 fe ff ff    	mov    -0x10c(%ebp),%ecx
  oldpgdir = curproc->pgdir;
80100e5a:	89 f0                	mov    %esi,%eax
80100e5c:	8b 76 04             	mov    0x4(%esi),%esi
  curproc->sz = sz;
80100e5f:	89 38                	mov    %edi,(%eax)
  curproc->pgdir = pgdir;
80100e61:	89 48 04             	mov    %ecx,0x4(%eax)
  curproc->tf->eip = elf.entry;  // main
80100e64:	89 c1                	mov    %eax,%ecx
80100e66:	8b 95 3c ff ff ff    	mov    -0xc4(%ebp),%edx
80100e6c:	8b 40 18             	mov    0x18(%eax),%eax
80100e6f:	89 50 38             	mov    %edx,0x38(%eax)
  curproc->tf->esp = sp;
80100e72:	8b 41 18             	mov    0x18(%ecx),%eax
80100e75:	89 58 44             	mov    %ebx,0x44(%eax)
  switchuvm(curproc);
80100e78:	89 0c 24             	mov    %ecx,(%esp)
80100e7b:	e8 10 63 00 00       	call   80107190 <switchuvm>
  freevm(oldpgdir);
80100e80:	89 34 24             	mov    %esi,(%esp)
80100e83:	e8 e8 66 00 00       	call   80107570 <freevm>
  return 0;
80100e88:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80100e8b:	8b 75 f8             	mov    -0x8(%ebp),%esi
80100e8e:	83 c4 10             	add    $0x10,%esp
80100e91:	8b 7d fc             	mov    -0x4(%ebp),%edi
80100e94:	31 c0                	xor    %eax,%eax
}
80100e96:	c9                   	leave
80100e97:	c3                   	ret
    end_op();
80100e98:	e8 13 21 00 00       	call   80102fb0 <end_op>
    cprintf("exec: fail\n");
80100e9d:	83 ec 0c             	sub    $0xc,%esp
80100ea0:	68 b0 79 10 80       	push   $0x801079b0
80100ea5:	e8 46 f8 ff ff       	call   801006f0 <cprintf>
    return -1;
80100eaa:	83 c4 10             	add    $0x10,%esp
80100ead:	e9 08 fd ff ff       	jmp    80100bba <exec+0x6a>
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
80100eb2:	be 00 20 00 00       	mov    $0x2000,%esi
80100eb7:	31 ff                	xor    %edi,%edi
80100eb9:	e9 2a fe ff ff       	jmp    80100ce8 <exec+0x198>
80100ebe:	66 90                	xchg   %ax,%ax

80100ec0 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
80100ec0:	55                   	push   %ebp
80100ec1:	89 e5                	mov    %esp,%ebp
80100ec3:	83 ec 10             	sub    $0x10,%esp
  initlock(&ftable.lock, "ftable");
80100ec6:	68 bc 79 10 80       	push   $0x801079bc
80100ecb:	68 80 ff 10 80       	push   $0x8010ff80
80100ed0:	e8 4b 38 00 00       	call   80104720 <initlock>
}
80100ed5:	83 c4 10             	add    $0x10,%esp
80100ed8:	c9                   	leave
80100ed9:	c3                   	ret
80100eda:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80100ee0 <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
80100ee0:	55                   	push   %ebp
80100ee1:	89 e5                	mov    %esp,%ebp
80100ee3:	53                   	push   %ebx
  struct file *f;

  acquire(&ftable.lock);
  for(f = ftable.file; f < ftable.file + NFILE; f++){
80100ee4:	bb b4 ff 10 80       	mov    $0x8010ffb4,%ebx
{
80100ee9:	83 ec 10             	sub    $0x10,%esp
  acquire(&ftable.lock);
80100eec:	68 80 ff 10 80       	push   $0x8010ff80
80100ef1:	e8 4a 3a 00 00       	call   80104940 <acquire>
80100ef6:	83 c4 10             	add    $0x10,%esp
80100ef9:	eb 10                	jmp    80100f0b <filealloc+0x2b>
80100efb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  for(f = ftable.file; f < ftable.file + NFILE; f++){
80100f00:	83 c3 18             	add    $0x18,%ebx
80100f03:	81 fb 14 09 11 80    	cmp    $0x80110914,%ebx
80100f09:	74 25                	je     80100f30 <filealloc+0x50>
    if(f->ref == 0){
80100f0b:	8b 43 04             	mov    0x4(%ebx),%eax
80100f0e:	85 c0                	test   %eax,%eax
80100f10:	75 ee                	jne    80100f00 <filealloc+0x20>
      f->ref = 1;
      release(&ftable.lock);
80100f12:	83 ec 0c             	sub    $0xc,%esp
      f->ref = 1;
80100f15:	c7 43 04 01 00 00 00 	movl   $0x1,0x4(%ebx)
      release(&ftable.lock);
80100f1c:	68 80 ff 10 80       	push   $0x8010ff80
80100f21:	e8 ba 39 00 00       	call   801048e0 <release>
      return f;
    }
  }
  release(&ftable.lock);
  return 0;
}
80100f26:	89 d8                	mov    %ebx,%eax
      return f;
80100f28:	83 c4 10             	add    $0x10,%esp
}
80100f2b:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80100f2e:	c9                   	leave
80100f2f:	c3                   	ret
  release(&ftable.lock);
80100f30:	83 ec 0c             	sub    $0xc,%esp
  return 0;
80100f33:	31 db                	xor    %ebx,%ebx
  release(&ftable.lock);
80100f35:	68 80 ff 10 80       	push   $0x8010ff80
80100f3a:	e8 a1 39 00 00       	call   801048e0 <release>
}
80100f3f:	89 d8                	mov    %ebx,%eax
  return 0;
80100f41:	83 c4 10             	add    $0x10,%esp
}
80100f44:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80100f47:	c9                   	leave
80100f48:	c3                   	ret
80100f49:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80100f50 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
80100f50:	55                   	push   %ebp
80100f51:	89 e5                	mov    %esp,%ebp
80100f53:	53                   	push   %ebx
80100f54:	83 ec 10             	sub    $0x10,%esp
80100f57:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&ftable.lock);
80100f5a:	68 80 ff 10 80       	push   $0x8010ff80
80100f5f:	e8 dc 39 00 00       	call   80104940 <acquire>
  if(f->ref < 1)
80100f64:	8b 43 04             	mov    0x4(%ebx),%eax
80100f67:	83 c4 10             	add    $0x10,%esp
80100f6a:	85 c0                	test   %eax,%eax
80100f6c:	7e 1a                	jle    80100f88 <filedup+0x38>
    panic("filedup");
  f->ref++;
80100f6e:	83 c0 01             	add    $0x1,%eax
  release(&ftable.lock);
80100f71:	83 ec 0c             	sub    $0xc,%esp
  f->ref++;
80100f74:	89 43 04             	mov    %eax,0x4(%ebx)
  release(&ftable.lock);
80100f77:	68 80 ff 10 80       	push   $0x8010ff80
80100f7c:	e8 5f 39 00 00       	call   801048e0 <release>
  return f;
}
80100f81:	89 d8                	mov    %ebx,%eax
80100f83:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80100f86:	c9                   	leave
80100f87:	c3                   	ret
    panic("filedup");
80100f88:	83 ec 0c             	sub    $0xc,%esp
80100f8b:	68 c3 79 10 80       	push   $0x801079c3
80100f90:	e8 0b f4 ff ff       	call   801003a0 <panic>
80100f95:	8d 76 00             	lea    0x0(%esi),%esi
80100f98:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80100f9f:	00 

80100fa0 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
80100fa0:	55                   	push   %ebp
80100fa1:	89 e5                	mov    %esp,%ebp
80100fa3:	83 ec 34             	sub    $0x34,%esp
  struct file ff;

  acquire(&ftable.lock);
80100fa6:	68 80 ff 10 80       	push   $0x8010ff80
{
80100fab:	89 5d f4             	mov    %ebx,-0xc(%ebp)
80100fae:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&ftable.lock);
80100fb1:	e8 8a 39 00 00       	call   80104940 <acquire>
  if(f->ref < 1)
80100fb6:	8b 43 04             	mov    0x4(%ebx),%eax
80100fb9:	83 c4 10             	add    $0x10,%esp
80100fbc:	85 c0                	test   %eax,%eax
80100fbe:	0f 8e a3 00 00 00    	jle    80101067 <fileclose+0xc7>
    panic("fileclose");
  if(--f->ref > 0){
80100fc4:	83 e8 01             	sub    $0x1,%eax
80100fc7:	89 43 04             	mov    %eax,0x4(%ebx)
80100fca:	75 44                	jne    80101010 <fileclose+0x70>
80100fcc:	89 75 f8             	mov    %esi,-0x8(%ebp)
    return;
  }
  ff = *f;
  f->ref = 0;
  f->type = FD_NONE;
  release(&ftable.lock);
80100fcf:	83 ec 0c             	sub    $0xc,%esp
80100fd2:	89 7d fc             	mov    %edi,-0x4(%ebp)
  ff = *f;
80100fd5:	8b 43 0c             	mov    0xc(%ebx),%eax
80100fd8:	8b 33                	mov    (%ebx),%esi
80100fda:	0f b6 7b 09          	movzbl 0x9(%ebx),%edi
  f->type = FD_NONE;
80100fde:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
  ff = *f;
80100fe4:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80100fe7:	8b 43 10             	mov    0x10(%ebx),%eax
  release(&ftable.lock);
80100fea:	68 80 ff 10 80       	push   $0x8010ff80
  ff = *f;
80100fef:	89 45 e0             	mov    %eax,-0x20(%ebp)
  release(&ftable.lock);
80100ff2:	e8 e9 38 00 00       	call   801048e0 <release>

  if(ff.type == FD_PIPE)
80100ff7:	83 c4 10             	add    $0x10,%esp
80100ffa:	83 fe 01             	cmp    $0x1,%esi
80100ffd:	74 49                	je     80101048 <fileclose+0xa8>
    pipeclose(ff.pipe, ff.writable);
  else if(ff.type == FD_INODE){
80100fff:	83 fe 02             	cmp    $0x2,%esi
80101002:	74 1c                	je     80101020 <fileclose+0x80>
80101004:	8b 75 f8             	mov    -0x8(%ebp),%esi
80101007:	8b 7d fc             	mov    -0x4(%ebp),%edi
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
8010100a:	8b 5d f4             	mov    -0xc(%ebp),%ebx
8010100d:	c9                   	leave
8010100e:	c3                   	ret
8010100f:	90                   	nop
    release(&ftable.lock);
80101010:	c7 45 08 80 ff 10 80 	movl   $0x8010ff80,0x8(%ebp)
}
80101017:	8b 5d f4             	mov    -0xc(%ebp),%ebx
8010101a:	c9                   	leave
    release(&ftable.lock);
8010101b:	e9 c0 38 00 00       	jmp    801048e0 <release>
    begin_op();
80101020:	e8 1b 1f 00 00       	call   80102f40 <begin_op>
    iput(ff.ip);
80101025:	83 ec 0c             	sub    $0xc,%esp
80101028:	ff 75 e0             	push   -0x20(%ebp)
8010102b:	e8 60 09 00 00       	call   80101990 <iput>
    end_op();
80101030:	8b 75 f8             	mov    -0x8(%ebp),%esi
80101033:	8b 7d fc             	mov    -0x4(%ebp),%edi
80101036:	83 c4 10             	add    $0x10,%esp
}
80101039:	8b 5d f4             	mov    -0xc(%ebp),%ebx
8010103c:	c9                   	leave
    end_op();
8010103d:	e9 6e 1f 00 00       	jmp    80102fb0 <end_op>
80101042:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    pipeclose(ff.pipe, ff.writable);
80101048:	89 f8                	mov    %edi,%eax
8010104a:	83 ec 08             	sub    $0x8,%esp
8010104d:	0f be c0             	movsbl %al,%eax
80101050:	50                   	push   %eax
80101051:	ff 75 e4             	push   -0x1c(%ebp)
80101054:	e8 a7 26 00 00       	call   80103700 <pipeclose>
80101059:	8b 75 f8             	mov    -0x8(%ebp),%esi
8010105c:	8b 7d fc             	mov    -0x4(%ebp),%edi
8010105f:	83 c4 10             	add    $0x10,%esp
}
80101062:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80101065:	c9                   	leave
80101066:	c3                   	ret
    panic("fileclose");
80101067:	83 ec 0c             	sub    $0xc,%esp
8010106a:	89 75 f8             	mov    %esi,-0x8(%ebp)
8010106d:	68 cb 79 10 80       	push   $0x801079cb
80101072:	89 7d fc             	mov    %edi,-0x4(%ebp)
80101075:	e8 26 f3 ff ff       	call   801003a0 <panic>
8010107a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80101080 <filestat>:

// Get metadata about file f.
int
filestat(struct file *f, struct stat *st)
{
80101080:	55                   	push   %ebp
80101081:	89 e5                	mov    %esp,%ebp
80101083:	53                   	push   %ebx
80101084:	83 ec 04             	sub    $0x4,%esp
80101087:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(f->type == FD_INODE){
8010108a:	83 3b 02             	cmpl   $0x2,(%ebx)
8010108d:	75 31                	jne    801010c0 <filestat+0x40>
    ilock(f->ip);
8010108f:	83 ec 0c             	sub    $0xc,%esp
80101092:	ff 73 10             	push   0x10(%ebx)
80101095:	e8 c6 07 00 00       	call   80101860 <ilock>
    stati(f->ip, st);
8010109a:	58                   	pop    %eax
8010109b:	5a                   	pop    %edx
8010109c:	ff 75 0c             	push   0xc(%ebp)
8010109f:	ff 73 10             	push   0x10(%ebx)
801010a2:	e8 b9 0a 00 00       	call   80101b60 <stati>
    iunlock(f->ip);
801010a7:	59                   	pop    %ecx
801010a8:	ff 73 10             	push   0x10(%ebx)
801010ab:	e8 90 08 00 00       	call   80101940 <iunlock>
    return 0;
  }
  return -1;
}
801010b0:	8b 5d fc             	mov    -0x4(%ebp),%ebx
    return 0;
801010b3:	83 c4 10             	add    $0x10,%esp
801010b6:	31 c0                	xor    %eax,%eax
}
801010b8:	c9                   	leave
801010b9:	c3                   	ret
801010ba:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
801010c0:	8b 5d fc             	mov    -0x4(%ebp),%ebx
  return -1;
801010c3:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
801010c8:	c9                   	leave
801010c9:	c3                   	ret
801010ca:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

801010d0 <fileread>:

// Read from file f.
int
fileread(struct file *f, char *addr, int n)
{
801010d0:	55                   	push   %ebp
801010d1:	89 e5                	mov    %esp,%ebp
801010d3:	57                   	push   %edi
801010d4:	56                   	push   %esi
801010d5:	53                   	push   %ebx
801010d6:	83 ec 0c             	sub    $0xc,%esp
801010d9:	8b 5d 08             	mov    0x8(%ebp),%ebx
801010dc:	8b 75 0c             	mov    0xc(%ebp),%esi
801010df:	8b 7d 10             	mov    0x10(%ebp),%edi
  int r;

  if(f->readable == 0)
801010e2:	80 7b 08 00          	cmpb   $0x0,0x8(%ebx)
801010e6:	74 60                	je     80101148 <fileread+0x78>
    return -1;
  if(f->type == FD_PIPE)
801010e8:	8b 03                	mov    (%ebx),%eax
801010ea:	83 f8 01             	cmp    $0x1,%eax
801010ed:	74 41                	je     80101130 <fileread+0x60>
    return piperead(f->pipe, addr, n);
  if(f->type == FD_INODE){
801010ef:	83 f8 02             	cmp    $0x2,%eax
801010f2:	75 5b                	jne    8010114f <fileread+0x7f>
    ilock(f->ip);
801010f4:	83 ec 0c             	sub    $0xc,%esp
801010f7:	ff 73 10             	push   0x10(%ebx)
801010fa:	e8 61 07 00 00       	call   80101860 <ilock>
    if((r = readi(f->ip, addr, f->off, n)) > 0)
801010ff:	57                   	push   %edi
80101100:	ff 73 14             	push   0x14(%ebx)
80101103:	56                   	push   %esi
80101104:	ff 73 10             	push   0x10(%ebx)
80101107:	e8 84 0a 00 00       	call   80101b90 <readi>
8010110c:	83 c4 20             	add    $0x20,%esp
8010110f:	89 c6                	mov    %eax,%esi
80101111:	85 c0                	test   %eax,%eax
80101113:	7e 03                	jle    80101118 <fileread+0x48>
      f->off += r;
80101115:	01 43 14             	add    %eax,0x14(%ebx)
    iunlock(f->ip);
80101118:	83 ec 0c             	sub    $0xc,%esp
8010111b:	ff 73 10             	push   0x10(%ebx)
8010111e:	e8 1d 08 00 00       	call   80101940 <iunlock>
    return r;
80101123:	83 c4 10             	add    $0x10,%esp
  }
  panic("fileread");
}
80101126:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101129:	89 f0                	mov    %esi,%eax
8010112b:	5b                   	pop    %ebx
8010112c:	5e                   	pop    %esi
8010112d:	5f                   	pop    %edi
8010112e:	5d                   	pop    %ebp
8010112f:	c3                   	ret
    return piperead(f->pipe, addr, n);
80101130:	8b 43 0c             	mov    0xc(%ebx),%eax
80101133:	89 45 08             	mov    %eax,0x8(%ebp)
}
80101136:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101139:	5b                   	pop    %ebx
8010113a:	5e                   	pop    %esi
8010113b:	5f                   	pop    %edi
8010113c:	5d                   	pop    %ebp
    return piperead(f->pipe, addr, n);
8010113d:	e9 7e 27 00 00       	jmp    801038c0 <piperead>
80101142:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    return -1;
80101148:	be ff ff ff ff       	mov    $0xffffffff,%esi
8010114d:	eb d7                	jmp    80101126 <fileread+0x56>
  panic("fileread");
8010114f:	83 ec 0c             	sub    $0xc,%esp
80101152:	68 d5 79 10 80       	push   $0x801079d5
80101157:	e8 44 f2 ff ff       	call   801003a0 <panic>
8010115c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80101160 <filewrite>:

//PAGEBREAK!
// Write to file f.
int
filewrite(struct file *f, char *addr, int n)
{
80101160:	55                   	push   %ebp
80101161:	89 e5                	mov    %esp,%ebp
80101163:	83 ec 28             	sub    $0x28,%esp
80101166:	8b 45 0c             	mov    0xc(%ebp),%eax
80101169:	89 7d fc             	mov    %edi,-0x4(%ebp)
8010116c:	8b 7d 08             	mov    0x8(%ebp),%edi
8010116f:	89 75 f8             	mov    %esi,-0x8(%ebp)
80101172:	89 45 dc             	mov    %eax,-0x24(%ebp)
80101175:	8b 45 10             	mov    0x10(%ebp),%eax
80101178:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  int r;

  if(f->writable == 0)
8010117b:	80 7f 09 00          	cmpb   $0x0,0x9(%edi)
8010117f:	0f 84 e9 00 00 00    	je     8010126e <filewrite+0x10e>
    return -1;
  if(f->type == FD_PIPE)
80101185:	8b 17                	mov    (%edi),%edx
80101187:	83 fa 01             	cmp    $0x1,%edx
8010118a:	0f 84 c8 00 00 00    	je     80101258 <filewrite+0xf8>
    return pipewrite(f->pipe, addr, n);
  if(f->type == FD_INODE){
80101190:	83 fa 02             	cmp    $0x2,%edx
80101193:	0f 85 dc 00 00 00    	jne    80101275 <filewrite+0x115>
    // and 2 blocks of slop for non-aligned writes.
    // this really belongs lower down, since writei()
    // might be writing a device like the console.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * 512;
    int i = 0;
    while(i < n){
80101199:	8b 55 e4             	mov    -0x1c(%ebp),%edx
8010119c:	85 d2                	test   %edx,%edx
8010119e:	0f 8e c6 00 00 00    	jle    8010126a <filewrite+0x10a>
801011a4:	89 5d f4             	mov    %ebx,-0xc(%ebp)
    int i = 0;
801011a7:	31 f6                	xor    %esi,%esi
801011a9:	eb 2a                	jmp    801011d5 <filewrite+0x75>
801011ab:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
        n1 = max;

      begin_op();
      ilock(f->ip);
      if ((r = writei(f->ip, addr + i, f->off, n1)) > 0)
        f->off += r;
801011b0:	01 47 14             	add    %eax,0x14(%edi)
      iunlock(f->ip);
801011b3:	83 ec 0c             	sub    $0xc,%esp
801011b6:	51                   	push   %ecx
        f->off += r;
801011b7:	89 45 e0             	mov    %eax,-0x20(%ebp)
      iunlock(f->ip);
801011ba:	e8 81 07 00 00       	call   80101940 <iunlock>
      end_op();
801011bf:	e8 ec 1d 00 00       	call   80102fb0 <end_op>

      if(r < 0)
        break;
      if(r != n1)
801011c4:	8b 45 e0             	mov    -0x20(%ebp),%eax
801011c7:	83 c4 10             	add    $0x10,%esp
801011ca:	39 d8                	cmp    %ebx,%eax
801011cc:	75 5d                	jne    8010122b <filewrite+0xcb>
        panic("short filewrite");
      i += r;
801011ce:	01 c6                	add    %eax,%esi
    while(i < n){
801011d0:	39 75 e4             	cmp    %esi,-0x1c(%ebp)
801011d3:	7e 6b                	jle    80101240 <filewrite+0xe0>
      int n1 = n - i;
801011d5:	8b 5d e4             	mov    -0x1c(%ebp),%ebx
      if(n1 > max)
801011d8:	b8 00 06 00 00       	mov    $0x600,%eax
      int n1 = n - i;
801011dd:	29 f3                	sub    %esi,%ebx
      if(n1 > max)
801011df:	39 c3                	cmp    %eax,%ebx
801011e1:	0f 4f d8             	cmovg  %eax,%ebx
      begin_op();
801011e4:	e8 57 1d 00 00       	call   80102f40 <begin_op>
      ilock(f->ip);
801011e9:	83 ec 0c             	sub    $0xc,%esp
801011ec:	ff 77 10             	push   0x10(%edi)
801011ef:	e8 6c 06 00 00       	call   80101860 <ilock>
      if ((r = writei(f->ip, addr + i, f->off, n1)) > 0)
801011f4:	8b 45 dc             	mov    -0x24(%ebp),%eax
801011f7:	53                   	push   %ebx
801011f8:	ff 77 14             	push   0x14(%edi)
801011fb:	01 f0                	add    %esi,%eax
801011fd:	50                   	push   %eax
801011fe:	ff 77 10             	push   0x10(%edi)
80101201:	e8 aa 0a 00 00       	call   80101cb0 <writei>
      iunlock(f->ip);
80101206:	8b 4f 10             	mov    0x10(%edi),%ecx
      if ((r = writei(f->ip, addr + i, f->off, n1)) > 0)
80101209:	83 c4 20             	add    $0x20,%esp
8010120c:	85 c0                	test   %eax,%eax
8010120e:	7f a0                	jg     801011b0 <filewrite+0x50>
      iunlock(f->ip);
80101210:	83 ec 0c             	sub    $0xc,%esp
80101213:	89 45 e0             	mov    %eax,-0x20(%ebp)
80101216:	51                   	push   %ecx
80101217:	e8 24 07 00 00       	call   80101940 <iunlock>
      end_op();
8010121c:	e8 8f 1d 00 00       	call   80102fb0 <end_op>
      if(r < 0)
80101221:	8b 45 e0             	mov    -0x20(%ebp),%eax
80101224:	83 c4 10             	add    $0x10,%esp
80101227:	85 c0                	test   %eax,%eax
80101229:	75 15                	jne    80101240 <filewrite+0xe0>
        panic("short filewrite");
8010122b:	83 ec 0c             	sub    $0xc,%esp
8010122e:	68 de 79 10 80       	push   $0x801079de
80101233:	e8 68 f1 ff ff       	call   801003a0 <panic>
80101238:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010123f:	00 
80101240:	8b 5d f4             	mov    -0xc(%ebp),%ebx
    return -1;
80101243:	39 75 e4             	cmp    %esi,-0x1c(%ebp)
80101246:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010124b:	0f 45 f0             	cmovne %eax,%esi
    }
    return i == n ? n : -1;
  }
  panic("filewrite");
}
8010124e:	89 f0                	mov    %esi,%eax
80101250:	8b 7d fc             	mov    -0x4(%ebp),%edi
80101253:	8b 75 f8             	mov    -0x8(%ebp),%esi
80101256:	c9                   	leave
80101257:	c3                   	ret
    return pipewrite(f->pipe, addr, n);
80101258:	8b 47 0c             	mov    0xc(%edi),%eax
}
8010125b:	8b 75 f8             	mov    -0x8(%ebp),%esi
8010125e:	8b 7d fc             	mov    -0x4(%ebp),%edi
    return pipewrite(f->pipe, addr, n);
80101261:	89 45 08             	mov    %eax,0x8(%ebp)
}
80101264:	c9                   	leave
    return pipewrite(f->pipe, addr, n);
80101265:	e9 36 25 00 00       	jmp    801037a0 <pipewrite>
    int i = 0;
8010126a:	31 f6                	xor    %esi,%esi
8010126c:	eb d5                	jmp    80101243 <filewrite+0xe3>
    return -1;
8010126e:	be ff ff ff ff       	mov    $0xffffffff,%esi
80101273:	eb d9                	jmp    8010124e <filewrite+0xee>
  panic("filewrite");
80101275:	83 ec 0c             	sub    $0xc,%esp
80101278:	89 5d f4             	mov    %ebx,-0xc(%ebp)
8010127b:	68 e4 79 10 80       	push   $0x801079e4
80101280:	e8 1b f1 ff ff       	call   801003a0 <panic>
80101285:	66 90                	xchg   %ax,%ax
80101287:	66 90                	xchg   %ax,%ax
80101289:	66 90                	xchg   %ax,%ax
8010128b:	66 90                	xchg   %ax,%ax
8010128d:	66 90                	xchg   %ax,%ax
8010128f:	90                   	nop

80101290 <balloc>:
// Blocks.

// Allocate a zeroed disk block.
static uint
balloc(uint dev)
{
80101290:	55                   	push   %ebp
80101291:	89 e5                	mov    %esp,%ebp
80101293:	57                   	push   %edi
80101294:	56                   	push   %esi
80101295:	53                   	push   %ebx
80101296:	83 ec 1c             	sub    $0x1c,%esp
  int b, bi, m;
  struct buf *bp;

  bp = 0;
  for(b = 0; b < sb.size; b += BPB){
80101299:	8b 0d d4 25 11 80    	mov    0x801125d4,%ecx
{
8010129f:	89 45 dc             	mov    %eax,-0x24(%ebp)
  for(b = 0; b < sb.size; b += BPB){
801012a2:	85 c9                	test   %ecx,%ecx
801012a4:	0f 84 8a 00 00 00    	je     80101334 <balloc+0xa4>
801012aa:	31 ff                	xor    %edi,%edi
    bp = bread(dev, BBLOCK(b, sb));
801012ac:	89 f8                	mov    %edi,%eax
801012ae:	83 ec 08             	sub    $0x8,%esp
801012b1:	89 fe                	mov    %edi,%esi
801012b3:	c1 f8 0c             	sar    $0xc,%eax
801012b6:	03 05 ec 25 11 80    	add    0x801125ec,%eax
801012bc:	50                   	push   %eax
801012bd:	ff 75 dc             	push   -0x24(%ebp)
801012c0:	e8 0b ee ff ff       	call   801000d0 <bread>
801012c5:	83 c4 10             	add    $0x10,%esp
801012c8:	89 7d d8             	mov    %edi,-0x28(%ebp)
801012cb:	89 45 e4             	mov    %eax,-0x1c(%ebp)
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
801012ce:	a1 d4 25 11 80       	mov    0x801125d4,%eax
801012d3:	89 45 e0             	mov    %eax,-0x20(%ebp)
801012d6:	31 c0                	xor    %eax,%eax
801012d8:	eb 32                	jmp    8010130c <balloc+0x7c>
801012da:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      m = 1 << (bi % 8);
801012e0:	89 c1                	mov    %eax,%ecx
801012e2:	bb 01 00 00 00       	mov    $0x1,%ebx
      if((bp->data[bi/8] & m) == 0){  // Is block free?
801012e7:	8b 7d e4             	mov    -0x1c(%ebp),%edi
      m = 1 << (bi % 8);
801012ea:	83 e1 07             	and    $0x7,%ecx
801012ed:	d3 e3                	shl    %cl,%ebx
      if((bp->data[bi/8] & m) == 0){  // Is block free?
801012ef:	89 c1                	mov    %eax,%ecx
801012f1:	c1 f9 03             	sar    $0x3,%ecx
801012f4:	0f b6 7c 0f 5c       	movzbl 0x5c(%edi,%ecx,1),%edi
801012f9:	89 fa                	mov    %edi,%edx
801012fb:	85 df                	test   %ebx,%edi
801012fd:	74 49                	je     80101348 <balloc+0xb8>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
801012ff:	83 c0 01             	add    $0x1,%eax
80101302:	83 c6 01             	add    $0x1,%esi
80101305:	3d 00 10 00 00       	cmp    $0x1000,%eax
8010130a:	74 05                	je     80101311 <balloc+0x81>
8010130c:	3b 75 e0             	cmp    -0x20(%ebp),%esi
8010130f:	72 cf                	jb     801012e0 <balloc+0x50>
        brelse(bp);
        bzero(dev, b + bi);
        return b + bi;
      }
    }
    brelse(bp);
80101311:	8b 7d d8             	mov    -0x28(%ebp),%edi
80101314:	83 ec 0c             	sub    $0xc,%esp
80101317:	ff 75 e4             	push   -0x1c(%ebp)
  for(b = 0; b < sb.size; b += BPB){
8010131a:	81 c7 00 10 00 00    	add    $0x1000,%edi
    brelse(bp);
80101320:	e8 db ee ff ff       	call   80100200 <brelse>
  for(b = 0; b < sb.size; b += BPB){
80101325:	83 c4 10             	add    $0x10,%esp
80101328:	3b 3d d4 25 11 80    	cmp    0x801125d4,%edi
8010132e:	0f 82 78 ff ff ff    	jb     801012ac <balloc+0x1c>
  }
  panic("balloc: out of blocks");
80101334:	83 ec 0c             	sub    $0xc,%esp
80101337:	68 ee 79 10 80       	push   $0x801079ee
8010133c:	e8 5f f0 ff ff       	call   801003a0 <panic>
80101341:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
        bp->data[bi/8] |= m;  // Mark block in use.
80101348:	8b 7d e4             	mov    -0x1c(%ebp),%edi
        log_write(bp);
8010134b:	83 ec 0c             	sub    $0xc,%esp
        bp->data[bi/8] |= m;  // Mark block in use.
8010134e:	09 da                	or     %ebx,%edx
80101350:	88 54 0f 5c          	mov    %dl,0x5c(%edi,%ecx,1)
        log_write(bp);
80101354:	57                   	push   %edi
80101355:	e8 c6 1d 00 00       	call   80103120 <log_write>
        brelse(bp);
8010135a:	89 3c 24             	mov    %edi,(%esp)
8010135d:	e8 9e ee ff ff       	call   80100200 <brelse>
  bp = bread(dev, bno);
80101362:	58                   	pop    %eax
80101363:	5a                   	pop    %edx
80101364:	56                   	push   %esi
80101365:	ff 75 dc             	push   -0x24(%ebp)
80101368:	e8 63 ed ff ff       	call   801000d0 <bread>
  memset(bp->data, 0, BSIZE);
8010136d:	83 c4 0c             	add    $0xc,%esp
  bp = bread(dev, bno);
80101370:	89 c3                	mov    %eax,%ebx
  memset(bp->data, 0, BSIZE);
80101372:	8d 40 5c             	lea    0x5c(%eax),%eax
80101375:	68 00 02 00 00       	push   $0x200
8010137a:	6a 00                	push   $0x0
8010137c:	50                   	push   %eax
8010137d:	e8 de 36 00 00       	call   80104a60 <memset>
  log_write(bp);
80101382:	89 1c 24             	mov    %ebx,(%esp)
80101385:	e8 96 1d 00 00       	call   80103120 <log_write>
  brelse(bp);
8010138a:	89 1c 24             	mov    %ebx,(%esp)
8010138d:	e8 6e ee ff ff       	call   80100200 <brelse>
}
80101392:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101395:	89 f0                	mov    %esi,%eax
80101397:	5b                   	pop    %ebx
80101398:	5e                   	pop    %esi
80101399:	5f                   	pop    %edi
8010139a:	5d                   	pop    %ebp
8010139b:	c3                   	ret
8010139c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

801013a0 <iget>:
// Find the inode with number inum on device dev
// and return the in-memory copy. Does not lock
// the inode and does not read it from disk.
static struct inode*
iget(uint dev, uint inum)
{
801013a0:	55                   	push   %ebp
801013a1:	89 e5                	mov    %esp,%ebp
801013a3:	57                   	push   %edi
801013a4:	89 d7                	mov    %edx,%edi
801013a6:	56                   	push   %esi
801013a7:	89 c6                	mov    %eax,%esi
801013a9:	53                   	push   %ebx
  struct inode *ip, *empty;

  acquire(&icache.lock);

  // Is the inode already cached?
  empty = 0;
801013aa:	31 db                	xor    %ebx,%ebx
{
801013ac:	83 ec 28             	sub    $0x28,%esp
  acquire(&icache.lock);
801013af:	68 80 09 11 80       	push   $0x80110980
801013b4:	e8 87 35 00 00       	call   80104940 <acquire>
801013b9:	83 c4 10             	add    $0x10,%esp
  for(ip = &icache.inode[0]; ip < &icache.inode[NINODE]; ip++){
801013bc:	b8 b4 09 11 80       	mov    $0x801109b4,%eax
801013c1:	eb 15                	jmp    801013d8 <iget+0x38>
801013c3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
801013c8:	39 30                	cmp    %esi,(%eax)
801013ca:	74 6c                	je     80101438 <iget+0x98>
  for(ip = &icache.inode[0]; ip < &icache.inode[NINODE]; ip++){
801013cc:	05 90 00 00 00       	add    $0x90,%eax
801013d1:	3d d4 25 11 80       	cmp    $0x801125d4,%eax
801013d6:	74 28                	je     80101400 <iget+0x60>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
801013d8:	8b 50 08             	mov    0x8(%eax),%edx
801013db:	85 d2                	test   %edx,%edx
801013dd:	7f e9                	jg     801013c8 <iget+0x28>
      ip->ref++;
      release(&icache.lock);
      return ip;
    }
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
801013df:	85 db                	test   %ebx,%ebx
801013e1:	75 e9                	jne    801013cc <iget+0x2c>
801013e3:	85 d2                	test   %edx,%edx
801013e5:	75 7c                	jne    80101463 <iget+0xc3>
      empty = ip;
801013e7:	89 c3                	mov    %eax,%ebx
  for(ip = &icache.inode[0]; ip < &icache.inode[NINODE]; ip++){
801013e9:	05 90 00 00 00       	add    $0x90,%eax
801013ee:	3d d4 25 11 80       	cmp    $0x801125d4,%eax
801013f3:	75 e3                	jne    801013d8 <iget+0x38>
801013f5:	8d 76 00             	lea    0x0(%esi),%esi
801013f8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801013ff:	00 
  }

  // Recycle an inode cache entry.
  if(empty == 0)
80101400:	85 db                	test   %ebx,%ebx
80101402:	74 7b                	je     8010147f <iget+0xdf>
  ip = empty;
  ip->dev = dev;
  ip->inum = inum;
  ip->ref = 1;
  ip->valid = 0;
  release(&icache.lock);
80101404:	83 ec 0c             	sub    $0xc,%esp
  ip->dev = dev;
80101407:	89 33                	mov    %esi,(%ebx)
  ip->inum = inum;
80101409:	89 7b 04             	mov    %edi,0x4(%ebx)
  ip->ref = 1;
8010140c:	c7 43 08 01 00 00 00 	movl   $0x1,0x8(%ebx)
  ip->valid = 0;
80101413:	c7 43 4c 00 00 00 00 	movl   $0x0,0x4c(%ebx)
  release(&icache.lock);
8010141a:	68 80 09 11 80       	push   $0x80110980
8010141f:	e8 bc 34 00 00       	call   801048e0 <release>

  return ip;
80101424:	83 c4 10             	add    $0x10,%esp
}
80101427:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010142a:	89 d8                	mov    %ebx,%eax
8010142c:	5b                   	pop    %ebx
8010142d:	5e                   	pop    %esi
8010142e:	5f                   	pop    %edi
8010142f:	5d                   	pop    %ebp
80101430:	c3                   	ret
80101431:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
80101438:	39 78 04             	cmp    %edi,0x4(%eax)
8010143b:	75 8f                	jne    801013cc <iget+0x2c>
      release(&icache.lock);
8010143d:	83 ec 0c             	sub    $0xc,%esp
      ip->ref++;
80101440:	83 c2 01             	add    $0x1,%edx
80101443:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80101446:	89 50 08             	mov    %edx,0x8(%eax)
      release(&icache.lock);
80101449:	68 80 09 11 80       	push   $0x80110980
8010144e:	e8 8d 34 00 00       	call   801048e0 <release>
      return ip;
80101453:	8b 5d e4             	mov    -0x1c(%ebp),%ebx
80101456:	83 c4 10             	add    $0x10,%esp
}
80101459:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010145c:	89 d8                	mov    %ebx,%eax
8010145e:	5b                   	pop    %ebx
8010145f:	5e                   	pop    %esi
80101460:	5f                   	pop    %edi
80101461:	5d                   	pop    %ebp
80101462:	c3                   	ret
  for(ip = &icache.inode[0]; ip < &icache.inode[NINODE]; ip++){
80101463:	05 90 00 00 00       	add    $0x90,%eax
80101468:	3d d4 25 11 80       	cmp    $0x801125d4,%eax
8010146d:	74 10                	je     8010147f <iget+0xdf>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
8010146f:	8b 50 08             	mov    0x8(%eax),%edx
80101472:	85 d2                	test   %edx,%edx
80101474:	0f 8f 4e ff ff ff    	jg     801013c8 <iget+0x28>
8010147a:	e9 64 ff ff ff       	jmp    801013e3 <iget+0x43>
    panic("iget: no inodes");
8010147f:	83 ec 0c             	sub    $0xc,%esp
80101482:	68 04 7a 10 80       	push   $0x80107a04
80101487:	e8 14 ef ff ff       	call   801003a0 <panic>
8010148c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80101490 <bfree>:
{
80101490:	55                   	push   %ebp
80101491:	89 c1                	mov    %eax,%ecx
  bp = bread(dev, BBLOCK(b, sb));
80101493:	89 d0                	mov    %edx,%eax
80101495:	c1 e8 0c             	shr    $0xc,%eax
{
80101498:	89 e5                	mov    %esp,%ebp
8010149a:	56                   	push   %esi
8010149b:	53                   	push   %ebx
  bp = bread(dev, BBLOCK(b, sb));
8010149c:	03 05 ec 25 11 80    	add    0x801125ec,%eax
{
801014a2:	89 d3                	mov    %edx,%ebx
  bp = bread(dev, BBLOCK(b, sb));
801014a4:	83 ec 08             	sub    $0x8,%esp
801014a7:	50                   	push   %eax
801014a8:	51                   	push   %ecx
801014a9:	e8 22 ec ff ff       	call   801000d0 <bread>
  m = 1 << (bi % 8);
801014ae:	89 d9                	mov    %ebx,%ecx
  if((bp->data[bi/8] & m) == 0)
801014b0:	c1 fb 03             	sar    $0x3,%ebx
801014b3:	83 c4 10             	add    $0x10,%esp
  bp = bread(dev, BBLOCK(b, sb));
801014b6:	89 c6                	mov    %eax,%esi
  m = 1 << (bi % 8);
801014b8:	83 e1 07             	and    $0x7,%ecx
801014bb:	b8 01 00 00 00       	mov    $0x1,%eax
  if((bp->data[bi/8] & m) == 0)
801014c0:	81 e3 ff 01 00 00    	and    $0x1ff,%ebx
  m = 1 << (bi % 8);
801014c6:	d3 e0                	shl    %cl,%eax
  if((bp->data[bi/8] & m) == 0)
801014c8:	0f b6 4c 1e 5c       	movzbl 0x5c(%esi,%ebx,1),%ecx
801014cd:	85 c1                	test   %eax,%ecx
801014cf:	74 23                	je     801014f4 <bfree+0x64>
  bp->data[bi/8] &= ~m;
801014d1:	f7 d0                	not    %eax
  log_write(bp);
801014d3:	83 ec 0c             	sub    $0xc,%esp
  bp->data[bi/8] &= ~m;
801014d6:	21 c8                	and    %ecx,%eax
801014d8:	88 44 1e 5c          	mov    %al,0x5c(%esi,%ebx,1)
  log_write(bp);
801014dc:	56                   	push   %esi
801014dd:	e8 3e 1c 00 00       	call   80103120 <log_write>
  brelse(bp);
801014e2:	89 34 24             	mov    %esi,(%esp)
801014e5:	e8 16 ed ff ff       	call   80100200 <brelse>
}
801014ea:	83 c4 10             	add    $0x10,%esp
801014ed:	8d 65 f8             	lea    -0x8(%ebp),%esp
801014f0:	5b                   	pop    %ebx
801014f1:	5e                   	pop    %esi
801014f2:	5d                   	pop    %ebp
801014f3:	c3                   	ret
    panic("freeing free block");
801014f4:	83 ec 0c             	sub    $0xc,%esp
801014f7:	68 14 7a 10 80       	push   $0x80107a14
801014fc:	e8 9f ee ff ff       	call   801003a0 <panic>
80101501:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80101508:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010150f:	00 

80101510 <bmap>:

// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
static uint
bmap(struct inode *ip, uint bn)
{
80101510:	55                   	push   %ebp
80101511:	89 e5                	mov    %esp,%ebp
80101513:	56                   	push   %esi
80101514:	89 c6                	mov    %eax,%esi
80101516:	53                   	push   %ebx
80101517:	83 ec 10             	sub    $0x10,%esp
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
8010151a:	83 fa 0b             	cmp    $0xb,%edx
8010151d:	0f 86 8d 00 00 00    	jbe    801015b0 <bmap+0xa0>
    if((addr = ip->addrs[bn]) == 0)
      ip->addrs[bn] = addr = balloc(ip->dev);
    return addr;
  }
  bn -= NDIRECT;
80101523:	8d 5a f4             	lea    -0xc(%edx),%ebx

  if(bn < NINDIRECT){
80101526:	83 fb 7f             	cmp    $0x7f,%ebx
80101529:	0f 87 a8 00 00 00    	ja     801015d7 <bmap+0xc7>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0)
8010152f:	8b 80 8c 00 00 00    	mov    0x8c(%eax),%eax
80101535:	85 c0                	test   %eax,%eax
80101537:	74 67                	je     801015a0 <bmap+0x90>
      ip->addrs[NDIRECT] = addr = balloc(ip->dev);
    bp = bread(ip->dev, addr);
80101539:	83 ec 08             	sub    $0x8,%esp
8010153c:	50                   	push   %eax
8010153d:	ff 36                	push   (%esi)
8010153f:	e8 8c eb ff ff       	call   801000d0 <bread>
    a = (uint*)bp->data;
    if((addr = a[bn]) == 0){
80101544:	83 c4 10             	add    $0x10,%esp
80101547:	8d 4c 98 5c          	lea    0x5c(%eax,%ebx,4),%ecx
    bp = bread(ip->dev, addr);
8010154b:	89 c2                	mov    %eax,%edx
    if((addr = a[bn]) == 0){
8010154d:	8b 19                	mov    (%ecx),%ebx
8010154f:	85 db                	test   %ebx,%ebx
80101551:	74 1d                	je     80101570 <bmap+0x60>
      a[bn] = addr = balloc(ip->dev);
      log_write(bp);
    }
    brelse(bp);
80101553:	83 ec 0c             	sub    $0xc,%esp
80101556:	52                   	push   %edx
80101557:	e8 a4 ec ff ff       	call   80100200 <brelse>
8010155c:	83 c4 10             	add    $0x10,%esp
    return addr;
  }

  panic("bmap: out of range");
}
8010155f:	8d 65 f8             	lea    -0x8(%ebp),%esp
80101562:	89 d8                	mov    %ebx,%eax
80101564:	5b                   	pop    %ebx
80101565:	5e                   	pop    %esi
80101566:	5d                   	pop    %ebp
80101567:	c3                   	ret
80101568:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010156f:	00 
80101570:	89 45 f4             	mov    %eax,-0xc(%ebp)
      a[bn] = addr = balloc(ip->dev);
80101573:	8b 06                	mov    (%esi),%eax
80101575:	89 4d f0             	mov    %ecx,-0x10(%ebp)
80101578:	e8 13 fd ff ff       	call   80101290 <balloc>
8010157d:	8b 4d f0             	mov    -0x10(%ebp),%ecx
      log_write(bp);
80101580:	8b 55 f4             	mov    -0xc(%ebp),%edx
80101583:	83 ec 0c             	sub    $0xc,%esp
      a[bn] = addr = balloc(ip->dev);
80101586:	89 c3                	mov    %eax,%ebx
80101588:	89 01                	mov    %eax,(%ecx)
      log_write(bp);
8010158a:	52                   	push   %edx
8010158b:	e8 90 1b 00 00       	call   80103120 <log_write>
80101590:	8b 55 f4             	mov    -0xc(%ebp),%edx
80101593:	83 c4 10             	add    $0x10,%esp
80101596:	eb bb                	jmp    80101553 <bmap+0x43>
80101598:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010159f:	00 
      ip->addrs[NDIRECT] = addr = balloc(ip->dev);
801015a0:	8b 06                	mov    (%esi),%eax
801015a2:	e8 e9 fc ff ff       	call   80101290 <balloc>
801015a7:	89 86 8c 00 00 00    	mov    %eax,0x8c(%esi)
801015ad:	eb 8a                	jmp    80101539 <bmap+0x29>
801015af:	90                   	nop
    if((addr = ip->addrs[bn]) == 0)
801015b0:	83 c2 14             	add    $0x14,%edx
801015b3:	8b 5c 90 0c          	mov    0xc(%eax,%edx,4),%ebx
801015b7:	85 db                	test   %ebx,%ebx
801015b9:	75 a4                	jne    8010155f <bmap+0x4f>
      ip->addrs[bn] = addr = balloc(ip->dev);
801015bb:	8b 00                	mov    (%eax),%eax
801015bd:	89 55 f4             	mov    %edx,-0xc(%ebp)
801015c0:	e8 cb fc ff ff       	call   80101290 <balloc>
801015c5:	8b 55 f4             	mov    -0xc(%ebp),%edx
801015c8:	89 c3                	mov    %eax,%ebx
801015ca:	89 44 96 0c          	mov    %eax,0xc(%esi,%edx,4)
}
801015ce:	8d 65 f8             	lea    -0x8(%ebp),%esp
801015d1:	89 d8                	mov    %ebx,%eax
801015d3:	5b                   	pop    %ebx
801015d4:	5e                   	pop    %esi
801015d5:	5d                   	pop    %ebp
801015d6:	c3                   	ret
  panic("bmap: out of range");
801015d7:	83 ec 0c             	sub    $0xc,%esp
801015da:	68 27 7a 10 80       	push   $0x80107a27
801015df:	e8 bc ed ff ff       	call   801003a0 <panic>
801015e4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
801015e8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801015ef:	00 

801015f0 <readsb>:
{
801015f0:	55                   	push   %ebp
801015f1:	89 e5                	mov    %esp,%ebp
801015f3:	56                   	push   %esi
801015f4:	53                   	push   %ebx
801015f5:	8b 75 0c             	mov    0xc(%ebp),%esi
  bp = bread(dev, 1);
801015f8:	83 ec 08             	sub    $0x8,%esp
801015fb:	6a 01                	push   $0x1
801015fd:	ff 75 08             	push   0x8(%ebp)
80101600:	e8 cb ea ff ff       	call   801000d0 <bread>
  memmove(sb, bp->data, sizeof(*sb));
80101605:	83 c4 0c             	add    $0xc,%esp
  bp = bread(dev, 1);
80101608:	89 c3                	mov    %eax,%ebx
  memmove(sb, bp->data, sizeof(*sb));
8010160a:	8d 40 5c             	lea    0x5c(%eax),%eax
8010160d:	6a 1c                	push   $0x1c
8010160f:	50                   	push   %eax
80101610:	56                   	push   %esi
80101611:	e8 ea 34 00 00       	call   80104b00 <memmove>
  brelse(bp);
80101616:	83 c4 10             	add    $0x10,%esp
80101619:	89 5d 08             	mov    %ebx,0x8(%ebp)
}
8010161c:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010161f:	5b                   	pop    %ebx
80101620:	5e                   	pop    %esi
80101621:	5d                   	pop    %ebp
  brelse(bp);
80101622:	e9 d9 eb ff ff       	jmp    80100200 <brelse>
80101627:	90                   	nop
80101628:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010162f:	00 

80101630 <iinit>:
{
80101630:	55                   	push   %ebp
80101631:	89 e5                	mov    %esp,%ebp
80101633:	53                   	push   %ebx
80101634:	bb c0 09 11 80       	mov    $0x801109c0,%ebx
80101639:	83 ec 0c             	sub    $0xc,%esp
  initlock(&icache.lock, "icache");
8010163c:	68 3a 7a 10 80       	push   $0x80107a3a
80101641:	68 80 09 11 80       	push   $0x80110980
80101646:	e8 d5 30 00 00       	call   80104720 <initlock>
  for(i = 0; i < NINODE; i++) {
8010164b:	83 c4 10             	add    $0x10,%esp
8010164e:	66 90                	xchg   %ax,%ax
    initsleeplock(&icache.inode[i].lock, "inode");
80101650:	83 ec 08             	sub    $0x8,%esp
80101653:	68 41 7a 10 80       	push   $0x80107a41
80101658:	53                   	push   %ebx
  for(i = 0; i < NINODE; i++) {
80101659:	81 c3 90 00 00 00    	add    $0x90,%ebx
    initsleeplock(&icache.inode[i].lock, "inode");
8010165f:	e8 8c 2f 00 00       	call   801045f0 <initsleeplock>
  for(i = 0; i < NINODE; i++) {
80101664:	83 c4 10             	add    $0x10,%esp
80101667:	81 fb e0 25 11 80    	cmp    $0x801125e0,%ebx
8010166d:	75 e1                	jne    80101650 <iinit+0x20>
  bp = bread(dev, 1);
8010166f:	83 ec 08             	sub    $0x8,%esp
80101672:	6a 01                	push   $0x1
80101674:	ff 75 08             	push   0x8(%ebp)
80101677:	e8 54 ea ff ff       	call   801000d0 <bread>
  memmove(sb, bp->data, sizeof(*sb));
8010167c:	83 c4 0c             	add    $0xc,%esp
  bp = bread(dev, 1);
8010167f:	89 c3                	mov    %eax,%ebx
  memmove(sb, bp->data, sizeof(*sb));
80101681:	8d 40 5c             	lea    0x5c(%eax),%eax
80101684:	6a 1c                	push   $0x1c
80101686:	50                   	push   %eax
80101687:	68 d4 25 11 80       	push   $0x801125d4
8010168c:	e8 6f 34 00 00       	call   80104b00 <memmove>
  brelse(bp);
80101691:	89 1c 24             	mov    %ebx,(%esp)
80101694:	e8 67 eb ff ff       	call   80100200 <brelse>
  cprintf("sb: size %d nblocks %d ninodes %d nlog %d logstart %d\
80101699:	ff 35 ec 25 11 80    	push   0x801125ec
8010169f:	ff 35 e8 25 11 80    	push   0x801125e8
801016a5:	ff 35 e4 25 11 80    	push   0x801125e4
801016ab:	ff 35 e0 25 11 80    	push   0x801125e0
801016b1:	ff 35 dc 25 11 80    	push   0x801125dc
801016b7:	ff 35 d8 25 11 80    	push   0x801125d8
801016bd:	ff 35 d4 25 11 80    	push   0x801125d4
801016c3:	68 54 7e 10 80       	push   $0x80107e54
801016c8:	e8 23 f0 ff ff       	call   801006f0 <cprintf>
}
801016cd:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801016d0:	83 c4 30             	add    $0x30,%esp
801016d3:	c9                   	leave
801016d4:	c3                   	ret
801016d5:	8d 76 00             	lea    0x0(%esi),%esi
801016d8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801016df:	00 

801016e0 <ialloc>:
{
801016e0:	55                   	push   %ebp
801016e1:	89 e5                	mov    %esp,%ebp
801016e3:	57                   	push   %edi
801016e4:	56                   	push   %esi
801016e5:	53                   	push   %ebx
801016e6:	83 ec 1c             	sub    $0x1c,%esp
801016e9:	0f b7 45 0c          	movzwl 0xc(%ebp),%eax
801016ed:	8b 75 08             	mov    0x8(%ebp),%esi
801016f0:	66 89 45 e6          	mov    %ax,-0x1a(%ebp)
  for(inum = 1; inum < sb.ninodes; inum++){
801016f4:	83 3d dc 25 11 80 01 	cmpl   $0x1,0x801125dc
801016fb:	0f 86 8f 00 00 00    	jbe    80101790 <ialloc+0xb0>
80101701:	bf 01 00 00 00       	mov    $0x1,%edi
80101706:	eb 1f                	jmp    80101727 <ialloc+0x47>
80101708:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010170f:	00 
    brelse(bp);
80101710:	83 ec 0c             	sub    $0xc,%esp
  for(inum = 1; inum < sb.ninodes; inum++){
80101713:	83 c7 01             	add    $0x1,%edi
    brelse(bp);
80101716:	53                   	push   %ebx
80101717:	e8 e4 ea ff ff       	call   80100200 <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
8010171c:	83 c4 10             	add    $0x10,%esp
8010171f:	3b 3d dc 25 11 80    	cmp    0x801125dc,%edi
80101725:	73 69                	jae    80101790 <ialloc+0xb0>
    bp = bread(dev, IBLOCK(inum, sb));
80101727:	89 f8                	mov    %edi,%eax
80101729:	83 ec 08             	sub    $0x8,%esp
8010172c:	c1 e8 03             	shr    $0x3,%eax
8010172f:	03 05 e8 25 11 80    	add    0x801125e8,%eax
80101735:	50                   	push   %eax
80101736:	56                   	push   %esi
80101737:	e8 94 e9 ff ff       	call   801000d0 <bread>
    if(dip->type == 0){  // a free inode
8010173c:	83 c4 10             	add    $0x10,%esp
    bp = bread(dev, IBLOCK(inum, sb));
8010173f:	89 c3                	mov    %eax,%ebx
    dip = (struct dinode*)bp->data + inum%IPB;
80101741:	89 f8                	mov    %edi,%eax
80101743:	83 e0 07             	and    $0x7,%eax
80101746:	c1 e0 06             	shl    $0x6,%eax
80101749:	8d 4c 03 5c          	lea    0x5c(%ebx,%eax,1),%ecx
    if(dip->type == 0){  // a free inode
8010174d:	66 83 39 00          	cmpw   $0x0,(%ecx)
80101751:	75 bd                	jne    80101710 <ialloc+0x30>
      memset(dip, 0, sizeof(*dip));
80101753:	83 ec 04             	sub    $0x4,%esp
80101756:	6a 40                	push   $0x40
80101758:	6a 00                	push   $0x0
8010175a:	51                   	push   %ecx
8010175b:	89 4d e0             	mov    %ecx,-0x20(%ebp)
8010175e:	e8 fd 32 00 00       	call   80104a60 <memset>
      dip->type = type;
80101763:	0f b7 45 e6          	movzwl -0x1a(%ebp),%eax
80101767:	8b 4d e0             	mov    -0x20(%ebp),%ecx
8010176a:	66 89 01             	mov    %ax,(%ecx)
      log_write(bp);   // mark it allocated on the disk
8010176d:	89 1c 24             	mov    %ebx,(%esp)
80101770:	e8 ab 19 00 00       	call   80103120 <log_write>
      brelse(bp);
80101775:	89 1c 24             	mov    %ebx,(%esp)
80101778:	e8 83 ea ff ff       	call   80100200 <brelse>
      return iget(dev, inum);
8010177d:	83 c4 10             	add    $0x10,%esp
}
80101780:	8d 65 f4             	lea    -0xc(%ebp),%esp
      return iget(dev, inum);
80101783:	89 fa                	mov    %edi,%edx
}
80101785:	5b                   	pop    %ebx
      return iget(dev, inum);
80101786:	89 f0                	mov    %esi,%eax
}
80101788:	5e                   	pop    %esi
80101789:	5f                   	pop    %edi
8010178a:	5d                   	pop    %ebp
      return iget(dev, inum);
8010178b:	e9 10 fc ff ff       	jmp    801013a0 <iget>
  panic("ialloc: no inodes");
80101790:	83 ec 0c             	sub    $0xc,%esp
80101793:	68 47 7a 10 80       	push   $0x80107a47
80101798:	e8 03 ec ff ff       	call   801003a0 <panic>
8010179d:	8d 76 00             	lea    0x0(%esi),%esi

801017a0 <iupdate>:
{
801017a0:	55                   	push   %ebp
801017a1:	89 e5                	mov    %esp,%ebp
801017a3:	56                   	push   %esi
801017a4:	53                   	push   %ebx
801017a5:	8b 5d 08             	mov    0x8(%ebp),%ebx
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
801017a8:	8b 43 04             	mov    0x4(%ebx),%eax
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
801017ab:	83 c3 5c             	add    $0x5c,%ebx
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
801017ae:	83 ec 08             	sub    $0x8,%esp
801017b1:	c1 e8 03             	shr    $0x3,%eax
801017b4:	03 05 e8 25 11 80    	add    0x801125e8,%eax
801017ba:	50                   	push   %eax
801017bb:	ff 73 a4             	push   -0x5c(%ebx)
801017be:	e8 0d e9 ff ff       	call   801000d0 <bread>
  dip->type = ip->type;
801017c3:	0f b7 53 f4          	movzwl -0xc(%ebx),%edx
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
801017c7:	83 c4 0c             	add    $0xc,%esp
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
801017ca:	89 c6                	mov    %eax,%esi
  dip = (struct dinode*)bp->data + ip->inum%IPB;
801017cc:	8b 43 a8             	mov    -0x58(%ebx),%eax
801017cf:	83 e0 07             	and    $0x7,%eax
801017d2:	c1 e0 06             	shl    $0x6,%eax
  dip->type = ip->type;
801017d5:	66 89 54 06 5c       	mov    %dx,0x5c(%esi,%eax,1)
  dip->major = ip->major;
801017da:	0f b7 53 f6          	movzwl -0xa(%ebx),%edx
801017de:	66 89 54 06 5e       	mov    %dx,0x5e(%esi,%eax,1)
  dip->minor = ip->minor;
801017e3:	0f b7 53 f8          	movzwl -0x8(%ebx),%edx
801017e7:	66 89 54 06 60       	mov    %dx,0x60(%esi,%eax,1)
  dip->nlink = ip->nlink;
801017ec:	0f b7 53 fa          	movzwl -0x6(%ebx),%edx
801017f0:	66 89 54 06 62       	mov    %dx,0x62(%esi,%eax,1)
  dip->size = ip->size;
801017f5:	8b 53 fc             	mov    -0x4(%ebx),%edx
801017f8:	89 54 06 64          	mov    %edx,0x64(%esi,%eax,1)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
801017fc:	8d 44 06 68          	lea    0x68(%esi,%eax,1),%eax
80101800:	6a 34                	push   $0x34
80101802:	53                   	push   %ebx
80101803:	50                   	push   %eax
80101804:	e8 f7 32 00 00       	call   80104b00 <memmove>
  log_write(bp);
80101809:	89 34 24             	mov    %esi,(%esp)
8010180c:	e8 0f 19 00 00       	call   80103120 <log_write>
  brelse(bp);
80101811:	83 c4 10             	add    $0x10,%esp
80101814:	89 75 08             	mov    %esi,0x8(%ebp)
}
80101817:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010181a:	5b                   	pop    %ebx
8010181b:	5e                   	pop    %esi
8010181c:	5d                   	pop    %ebp
  brelse(bp);
8010181d:	e9 de e9 ff ff       	jmp    80100200 <brelse>
80101822:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80101828:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010182f:	00 

80101830 <idup>:
{
80101830:	55                   	push   %ebp
80101831:	89 e5                	mov    %esp,%ebp
80101833:	53                   	push   %ebx
80101834:	83 ec 10             	sub    $0x10,%esp
80101837:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&icache.lock);
8010183a:	68 80 09 11 80       	push   $0x80110980
8010183f:	e8 fc 30 00 00       	call   80104940 <acquire>
  ip->ref++;
80101844:	83 43 08 01          	addl   $0x1,0x8(%ebx)
  release(&icache.lock);
80101848:	c7 04 24 80 09 11 80 	movl   $0x80110980,(%esp)
8010184f:	e8 8c 30 00 00       	call   801048e0 <release>
}
80101854:	89 d8                	mov    %ebx,%eax
80101856:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80101859:	c9                   	leave
8010185a:	c3                   	ret
8010185b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80101860 <ilock>:
{
80101860:	55                   	push   %ebp
80101861:	89 e5                	mov    %esp,%ebp
80101863:	53                   	push   %ebx
80101864:	83 ec 14             	sub    $0x14,%esp
80101867:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(ip == 0 || ip->ref < 1)
8010186a:	85 db                	test   %ebx,%ebx
8010186c:	0f 84 bb 00 00 00    	je     8010192d <ilock+0xcd>
80101872:	8b 53 08             	mov    0x8(%ebx),%edx
80101875:	85 d2                	test   %edx,%edx
80101877:	0f 8e b0 00 00 00    	jle    8010192d <ilock+0xcd>
  acquiresleep(&ip->lock);
8010187d:	83 ec 0c             	sub    $0xc,%esp
80101880:	8d 43 0c             	lea    0xc(%ebx),%eax
80101883:	50                   	push   %eax
80101884:	e8 a7 2d 00 00       	call   80104630 <acquiresleep>
  if(ip->valid == 0){
80101889:	8b 43 4c             	mov    0x4c(%ebx),%eax
8010188c:	83 c4 10             	add    $0x10,%esp
8010188f:	85 c0                	test   %eax,%eax
80101891:	74 0d                	je     801018a0 <ilock+0x40>
}
80101893:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80101896:	c9                   	leave
80101897:	c3                   	ret
80101898:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010189f:	00 
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
801018a0:	8b 43 04             	mov    0x4(%ebx),%eax
801018a3:	83 ec 08             	sub    $0x8,%esp
801018a6:	c1 e8 03             	shr    $0x3,%eax
801018a9:	03 05 e8 25 11 80    	add    0x801125e8,%eax
801018af:	50                   	push   %eax
801018b0:	ff 33                	push   (%ebx)
801018b2:	e8 19 e8 ff ff       	call   801000d0 <bread>
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
801018b7:	83 c4 0c             	add    $0xc,%esp
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
801018ba:	89 c2                	mov    %eax,%edx
    dip = (struct dinode*)bp->data + ip->inum%IPB;
801018bc:	8b 43 04             	mov    0x4(%ebx),%eax
801018bf:	89 55 f4             	mov    %edx,-0xc(%ebp)
801018c2:	83 e0 07             	and    $0x7,%eax
801018c5:	c1 e0 06             	shl    $0x6,%eax
801018c8:	8d 44 02 5c          	lea    0x5c(%edx,%eax,1),%eax
    ip->type = dip->type;
801018cc:	0f b7 08             	movzwl (%eax),%ecx
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
801018cf:	83 c0 0c             	add    $0xc,%eax
    ip->type = dip->type;
801018d2:	66 89 4b 50          	mov    %cx,0x50(%ebx)
    ip->major = dip->major;
801018d6:	0f b7 48 f6          	movzwl -0xa(%eax),%ecx
801018da:	66 89 4b 52          	mov    %cx,0x52(%ebx)
    ip->minor = dip->minor;
801018de:	0f b7 48 f8          	movzwl -0x8(%eax),%ecx
801018e2:	66 89 4b 54          	mov    %cx,0x54(%ebx)
    ip->nlink = dip->nlink;
801018e6:	0f b7 48 fa          	movzwl -0x6(%eax),%ecx
801018ea:	66 89 4b 56          	mov    %cx,0x56(%ebx)
    ip->size = dip->size;
801018ee:	8b 48 fc             	mov    -0x4(%eax),%ecx
801018f1:	89 4b 58             	mov    %ecx,0x58(%ebx)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
801018f4:	6a 34                	push   $0x34
801018f6:	50                   	push   %eax
801018f7:	8d 43 5c             	lea    0x5c(%ebx),%eax
801018fa:	50                   	push   %eax
801018fb:	e8 00 32 00 00       	call   80104b00 <memmove>
    brelse(bp);
80101900:	8b 55 f4             	mov    -0xc(%ebp),%edx
80101903:	89 14 24             	mov    %edx,(%esp)
80101906:	e8 f5 e8 ff ff       	call   80100200 <brelse>
    ip->valid = 1;
8010190b:	c7 43 4c 01 00 00 00 	movl   $0x1,0x4c(%ebx)
    if(ip->type == 0)
80101912:	83 c4 10             	add    $0x10,%esp
80101915:	66 83 7b 50 00       	cmpw   $0x0,0x50(%ebx)
8010191a:	0f 85 73 ff ff ff    	jne    80101893 <ilock+0x33>
      panic("ilock: no type");
80101920:	83 ec 0c             	sub    $0xc,%esp
80101923:	68 5f 7a 10 80       	push   $0x80107a5f
80101928:	e8 73 ea ff ff       	call   801003a0 <panic>
    panic("ilock");
8010192d:	83 ec 0c             	sub    $0xc,%esp
80101930:	68 59 7a 10 80       	push   $0x80107a59
80101935:	e8 66 ea ff ff       	call   801003a0 <panic>
8010193a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80101940 <iunlock>:
{
80101940:	55                   	push   %ebp
80101941:	89 e5                	mov    %esp,%ebp
80101943:	56                   	push   %esi
80101944:	53                   	push   %ebx
80101945:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
80101948:	85 db                	test   %ebx,%ebx
8010194a:	74 28                	je     80101974 <iunlock+0x34>
8010194c:	83 ec 0c             	sub    $0xc,%esp
8010194f:	8d 73 0c             	lea    0xc(%ebx),%esi
80101952:	56                   	push   %esi
80101953:	e8 78 2d 00 00       	call   801046d0 <holdingsleep>
80101958:	83 c4 10             	add    $0x10,%esp
8010195b:	85 c0                	test   %eax,%eax
8010195d:	74 15                	je     80101974 <iunlock+0x34>
8010195f:	8b 43 08             	mov    0x8(%ebx),%eax
80101962:	85 c0                	test   %eax,%eax
80101964:	7e 0e                	jle    80101974 <iunlock+0x34>
  releasesleep(&ip->lock);
80101966:	89 75 08             	mov    %esi,0x8(%ebp)
}
80101969:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010196c:	5b                   	pop    %ebx
8010196d:	5e                   	pop    %esi
8010196e:	5d                   	pop    %ebp
  releasesleep(&ip->lock);
8010196f:	e9 1c 2d 00 00       	jmp    80104690 <releasesleep>
    panic("iunlock");
80101974:	83 ec 0c             	sub    $0xc,%esp
80101977:	68 6e 7a 10 80       	push   $0x80107a6e
8010197c:	e8 1f ea ff ff       	call   801003a0 <panic>
80101981:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80101988:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010198f:	00 

80101990 <iput>:
{
80101990:	55                   	push   %ebp
80101991:	89 e5                	mov    %esp,%ebp
80101993:	83 ec 34             	sub    $0x34,%esp
80101996:	89 5d f4             	mov    %ebx,-0xc(%ebp)
80101999:	8b 5d 08             	mov    0x8(%ebp),%ebx
8010199c:	89 75 f8             	mov    %esi,-0x8(%ebp)
  acquiresleep(&ip->lock);
8010199f:	8d 73 0c             	lea    0xc(%ebx),%esi
801019a2:	56                   	push   %esi
801019a3:	e8 88 2c 00 00       	call   80104630 <acquiresleep>
  if(ip->valid && ip->nlink == 0){
801019a8:	8b 53 4c             	mov    0x4c(%ebx),%edx
801019ab:	83 c4 10             	add    $0x10,%esp
801019ae:	85 d2                	test   %edx,%edx
801019b0:	74 07                	je     801019b9 <iput+0x29>
801019b2:	66 83 7b 56 00       	cmpw   $0x0,0x56(%ebx)
801019b7:	74 37                	je     801019f0 <iput+0x60>
  releasesleep(&ip->lock);
801019b9:	83 ec 0c             	sub    $0xc,%esp
801019bc:	56                   	push   %esi
801019bd:	e8 ce 2c 00 00       	call   80104690 <releasesleep>
  acquire(&icache.lock);
801019c2:	c7 04 24 80 09 11 80 	movl   $0x80110980,(%esp)
801019c9:	e8 72 2f 00 00       	call   80104940 <acquire>
  ip->ref--;
801019ce:	83 6b 08 01          	subl   $0x1,0x8(%ebx)
  release(&icache.lock);
801019d2:	83 c4 10             	add    $0x10,%esp
}
801019d5:	8b 5d f4             	mov    -0xc(%ebp),%ebx
  release(&icache.lock);
801019d8:	c7 45 08 80 09 11 80 	movl   $0x80110980,0x8(%ebp)
}
801019df:	8b 75 f8             	mov    -0x8(%ebp),%esi
801019e2:	c9                   	leave
  release(&icache.lock);
801019e3:	e9 f8 2e 00 00       	jmp    801048e0 <release>
801019e8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801019ef:	00 
    acquire(&icache.lock);
801019f0:	83 ec 0c             	sub    $0xc,%esp
801019f3:	89 7d fc             	mov    %edi,-0x4(%ebp)
801019f6:	68 80 09 11 80       	push   $0x80110980
801019fb:	e8 40 2f 00 00       	call   80104940 <acquire>
    int r = ip->ref;
80101a00:	8b 7b 08             	mov    0x8(%ebx),%edi
    release(&icache.lock);
80101a03:	c7 04 24 80 09 11 80 	movl   $0x80110980,(%esp)
80101a0a:	e8 d1 2e 00 00       	call   801048e0 <release>
    if(r == 1){
80101a0f:	83 c4 10             	add    $0x10,%esp
80101a12:	83 ff 01             	cmp    $0x1,%edi
80101a15:	74 09                	je     80101a20 <iput+0x90>
80101a17:	8b 7d fc             	mov    -0x4(%ebp),%edi
80101a1a:	eb 9d                	jmp    801019b9 <iput+0x29>
80101a1c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80101a20:	89 f7                	mov    %esi,%edi
80101a22:	89 d9                	mov    %ebx,%ecx
80101a24:	8d b3 8c 00 00 00    	lea    0x8c(%ebx),%esi
80101a2a:	83 c3 5c             	add    $0x5c,%ebx
80101a2d:	eb 08                	jmp    80101a37 <iput+0xa7>
80101a2f:	90                   	nop
{
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
80101a30:	83 c3 04             	add    $0x4,%ebx
80101a33:	39 f3                	cmp    %esi,%ebx
80101a35:	74 21                	je     80101a58 <iput+0xc8>
    if(ip->addrs[i]){
80101a37:	8b 13                	mov    (%ebx),%edx
80101a39:	85 d2                	test   %edx,%edx
80101a3b:	74 f3                	je     80101a30 <iput+0xa0>
      bfree(ip->dev, ip->addrs[i]);
80101a3d:	8b 01                	mov    (%ecx),%eax
80101a3f:	89 4d e4             	mov    %ecx,-0x1c(%ebp)
80101a42:	e8 49 fa ff ff       	call   80101490 <bfree>
      ip->addrs[i] = 0;
80101a47:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
80101a4d:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
80101a50:	eb de                	jmp    80101a30 <iput+0xa0>
80101a52:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    }
  }

  if(ip->addrs[NDIRECT]){
80101a58:	8b 81 8c 00 00 00    	mov    0x8c(%ecx),%eax
80101a5e:	89 fe                	mov    %edi,%esi
80101a60:	89 cb                	mov    %ecx,%ebx
80101a62:	85 c0                	test   %eax,%eax
80101a64:	75 30                	jne    80101a96 <iput+0x106>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
  iupdate(ip);
80101a66:	83 ec 0c             	sub    $0xc,%esp
  ip->size = 0;
80101a69:	c7 43 58 00 00 00 00 	movl   $0x0,0x58(%ebx)
  iupdate(ip);
80101a70:	53                   	push   %ebx
80101a71:	e8 2a fd ff ff       	call   801017a0 <iupdate>
      ip->type = 0;
80101a76:	31 c0                	xor    %eax,%eax
80101a78:	66 89 43 50          	mov    %ax,0x50(%ebx)
      iupdate(ip);
80101a7c:	89 1c 24             	mov    %ebx,(%esp)
80101a7f:	e8 1c fd ff ff       	call   801017a0 <iupdate>
      ip->valid = 0;
80101a84:	c7 43 4c 00 00 00 00 	movl   $0x0,0x4c(%ebx)
80101a8b:	83 c4 10             	add    $0x10,%esp
80101a8e:	8b 7d fc             	mov    -0x4(%ebp),%edi
80101a91:	e9 23 ff ff ff       	jmp    801019b9 <iput+0x29>
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
80101a96:	83 ec 08             	sub    $0x8,%esp
80101a99:	50                   	push   %eax
80101a9a:	ff 31                	push   (%ecx)
80101a9c:	e8 2f e6 ff ff       	call   801000d0 <bread>
    for(j = 0; j < NINDIRECT; j++){
80101aa1:	83 c4 10             	add    $0x10,%esp
80101aa4:	89 d9                	mov    %ebx,%ecx
80101aa6:	89 7d e0             	mov    %edi,-0x20(%ebp)
80101aa9:	89 45 dc             	mov    %eax,-0x24(%ebp)
80101aac:	8d 70 5c             	lea    0x5c(%eax),%esi
80101aaf:	8d 98 5c 02 00 00    	lea    0x25c(%eax),%ebx
80101ab5:	eb 10                	jmp    80101ac7 <iput+0x137>
80101ab7:	90                   	nop
80101ab8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80101abf:	00 
80101ac0:	83 c6 04             	add    $0x4,%esi
80101ac3:	39 de                	cmp    %ebx,%esi
80101ac5:	74 15                	je     80101adc <iput+0x14c>
      if(a[j])
80101ac7:	8b 16                	mov    (%esi),%edx
80101ac9:	85 d2                	test   %edx,%edx
80101acb:	74 f3                	je     80101ac0 <iput+0x130>
        bfree(ip->dev, a[j]);
80101acd:	8b 01                	mov    (%ecx),%eax
80101acf:	89 4d e4             	mov    %ecx,-0x1c(%ebp)
80101ad2:	e8 b9 f9 ff ff       	call   80101490 <bfree>
80101ad7:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
80101ada:	eb e4                	jmp    80101ac0 <iput+0x130>
    brelse(bp);
80101adc:	8b 45 dc             	mov    -0x24(%ebp),%eax
80101adf:	83 ec 0c             	sub    $0xc,%esp
80101ae2:	89 cb                	mov    %ecx,%ebx
80101ae4:	8b 75 e0             	mov    -0x20(%ebp),%esi
80101ae7:	50                   	push   %eax
80101ae8:	e8 13 e7 ff ff       	call   80100200 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
80101aed:	8b 93 8c 00 00 00    	mov    0x8c(%ebx),%edx
80101af3:	8b 03                	mov    (%ebx),%eax
80101af5:	e8 96 f9 ff ff       	call   80101490 <bfree>
    ip->addrs[NDIRECT] = 0;
80101afa:	83 c4 10             	add    $0x10,%esp
80101afd:	c7 83 8c 00 00 00 00 	movl   $0x0,0x8c(%ebx)
80101b04:	00 00 00 
80101b07:	e9 5a ff ff ff       	jmp    80101a66 <iput+0xd6>
80101b0c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80101b10 <iunlockput>:
{
80101b10:	55                   	push   %ebp
80101b11:	89 e5                	mov    %esp,%ebp
80101b13:	56                   	push   %esi
80101b14:	53                   	push   %ebx
80101b15:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
80101b18:	85 db                	test   %ebx,%ebx
80101b1a:	74 34                	je     80101b50 <iunlockput+0x40>
80101b1c:	83 ec 0c             	sub    $0xc,%esp
80101b1f:	8d 73 0c             	lea    0xc(%ebx),%esi
80101b22:	56                   	push   %esi
80101b23:	e8 a8 2b 00 00       	call   801046d0 <holdingsleep>
80101b28:	83 c4 10             	add    $0x10,%esp
80101b2b:	85 c0                	test   %eax,%eax
80101b2d:	74 21                	je     80101b50 <iunlockput+0x40>
80101b2f:	8b 43 08             	mov    0x8(%ebx),%eax
80101b32:	85 c0                	test   %eax,%eax
80101b34:	7e 1a                	jle    80101b50 <iunlockput+0x40>
  releasesleep(&ip->lock);
80101b36:	83 ec 0c             	sub    $0xc,%esp
80101b39:	56                   	push   %esi
80101b3a:	e8 51 2b 00 00       	call   80104690 <releasesleep>
  iput(ip);
80101b3f:	83 c4 10             	add    $0x10,%esp
80101b42:	89 5d 08             	mov    %ebx,0x8(%ebp)
}
80101b45:	8d 65 f8             	lea    -0x8(%ebp),%esp
80101b48:	5b                   	pop    %ebx
80101b49:	5e                   	pop    %esi
80101b4a:	5d                   	pop    %ebp
  iput(ip);
80101b4b:	e9 40 fe ff ff       	jmp    80101990 <iput>
    panic("iunlock");
80101b50:	83 ec 0c             	sub    $0xc,%esp
80101b53:	68 6e 7a 10 80       	push   $0x80107a6e
80101b58:	e8 43 e8 ff ff       	call   801003a0 <panic>
80101b5d:	8d 76 00             	lea    0x0(%esi),%esi

80101b60 <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
80101b60:	55                   	push   %ebp
80101b61:	89 e5                	mov    %esp,%ebp
80101b63:	8b 55 08             	mov    0x8(%ebp),%edx
80101b66:	8b 45 0c             	mov    0xc(%ebp),%eax
  st->dev = ip->dev;
80101b69:	8b 0a                	mov    (%edx),%ecx
80101b6b:	89 48 04             	mov    %ecx,0x4(%eax)
  st->ino = ip->inum;
80101b6e:	8b 4a 04             	mov    0x4(%edx),%ecx
80101b71:	89 48 08             	mov    %ecx,0x8(%eax)
  st->type = ip->type;
80101b74:	0f b7 4a 50          	movzwl 0x50(%edx),%ecx
80101b78:	66 89 08             	mov    %cx,(%eax)
  st->nlink = ip->nlink;
80101b7b:	0f b7 4a 56          	movzwl 0x56(%edx),%ecx
80101b7f:	66 89 48 0c          	mov    %cx,0xc(%eax)
  st->size = ip->size;
80101b83:	8b 52 58             	mov    0x58(%edx),%edx
80101b86:	89 50 10             	mov    %edx,0x10(%eax)
}
80101b89:	5d                   	pop    %ebp
80101b8a:	c3                   	ret
80101b8b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80101b90 <readi>:
//PAGEBREAK!
// Read data from inode.
// Caller must hold ip->lock.
int
readi(struct inode *ip, char *dst, uint off, uint n)
{
80101b90:	55                   	push   %ebp
80101b91:	89 e5                	mov    %esp,%ebp
80101b93:	83 ec 28             	sub    $0x28,%esp
80101b96:	89 75 f8             	mov    %esi,-0x8(%ebp)
80101b99:	8b 45 0c             	mov    0xc(%ebp),%eax
80101b9c:	8b 75 08             	mov    0x8(%ebp),%esi
80101b9f:	89 7d fc             	mov    %edi,-0x4(%ebp)
80101ba2:	89 45 e0             	mov    %eax,-0x20(%ebp)
80101ba5:	8b 7d 10             	mov    0x10(%ebp),%edi
80101ba8:	89 75 d8             	mov    %esi,-0x28(%ebp)
80101bab:	8b 45 14             	mov    0x14(%ebp),%eax
  uint tot, m;
  struct buf *bp;

  if(ip->type == T_DEV){
80101bae:	66 83 7e 50 03       	cmpw   $0x3,0x50(%esi)
80101bb3:	0f 84 bf 00 00 00    	je     80101c78 <readi+0xe8>
    if(ip->major < 0 || ip->major >= NDEV || !devsw[ip->major].read)
      return -1;
    return devsw[ip->major].read(ip, dst, n);
  }

  if(off > ip->size || off + n < off)
80101bb9:	8b 75 d8             	mov    -0x28(%ebp),%esi
80101bbc:	8b 56 58             	mov    0x58(%esi),%edx
80101bbf:	39 fa                	cmp    %edi,%edx
80101bc1:	0f 82 e1 00 00 00    	jb     80101ca8 <readi+0x118>
80101bc7:	89 f9                	mov    %edi,%ecx
80101bc9:	89 5d f4             	mov    %ebx,-0xc(%ebp)
80101bcc:	31 db                	xor    %ebx,%ebx
80101bce:	01 c1                	add    %eax,%ecx
80101bd0:	0f 92 c3             	setb   %bl
80101bd3:	89 5d e4             	mov    %ebx,-0x1c(%ebp)
80101bd6:	0f 82 c9 00 00 00    	jb     80101ca5 <readi+0x115>
    return -1;
  if(off + n > ip->size)
    n = ip->size - off;
80101bdc:	89 d3                	mov    %edx,%ebx
80101bde:	29 fb                	sub    %edi,%ebx
80101be0:	39 ca                	cmp    %ecx,%edx
80101be2:	0f 42 c3             	cmovb  %ebx,%eax

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
80101be5:	85 c0                	test   %eax,%eax
80101be7:	0f 84 b3 00 00 00    	je     80101ca0 <readi+0x110>
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
    m = min(n - tot, BSIZE - off%BSIZE);
80101bed:	8b 75 e4             	mov    -0x1c(%ebp),%esi
80101bf0:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80101bf3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80101bf8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80101bff:	00 
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
80101c00:	8b 5d d8             	mov    -0x28(%ebp),%ebx
80101c03:	89 fa                	mov    %edi,%edx
80101c05:	c1 ea 09             	shr    $0x9,%edx
80101c08:	89 d8                	mov    %ebx,%eax
80101c0a:	e8 01 f9 ff ff       	call   80101510 <bmap>
80101c0f:	83 ec 08             	sub    $0x8,%esp
80101c12:	50                   	push   %eax
80101c13:	ff 33                	push   (%ebx)
80101c15:	e8 b6 e4 ff ff       	call   801000d0 <bread>
    m = min(n - tot, BSIZE - off%BSIZE);
80101c1a:	8b 5d e4             	mov    -0x1c(%ebp),%ebx
80101c1d:	b9 00 02 00 00       	mov    $0x200,%ecx
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
80101c22:	89 c2                	mov    %eax,%edx
    m = min(n - tot, BSIZE - off%BSIZE);
80101c24:	89 f8                	mov    %edi,%eax
80101c26:	25 ff 01 00 00       	and    $0x1ff,%eax
80101c2b:	29 f3                	sub    %esi,%ebx
80101c2d:	29 c1                	sub    %eax,%ecx
    memmove(dst, bp->data + off%BSIZE, m);
80101c2f:	8d 44 02 5c          	lea    0x5c(%edx,%eax,1),%eax
    m = min(n - tot, BSIZE - off%BSIZE);
80101c33:	39 d9                	cmp    %ebx,%ecx
80101c35:	0f 46 d9             	cmovbe %ecx,%ebx
    memmove(dst, bp->data + off%BSIZE, m);
80101c38:	83 c4 0c             	add    $0xc,%esp
80101c3b:	53                   	push   %ebx
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
80101c3c:	01 de                	add    %ebx,%esi
80101c3e:	01 df                	add    %ebx,%edi
    memmove(dst, bp->data + off%BSIZE, m);
80101c40:	50                   	push   %eax
80101c41:	ff 75 e0             	push   -0x20(%ebp)
80101c44:	89 55 dc             	mov    %edx,-0x24(%ebp)
80101c47:	e8 b4 2e 00 00       	call   80104b00 <memmove>
    brelse(bp);
80101c4c:	8b 55 dc             	mov    -0x24(%ebp),%edx
80101c4f:	89 14 24             	mov    %edx,(%esp)
80101c52:	e8 a9 e5 ff ff       	call   80100200 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
80101c57:	01 5d e0             	add    %ebx,-0x20(%ebp)
80101c5a:	8b 5d e4             	mov    -0x1c(%ebp),%ebx
80101c5d:	83 c4 10             	add    $0x10,%esp
80101c60:	39 de                	cmp    %ebx,%esi
80101c62:	72 9c                	jb     80101c00 <readi+0x70>
80101c64:	89 d8                	mov    %ebx,%eax
  }
  return n;
80101c66:	8b 5d f4             	mov    -0xc(%ebp),%ebx
}
80101c69:	8b 75 f8             	mov    -0x8(%ebp),%esi
80101c6c:	8b 7d fc             	mov    -0x4(%ebp),%edi
80101c6f:	c9                   	leave
80101c70:	c3                   	ret
80101c71:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    if(ip->major < 0 || ip->major >= NDEV || !devsw[ip->major].read)
80101c78:	0f bf 56 52          	movswl 0x52(%esi),%edx
80101c7c:	66 83 fa 09          	cmp    $0x9,%dx
80101c80:	77 26                	ja     80101ca8 <readi+0x118>
80101c82:	8b 14 d5 20 09 11 80 	mov    -0x7feef6e0(,%edx,8),%edx
80101c89:	85 d2                	test   %edx,%edx
80101c8b:	74 1b                	je     80101ca8 <readi+0x118>
}
80101c8d:	8b 75 f8             	mov    -0x8(%ebp),%esi
80101c90:	8b 7d fc             	mov    -0x4(%ebp),%edi
    return devsw[ip->major].read(ip, dst, n);
80101c93:	89 45 10             	mov    %eax,0x10(%ebp)
}
80101c96:	c9                   	leave
    return devsw[ip->major].read(ip, dst, n);
80101c97:	ff e2                	jmp    *%edx
80101c99:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80101ca0:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80101ca3:	eb c4                	jmp    80101c69 <readi+0xd9>
80101ca5:	8b 5d f4             	mov    -0xc(%ebp),%ebx
      return -1;
80101ca8:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80101cad:	eb ba                	jmp    80101c69 <readi+0xd9>
80101caf:	90                   	nop

80101cb0 <writei>:
// PAGEBREAK!
// Write data to inode.
// Caller must hold ip->lock.
int
writei(struct inode *ip, char *src, uint off, uint n)
{
80101cb0:	55                   	push   %ebp
80101cb1:	89 e5                	mov    %esp,%ebp
80101cb3:	83 ec 28             	sub    $0x28,%esp
80101cb6:	89 75 f8             	mov    %esi,-0x8(%ebp)
80101cb9:	8b 45 08             	mov    0x8(%ebp),%eax
80101cbc:	89 7d fc             	mov    %edi,-0x4(%ebp)
80101cbf:	8b 75 14             	mov    0x14(%ebp),%esi
80101cc2:	8b 7d 0c             	mov    0xc(%ebp),%edi
80101cc5:	89 75 e0             	mov    %esi,-0x20(%ebp)
80101cc8:	89 7d dc             	mov    %edi,-0x24(%ebp)
80101ccb:	8b 7d 10             	mov    0x10(%ebp),%edi
  uint tot, m;
  struct buf *bp;

  if(ip->type == T_DEV){
80101cce:	66 83 78 50 03       	cmpw   $0x3,0x50(%eax)
80101cd3:	0f 84 b7 00 00 00    	je     80101d90 <writei+0xe0>
    if(ip->major < 0 || ip->major >= NDEV || !devsw[ip->major].write)
      return -1;
    return devsw[ip->major].write(ip, src, n);
  }

  if(off > ip->size || off + n < off)
80101cd9:	39 78 58             	cmp    %edi,0x58(%eax)
80101cdc:	0f 82 ea 00 00 00    	jb     80101dcc <writei+0x11c>
    return -1;
  if(off + n > MAXFILE*BSIZE)
80101ce2:	8b 75 e0             	mov    -0x20(%ebp),%esi
80101ce5:	89 f2                	mov    %esi,%edx
80101ce7:	01 fa                	add    %edi,%edx
80101ce9:	0f 82 dd 00 00 00    	jb     80101dcc <writei+0x11c>
80101cef:	81 fa 00 18 01 00    	cmp    $0x11800,%edx
80101cf5:	0f 87 d1 00 00 00    	ja     80101dcc <writei+0x11c>
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
80101cfb:	85 f6                	test   %esi,%esi
80101cfd:	0f 84 81 00 00 00    	je     80101d84 <writei+0xd4>
80101d03:	89 5d f4             	mov    %ebx,-0xc(%ebp)
80101d06:	c7 45 e4 00 00 00 00 	movl   $0x0,-0x1c(%ebp)
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
    m = min(n - tot, BSIZE - off%BSIZE);
80101d0d:	89 45 d8             	mov    %eax,-0x28(%ebp)
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
80101d10:	8b 75 d8             	mov    -0x28(%ebp),%esi
80101d13:	89 fa                	mov    %edi,%edx
80101d15:	c1 ea 09             	shr    $0x9,%edx
80101d18:	89 f0                	mov    %esi,%eax
80101d1a:	e8 f1 f7 ff ff       	call   80101510 <bmap>
80101d1f:	83 ec 08             	sub    $0x8,%esp
80101d22:	50                   	push   %eax
80101d23:	ff 36                	push   (%esi)
80101d25:	e8 a6 e3 ff ff       	call   801000d0 <bread>
    m = min(n - tot, BSIZE - off%BSIZE);
80101d2a:	b9 00 02 00 00       	mov    $0x200,%ecx
80101d2f:	8b 5d e0             	mov    -0x20(%ebp),%ebx
80101d32:	2b 5d e4             	sub    -0x1c(%ebp),%ebx
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
80101d35:	89 c6                	mov    %eax,%esi
    m = min(n - tot, BSIZE - off%BSIZE);
80101d37:	89 f8                	mov    %edi,%eax
80101d39:	25 ff 01 00 00       	and    $0x1ff,%eax
80101d3e:	29 c1                	sub    %eax,%ecx
    memmove(bp->data + off%BSIZE, src, m);
80101d40:	8d 44 06 5c          	lea    0x5c(%esi,%eax,1),%eax
    m = min(n - tot, BSIZE - off%BSIZE);
80101d44:	39 d9                	cmp    %ebx,%ecx
80101d46:	0f 46 d9             	cmovbe %ecx,%ebx
    memmove(bp->data + off%BSIZE, src, m);
80101d49:	83 c4 0c             	add    $0xc,%esp
80101d4c:	53                   	push   %ebx
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
80101d4d:	01 df                	add    %ebx,%edi
    memmove(bp->data + off%BSIZE, src, m);
80101d4f:	ff 75 dc             	push   -0x24(%ebp)
80101d52:	50                   	push   %eax
80101d53:	e8 a8 2d 00 00       	call   80104b00 <memmove>
    log_write(bp);
80101d58:	89 34 24             	mov    %esi,(%esp)
80101d5b:	e8 c0 13 00 00       	call   80103120 <log_write>
    brelse(bp);
80101d60:	89 34 24             	mov    %esi,(%esp)
80101d63:	e8 98 e4 ff ff       	call   80100200 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
80101d68:	01 5d e4             	add    %ebx,-0x1c(%ebp)
80101d6b:	83 c4 10             	add    $0x10,%esp
80101d6e:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80101d71:	01 5d dc             	add    %ebx,-0x24(%ebp)
80101d74:	3b 45 e0             	cmp    -0x20(%ebp),%eax
80101d77:	72 97                	jb     80101d10 <writei+0x60>
  }

  if(n > 0 && off > ip->size){
80101d79:	8b 45 d8             	mov    -0x28(%ebp),%eax
80101d7c:	39 78 58             	cmp    %edi,0x58(%eax)
80101d7f:	72 37                	jb     80101db8 <writei+0x108>
80101d81:	8b 5d f4             	mov    -0xc(%ebp),%ebx
    ip->size = off;
    iupdate(ip);
  }
  return n;
80101d84:	8b 45 e0             	mov    -0x20(%ebp),%eax
}
80101d87:	8b 75 f8             	mov    -0x8(%ebp),%esi
80101d8a:	8b 7d fc             	mov    -0x4(%ebp),%edi
80101d8d:	c9                   	leave
80101d8e:	c3                   	ret
80101d8f:	90                   	nop
    if(ip->major < 0 || ip->major >= NDEV || !devsw[ip->major].write)
80101d90:	0f bf 40 52          	movswl 0x52(%eax),%eax
80101d94:	66 83 f8 09          	cmp    $0x9,%ax
80101d98:	77 32                	ja     80101dcc <writei+0x11c>
80101d9a:	8b 04 c5 24 09 11 80 	mov    -0x7feef6dc(,%eax,8),%eax
80101da1:	85 c0                	test   %eax,%eax
80101da3:	74 27                	je     80101dcc <writei+0x11c>
    return devsw[ip->major].write(ip, src, n);
80101da5:	8b 7d e0             	mov    -0x20(%ebp),%edi
}
80101da8:	8b 75 f8             	mov    -0x8(%ebp),%esi
    return devsw[ip->major].write(ip, src, n);
80101dab:	89 7d 10             	mov    %edi,0x10(%ebp)
}
80101dae:	8b 7d fc             	mov    -0x4(%ebp),%edi
80101db1:	c9                   	leave
    return devsw[ip->major].write(ip, src, n);
80101db2:	ff e0                	jmp    *%eax
80101db4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    iupdate(ip);
80101db8:	83 ec 0c             	sub    $0xc,%esp
    ip->size = off;
80101dbb:	89 78 58             	mov    %edi,0x58(%eax)
    iupdate(ip);
80101dbe:	50                   	push   %eax
80101dbf:	e8 dc f9 ff ff       	call   801017a0 <iupdate>
80101dc4:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80101dc7:	83 c4 10             	add    $0x10,%esp
80101dca:	eb b8                	jmp    80101d84 <writei+0xd4>
      return -1;
80101dcc:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80101dd1:	eb b4                	jmp    80101d87 <writei+0xd7>
80101dd3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80101dd8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80101ddf:	00 

80101de0 <namecmp>:
//PAGEBREAK!
// Directories

int
namecmp(const char *s, const char *t)
{
80101de0:	55                   	push   %ebp
80101de1:	89 e5                	mov    %esp,%ebp
80101de3:	83 ec 0c             	sub    $0xc,%esp
  return strncmp(s, t, DIRSIZ);
80101de6:	6a 0e                	push   $0xe
80101de8:	ff 75 0c             	push   0xc(%ebp)
80101deb:	ff 75 08             	push   0x8(%ebp)
80101dee:	e8 8d 2d 00 00       	call   80104b80 <strncmp>
}
80101df3:	c9                   	leave
80101df4:	c3                   	ret
80101df5:	8d 76 00             	lea    0x0(%esi),%esi
80101df8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80101dff:	00 

80101e00 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
80101e00:	55                   	push   %ebp
80101e01:	89 e5                	mov    %esp,%ebp
80101e03:	57                   	push   %edi
80101e04:	56                   	push   %esi
80101e05:	53                   	push   %ebx
80101e06:	83 ec 1c             	sub    $0x1c,%esp
80101e09:	8b 5d 08             	mov    0x8(%ebp),%ebx
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
80101e0c:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
80101e11:	0f 85 8d 00 00 00    	jne    80101ea4 <dirlookup+0xa4>
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
80101e17:	8b 53 58             	mov    0x58(%ebx),%edx
80101e1a:	31 ff                	xor    %edi,%edi
80101e1c:	8d 75 d8             	lea    -0x28(%ebp),%esi
80101e1f:	85 d2                	test   %edx,%edx
80101e21:	74 46                	je     80101e69 <dirlookup+0x69>
80101e23:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80101e28:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80101e2f:	00 
    if(readi(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
80101e30:	6a 10                	push   $0x10
80101e32:	57                   	push   %edi
80101e33:	56                   	push   %esi
80101e34:	53                   	push   %ebx
80101e35:	e8 56 fd ff ff       	call   80101b90 <readi>
80101e3a:	83 c4 10             	add    $0x10,%esp
80101e3d:	83 f8 10             	cmp    $0x10,%eax
80101e40:	75 55                	jne    80101e97 <dirlookup+0x97>
      panic("dirlookup read");
    if(de.inum == 0)
80101e42:	66 83 7d d8 00       	cmpw   $0x0,-0x28(%ebp)
80101e47:	74 18                	je     80101e61 <dirlookup+0x61>
  return strncmp(s, t, DIRSIZ);
80101e49:	83 ec 04             	sub    $0x4,%esp
80101e4c:	8d 45 da             	lea    -0x26(%ebp),%eax
80101e4f:	6a 0e                	push   $0xe
80101e51:	50                   	push   %eax
80101e52:	ff 75 0c             	push   0xc(%ebp)
80101e55:	e8 26 2d 00 00       	call   80104b80 <strncmp>
      continue;
    if(namecmp(name, de.name) == 0){
80101e5a:	83 c4 10             	add    $0x10,%esp
80101e5d:	85 c0                	test   %eax,%eax
80101e5f:	74 17                	je     80101e78 <dirlookup+0x78>
  for(off = 0; off < dp->size; off += sizeof(de)){
80101e61:	83 c7 10             	add    $0x10,%edi
80101e64:	3b 7b 58             	cmp    0x58(%ebx),%edi
80101e67:	72 c7                	jb     80101e30 <dirlookup+0x30>
      return iget(dp->dev, inum);
    }
  }

  return 0;
}
80101e69:	8d 65 f4             	lea    -0xc(%ebp),%esp
  return 0;
80101e6c:	31 c0                	xor    %eax,%eax
}
80101e6e:	5b                   	pop    %ebx
80101e6f:	5e                   	pop    %esi
80101e70:	5f                   	pop    %edi
80101e71:	5d                   	pop    %ebp
80101e72:	c3                   	ret
80101e73:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
      if(poff)
80101e78:	8b 45 10             	mov    0x10(%ebp),%eax
80101e7b:	85 c0                	test   %eax,%eax
80101e7d:	74 05                	je     80101e84 <dirlookup+0x84>
        *poff = off;
80101e7f:	8b 45 10             	mov    0x10(%ebp),%eax
80101e82:	89 38                	mov    %edi,(%eax)
      inum = de.inum;
80101e84:	0f b7 55 d8          	movzwl -0x28(%ebp),%edx
      return iget(dp->dev, inum);
80101e88:	8b 03                	mov    (%ebx),%eax
80101e8a:	e8 11 f5 ff ff       	call   801013a0 <iget>
}
80101e8f:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101e92:	5b                   	pop    %ebx
80101e93:	5e                   	pop    %esi
80101e94:	5f                   	pop    %edi
80101e95:	5d                   	pop    %ebp
80101e96:	c3                   	ret
      panic("dirlookup read");
80101e97:	83 ec 0c             	sub    $0xc,%esp
80101e9a:	68 88 7a 10 80       	push   $0x80107a88
80101e9f:	e8 fc e4 ff ff       	call   801003a0 <panic>
    panic("dirlookup not DIR");
80101ea4:	83 ec 0c             	sub    $0xc,%esp
80101ea7:	68 76 7a 10 80       	push   $0x80107a76
80101eac:	e8 ef e4 ff ff       	call   801003a0 <panic>
80101eb1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80101eb8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80101ebf:	00 

80101ec0 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
80101ec0:	55                   	push   %ebp
80101ec1:	89 e5                	mov    %esp,%ebp
80101ec3:	57                   	push   %edi
80101ec4:	56                   	push   %esi
80101ec5:	53                   	push   %ebx
80101ec6:	89 c3                	mov    %eax,%ebx
80101ec8:	83 ec 1c             	sub    $0x1c,%esp
80101ecb:	89 55 dc             	mov    %edx,-0x24(%ebp)
80101ece:	89 4d e4             	mov    %ecx,-0x1c(%ebp)
  struct inode *ip, *next;

  if(*path == '/')
80101ed1:	80 38 2f             	cmpb   $0x2f,(%eax)
80101ed4:	0f 84 6a 01 00 00    	je     80102044 <namex+0x184>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
80101eda:	e8 c1 1c 00 00       	call   80103ba0 <myproc>
  acquire(&icache.lock);
80101edf:	83 ec 0c             	sub    $0xc,%esp
    ip = idup(myproc()->cwd);
80101ee2:	8b 70 68             	mov    0x68(%eax),%esi
  acquire(&icache.lock);
80101ee5:	68 80 09 11 80       	push   $0x80110980
80101eea:	e8 51 2a 00 00       	call   80104940 <acquire>
  ip->ref++;
80101eef:	83 46 08 01          	addl   $0x1,0x8(%esi)
  release(&icache.lock);
80101ef3:	c7 04 24 80 09 11 80 	movl   $0x80110980,(%esp)
80101efa:	e8 e1 29 00 00       	call   801048e0 <release>
80101eff:	83 c4 10             	add    $0x10,%esp
80101f02:	eb 0f                	jmp    80101f13 <namex+0x53>
80101f04:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80101f08:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80101f0f:	00 
    path++;
80101f10:	83 c3 01             	add    $0x1,%ebx
  while(*path == '/')
80101f13:	0f b6 03             	movzbl (%ebx),%eax
80101f16:	3c 2f                	cmp    $0x2f,%al
80101f18:	74 f6                	je     80101f10 <namex+0x50>
  if(*path == 0)
80101f1a:	84 c0                	test   %al,%al
80101f1c:	0f 84 3e 01 00 00    	je     80102060 <namex+0x1a0>
  while(*path != '/' && *path != 0)
80101f22:	0f b6 03             	movzbl (%ebx),%eax
80101f25:	84 c0                	test   %al,%al
80101f27:	0f 84 0b 01 00 00    	je     80102038 <namex+0x178>
80101f2d:	3c 2f                	cmp    $0x2f,%al
80101f2f:	0f 84 03 01 00 00    	je     80102038 <namex+0x178>
80101f35:	89 df                	mov    %ebx,%edi
80101f37:	90                   	nop
80101f38:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80101f3f:	00 
80101f40:	0f b6 47 01          	movzbl 0x1(%edi),%eax
    path++;
80101f44:	83 c7 01             	add    $0x1,%edi
  while(*path != '/' && *path != 0)
80101f47:	3c 2f                	cmp    $0x2f,%al
80101f49:	74 04                	je     80101f4f <namex+0x8f>
80101f4b:	84 c0                	test   %al,%al
80101f4d:	75 f1                	jne    80101f40 <namex+0x80>
  len = path - s;
80101f4f:	89 f8                	mov    %edi,%eax
80101f51:	29 d8                	sub    %ebx,%eax
  if(len >= DIRSIZ)
80101f53:	83 f8 0d             	cmp    $0xd,%eax
80101f56:	0f 8e b4 00 00 00    	jle    80102010 <namex+0x150>
    memmove(name, s, DIRSIZ);
80101f5c:	83 ec 04             	sub    $0x4,%esp
80101f5f:	6a 0e                	push   $0xe
80101f61:	53                   	push   %ebx
80101f62:	89 fb                	mov    %edi,%ebx
80101f64:	ff 75 e4             	push   -0x1c(%ebp)
80101f67:	e8 94 2b 00 00       	call   80104b00 <memmove>
80101f6c:	83 c4 10             	add    $0x10,%esp
  while(*path == '/')
80101f6f:	80 3f 2f             	cmpb   $0x2f,(%edi)
80101f72:	75 14                	jne    80101f88 <namex+0xc8>
80101f74:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80101f78:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80101f7f:	00 
    path++;
80101f80:	83 c3 01             	add    $0x1,%ebx
  while(*path == '/')
80101f83:	80 3b 2f             	cmpb   $0x2f,(%ebx)
80101f86:	74 f8                	je     80101f80 <namex+0xc0>

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
80101f88:	83 ec 0c             	sub    $0xc,%esp
80101f8b:	56                   	push   %esi
80101f8c:	e8 cf f8 ff ff       	call   80101860 <ilock>
    if(ip->type != T_DIR){
80101f91:	83 c4 10             	add    $0x10,%esp
80101f94:	66 83 7e 50 01       	cmpw   $0x1,0x50(%esi)
80101f99:	0f 85 d6 00 00 00    	jne    80102075 <namex+0x1b5>
      iunlockput(ip);
      return 0;
    }
    if(nameiparent && *path == '\0'){
80101f9f:	8b 45 dc             	mov    -0x24(%ebp),%eax
80101fa2:	85 c0                	test   %eax,%eax
80101fa4:	74 09                	je     80101faf <namex+0xef>
80101fa6:	80 3b 00             	cmpb   $0x0,(%ebx)
80101fa9:	0f 84 2b 01 00 00    	je     801020da <namex+0x21a>
      // Stop one level early.
      iunlock(ip);
      return ip;
    }
    if((next = dirlookup(ip, name, 0)) == 0){
80101faf:	83 ec 04             	sub    $0x4,%esp
80101fb2:	6a 00                	push   $0x0
80101fb4:	ff 75 e4             	push   -0x1c(%ebp)
80101fb7:	56                   	push   %esi
80101fb8:	e8 43 fe ff ff       	call   80101e00 <dirlookup>
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
80101fbd:	8d 56 0c             	lea    0xc(%esi),%edx
    if((next = dirlookup(ip, name, 0)) == 0){
80101fc0:	83 c4 10             	add    $0x10,%esp
80101fc3:	89 c7                	mov    %eax,%edi
80101fc5:	85 c0                	test   %eax,%eax
80101fc7:	0f 84 ea 00 00 00    	je     801020b7 <namex+0x1f7>
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
80101fcd:	83 ec 0c             	sub    $0xc,%esp
80101fd0:	52                   	push   %edx
80101fd1:	89 55 e0             	mov    %edx,-0x20(%ebp)
80101fd4:	e8 f7 26 00 00       	call   801046d0 <holdingsleep>
80101fd9:	83 c4 10             	add    $0x10,%esp
80101fdc:	85 c0                	test   %eax,%eax
80101fde:	0f 84 36 01 00 00    	je     8010211a <namex+0x25a>
80101fe4:	8b 56 08             	mov    0x8(%esi),%edx
80101fe7:	85 d2                	test   %edx,%edx
80101fe9:	0f 8e 2b 01 00 00    	jle    8010211a <namex+0x25a>
  releasesleep(&ip->lock);
80101fef:	8b 55 e0             	mov    -0x20(%ebp),%edx
80101ff2:	83 ec 0c             	sub    $0xc,%esp
80101ff5:	52                   	push   %edx
80101ff6:	e8 95 26 00 00       	call   80104690 <releasesleep>
  iput(ip);
80101ffb:	89 34 24             	mov    %esi,(%esp)
      iunlockput(ip);
      return 0;
    }
    iunlockput(ip);
    ip = next;
80101ffe:	89 fe                	mov    %edi,%esi
  iput(ip);
80102000:	e8 8b f9 ff ff       	call   80101990 <iput>
80102005:	83 c4 10             	add    $0x10,%esp
  while(*path == '/')
80102008:	e9 06 ff ff ff       	jmp    80101f13 <namex+0x53>
8010200d:	8d 76 00             	lea    0x0(%esi),%esi
    name[len] = 0;
80102010:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
80102013:	01 c1                	add    %eax,%ecx
80102015:	89 4d e0             	mov    %ecx,-0x20(%ebp)
    memmove(name, s, len);
80102018:	83 ec 04             	sub    $0x4,%esp
8010201b:	50                   	push   %eax
8010201c:	53                   	push   %ebx
    name[len] = 0;
8010201d:	89 fb                	mov    %edi,%ebx
    memmove(name, s, len);
8010201f:	ff 75 e4             	push   -0x1c(%ebp)
80102022:	e8 d9 2a 00 00       	call   80104b00 <memmove>
    name[len] = 0;
80102027:	8b 45 e0             	mov    -0x20(%ebp),%eax
8010202a:	83 c4 10             	add    $0x10,%esp
8010202d:	c6 00 00             	movb   $0x0,(%eax)
80102030:	e9 3a ff ff ff       	jmp    80101f6f <namex+0xaf>
80102035:	8d 76 00             	lea    0x0(%esi),%esi
  while(*path != '/' && *path != 0)
80102038:	8b 45 e4             	mov    -0x1c(%ebp),%eax
8010203b:	89 df                	mov    %ebx,%edi
8010203d:	89 45 e0             	mov    %eax,-0x20(%ebp)
80102040:	31 c0                	xor    %eax,%eax
80102042:	eb d4                	jmp    80102018 <namex+0x158>
    ip = iget(ROOTDEV, ROOTINO);
80102044:	ba 01 00 00 00       	mov    $0x1,%edx
80102049:	b8 01 00 00 00       	mov    $0x1,%eax
8010204e:	e8 4d f3 ff ff       	call   801013a0 <iget>
80102053:	89 c6                	mov    %eax,%esi
80102055:	e9 b9 fe ff ff       	jmp    80101f13 <namex+0x53>
8010205a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  }
  if(nameiparent){
80102060:	8b 45 dc             	mov    -0x24(%ebp),%eax
80102063:	85 c0                	test   %eax,%eax
80102065:	0f 85 9f 00 00 00    	jne    8010210a <namex+0x24a>
    iput(ip);
    return 0;
  }
  return ip;
}
8010206b:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010206e:	89 f0                	mov    %esi,%eax
80102070:	5b                   	pop    %ebx
80102071:	5e                   	pop    %esi
80102072:	5f                   	pop    %edi
80102073:	5d                   	pop    %ebp
80102074:	c3                   	ret
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
80102075:	83 ec 0c             	sub    $0xc,%esp
80102078:	8d 5e 0c             	lea    0xc(%esi),%ebx
8010207b:	53                   	push   %ebx
8010207c:	e8 4f 26 00 00       	call   801046d0 <holdingsleep>
80102081:	83 c4 10             	add    $0x10,%esp
80102084:	85 c0                	test   %eax,%eax
80102086:	0f 84 8e 00 00 00    	je     8010211a <namex+0x25a>
8010208c:	8b 46 08             	mov    0x8(%esi),%eax
8010208f:	85 c0                	test   %eax,%eax
80102091:	0f 8e 83 00 00 00    	jle    8010211a <namex+0x25a>
  releasesleep(&ip->lock);
80102097:	83 ec 0c             	sub    $0xc,%esp
8010209a:	53                   	push   %ebx
8010209b:	e8 f0 25 00 00       	call   80104690 <releasesleep>
  iput(ip);
801020a0:	89 34 24             	mov    %esi,(%esp)
      return 0;
801020a3:	31 f6                	xor    %esi,%esi
  iput(ip);
801020a5:	e8 e6 f8 ff ff       	call   80101990 <iput>
      return 0;
801020aa:	83 c4 10             	add    $0x10,%esp
}
801020ad:	8d 65 f4             	lea    -0xc(%ebp),%esp
801020b0:	89 f0                	mov    %esi,%eax
801020b2:	5b                   	pop    %ebx
801020b3:	5e                   	pop    %esi
801020b4:	5f                   	pop    %edi
801020b5:	5d                   	pop    %ebp
801020b6:	c3                   	ret
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
801020b7:	83 ec 0c             	sub    $0xc,%esp
801020ba:	52                   	push   %edx
801020bb:	89 55 e4             	mov    %edx,-0x1c(%ebp)
801020be:	e8 0d 26 00 00       	call   801046d0 <holdingsleep>
801020c3:	83 c4 10             	add    $0x10,%esp
801020c6:	85 c0                	test   %eax,%eax
801020c8:	74 50                	je     8010211a <namex+0x25a>
801020ca:	8b 4e 08             	mov    0x8(%esi),%ecx
801020cd:	85 c9                	test   %ecx,%ecx
801020cf:	7e 49                	jle    8010211a <namex+0x25a>
  releasesleep(&ip->lock);
801020d1:	8b 55 e4             	mov    -0x1c(%ebp),%edx
801020d4:	83 ec 0c             	sub    $0xc,%esp
801020d7:	52                   	push   %edx
801020d8:	eb c1                	jmp    8010209b <namex+0x1db>
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
801020da:	83 ec 0c             	sub    $0xc,%esp
801020dd:	8d 5e 0c             	lea    0xc(%esi),%ebx
801020e0:	53                   	push   %ebx
801020e1:	e8 ea 25 00 00       	call   801046d0 <holdingsleep>
801020e6:	83 c4 10             	add    $0x10,%esp
801020e9:	85 c0                	test   %eax,%eax
801020eb:	74 2d                	je     8010211a <namex+0x25a>
801020ed:	8b 7e 08             	mov    0x8(%esi),%edi
801020f0:	85 ff                	test   %edi,%edi
801020f2:	7e 26                	jle    8010211a <namex+0x25a>
  releasesleep(&ip->lock);
801020f4:	83 ec 0c             	sub    $0xc,%esp
801020f7:	53                   	push   %ebx
801020f8:	e8 93 25 00 00       	call   80104690 <releasesleep>
      return ip;
801020fd:	83 c4 10             	add    $0x10,%esp
}
80102100:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102103:	89 f0                	mov    %esi,%eax
80102105:	5b                   	pop    %ebx
80102106:	5e                   	pop    %esi
80102107:	5f                   	pop    %edi
80102108:	5d                   	pop    %ebp
80102109:	c3                   	ret
    iput(ip);
8010210a:	83 ec 0c             	sub    $0xc,%esp
8010210d:	56                   	push   %esi
      return 0;
8010210e:	31 f6                	xor    %esi,%esi
    iput(ip);
80102110:	e8 7b f8 ff ff       	call   80101990 <iput>
    return 0;
80102115:	83 c4 10             	add    $0x10,%esp
80102118:	eb 93                	jmp    801020ad <namex+0x1ed>
    panic("iunlock");
8010211a:	83 ec 0c             	sub    $0xc,%esp
8010211d:	68 6e 7a 10 80       	push   $0x80107a6e
80102122:	e8 79 e2 ff ff       	call   801003a0 <panic>
80102127:	90                   	nop
80102128:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010212f:	00 

80102130 <dirlink>:
{
80102130:	55                   	push   %ebp
80102131:	89 e5                	mov    %esp,%ebp
80102133:	83 ec 2c             	sub    $0x2c,%esp
80102136:	89 5d f4             	mov    %ebx,-0xc(%ebp)
80102139:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if((ip = dirlookup(dp, name, 0)) != 0){
8010213c:	6a 00                	push   $0x0
8010213e:	ff 75 0c             	push   0xc(%ebp)
80102141:	53                   	push   %ebx
80102142:	e8 b9 fc ff ff       	call   80101e00 <dirlookup>
80102147:	83 c4 10             	add    $0x10,%esp
8010214a:	85 c0                	test   %eax,%eax
8010214c:	75 72                	jne    801021c0 <dirlink+0x90>
8010214e:	89 75 f8             	mov    %esi,-0x8(%ebp)
80102151:	8d 75 d8             	lea    -0x28(%ebp),%esi
80102154:	89 7d fc             	mov    %edi,-0x4(%ebp)
  for(off = 0; off < dp->size; off += sizeof(de)){
80102157:	8b 7b 58             	mov    0x58(%ebx),%edi
8010215a:	85 ff                	test   %edi,%edi
8010215c:	74 2b                	je     80102189 <dirlink+0x59>
8010215e:	31 ff                	xor    %edi,%edi
80102160:	8d 75 d8             	lea    -0x28(%ebp),%esi
80102163:	eb 0b                	jmp    80102170 <dirlink+0x40>
80102165:	8d 76 00             	lea    0x0(%esi),%esi
80102168:	83 c7 10             	add    $0x10,%edi
8010216b:	3b 7b 58             	cmp    0x58(%ebx),%edi
8010216e:	73 19                	jae    80102189 <dirlink+0x59>
    if(readi(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
80102170:	6a 10                	push   $0x10
80102172:	57                   	push   %edi
80102173:	56                   	push   %esi
80102174:	53                   	push   %ebx
80102175:	e8 16 fa ff ff       	call   80101b90 <readi>
8010217a:	83 c4 10             	add    $0x10,%esp
8010217d:	83 f8 10             	cmp    $0x10,%eax
80102180:	75 51                	jne    801021d3 <dirlink+0xa3>
    if(de.inum == 0)
80102182:	66 83 7d d8 00       	cmpw   $0x0,-0x28(%ebp)
80102187:	75 df                	jne    80102168 <dirlink+0x38>
  strncpy(de.name, name, DIRSIZ);
80102189:	83 ec 04             	sub    $0x4,%esp
8010218c:	8d 45 da             	lea    -0x26(%ebp),%eax
8010218f:	6a 0e                	push   $0xe
80102191:	ff 75 0c             	push   0xc(%ebp)
80102194:	50                   	push   %eax
80102195:	e8 36 2a 00 00       	call   80104bd0 <strncpy>
  if(writei(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
8010219a:	6a 10                	push   $0x10
  de.inum = inum;
8010219c:	8b 45 10             	mov    0x10(%ebp),%eax
  if(writei(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
8010219f:	57                   	push   %edi
801021a0:	56                   	push   %esi
801021a1:	53                   	push   %ebx
  de.inum = inum;
801021a2:	66 89 45 d8          	mov    %ax,-0x28(%ebp)
  if(writei(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
801021a6:	e8 05 fb ff ff       	call   80101cb0 <writei>
801021ab:	83 c4 20             	add    $0x20,%esp
801021ae:	83 f8 10             	cmp    $0x10,%eax
801021b1:	75 2d                	jne    801021e0 <dirlink+0xb0>
  return 0;
801021b3:	8b 75 f8             	mov    -0x8(%ebp),%esi
801021b6:	8b 7d fc             	mov    -0x4(%ebp),%edi
801021b9:	31 c0                	xor    %eax,%eax
}
801021bb:	8b 5d f4             	mov    -0xc(%ebp),%ebx
801021be:	c9                   	leave
801021bf:	c3                   	ret
    iput(ip);
801021c0:	83 ec 0c             	sub    $0xc,%esp
801021c3:	50                   	push   %eax
801021c4:	e8 c7 f7 ff ff       	call   80101990 <iput>
    return -1;
801021c9:	83 c4 10             	add    $0x10,%esp
801021cc:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801021d1:	eb e8                	jmp    801021bb <dirlink+0x8b>
      panic("dirlink read");
801021d3:	83 ec 0c             	sub    $0xc,%esp
801021d6:	68 97 7a 10 80       	push   $0x80107a97
801021db:	e8 c0 e1 ff ff       	call   801003a0 <panic>
    panic("dirlink");
801021e0:	83 ec 0c             	sub    $0xc,%esp
801021e3:	68 f3 7c 10 80       	push   $0x80107cf3
801021e8:	e8 b3 e1 ff ff       	call   801003a0 <panic>
801021ed:	8d 76 00             	lea    0x0(%esi),%esi

801021f0 <namei>:

struct inode*
namei(char *path)
{
801021f0:	55                   	push   %ebp
  char name[DIRSIZ];
  return namex(path, 0, name);
801021f1:	31 d2                	xor    %edx,%edx
{
801021f3:	89 e5                	mov    %esp,%ebp
801021f5:	83 ec 18             	sub    $0x18,%esp
  return namex(path, 0, name);
801021f8:	8b 45 08             	mov    0x8(%ebp),%eax
801021fb:	8d 4d ea             	lea    -0x16(%ebp),%ecx
801021fe:	e8 bd fc ff ff       	call   80101ec0 <namex>
}
80102203:	c9                   	leave
80102204:	c3                   	ret
80102205:	8d 76 00             	lea    0x0(%esi),%esi
80102208:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010220f:	00 

80102210 <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
80102210:	55                   	push   %ebp
  return namex(path, 1, name);
80102211:	ba 01 00 00 00       	mov    $0x1,%edx
{
80102216:	89 e5                	mov    %esp,%ebp
  return namex(path, 1, name);
80102218:	8b 4d 0c             	mov    0xc(%ebp),%ecx
8010221b:	8b 45 08             	mov    0x8(%ebp),%eax
}
8010221e:	5d                   	pop    %ebp
  return namex(path, 1, name);
8010221f:	e9 9c fc ff ff       	jmp    80101ec0 <namex>
80102224:	66 90                	xchg   %ax,%ax
80102226:	66 90                	xchg   %ax,%ax
80102228:	66 90                	xchg   %ax,%ax
8010222a:	66 90                	xchg   %ax,%ax
8010222c:	66 90                	xchg   %ax,%ax
8010222e:	66 90                	xchg   %ax,%ax

80102230 <idestart>:
}

// Start the request for b.  Caller must hold idelock.
static void
idestart(struct buf *b)
{
80102230:	55                   	push   %ebp
80102231:	89 e5                	mov    %esp,%ebp
80102233:	83 ec 18             	sub    $0x18,%esp
80102236:	89 5d f4             	mov    %ebx,-0xc(%ebp)
80102239:	89 75 f8             	mov    %esi,-0x8(%ebp)
  if(b == 0)
8010223c:	85 c0                	test   %eax,%eax
8010223e:	0f 84 ac 00 00 00    	je     801022f0 <idestart+0xc0>
    panic("idestart");
  if(b->blockno >= FSSIZE)
80102244:	8b 70 08             	mov    0x8(%eax),%esi
80102247:	89 c3                	mov    %eax,%ebx
80102249:	81 fe e7 03 00 00    	cmp    $0x3e7,%esi
8010224f:	0f 87 8b 00 00 00    	ja     801022e0 <idestart+0xb0>
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102255:	b9 f7 01 00 00       	mov    $0x1f7,%ecx
8010225a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80102260:	89 ca                	mov    %ecx,%edx
80102262:	ec                   	in     (%dx),%al
  while(((r = inb(0x1f7)) & (IDE_BSY|IDE_DRDY)) != IDE_DRDY)
80102263:	83 e0 c0             	and    $0xffffffc0,%eax
80102266:	3c 40                	cmp    $0x40,%al
80102268:	75 f6                	jne    80102260 <idestart+0x30>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
8010226a:	ba f6 03 00 00       	mov    $0x3f6,%edx
8010226f:	31 c0                	xor    %eax,%eax
80102271:	ee                   	out    %al,(%dx)
80102272:	b8 01 00 00 00       	mov    $0x1,%eax
80102277:	ba f2 01 00 00       	mov    $0x1f2,%edx
8010227c:	ee                   	out    %al,(%dx)
8010227d:	ba f3 01 00 00       	mov    $0x1f3,%edx
80102282:	89 f0                	mov    %esi,%eax
80102284:	ee                   	out    %al,(%dx)

  idewait(0);
  outb(0x3f6, 0);  // generate interrupt
  outb(0x1f2, sector_per_block);  // number of sectors
  outb(0x1f3, sector & 0xff);
  outb(0x1f4, (sector >> 8) & 0xff);
80102285:	89 f0                	mov    %esi,%eax
80102287:	ba f4 01 00 00       	mov    $0x1f4,%edx
8010228c:	c1 f8 08             	sar    $0x8,%eax
8010228f:	ee                   	out    %al,(%dx)
80102290:	ba f5 01 00 00       	mov    $0x1f5,%edx
80102295:	31 c0                	xor    %eax,%eax
80102297:	ee                   	out    %al,(%dx)
  outb(0x1f5, (sector >> 16) & 0xff);
  outb(0x1f6, 0xe0 | ((b->dev&1)<<4) | ((sector>>24)&0x0f));
80102298:	0f b6 43 04          	movzbl 0x4(%ebx),%eax
8010229c:	ba f6 01 00 00       	mov    $0x1f6,%edx
801022a1:	c1 e0 04             	shl    $0x4,%eax
801022a4:	83 e0 10             	and    $0x10,%eax
801022a7:	83 c8 e0             	or     $0xffffffe0,%eax
801022aa:	ee                   	out    %al,(%dx)
  if(b->flags & B_DIRTY){
801022ab:	f6 03 04             	testb  $0x4,(%ebx)
801022ae:	75 10                	jne    801022c0 <idestart+0x90>
801022b0:	b8 20 00 00 00       	mov    $0x20,%eax
801022b5:	89 ca                	mov    %ecx,%edx
801022b7:	ee                   	out    %al,(%dx)
801022b8:	8b 5d f4             	mov    -0xc(%ebp),%ebx
801022bb:	8b 75 f8             	mov    -0x8(%ebp),%esi
    outb(0x1f7, write_cmd);
    outsl(0x1f0, b->data, BSIZE/4);
  } else {
    outb(0x1f7, read_cmd);
  }
}
801022be:	c9                   	leave
801022bf:	c3                   	ret
801022c0:	b8 30 00 00 00       	mov    $0x30,%eax
801022c5:	89 ca                	mov    %ecx,%edx
801022c7:	ee                   	out    %al,(%dx)
  asm volatile("cld; rep outsl" :
801022c8:	b9 80 00 00 00       	mov    $0x80,%ecx
    outsl(0x1f0, b->data, BSIZE/4);
801022cd:	8d 73 5c             	lea    0x5c(%ebx),%esi
801022d0:	ba f0 01 00 00       	mov    $0x1f0,%edx
801022d5:	fc                   	cld
801022d6:	f3 6f                	rep outsl %ds:(%esi),(%dx)
801022d8:	8b 5d f4             	mov    -0xc(%ebp),%ebx
801022db:	8b 75 f8             	mov    -0x8(%ebp),%esi
}
801022de:	c9                   	leave
801022df:	c3                   	ret
    panic("incorrect blockno");
801022e0:	83 ec 0c             	sub    $0xc,%esp
801022e3:	89 7d fc             	mov    %edi,-0x4(%ebp)
801022e6:	68 ad 7a 10 80       	push   $0x80107aad
801022eb:	e8 b0 e0 ff ff       	call   801003a0 <panic>
    panic("idestart");
801022f0:	83 ec 0c             	sub    $0xc,%esp
801022f3:	89 7d fc             	mov    %edi,-0x4(%ebp)
801022f6:	68 a4 7a 10 80       	push   $0x80107aa4
801022fb:	e8 a0 e0 ff ff       	call   801003a0 <panic>

80102300 <ideinit>:
{
80102300:	55                   	push   %ebp
80102301:	89 e5                	mov    %esp,%ebp
80102303:	83 ec 10             	sub    $0x10,%esp
  initlock(&idelock, "ide");
80102306:	68 bf 7a 10 80       	push   $0x80107abf
8010230b:	68 20 26 11 80       	push   $0x80112620
80102310:	e8 0b 24 00 00       	call   80104720 <initlock>
  ioapicenable(IRQ_IDE, ncpu - 1);
80102315:	58                   	pop    %eax
80102316:	a1 a4 27 11 80       	mov    0x801127a4,%eax
8010231b:	5a                   	pop    %edx
8010231c:	83 e8 01             	sub    $0x1,%eax
8010231f:	50                   	push   %eax
80102320:	6a 0e                	push   $0xe
80102322:	e8 d9 02 00 00       	call   80102600 <ioapicenable>
  while(((r = inb(0x1f7)) & (IDE_BSY|IDE_DRDY)) != IDE_DRDY)
80102327:	83 c4 10             	add    $0x10,%esp
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
8010232a:	ba f7 01 00 00       	mov    $0x1f7,%edx
8010232f:	90                   	nop
80102330:	ec                   	in     (%dx),%al
80102331:	83 e0 c0             	and    $0xffffffc0,%eax
80102334:	3c 40                	cmp    $0x40,%al
80102336:	75 f8                	jne    80102330 <ideinit+0x30>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102338:	b8 f0 ff ff ff       	mov    $0xfffffff0,%eax
8010233d:	ba f6 01 00 00       	mov    $0x1f6,%edx
80102342:	ee                   	out    %al,(%dx)
80102343:	b9 e8 03 00 00       	mov    $0x3e8,%ecx
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102348:	ba f7 01 00 00       	mov    $0x1f7,%edx
8010234d:	eb 06                	jmp    80102355 <ideinit+0x55>
8010234f:	90                   	nop
  for(i=0; i<1000; i++){
80102350:	83 e9 01             	sub    $0x1,%ecx
80102353:	74 0f                	je     80102364 <ideinit+0x64>
80102355:	ec                   	in     (%dx),%al
    if(inb(0x1f7) != 0){
80102356:	84 c0                	test   %al,%al
80102358:	74 f6                	je     80102350 <ideinit+0x50>
      havedisk1 = 1;
8010235a:	c7 05 00 26 11 80 01 	movl   $0x1,0x80112600
80102361:	00 00 00 
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102364:	b8 e0 ff ff ff       	mov    $0xffffffe0,%eax
80102369:	ba f6 01 00 00       	mov    $0x1f6,%edx
8010236e:	ee                   	out    %al,(%dx)
}
8010236f:	c9                   	leave
80102370:	c3                   	ret
80102371:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80102378:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010237f:	00 

80102380 <ideintr>:

// Interrupt handler.
void
ideintr(void)
{
80102380:	55                   	push   %ebp
80102381:	89 e5                	mov    %esp,%ebp
80102383:	83 ec 24             	sub    $0x24,%esp
  struct buf *b;

  // First queued buffer is the active request.
  acquire(&idelock);
80102386:	68 20 26 11 80       	push   $0x80112620
{
8010238b:	89 5d f4             	mov    %ebx,-0xc(%ebp)
  acquire(&idelock);
8010238e:	e8 ad 25 00 00       	call   80104940 <acquire>

  if((b = idequeue) == 0){
80102393:	8b 1d 04 26 11 80    	mov    0x80112604,%ebx
80102399:	83 c4 10             	add    $0x10,%esp
8010239c:	85 db                	test   %ebx,%ebx
8010239e:	74 6c                	je     8010240c <ideintr+0x8c>
801023a0:	89 75 f8             	mov    %esi,-0x8(%ebp)
    release(&idelock);
    return;
  }
  idequeue = b->qnext;
801023a3:	8b 43 58             	mov    0x58(%ebx),%eax
801023a6:	a3 04 26 11 80       	mov    %eax,0x80112604

  // Read data if needed.
  if(!(b->flags & B_DIRTY) && idewait(1) >= 0)
801023ab:	8b 33                	mov    (%ebx),%esi
801023ad:	f7 c6 04 00 00 00    	test   $0x4,%esi
801023b3:	75 32                	jne    801023e7 <ideintr+0x67>
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801023b5:	ba f7 01 00 00       	mov    $0x1f7,%edx
801023ba:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
801023c0:	ec                   	in     (%dx),%al
  while(((r = inb(0x1f7)) & (IDE_BSY|IDE_DRDY)) != IDE_DRDY)
801023c1:	89 c1                	mov    %eax,%ecx
801023c3:	83 e1 c0             	and    $0xffffffc0,%ecx
801023c6:	80 f9 40             	cmp    $0x40,%cl
801023c9:	75 f5                	jne    801023c0 <ideintr+0x40>
  if(checkerr && (r & (IDE_DF|IDE_ERR)) != 0)
801023cb:	a8 21                	test   $0x21,%al
801023cd:	75 18                	jne    801023e7 <ideintr+0x67>
801023cf:	89 7d fc             	mov    %edi,-0x4(%ebp)
  asm volatile("cld; rep insl" :
801023d2:	b9 80 00 00 00       	mov    $0x80,%ecx
801023d7:	ba f0 01 00 00       	mov    $0x1f0,%edx
801023dc:	8d 7b 5c             	lea    0x5c(%ebx),%edi
801023df:	fc                   	cld
801023e0:	f3 6d                	rep insl (%dx),%es:(%edi)
    insl(0x1f0, b->data, BSIZE/4);

  // Wake process waiting for this buf.
  b->flags |= B_VALID;
801023e2:	8b 33                	mov    (%ebx),%esi
801023e4:	8b 7d fc             	mov    -0x4(%ebp),%edi
  b->flags &= ~B_DIRTY;
801023e7:	83 e6 fb             	and    $0xfffffffb,%esi
  wakeup(b);
801023ea:	83 ec 0c             	sub    $0xc,%esp
  b->flags &= ~B_DIRTY;
801023ed:	83 ce 02             	or     $0x2,%esi
801023f0:	89 33                	mov    %esi,(%ebx)
  wakeup(b);
801023f2:	53                   	push   %ebx
801023f3:	e8 d8 1f 00 00       	call   801043d0 <wakeup>

  // Start disk on next buf in queue.
  if(idequeue != 0)
801023f8:	a1 04 26 11 80       	mov    0x80112604,%eax
801023fd:	83 c4 10             	add    $0x10,%esp
80102400:	85 c0                	test   %eax,%eax
80102402:	74 1c                	je     80102420 <ideintr+0xa0>
    idestart(idequeue);
80102404:	e8 27 fe ff ff       	call   80102230 <idestart>
80102409:	8b 75 f8             	mov    -0x8(%ebp),%esi
    release(&idelock);
8010240c:	83 ec 0c             	sub    $0xc,%esp
8010240f:	68 20 26 11 80       	push   $0x80112620
80102414:	e8 c7 24 00 00       	call   801048e0 <release>

  release(&idelock);
}
80102419:	8b 5d f4             	mov    -0xc(%ebp),%ebx
8010241c:	c9                   	leave
8010241d:	c3                   	ret
8010241e:	66 90                	xchg   %ax,%ax
80102420:	8b 75 f8             	mov    -0x8(%ebp),%esi
80102423:	eb e7                	jmp    8010240c <ideintr+0x8c>
80102425:	8d 76 00             	lea    0x0(%esi),%esi
80102428:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010242f:	00 

80102430 <iderw>:
// Sync buf with disk.
// If B_DIRTY is set, write buf to disk, clear B_DIRTY, set B_VALID.
// Else if B_VALID is not set, read buf from disk, set B_VALID.
void
iderw(struct buf *b)
{
80102430:	55                   	push   %ebp
80102431:	89 e5                	mov    %esp,%ebp
80102433:	53                   	push   %ebx
80102434:	83 ec 10             	sub    $0x10,%esp
80102437:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct buf **pp;

  if(!holdingsleep(&b->lock))
8010243a:	8d 43 0c             	lea    0xc(%ebx),%eax
8010243d:	50                   	push   %eax
8010243e:	e8 8d 22 00 00       	call   801046d0 <holdingsleep>
80102443:	83 c4 10             	add    $0x10,%esp
80102446:	85 c0                	test   %eax,%eax
80102448:	0f 84 c3 00 00 00    	je     80102511 <iderw+0xe1>
    panic("iderw: buf not locked");
  if((b->flags & (B_VALID|B_DIRTY)) == B_VALID)
8010244e:	8b 03                	mov    (%ebx),%eax
80102450:	83 e0 06             	and    $0x6,%eax
80102453:	83 f8 02             	cmp    $0x2,%eax
80102456:	0f 84 a8 00 00 00    	je     80102504 <iderw+0xd4>
    panic("iderw: nothing to do");
  if(b->dev != 0 && !havedisk1)
8010245c:	8b 53 04             	mov    0x4(%ebx),%edx
8010245f:	85 d2                	test   %edx,%edx
80102461:	74 0d                	je     80102470 <iderw+0x40>
80102463:	a1 00 26 11 80       	mov    0x80112600,%eax
80102468:	85 c0                	test   %eax,%eax
8010246a:	0f 84 87 00 00 00    	je     801024f7 <iderw+0xc7>
    panic("iderw: ide disk 1 not present");

  acquire(&idelock);  //DOC:acquire-lock
80102470:	83 ec 0c             	sub    $0xc,%esp
80102473:	68 20 26 11 80       	push   $0x80112620
80102478:	e8 c3 24 00 00       	call   80104940 <acquire>

  // Append b to idequeue.
  b->qnext = 0;
  for(pp=&idequeue; *pp; pp=&(*pp)->qnext)  //DOC:insert-queue
8010247d:	a1 04 26 11 80       	mov    0x80112604,%eax
  b->qnext = 0;
80102482:	c7 43 58 00 00 00 00 	movl   $0x0,0x58(%ebx)
  for(pp=&idequeue; *pp; pp=&(*pp)->qnext)  //DOC:insert-queue
80102489:	83 c4 10             	add    $0x10,%esp
8010248c:	85 c0                	test   %eax,%eax
8010248e:	74 60                	je     801024f0 <iderw+0xc0>
80102490:	89 c2                	mov    %eax,%edx
80102492:	8b 40 58             	mov    0x58(%eax),%eax
80102495:	85 c0                	test   %eax,%eax
80102497:	75 f7                	jne    80102490 <iderw+0x60>
80102499:	83 c2 58             	add    $0x58,%edx
    ;
  *pp = b;
8010249c:	89 1a                	mov    %ebx,(%edx)

  // Start disk if necessary.
  if(idequeue == b)
8010249e:	39 1d 04 26 11 80    	cmp    %ebx,0x80112604
801024a4:	74 3a                	je     801024e0 <iderw+0xb0>
    idestart(b);

  // Wait for request to finish.
  while((b->flags & (B_VALID|B_DIRTY)) != B_VALID){
801024a6:	8b 03                	mov    (%ebx),%eax
801024a8:	83 e0 06             	and    $0x6,%eax
801024ab:	83 f8 02             	cmp    $0x2,%eax
801024ae:	74 1b                	je     801024cb <iderw+0x9b>
    sleep(b, &idelock);
801024b0:	83 ec 08             	sub    $0x8,%esp
801024b3:	68 20 26 11 80       	push   $0x80112620
801024b8:	53                   	push   %ebx
801024b9:	e8 52 1e 00 00       	call   80104310 <sleep>
  while((b->flags & (B_VALID|B_DIRTY)) != B_VALID){
801024be:	8b 03                	mov    (%ebx),%eax
801024c0:	83 c4 10             	add    $0x10,%esp
801024c3:	83 e0 06             	and    $0x6,%eax
801024c6:	83 f8 02             	cmp    $0x2,%eax
801024c9:	75 e5                	jne    801024b0 <iderw+0x80>
  }


  release(&idelock);
801024cb:	c7 45 08 20 26 11 80 	movl   $0x80112620,0x8(%ebp)
}
801024d2:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801024d5:	c9                   	leave
  release(&idelock);
801024d6:	e9 05 24 00 00       	jmp    801048e0 <release>
801024db:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    idestart(b);
801024e0:	89 d8                	mov    %ebx,%eax
801024e2:	e8 49 fd ff ff       	call   80102230 <idestart>
801024e7:	eb bd                	jmp    801024a6 <iderw+0x76>
801024e9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  for(pp=&idequeue; *pp; pp=&(*pp)->qnext)  //DOC:insert-queue
801024f0:	ba 04 26 11 80       	mov    $0x80112604,%edx
801024f5:	eb a5                	jmp    8010249c <iderw+0x6c>
    panic("iderw: ide disk 1 not present");
801024f7:	83 ec 0c             	sub    $0xc,%esp
801024fa:	68 ee 7a 10 80       	push   $0x80107aee
801024ff:	e8 9c de ff ff       	call   801003a0 <panic>
    panic("iderw: nothing to do");
80102504:	83 ec 0c             	sub    $0xc,%esp
80102507:	68 d9 7a 10 80       	push   $0x80107ad9
8010250c:	e8 8f de ff ff       	call   801003a0 <panic>
    panic("iderw: buf not locked");
80102511:	83 ec 0c             	sub    $0xc,%esp
80102514:	68 c3 7a 10 80       	push   $0x80107ac3
80102519:	e8 82 de ff ff       	call   801003a0 <panic>
8010251e:	66 90                	xchg   %ax,%ax
80102520:	66 90                	xchg   %ax,%ax
80102522:	66 90                	xchg   %ax,%ax
80102524:	66 90                	xchg   %ax,%ax
80102526:	66 90                	xchg   %ax,%ax
80102528:	66 90                	xchg   %ax,%ax
8010252a:	66 90                	xchg   %ax,%ax
8010252c:	66 90                	xchg   %ax,%ax
8010252e:	66 90                	xchg   %ax,%ax
80102530:	66 90                	xchg   %ax,%ax
80102532:	66 90                	xchg   %ax,%ax
80102534:	66 90                	xchg   %ax,%ax
80102536:	66 90                	xchg   %ax,%ax
80102538:	66 90                	xchg   %ax,%ax
8010253a:	66 90                	xchg   %ax,%ax
8010253c:	66 90                	xchg   %ax,%ax
8010253e:	66 90                	xchg   %ax,%ax

80102540 <ioapicinit>:
  ioapic->data = data;
}

void
ioapicinit(void)
{
80102540:	55                   	push   %ebp
80102541:	89 e5                	mov    %esp,%ebp
80102543:	56                   	push   %esi
80102544:	53                   	push   %ebx
  int i, id, maxintr;

  ioapic = (volatile struct ioapic*)IOAPIC;
80102545:	c7 05 54 26 11 80 00 	movl   $0xfec00000,0x80112654
8010254c:	00 c0 fe 
  ioapic->reg = reg;
8010254f:	c7 05 00 00 c0 fe 01 	movl   $0x1,0xfec00000
80102556:	00 00 00 
  return ioapic->data;
80102559:	8b 15 54 26 11 80    	mov    0x80112654,%edx
8010255f:	8b 72 10             	mov    0x10(%edx),%esi
  ioapic->reg = reg;
80102562:	c7 02 00 00 00 00    	movl   $0x0,(%edx)
  return ioapic->data;
80102568:	8b 0d 54 26 11 80    	mov    0x80112654,%ecx
  maxintr = (ioapicread(REG_VER) >> 16) & 0xFF;
  id = ioapicread(REG_ID) >> 24;
  if(id != ioapicid)
8010256e:	0f b6 15 a0 27 11 80 	movzbl 0x801127a0,%edx
  maxintr = (ioapicread(REG_VER) >> 16) & 0xFF;
80102575:	c1 ee 10             	shr    $0x10,%esi
80102578:	89 f0                	mov    %esi,%eax
8010257a:	0f b6 f0             	movzbl %al,%esi
  return ioapic->data;
8010257d:	8b 41 10             	mov    0x10(%ecx),%eax
  id = ioapicread(REG_ID) >> 24;
80102580:	c1 e8 18             	shr    $0x18,%eax
  if(id != ioapicid)
80102583:	39 c2                	cmp    %eax,%edx
80102585:	74 16                	je     8010259d <ioapicinit+0x5d>
    cprintf("ioapicinit: id isn't equal to ioapicid; not a MP\n");
80102587:	83 ec 0c             	sub    $0xc,%esp
8010258a:	68 a8 7e 10 80       	push   $0x80107ea8
8010258f:	e8 5c e1 ff ff       	call   801006f0 <cprintf>
  ioapic->reg = reg;
80102594:	8b 0d 54 26 11 80    	mov    0x80112654,%ecx
8010259a:	83 c4 10             	add    $0x10,%esp

  // Mark all interrupts edge-triggered, active high, disabled,
  // and not routed to any CPUs.
  for(i = 0; i <= maxintr; i++){
8010259d:	83 c6 21             	add    $0x21,%esi
{
801025a0:	ba 10 00 00 00       	mov    $0x10,%edx
801025a5:	b8 20 00 00 00       	mov    $0x20,%eax
801025aa:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
801025b0:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801025b7:	00 
801025b8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801025bf:	00 
  ioapic->reg = reg;
801025c0:	89 11                	mov    %edx,(%ecx)
801025c2:	89 c3                	mov    %eax,%ebx
  ioapic->data = data;
801025c4:	8b 0d 54 26 11 80    	mov    0x80112654,%ecx
  for(i = 0; i <= maxintr; i++){
801025ca:	83 c0 01             	add    $0x1,%eax
801025cd:	81 cb 00 00 01 00    	or     $0x10000,%ebx
  ioapic->data = data;
801025d3:	89 59 10             	mov    %ebx,0x10(%ecx)
  ioapic->reg = reg;
801025d6:	8d 5a 01             	lea    0x1(%edx),%ebx
  for(i = 0; i <= maxintr; i++){
801025d9:	83 c2 02             	add    $0x2,%edx
  ioapic->reg = reg;
801025dc:	89 19                	mov    %ebx,(%ecx)
  ioapic->data = data;
801025de:	8b 0d 54 26 11 80    	mov    0x80112654,%ecx
801025e4:	c7 41 10 00 00 00 00 	movl   $0x0,0x10(%ecx)
  for(i = 0; i <= maxintr; i++){
801025eb:	39 f0                	cmp    %esi,%eax
801025ed:	75 d1                	jne    801025c0 <ioapicinit+0x80>
    ioapicwrite(REG_TABLE+2*i, INT_DISABLED | (T_IRQ0 + i));
    ioapicwrite(REG_TABLE+2*i+1, 0);
  }
}
801025ef:	8d 65 f8             	lea    -0x8(%ebp),%esp
801025f2:	5b                   	pop    %ebx
801025f3:	5e                   	pop    %esi
801025f4:	5d                   	pop    %ebp
801025f5:	c3                   	ret
801025f6:	66 90                	xchg   %ax,%ax
801025f8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801025ff:	00 

80102600 <ioapicenable>:

void
ioapicenable(int irq, int cpunum)
{
80102600:	55                   	push   %ebp
  ioapic->reg = reg;
80102601:	8b 0d 54 26 11 80    	mov    0x80112654,%ecx
{
80102607:	89 e5                	mov    %esp,%ebp
80102609:	8b 45 08             	mov    0x8(%ebp),%eax
  // Mark interrupt edge-triggered, active high,
  // enabled, and routed to the given cpunum,
  // which happens to be that cpu's APIC ID.
  ioapicwrite(REG_TABLE+2*irq, T_IRQ0 + irq);
8010260c:	8d 50 20             	lea    0x20(%eax),%edx
8010260f:	8d 44 00 10          	lea    0x10(%eax,%eax,1),%eax
  ioapic->reg = reg;
80102613:	89 01                	mov    %eax,(%ecx)
  ioapic->data = data;
80102615:	8b 0d 54 26 11 80    	mov    0x80112654,%ecx
  ioapicwrite(REG_TABLE+2*irq+1, cpunum << 24);
8010261b:	83 c0 01             	add    $0x1,%eax
  ioapic->data = data;
8010261e:	89 51 10             	mov    %edx,0x10(%ecx)
  ioapicwrite(REG_TABLE+2*irq+1, cpunum << 24);
80102621:	8b 55 0c             	mov    0xc(%ebp),%edx
  ioapic->reg = reg;
80102624:	89 01                	mov    %eax,(%ecx)
  ioapic->data = data;
80102626:	a1 54 26 11 80       	mov    0x80112654,%eax
  ioapicwrite(REG_TABLE+2*irq+1, cpunum << 24);
8010262b:	c1 e2 18             	shl    $0x18,%edx
  ioapic->data = data;
8010262e:	89 50 10             	mov    %edx,0x10(%eax)
}
80102631:	5d                   	pop    %ebp
80102632:	c3                   	ret
80102633:	66 90                	xchg   %ax,%ax
80102635:	66 90                	xchg   %ax,%ax
80102637:	66 90                	xchg   %ax,%ax
80102639:	66 90                	xchg   %ax,%ax
8010263b:	66 90                	xchg   %ax,%ax
8010263d:	66 90                	xchg   %ax,%ax
8010263f:	90                   	nop

80102640 <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(char *v)
{
80102640:	55                   	push   %ebp
80102641:	89 e5                	mov    %esp,%ebp
80102643:	53                   	push   %ebx
80102644:	83 ec 04             	sub    $0x4,%esp
80102647:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct run *r;

  if((uint)v % PGSIZE || v < end || V2P(v) >= PHYSTOP)
8010264a:	f7 c3 ff 0f 00 00    	test   $0xfff,%ebx
80102650:	75 76                	jne    801026c8 <kfree+0x88>
80102652:	81 fb f0 65 11 80    	cmp    $0x801165f0,%ebx
80102658:	72 6e                	jb     801026c8 <kfree+0x88>
8010265a:	8d 83 00 00 00 80    	lea    -0x80000000(%ebx),%eax
80102660:	3d ff ff ff 0d       	cmp    $0xdffffff,%eax
80102665:	77 61                	ja     801026c8 <kfree+0x88>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(v, 1, PGSIZE);
80102667:	83 ec 04             	sub    $0x4,%esp
8010266a:	68 00 10 00 00       	push   $0x1000
8010266f:	6a 01                	push   $0x1
80102671:	53                   	push   %ebx
80102672:	e8 e9 23 00 00       	call   80104a60 <memset>

  if(kmem.use_lock)
80102677:	8b 15 94 26 11 80    	mov    0x80112694,%edx
8010267d:	83 c4 10             	add    $0x10,%esp
80102680:	85 d2                	test   %edx,%edx
80102682:	75 1c                	jne    801026a0 <kfree+0x60>
    acquire(&kmem.lock);
  r = (struct run*)v;
  r->next = kmem.freelist;
80102684:	a1 98 26 11 80       	mov    0x80112698,%eax
80102689:	89 03                	mov    %eax,(%ebx)
  kmem.freelist = r;
  if(kmem.use_lock)
8010268b:	a1 94 26 11 80       	mov    0x80112694,%eax
  kmem.freelist = r;
80102690:	89 1d 98 26 11 80    	mov    %ebx,0x80112698
  if(kmem.use_lock)
80102696:	85 c0                	test   %eax,%eax
80102698:	75 1e                	jne    801026b8 <kfree+0x78>
    release(&kmem.lock);
}
8010269a:	8b 5d fc             	mov    -0x4(%ebp),%ebx
8010269d:	c9                   	leave
8010269e:	c3                   	ret
8010269f:	90                   	nop
    acquire(&kmem.lock);
801026a0:	83 ec 0c             	sub    $0xc,%esp
801026a3:	68 60 26 11 80       	push   $0x80112660
801026a8:	e8 93 22 00 00       	call   80104940 <acquire>
801026ad:	83 c4 10             	add    $0x10,%esp
801026b0:	eb d2                	jmp    80102684 <kfree+0x44>
801026b2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    release(&kmem.lock);
801026b8:	c7 45 08 60 26 11 80 	movl   $0x80112660,0x8(%ebp)
}
801026bf:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801026c2:	c9                   	leave
    release(&kmem.lock);
801026c3:	e9 18 22 00 00       	jmp    801048e0 <release>
    panic("kfree");
801026c8:	83 ec 0c             	sub    $0xc,%esp
801026cb:	68 0c 7b 10 80       	push   $0x80107b0c
801026d0:	e8 cb dc ff ff       	call   801003a0 <panic>
801026d5:	8d 76 00             	lea    0x0(%esi),%esi
801026d8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801026df:	00 

801026e0 <freerange>:
{
801026e0:	55                   	push   %ebp
801026e1:	89 e5                	mov    %esp,%ebp
801026e3:	56                   	push   %esi
801026e4:	53                   	push   %ebx
  p = (char*)PGROUNDUP((uint)vstart);
801026e5:	8b 45 08             	mov    0x8(%ebp),%eax
{
801026e8:	8b 75 0c             	mov    0xc(%ebp),%esi
  p = (char*)PGROUNDUP((uint)vstart);
801026eb:	8d 98 ff 0f 00 00    	lea    0xfff(%eax),%ebx
801026f1:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
801026f7:	81 c3 00 10 00 00    	add    $0x1000,%ebx
801026fd:	39 de                	cmp    %ebx,%esi
801026ff:	72 2b                	jb     8010272c <freerange+0x4c>
80102701:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80102708:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010270f:	00 
    kfree(p);
80102710:	83 ec 0c             	sub    $0xc,%esp
80102713:	8d 83 00 f0 ff ff    	lea    -0x1000(%ebx),%eax
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80102719:	81 c3 00 10 00 00    	add    $0x1000,%ebx
    kfree(p);
8010271f:	50                   	push   %eax
80102720:	e8 1b ff ff ff       	call   80102640 <kfree>
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80102725:	83 c4 10             	add    $0x10,%esp
80102728:	39 de                	cmp    %ebx,%esi
8010272a:	73 e4                	jae    80102710 <freerange+0x30>
}
8010272c:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010272f:	5b                   	pop    %ebx
80102730:	5e                   	pop    %esi
80102731:	5d                   	pop    %ebp
80102732:	c3                   	ret
80102733:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80102738:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010273f:	00 

80102740 <kinit2>:
{
80102740:	55                   	push   %ebp
80102741:	89 e5                	mov    %esp,%ebp
80102743:	56                   	push   %esi
80102744:	53                   	push   %ebx
  p = (char*)PGROUNDUP((uint)vstart);
80102745:	8b 45 08             	mov    0x8(%ebp),%eax
{
80102748:	8b 75 0c             	mov    0xc(%ebp),%esi
  p = (char*)PGROUNDUP((uint)vstart);
8010274b:	8d 98 ff 0f 00 00    	lea    0xfff(%eax),%ebx
80102751:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80102757:	81 c3 00 10 00 00    	add    $0x1000,%ebx
8010275d:	39 de                	cmp    %ebx,%esi
8010275f:	72 2b                	jb     8010278c <kinit2+0x4c>
80102761:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80102768:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010276f:	00 
    kfree(p);
80102770:	83 ec 0c             	sub    $0xc,%esp
80102773:	8d 83 00 f0 ff ff    	lea    -0x1000(%ebx),%eax
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80102779:	81 c3 00 10 00 00    	add    $0x1000,%ebx
    kfree(p);
8010277f:	50                   	push   %eax
80102780:	e8 bb fe ff ff       	call   80102640 <kfree>
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80102785:	83 c4 10             	add    $0x10,%esp
80102788:	39 de                	cmp    %ebx,%esi
8010278a:	73 e4                	jae    80102770 <kinit2+0x30>
  kmem.use_lock = 1;
8010278c:	c7 05 94 26 11 80 01 	movl   $0x1,0x80112694
80102793:	00 00 00 
}
80102796:	8d 65 f8             	lea    -0x8(%ebp),%esp
80102799:	5b                   	pop    %ebx
8010279a:	5e                   	pop    %esi
8010279b:	5d                   	pop    %ebp
8010279c:	c3                   	ret
8010279d:	8d 76 00             	lea    0x0(%esi),%esi

801027a0 <kinit1>:
{
801027a0:	55                   	push   %ebp
801027a1:	89 e5                	mov    %esp,%ebp
801027a3:	56                   	push   %esi
801027a4:	53                   	push   %ebx
801027a5:	8b 75 0c             	mov    0xc(%ebp),%esi
  initlock(&kmem.lock, "kmem");
801027a8:	83 ec 08             	sub    $0x8,%esp
801027ab:	68 12 7b 10 80       	push   $0x80107b12
801027b0:	68 60 26 11 80       	push   $0x80112660
801027b5:	e8 66 1f 00 00       	call   80104720 <initlock>
  p = (char*)PGROUNDUP((uint)vstart);
801027ba:	8b 45 08             	mov    0x8(%ebp),%eax
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
801027bd:	83 c4 10             	add    $0x10,%esp
  kmem.use_lock = 0;
801027c0:	c7 05 94 26 11 80 00 	movl   $0x0,0x80112694
801027c7:	00 00 00 
  p = (char*)PGROUNDUP((uint)vstart);
801027ca:	8d 98 ff 0f 00 00    	lea    0xfff(%eax),%ebx
801027d0:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
801027d6:	81 c3 00 10 00 00    	add    $0x1000,%ebx
801027dc:	39 de                	cmp    %ebx,%esi
801027de:	72 1c                	jb     801027fc <kinit1+0x5c>
    kfree(p);
801027e0:	83 ec 0c             	sub    $0xc,%esp
801027e3:	8d 83 00 f0 ff ff    	lea    -0x1000(%ebx),%eax
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
801027e9:	81 c3 00 10 00 00    	add    $0x1000,%ebx
    kfree(p);
801027ef:	50                   	push   %eax
801027f0:	e8 4b fe ff ff       	call   80102640 <kfree>
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
801027f5:	83 c4 10             	add    $0x10,%esp
801027f8:	39 de                	cmp    %ebx,%esi
801027fa:	73 e4                	jae    801027e0 <kinit1+0x40>
}
801027fc:	8d 65 f8             	lea    -0x8(%ebp),%esp
801027ff:	5b                   	pop    %ebx
80102800:	5e                   	pop    %esi
80102801:	5d                   	pop    %ebp
80102802:	c3                   	ret
80102803:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80102808:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010280f:	00 

80102810 <kalloc>:
char*
kalloc(void)
{
  struct run *r;

  if(kmem.use_lock)
80102810:	a1 94 26 11 80       	mov    0x80112694,%eax
80102815:	85 c0                	test   %eax,%eax
80102817:	75 1f                	jne    80102838 <kalloc+0x28>
    acquire(&kmem.lock);
  r = kmem.freelist;
80102819:	a1 98 26 11 80       	mov    0x80112698,%eax
  if(r)
8010281e:	85 c0                	test   %eax,%eax
80102820:	74 0e                	je     80102830 <kalloc+0x20>
    kmem.freelist = r->next;
80102822:	8b 10                	mov    (%eax),%edx
80102824:	89 15 98 26 11 80    	mov    %edx,0x80112698
  if(kmem.use_lock)
8010282a:	c3                   	ret
8010282b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    release(&kmem.lock);
  return (char*)r;
}
80102830:	c3                   	ret
80102831:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
{
80102838:	55                   	push   %ebp
80102839:	89 e5                	mov    %esp,%ebp
8010283b:	83 ec 24             	sub    $0x24,%esp
    acquire(&kmem.lock);
8010283e:	68 60 26 11 80       	push   $0x80112660
80102843:	e8 f8 20 00 00       	call   80104940 <acquire>
  r = kmem.freelist;
80102848:	a1 98 26 11 80       	mov    0x80112698,%eax
  if(kmem.use_lock)
8010284d:	8b 15 94 26 11 80    	mov    0x80112694,%edx
  if(r)
80102853:	83 c4 10             	add    $0x10,%esp
80102856:	85 c0                	test   %eax,%eax
80102858:	74 08                	je     80102862 <kalloc+0x52>
    kmem.freelist = r->next;
8010285a:	8b 08                	mov    (%eax),%ecx
8010285c:	89 0d 98 26 11 80    	mov    %ecx,0x80112698
  if(kmem.use_lock)
80102862:	85 d2                	test   %edx,%edx
80102864:	74 16                	je     8010287c <kalloc+0x6c>
    release(&kmem.lock);
80102866:	83 ec 0c             	sub    $0xc,%esp
80102869:	89 45 f4             	mov    %eax,-0xc(%ebp)
8010286c:	68 60 26 11 80       	push   $0x80112660
80102871:	e8 6a 20 00 00       	call   801048e0 <release>
  return (char*)r;
80102876:	8b 45 f4             	mov    -0xc(%ebp),%eax
    release(&kmem.lock);
80102879:	83 c4 10             	add    $0x10,%esp
}
8010287c:	c9                   	leave
8010287d:	c3                   	ret
8010287e:	66 90                	xchg   %ax,%ax

80102880 <kbdgetc>:
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102880:	ba 64 00 00 00       	mov    $0x64,%edx
80102885:	ec                   	in     (%dx),%al
    normalmap, shiftmap, ctlmap, ctlmap
  };
  uint st, data, c;

  st = inb(KBSTATP);
  if((st & KBS_DIB) == 0)
80102886:	a8 01                	test   $0x1,%al
80102888:	74 6e                	je     801028f8 <kbdgetc+0x78>
8010288a:	ba 60 00 00 00       	mov    $0x60,%edx
8010288f:	ec                   	in     (%dx),%al
    return -1;
  data = inb(KBDATAP);

  if(data == 0xE0){
    shift |= E0ESC;
80102890:	8b 15 9c 26 11 80    	mov    0x8011269c,%edx
  data = inb(KBDATAP);
80102896:	0f b6 c8             	movzbl %al,%ecx
  if(data == 0xE0){
80102899:	3c e0                	cmp    $0xe0,%al
8010289b:	74 63                	je     80102900 <kbdgetc+0x80>
    return 0;
  } else if(data & 0x80){
8010289d:	84 c0                	test   %al,%al
8010289f:	78 6f                	js     80102910 <kbdgetc+0x90>
    shift &= ~(shiftcode[data] | E0ESC);
    return 0;
  } else if(shift & E0ESC){
    // Last character was an E0 escape; or with 0x80
    data |= 0x80;
    shift &= ~E0ESC;
801028a1:	83 c8 80             	or     $0xffffff80,%eax
801028a4:	f6 c2 40             	test   $0x40,%dl
801028a7:	0f b6 c0             	movzbl %al,%eax
801028aa:	0f 45 c8             	cmovne %eax,%ecx
801028ad:	89 d0                	mov    %edx,%eax
801028af:	83 e0 bf             	and    $0xffffffbf,%eax
801028b2:	f6 c2 40             	test   $0x40,%dl
801028b5:	0f 45 d0             	cmovne %eax,%edx
  }

  shift |= shiftcode[data];
801028b8:	0f b6 81 00 81 10 80 	movzbl -0x7fef7f00(%ecx),%eax
801028bf:	09 c2                	or     %eax,%edx
  shift ^= togglecode[data];
801028c1:	0f b6 81 00 80 10 80 	movzbl -0x7fef8000(%ecx),%eax
801028c8:	31 c2                	xor    %eax,%edx
  c = charcode[shift & (CTL | SHIFT)][data];
801028ca:	89 d0                	mov    %edx,%eax
  shift ^= togglecode[data];
801028cc:	89 15 9c 26 11 80    	mov    %edx,0x8011269c
  c = charcode[shift & (CTL | SHIFT)][data];
801028d2:	83 e0 03             	and    $0x3,%eax
  if(shift & CAPSLOCK){
801028d5:	83 e2 08             	and    $0x8,%edx
  c = charcode[shift & (CTL | SHIFT)][data];
801028d8:	8b 04 85 e0 7f 10 80 	mov    -0x7fef8020(,%eax,4),%eax
801028df:	0f b6 04 08          	movzbl (%eax,%ecx,1),%eax
  if(shift & CAPSLOCK){
801028e3:	74 18                	je     801028fd <kbdgetc+0x7d>
    if('a' <= c && c <= 'z')
801028e5:	8d 50 9f             	lea    -0x61(%eax),%edx
801028e8:	83 fa 19             	cmp    $0x19,%edx
801028eb:	77 4b                	ja     80102938 <kbdgetc+0xb8>
      c += 'A' - 'a';
801028ed:	83 e8 20             	sub    $0x20,%eax
801028f0:	c3                   	ret
801028f1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    return -1;
801028f8:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    else if('A' <= c && c <= 'Z')
      c += 'a' - 'A';
  }
  return c;
}
801028fd:	c3                   	ret
801028fe:	66 90                	xchg   %ax,%ax
    shift |= E0ESC;
80102900:	83 ca 40             	or     $0x40,%edx
    return 0;
80102903:	31 c0                	xor    %eax,%eax
    shift |= E0ESC;
80102905:	89 15 9c 26 11 80    	mov    %edx,0x8011269c
    return 0;
8010290b:	c3                   	ret
8010290c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    data = (shift & E0ESC ? data : data & 0x7F);
80102910:	83 e0 7f             	and    $0x7f,%eax
80102913:	f6 c2 40             	test   $0x40,%dl
80102916:	0f 44 c8             	cmove  %eax,%ecx
    shift &= ~(shiftcode[data] | E0ESC);
80102919:	0f b6 81 00 81 10 80 	movzbl -0x7fef7f00(%ecx),%eax
80102920:	83 c8 40             	or     $0x40,%eax
80102923:	0f b6 c0             	movzbl %al,%eax
80102926:	f7 d0                	not    %eax
80102928:	21 d0                	and    %edx,%eax
8010292a:	a3 9c 26 11 80       	mov    %eax,0x8011269c
    return 0;
8010292f:	31 c0                	xor    %eax,%eax
80102931:	c3                   	ret
80102932:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    else if('A' <= c && c <= 'Z')
80102938:	8d 48 bf             	lea    -0x41(%eax),%ecx
      c += 'a' - 'A';
8010293b:	8d 50 20             	lea    0x20(%eax),%edx
8010293e:	83 f9 1a             	cmp    $0x1a,%ecx
80102941:	0f 42 c2             	cmovb  %edx,%eax
  return c;
80102944:	c3                   	ret
80102945:	8d 76 00             	lea    0x0(%esi),%esi
80102948:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010294f:	00 

80102950 <kbdintr>:

void
kbdintr(void)
{
80102950:	55                   	push   %ebp
80102951:	89 e5                	mov    %esp,%ebp
80102953:	83 ec 14             	sub    $0x14,%esp
  consoleintr(kbdgetc);
80102956:	68 80 28 10 80       	push   $0x80102880
8010295b:	e8 b0 df ff ff       	call   80100910 <consoleintr>
}
80102960:	83 c4 10             	add    $0x10,%esp
80102963:	c9                   	leave
80102964:	c3                   	ret
80102965:	66 90                	xchg   %ax,%ax
80102967:	66 90                	xchg   %ax,%ax
80102969:	66 90                	xchg   %ax,%ax
8010296b:	66 90                	xchg   %ax,%ax
8010296d:	66 90                	xchg   %ax,%ax
8010296f:	90                   	nop

80102970 <lapicinit>:
}

void
lapicinit(void)
{
  if(!lapic)
80102970:	a1 a0 26 11 80       	mov    0x801126a0,%eax
80102975:	85 c0                	test   %eax,%eax
80102977:	0f 84 cc 00 00 00    	je     80102a49 <lapicinit+0xd9>
  lapic[index] = value;
8010297d:	c7 80 f0 00 00 00 3f 	movl   $0x13f,0xf0(%eax)
80102984:	01 00 00 
  lapic[ID];  // wait for write to finish, by reading
80102987:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
8010298a:	c7 80 e0 03 00 00 0b 	movl   $0xb,0x3e0(%eax)
80102991:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
80102994:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
80102997:	c7 80 20 03 00 00 20 	movl   $0x20020,0x320(%eax)
8010299e:	00 02 00 
  lapic[ID];  // wait for write to finish, by reading
801029a1:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
801029a4:	c7 80 80 03 00 00 80 	movl   $0x989680,0x380(%eax)
801029ab:	96 98 00 
  lapic[ID];  // wait for write to finish, by reading
801029ae:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
801029b1:	c7 80 50 03 00 00 00 	movl   $0x10000,0x350(%eax)
801029b8:	00 01 00 
  lapic[ID];  // wait for write to finish, by reading
801029bb:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
801029be:	c7 80 60 03 00 00 00 	movl   $0x10000,0x360(%eax)
801029c5:	00 01 00 
  lapic[ID];  // wait for write to finish, by reading
801029c8:	8b 50 20             	mov    0x20(%eax),%edx
  lapicw(LINT0, MASKED);
  lapicw(LINT1, MASKED);

  // Disable performance counter overflow interrupts
  // on machines that provide that interrupt entry.
  if(((lapic[VER]>>16) & 0xFF) >= 4)
801029cb:	f7 40 30 00 00 fc 00 	testl  $0xfc0000,0x30(%eax)
801029d2:	75 7c                	jne    80102a50 <lapicinit+0xe0>
  lapic[index] = value;
801029d4:	c7 80 70 03 00 00 33 	movl   $0x33,0x370(%eax)
801029db:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
801029de:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
801029e1:	c7 80 80 02 00 00 00 	movl   $0x0,0x280(%eax)
801029e8:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
801029eb:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
801029ee:	c7 80 80 02 00 00 00 	movl   $0x0,0x280(%eax)
801029f5:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
801029f8:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
801029fb:	c7 80 b0 00 00 00 00 	movl   $0x0,0xb0(%eax)
80102a02:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
80102a05:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
80102a08:	c7 80 10 03 00 00 00 	movl   $0x0,0x310(%eax)
80102a0f:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
80102a12:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
80102a15:	c7 80 00 03 00 00 00 	movl   $0x88500,0x300(%eax)
80102a1c:	85 08 00 
  lapic[ID];  // wait for write to finish, by reading
80102a1f:	8b 50 20             	mov    0x20(%eax),%edx
  lapicw(EOI, 0);

  // Send an Init Level De-Assert to synchronise arbitration ID's.
  lapicw(ICRHI, 0);
  lapicw(ICRLO, BCAST | INIT | LEVEL);
  while(lapic[ICRLO] & DELIVS)
80102a22:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80102a28:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102a2f:	00 
80102a30:	f7 80 00 03 00 00 00 	testl  $0x1000,0x300(%eax)
80102a37:	10 00 00 
80102a3a:	75 f4                	jne    80102a30 <lapicinit+0xc0>
  lapic[index] = value;
80102a3c:	c7 80 80 00 00 00 00 	movl   $0x0,0x80(%eax)
80102a43:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
80102a46:	8b 40 20             	mov    0x20(%eax),%eax
    ;

  // Enable interrupts on the APIC (but not on the processor).
  lapicw(TPR, 0);
}
80102a49:	c3                   	ret
80102a4a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  lapic[index] = value;
80102a50:	c7 80 40 03 00 00 00 	movl   $0x10000,0x340(%eax)
80102a57:	00 01 00 
  lapic[ID];  // wait for write to finish, by reading
80102a5a:	8b 50 20             	mov    0x20(%eax),%edx
80102a5d:	e9 72 ff ff ff       	jmp    801029d4 <lapicinit+0x64>
80102a62:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80102a68:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102a6f:	00 

80102a70 <lapicid>:

int
lapicid(void)
{
  if (!lapic)
80102a70:	a1 a0 26 11 80       	mov    0x801126a0,%eax
80102a75:	85 c0                	test   %eax,%eax
80102a77:	74 07                	je     80102a80 <lapicid+0x10>
    return 0;
  return lapic[ID] >> 24;
80102a79:	8b 40 20             	mov    0x20(%eax),%eax
80102a7c:	c1 e8 18             	shr    $0x18,%eax
80102a7f:	c3                   	ret
80102a80:	31 c0                	xor    %eax,%eax
}
80102a82:	c3                   	ret
80102a83:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80102a88:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102a8f:	00 

80102a90 <lapiceoi>:

// Acknowledge interrupt.
void
lapiceoi(void)
{
  if(lapic)
80102a90:	a1 a0 26 11 80       	mov    0x801126a0,%eax
80102a95:	85 c0                	test   %eax,%eax
80102a97:	74 0d                	je     80102aa6 <lapiceoi+0x16>
  lapic[index] = value;
80102a99:	c7 80 b0 00 00 00 00 	movl   $0x0,0xb0(%eax)
80102aa0:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
80102aa3:	8b 40 20             	mov    0x20(%eax),%eax
    lapicw(EOI, 0);
}
80102aa6:	c3                   	ret
80102aa7:	90                   	nop
80102aa8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102aaf:	00 

80102ab0 <microdelay>:
// Spin for a given number of microseconds.
// On real hardware would want to tune this dynamically.
void
microdelay(int us)
{
}
80102ab0:	c3                   	ret
80102ab1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80102ab8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102abf:	00 

80102ac0 <lapicstartap>:

// Start additional processor running entry code at addr.
// See Appendix B of MultiProcessor Specification.
void
lapicstartap(uchar apicid, uint addr)
{
80102ac0:	55                   	push   %ebp
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102ac1:	ba 70 00 00 00       	mov    $0x70,%edx
80102ac6:	89 e5                	mov    %esp,%ebp
80102ac8:	56                   	push   %esi
80102ac9:	53                   	push   %ebx
80102aca:	83 ec 04             	sub    $0x4,%esp
80102acd:	0f b6 45 08          	movzbl 0x8(%ebp),%eax
80102ad1:	8b 4d 0c             	mov    0xc(%ebp),%ecx
80102ad4:	88 45 f4             	mov    %al,-0xc(%ebp)
80102ad7:	b8 0f 00 00 00       	mov    $0xf,%eax
80102adc:	ee                   	out    %al,(%dx)
80102add:	b8 0a 00 00 00       	mov    $0xa,%eax
80102ae2:	ba 71 00 00 00       	mov    $0x71,%edx
80102ae7:	ee                   	out    %al,(%dx)
  // and the warm reset vector (DWORD based at 40:67) to point at
  // the AP startup code prior to the [universal startup algorithm]."
  outb(CMOS_PORT, 0xF);  // offset 0xF is shutdown code
  outb(CMOS_PORT+1, 0x0A);
  wrv = (ushort*)P2V((0x40<<4 | 0x67));  // Warm reset vector
  wrv[0] = 0;
80102ae8:	31 c0                	xor    %eax,%eax
80102aea:	66 a3 67 04 00 80    	mov    %ax,0x80000467
  wrv[1] = addr >> 4;
80102af0:	89 c8                	mov    %ecx,%eax
  // when it is in the halted state due to an INIT.  So the second
  // should be ignored, but it is part of the official Intel algorithm.
  // Bochs complains about the second one.  Too bad for Bochs.
  for(i = 0; i < 2; i++){
    lapicw(ICRHI, apicid<<24);
    lapicw(ICRLO, STARTUP | (addr>>12));
80102af2:	c1 e9 0c             	shr    $0xc,%ecx
  wrv[1] = addr >> 4;
80102af5:	c1 e8 04             	shr    $0x4,%eax
    lapicw(ICRLO, STARTUP | (addr>>12));
80102af8:	80 cd 06             	or     $0x6,%ch
  wrv[1] = addr >> 4;
80102afb:	66 a3 69 04 00 80    	mov    %ax,0x80000469
  lapic[index] = value;
80102b01:	8b 55 f4             	mov    -0xc(%ebp),%edx
80102b04:	a1 a0 26 11 80       	mov    0x801126a0,%eax
80102b09:	c1 e2 18             	shl    $0x18,%edx
80102b0c:	89 90 10 03 00 00    	mov    %edx,0x310(%eax)
  lapic[ID];  // wait for write to finish, by reading
80102b12:	8b 58 20             	mov    0x20(%eax),%ebx
  lapic[index] = value;
80102b15:	c7 80 00 03 00 00 00 	movl   $0xc500,0x300(%eax)
80102b1c:	c5 00 00 
  lapic[ID];  // wait for write to finish, by reading
80102b1f:	8b 58 20             	mov    0x20(%eax),%ebx
  lapic[index] = value;
80102b22:	c7 80 00 03 00 00 00 	movl   $0x8500,0x300(%eax)
80102b29:	85 00 00 
  lapic[ID];  // wait for write to finish, by reading
80102b2c:	8b 58 20             	mov    0x20(%eax),%ebx
    lapicw(ICRLO, STARTUP | (addr>>12));
80102b2f:	bb 02 00 00 00       	mov    $0x2,%ebx
  lapic[index] = value;
80102b34:	89 90 10 03 00 00    	mov    %edx,0x310(%eax)
  lapic[ID];  // wait for write to finish, by reading
80102b3a:	8b 70 20             	mov    0x20(%eax),%esi
  lapic[index] = value;
80102b3d:	89 88 00 03 00 00    	mov    %ecx,0x300(%eax)
  lapic[ID];  // wait for write to finish, by reading
80102b43:	8b 70 20             	mov    0x20(%eax),%esi
  for(i = 0; i < 2; i++){
80102b46:	83 fb 01             	cmp    $0x1,%ebx
80102b49:	75 0d                	jne    80102b58 <lapicstartap+0x98>
    microdelay(200);
  }
}
80102b4b:	83 c4 04             	add    $0x4,%esp
80102b4e:	5b                   	pop    %ebx
80102b4f:	5e                   	pop    %esi
80102b50:	5d                   	pop    %ebp
80102b51:	c3                   	ret
80102b52:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  for(i = 0; i < 2; i++){
80102b58:	bb 01 00 00 00       	mov    $0x1,%ebx
80102b5d:	eb d5                	jmp    80102b34 <lapicstartap+0x74>
80102b5f:	90                   	nop

80102b60 <cmostime>:
}

// qemu seems to use 24-hour GWT and the values are BCD encoded
void
cmostime(struct rtcdate *r)
{
80102b60:	55                   	push   %ebp
80102b61:	b8 0b 00 00 00       	mov    $0xb,%eax
80102b66:	ba 70 00 00 00       	mov    $0x70,%edx
80102b6b:	89 e5                	mov    %esp,%ebp
80102b6d:	83 ec 58             	sub    $0x58,%esp
80102b70:	89 5d f4             	mov    %ebx,-0xc(%ebp)
80102b73:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102b74:	ba 71 00 00 00       	mov    $0x71,%edx
80102b79:	ec                   	in     (%dx),%al
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102b7a:	88 45 b7             	mov    %al,-0x49(%ebp)
80102b7d:	8d 76 00             	lea    0x0(%esi),%esi
80102b80:	31 c0                	xor    %eax,%eax
80102b82:	ba 70 00 00 00       	mov    $0x70,%edx
80102b87:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102b88:	ba 71 00 00 00       	mov    $0x71,%edx
80102b8d:	ec                   	in     (%dx),%al
  return inb(CMOS_RETURN);
80102b8e:	0f b6 c0             	movzbl %al,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102b91:	ba 70 00 00 00       	mov    $0x70,%edx
80102b96:	89 45 b8             	mov    %eax,-0x48(%ebp)
80102b99:	b8 02 00 00 00       	mov    $0x2,%eax
80102b9e:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102b9f:	ba 71 00 00 00       	mov    $0x71,%edx
80102ba4:	ec                   	in     (%dx),%al
80102ba5:	0f b6 c0             	movzbl %al,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102ba8:	ba 70 00 00 00       	mov    $0x70,%edx
80102bad:	89 45 bc             	mov    %eax,-0x44(%ebp)
80102bb0:	b8 04 00 00 00       	mov    $0x4,%eax
80102bb5:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102bb6:	ba 71 00 00 00       	mov    $0x71,%edx
80102bbb:	ec                   	in     (%dx),%al
80102bbc:	0f b6 c0             	movzbl %al,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102bbf:	ba 70 00 00 00       	mov    $0x70,%edx
80102bc4:	89 45 c0             	mov    %eax,-0x40(%ebp)
80102bc7:	b8 07 00 00 00       	mov    $0x7,%eax
80102bcc:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102bcd:	ba 71 00 00 00       	mov    $0x71,%edx
80102bd2:	ec                   	in     (%dx),%al
80102bd3:	0f b6 c0             	movzbl %al,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102bd6:	ba 70 00 00 00       	mov    $0x70,%edx
80102bdb:	89 45 c4             	mov    %eax,-0x3c(%ebp)
80102bde:	b8 08 00 00 00       	mov    $0x8,%eax
80102be3:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102be4:	ba 71 00 00 00       	mov    $0x71,%edx
80102be9:	ec                   	in     (%dx),%al
80102bea:	0f b6 c0             	movzbl %al,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102bed:	ba 70 00 00 00       	mov    $0x70,%edx
80102bf2:	89 45 c8             	mov    %eax,-0x38(%ebp)
80102bf5:	b8 09 00 00 00       	mov    $0x9,%eax
80102bfa:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102bfb:	ba 71 00 00 00       	mov    $0x71,%edx
80102c00:	ec                   	in     (%dx),%al
80102c01:	0f b6 c0             	movzbl %al,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102c04:	ba 70 00 00 00       	mov    $0x70,%edx
80102c09:	89 45 cc             	mov    %eax,-0x34(%ebp)
80102c0c:	b8 0a 00 00 00       	mov    $0xa,%eax
80102c11:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102c12:	ba 71 00 00 00       	mov    $0x71,%edx
80102c17:	ec                   	in     (%dx),%al
  bcd = (sb & (1 << 2)) == 0;

  // make sure CMOS doesn't modify time while we read it
  for(;;) {
    fill_rtcdate(&t1);
    if(cmos_read(CMOS_STATA) & CMOS_UIP)
80102c18:	84 c0                	test   %al,%al
80102c1a:	0f 88 60 ff ff ff    	js     80102b80 <cmostime+0x20>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102c20:	31 c0                	xor    %eax,%eax
80102c22:	ba 70 00 00 00       	mov    $0x70,%edx
80102c27:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102c28:	ba 71 00 00 00       	mov    $0x71,%edx
80102c2d:	ec                   	in     (%dx),%al
  return inb(CMOS_RETURN);
80102c2e:	0f b6 c0             	movzbl %al,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102c31:	ba 70 00 00 00       	mov    $0x70,%edx
80102c36:	89 45 d0             	mov    %eax,-0x30(%ebp)
80102c39:	b8 02 00 00 00       	mov    $0x2,%eax
80102c3e:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102c3f:	ba 71 00 00 00       	mov    $0x71,%edx
80102c44:	ec                   	in     (%dx),%al
80102c45:	0f b6 c0             	movzbl %al,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102c48:	ba 70 00 00 00       	mov    $0x70,%edx
80102c4d:	89 45 d4             	mov    %eax,-0x2c(%ebp)
80102c50:	b8 04 00 00 00       	mov    $0x4,%eax
80102c55:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102c56:	ba 71 00 00 00       	mov    $0x71,%edx
80102c5b:	ec                   	in     (%dx),%al
80102c5c:	0f b6 c0             	movzbl %al,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102c5f:	ba 70 00 00 00       	mov    $0x70,%edx
80102c64:	89 45 d8             	mov    %eax,-0x28(%ebp)
80102c67:	b8 07 00 00 00       	mov    $0x7,%eax
80102c6c:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102c6d:	ba 71 00 00 00       	mov    $0x71,%edx
80102c72:	ec                   	in     (%dx),%al
80102c73:	0f b6 c0             	movzbl %al,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102c76:	ba 70 00 00 00       	mov    $0x70,%edx
80102c7b:	89 45 dc             	mov    %eax,-0x24(%ebp)
80102c7e:	b8 08 00 00 00       	mov    $0x8,%eax
80102c83:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102c84:	ba 71 00 00 00       	mov    $0x71,%edx
80102c89:	ec                   	in     (%dx),%al
80102c8a:	0f b6 c0             	movzbl %al,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102c8d:	ba 70 00 00 00       	mov    $0x70,%edx
80102c92:	89 45 e0             	mov    %eax,-0x20(%ebp)
80102c95:	b8 09 00 00 00       	mov    $0x9,%eax
80102c9a:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102c9b:	ba 71 00 00 00       	mov    $0x71,%edx
80102ca0:	ec                   	in     (%dx),%al
80102ca1:	0f b6 c0             	movzbl %al,%eax
        continue;
    fill_rtcdate(&t2);
    if(memcmp(&t1, &t2, sizeof(t1)) == 0)
80102ca4:	83 ec 04             	sub    $0x4,%esp
  return inb(CMOS_RETURN);
80102ca7:	89 45 e4             	mov    %eax,-0x1c(%ebp)
    if(memcmp(&t1, &t2, sizeof(t1)) == 0)
80102caa:	8d 45 d0             	lea    -0x30(%ebp),%eax
80102cad:	6a 18                	push   $0x18
80102caf:	50                   	push   %eax
80102cb0:	8d 45 b8             	lea    -0x48(%ebp),%eax
80102cb3:	50                   	push   %eax
80102cb4:	e8 e7 1d 00 00       	call   80104aa0 <memcmp>
80102cb9:	83 c4 10             	add    $0x10,%esp
80102cbc:	85 c0                	test   %eax,%eax
80102cbe:	0f 85 bc fe ff ff    	jne    80102b80 <cmostime+0x20>
      break;
  }

  // convert
  if(bcd) {
80102cc4:	8b 5d 08             	mov    0x8(%ebp),%ebx
80102cc7:	f6 45 b7 04          	testb  $0x4,-0x49(%ebp)
80102ccb:	75 78                	jne    80102d45 <cmostime+0x1e5>
#define    CONV(x)     (t1.x = ((t1.x >> 4) * 10) + (t1.x & 0xf))
    CONV(second);
80102ccd:	8b 45 b8             	mov    -0x48(%ebp),%eax
80102cd0:	89 c2                	mov    %eax,%edx
80102cd2:	83 e0 0f             	and    $0xf,%eax
80102cd5:	c1 ea 04             	shr    $0x4,%edx
80102cd8:	8d 14 92             	lea    (%edx,%edx,4),%edx
80102cdb:	8d 04 50             	lea    (%eax,%edx,2),%eax
80102cde:	89 45 b8             	mov    %eax,-0x48(%ebp)
    CONV(minute);
80102ce1:	8b 45 bc             	mov    -0x44(%ebp),%eax
80102ce4:	89 c2                	mov    %eax,%edx
80102ce6:	83 e0 0f             	and    $0xf,%eax
80102ce9:	c1 ea 04             	shr    $0x4,%edx
80102cec:	8d 14 92             	lea    (%edx,%edx,4),%edx
80102cef:	8d 04 50             	lea    (%eax,%edx,2),%eax
80102cf2:	89 45 bc             	mov    %eax,-0x44(%ebp)
    CONV(hour  );
80102cf5:	8b 45 c0             	mov    -0x40(%ebp),%eax
80102cf8:	89 c2                	mov    %eax,%edx
80102cfa:	83 e0 0f             	and    $0xf,%eax
80102cfd:	c1 ea 04             	shr    $0x4,%edx
80102d00:	8d 14 92             	lea    (%edx,%edx,4),%edx
80102d03:	8d 04 50             	lea    (%eax,%edx,2),%eax
80102d06:	89 45 c0             	mov    %eax,-0x40(%ebp)
    CONV(day   );
80102d09:	8b 45 c4             	mov    -0x3c(%ebp),%eax
80102d0c:	89 c2                	mov    %eax,%edx
80102d0e:	83 e0 0f             	and    $0xf,%eax
80102d11:	c1 ea 04             	shr    $0x4,%edx
80102d14:	8d 14 92             	lea    (%edx,%edx,4),%edx
80102d17:	8d 04 50             	lea    (%eax,%edx,2),%eax
80102d1a:	89 45 c4             	mov    %eax,-0x3c(%ebp)
    CONV(month );
80102d1d:	8b 45 c8             	mov    -0x38(%ebp),%eax
80102d20:	89 c2                	mov    %eax,%edx
80102d22:	83 e0 0f             	and    $0xf,%eax
80102d25:	c1 ea 04             	shr    $0x4,%edx
80102d28:	8d 14 92             	lea    (%edx,%edx,4),%edx
80102d2b:	8d 04 50             	lea    (%eax,%edx,2),%eax
80102d2e:	89 45 c8             	mov    %eax,-0x38(%ebp)
    CONV(year  );
80102d31:	8b 45 cc             	mov    -0x34(%ebp),%eax
80102d34:	89 c2                	mov    %eax,%edx
80102d36:	83 e0 0f             	and    $0xf,%eax
80102d39:	c1 ea 04             	shr    $0x4,%edx
80102d3c:	8d 14 92             	lea    (%edx,%edx,4),%edx
80102d3f:	8d 04 50             	lea    (%eax,%edx,2),%eax
80102d42:	89 45 cc             	mov    %eax,-0x34(%ebp)
#undef     CONV
  }

  *r = t1;
80102d45:	8b 45 b8             	mov    -0x48(%ebp),%eax
80102d48:	89 03                	mov    %eax,(%ebx)
80102d4a:	8b 45 bc             	mov    -0x44(%ebp),%eax
80102d4d:	89 43 04             	mov    %eax,0x4(%ebx)
80102d50:	8b 45 c0             	mov    -0x40(%ebp),%eax
80102d53:	89 43 08             	mov    %eax,0x8(%ebx)
80102d56:	8b 45 c4             	mov    -0x3c(%ebp),%eax
80102d59:	89 43 0c             	mov    %eax,0xc(%ebx)
80102d5c:	8b 45 c8             	mov    -0x38(%ebp),%eax
80102d5f:	89 43 10             	mov    %eax,0x10(%ebx)
80102d62:	8b 45 cc             	mov    -0x34(%ebp),%eax
80102d65:	89 43 14             	mov    %eax,0x14(%ebx)
  r->year += 2000;
80102d68:	81 43 14 d0 07 00 00 	addl   $0x7d0,0x14(%ebx)
}
80102d6f:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80102d72:	c9                   	leave
80102d73:	c3                   	ret
80102d74:	66 90                	xchg   %ax,%ax
80102d76:	66 90                	xchg   %ax,%ax
80102d78:	66 90                	xchg   %ax,%ax
80102d7a:	66 90                	xchg   %ax,%ax
80102d7c:	66 90                	xchg   %ax,%ax
80102d7e:	66 90                	xchg   %ax,%ax

80102d80 <install_trans>:
static void
install_trans(void)
{
  int tail;

  for (tail = 0; tail < log.lh.n; tail++) {
80102d80:	8b 0d 08 27 11 80    	mov    0x80112708,%ecx
80102d86:	85 c9                	test   %ecx,%ecx
80102d88:	0f 8e 8a 00 00 00    	jle    80102e18 <install_trans+0x98>
{
80102d8e:	55                   	push   %ebp
80102d8f:	89 e5                	mov    %esp,%ebp
80102d91:	57                   	push   %edi
  for (tail = 0; tail < log.lh.n; tail++) {
80102d92:	31 ff                	xor    %edi,%edi
{
80102d94:	56                   	push   %esi
80102d95:	53                   	push   %ebx
80102d96:	83 ec 0c             	sub    $0xc,%esp
80102d99:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
80102da0:	a1 f4 26 11 80       	mov    0x801126f4,%eax
80102da5:	83 ec 08             	sub    $0x8,%esp
80102da8:	8d 44 38 01          	lea    0x1(%eax,%edi,1),%eax
80102dac:	50                   	push   %eax
80102dad:	ff 35 04 27 11 80    	push   0x80112704
80102db3:	e8 18 d3 ff ff       	call   801000d0 <bread>
80102db8:	89 c6                	mov    %eax,%esi
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
80102dba:	58                   	pop    %eax
80102dbb:	5a                   	pop    %edx
80102dbc:	ff 34 bd 0c 27 11 80 	push   -0x7feed8f4(,%edi,4)
80102dc3:	ff 35 04 27 11 80    	push   0x80112704
  for (tail = 0; tail < log.lh.n; tail++) {
80102dc9:	83 c7 01             	add    $0x1,%edi
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
80102dcc:	e8 ff d2 ff ff       	call   801000d0 <bread>
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
80102dd1:	83 c4 0c             	add    $0xc,%esp
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
80102dd4:	89 c3                	mov    %eax,%ebx
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
80102dd6:	8d 46 5c             	lea    0x5c(%esi),%eax
80102dd9:	68 00 02 00 00       	push   $0x200
80102dde:	50                   	push   %eax
80102ddf:	8d 43 5c             	lea    0x5c(%ebx),%eax
80102de2:	50                   	push   %eax
80102de3:	e8 18 1d 00 00       	call   80104b00 <memmove>
    bwrite(dbuf);  // write dst to disk
80102de8:	89 1c 24             	mov    %ebx,(%esp)
80102deb:	e8 d0 d3 ff ff       	call   801001c0 <bwrite>
    brelse(lbuf);
80102df0:	89 34 24             	mov    %esi,(%esp)
80102df3:	e8 08 d4 ff ff       	call   80100200 <brelse>
    brelse(dbuf);
80102df8:	89 1c 24             	mov    %ebx,(%esp)
80102dfb:	e8 00 d4 ff ff       	call   80100200 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
80102e00:	83 c4 10             	add    $0x10,%esp
80102e03:	39 3d 08 27 11 80    	cmp    %edi,0x80112708
80102e09:	7f 95                	jg     80102da0 <install_trans+0x20>
  }
}
80102e0b:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102e0e:	5b                   	pop    %ebx
80102e0f:	5e                   	pop    %esi
80102e10:	5f                   	pop    %edi
80102e11:	5d                   	pop    %ebp
80102e12:	c3                   	ret
80102e13:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80102e18:	c3                   	ret
80102e19:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80102e20 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
80102e20:	55                   	push   %ebp
80102e21:	89 e5                	mov    %esp,%ebp
80102e23:	53                   	push   %ebx
80102e24:	83 ec 0c             	sub    $0xc,%esp
  struct buf *buf = bread(log.dev, log.start);
80102e27:	ff 35 f4 26 11 80    	push   0x801126f4
80102e2d:	ff 35 04 27 11 80    	push   0x80112704
80102e33:	e8 98 d2 ff ff       	call   801000d0 <bread>
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
  for (i = 0; i < log.lh.n; i++) {
80102e38:	83 c4 10             	add    $0x10,%esp
  struct buf *buf = bread(log.dev, log.start);
80102e3b:	89 c3                	mov    %eax,%ebx
  hb->n = log.lh.n;
80102e3d:	a1 08 27 11 80       	mov    0x80112708,%eax
80102e42:	89 43 5c             	mov    %eax,0x5c(%ebx)
  for (i = 0; i < log.lh.n; i++) {
80102e45:	85 c0                	test   %eax,%eax
80102e47:	7e 29                	jle    80102e72 <write_head+0x52>
80102e49:	31 d2                	xor    %edx,%edx
80102e4b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80102e50:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102e57:	00 
80102e58:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102e5f:	00 
    hb->block[i] = log.lh.block[i];
80102e60:	8b 0c 95 0c 27 11 80 	mov    -0x7feed8f4(,%edx,4),%ecx
80102e67:	89 4c 93 60          	mov    %ecx,0x60(%ebx,%edx,4)
  for (i = 0; i < log.lh.n; i++) {
80102e6b:	83 c2 01             	add    $0x1,%edx
80102e6e:	39 d0                	cmp    %edx,%eax
80102e70:	75 ee                	jne    80102e60 <write_head+0x40>
  }
  bwrite(buf);
80102e72:	83 ec 0c             	sub    $0xc,%esp
80102e75:	53                   	push   %ebx
80102e76:	e8 45 d3 ff ff       	call   801001c0 <bwrite>
  brelse(buf);
80102e7b:	89 1c 24             	mov    %ebx,(%esp)
80102e7e:	e8 7d d3 ff ff       	call   80100200 <brelse>
}
80102e83:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102e86:	83 c4 10             	add    $0x10,%esp
80102e89:	c9                   	leave
80102e8a:	c3                   	ret
80102e8b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80102e90 <initlog>:
{
80102e90:	55                   	push   %ebp
80102e91:	89 e5                	mov    %esp,%ebp
80102e93:	53                   	push   %ebx
80102e94:	83 ec 2c             	sub    $0x2c,%esp
80102e97:	8b 5d 08             	mov    0x8(%ebp),%ebx
  initlock(&log.lock, "log");
80102e9a:	68 17 7b 10 80       	push   $0x80107b17
80102e9f:	68 c0 26 11 80       	push   $0x801126c0
80102ea4:	e8 77 18 00 00       	call   80104720 <initlock>
  readsb(dev, &sb);
80102ea9:	58                   	pop    %eax
80102eaa:	8d 45 dc             	lea    -0x24(%ebp),%eax
80102ead:	5a                   	pop    %edx
80102eae:	50                   	push   %eax
80102eaf:	53                   	push   %ebx
80102eb0:	e8 3b e7 ff ff       	call   801015f0 <readsb>
  log.start = sb.logstart;
80102eb5:	8b 45 ec             	mov    -0x14(%ebp),%eax
  struct buf *buf = bread(log.dev, log.start);
80102eb8:	59                   	pop    %ecx
  log.dev = dev;
80102eb9:	89 1d 04 27 11 80    	mov    %ebx,0x80112704
  log.size = sb.nlog;
80102ebf:	8b 55 e8             	mov    -0x18(%ebp),%edx
  log.start = sb.logstart;
80102ec2:	a3 f4 26 11 80       	mov    %eax,0x801126f4
  log.size = sb.nlog;
80102ec7:	89 15 f8 26 11 80    	mov    %edx,0x801126f8
  struct buf *buf = bread(log.dev, log.start);
80102ecd:	5a                   	pop    %edx
80102ece:	50                   	push   %eax
80102ecf:	53                   	push   %ebx
80102ed0:	e8 fb d1 ff ff       	call   801000d0 <bread>
  for (i = 0; i < log.lh.n; i++) {
80102ed5:	83 c4 10             	add    $0x10,%esp
  log.lh.n = lh->n;
80102ed8:	8b 58 5c             	mov    0x5c(%eax),%ebx
80102edb:	89 1d 08 27 11 80    	mov    %ebx,0x80112708
  for (i = 0; i < log.lh.n; i++) {
80102ee1:	85 db                	test   %ebx,%ebx
80102ee3:	7e 2d                	jle    80102f12 <initlog+0x82>
80102ee5:	31 d2                	xor    %edx,%edx
80102ee7:	eb 17                	jmp    80102f00 <initlog+0x70>
80102ee9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80102ef0:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102ef7:	00 
80102ef8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102eff:	00 
    log.lh.block[i] = lh->block[i];
80102f00:	8b 4c 90 60          	mov    0x60(%eax,%edx,4),%ecx
80102f04:	89 0c 95 0c 27 11 80 	mov    %ecx,-0x7feed8f4(,%edx,4)
  for (i = 0; i < log.lh.n; i++) {
80102f0b:	83 c2 01             	add    $0x1,%edx
80102f0e:	39 d3                	cmp    %edx,%ebx
80102f10:	75 ee                	jne    80102f00 <initlog+0x70>
  brelse(buf);
80102f12:	83 ec 0c             	sub    $0xc,%esp
80102f15:	50                   	push   %eax
80102f16:	e8 e5 d2 ff ff       	call   80100200 <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(); // if committed, copy from log to disk
80102f1b:	e8 60 fe ff ff       	call   80102d80 <install_trans>
  log.lh.n = 0;
80102f20:	c7 05 08 27 11 80 00 	movl   $0x0,0x80112708
80102f27:	00 00 00 
  write_head(); // clear the log
80102f2a:	e8 f1 fe ff ff       	call   80102e20 <write_head>
}
80102f2f:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102f32:	83 c4 10             	add    $0x10,%esp
80102f35:	c9                   	leave
80102f36:	c3                   	ret
80102f37:	90                   	nop
80102f38:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102f3f:	00 

80102f40 <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
80102f40:	55                   	push   %ebp
80102f41:	89 e5                	mov    %esp,%ebp
80102f43:	83 ec 14             	sub    $0x14,%esp
  acquire(&log.lock);
80102f46:	68 c0 26 11 80       	push   $0x801126c0
80102f4b:	e8 f0 19 00 00       	call   80104940 <acquire>
80102f50:	83 c4 10             	add    $0x10,%esp
80102f53:	eb 18                	jmp    80102f6d <begin_op+0x2d>
80102f55:	8d 76 00             	lea    0x0(%esi),%esi
  while(1){
    if(log.committing){
      sleep(&log, &log.lock);
80102f58:	83 ec 08             	sub    $0x8,%esp
80102f5b:	68 c0 26 11 80       	push   $0x801126c0
80102f60:	68 c0 26 11 80       	push   $0x801126c0
80102f65:	e8 a6 13 00 00       	call   80104310 <sleep>
80102f6a:	83 c4 10             	add    $0x10,%esp
    if(log.committing){
80102f6d:	a1 00 27 11 80       	mov    0x80112700,%eax
80102f72:	85 c0                	test   %eax,%eax
80102f74:	75 e2                	jne    80102f58 <begin_op+0x18>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
80102f76:	a1 fc 26 11 80       	mov    0x801126fc,%eax
80102f7b:	8b 15 08 27 11 80    	mov    0x80112708,%edx
80102f81:	83 c0 01             	add    $0x1,%eax
80102f84:	8d 0c 80             	lea    (%eax,%eax,4),%ecx
80102f87:	8d 14 4a             	lea    (%edx,%ecx,2),%edx
80102f8a:	83 fa 1e             	cmp    $0x1e,%edx
80102f8d:	7f c9                	jg     80102f58 <begin_op+0x18>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    } else {
      log.outstanding += 1;
      release(&log.lock);
80102f8f:	83 ec 0c             	sub    $0xc,%esp
      log.outstanding += 1;
80102f92:	a3 fc 26 11 80       	mov    %eax,0x801126fc
      release(&log.lock);
80102f97:	68 c0 26 11 80       	push   $0x801126c0
80102f9c:	e8 3f 19 00 00       	call   801048e0 <release>
      break;
    }
  }
}
80102fa1:	83 c4 10             	add    $0x10,%esp
80102fa4:	c9                   	leave
80102fa5:	c3                   	ret
80102fa6:	66 90                	xchg   %ax,%ax
80102fa8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102faf:	00 

80102fb0 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
80102fb0:	55                   	push   %ebp
80102fb1:	89 e5                	mov    %esp,%ebp
80102fb3:	83 ec 24             	sub    $0x24,%esp
  int do_commit = 0;

  acquire(&log.lock);
80102fb6:	68 c0 26 11 80       	push   $0x801126c0
{
80102fbb:	89 5d f4             	mov    %ebx,-0xc(%ebp)
  acquire(&log.lock);
80102fbe:	e8 7d 19 00 00       	call   80104940 <acquire>
  log.outstanding -= 1;
80102fc3:	a1 fc 26 11 80       	mov    0x801126fc,%eax
  if(log.committing)
80102fc8:	83 c4 10             	add    $0x10,%esp
  log.outstanding -= 1;
80102fcb:	8d 58 ff             	lea    -0x1(%eax),%ebx
  if(log.committing)
80102fce:	a1 00 27 11 80       	mov    0x80112700,%eax
  log.outstanding -= 1;
80102fd3:	89 1d fc 26 11 80    	mov    %ebx,0x801126fc
  if(log.committing)
80102fd9:	85 c0                	test   %eax,%eax
80102fdb:	0f 85 20 01 00 00    	jne    80103101 <end_op+0x151>
    panic("log.committing");
  if(log.outstanding == 0){
80102fe1:	85 db                	test   %ebx,%ebx
80102fe3:	0f 85 f7 00 00 00    	jne    801030e0 <end_op+0x130>
    do_commit = 1;
    log.committing = 1;
80102fe9:	c7 05 00 27 11 80 01 	movl   $0x1,0x80112700
80102ff0:	00 00 00 
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
80102ff3:	83 ec 0c             	sub    $0xc,%esp
80102ff6:	68 c0 26 11 80       	push   $0x801126c0
80102ffb:	e8 e0 18 00 00       	call   801048e0 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
80103000:	8b 0d 08 27 11 80    	mov    0x80112708,%ecx
80103006:	83 c4 10             	add    $0x10,%esp
80103009:	85 c9                	test   %ecx,%ecx
8010300b:	7f 3b                	jg     80103048 <end_op+0x98>
    acquire(&log.lock);
8010300d:	83 ec 0c             	sub    $0xc,%esp
80103010:	68 c0 26 11 80       	push   $0x801126c0
80103015:	e8 26 19 00 00       	call   80104940 <acquire>
    wakeup(&log);
8010301a:	c7 04 24 c0 26 11 80 	movl   $0x801126c0,(%esp)
    log.committing = 0;
80103021:	c7 05 00 27 11 80 00 	movl   $0x0,0x80112700
80103028:	00 00 00 
    wakeup(&log);
8010302b:	e8 a0 13 00 00       	call   801043d0 <wakeup>
    release(&log.lock);
80103030:	c7 04 24 c0 26 11 80 	movl   $0x801126c0,(%esp)
80103037:	e8 a4 18 00 00       	call   801048e0 <release>
}
8010303c:	8b 5d f4             	mov    -0xc(%ebp),%ebx
    release(&log.lock);
8010303f:	83 c4 10             	add    $0x10,%esp
}
80103042:	c9                   	leave
80103043:	c3                   	ret
80103044:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80103048:	89 75 f8             	mov    %esi,-0x8(%ebp)
8010304b:	89 7d fc             	mov    %edi,-0x4(%ebp)
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
8010304e:	a1 f4 26 11 80       	mov    0x801126f4,%eax
80103053:	83 ec 08             	sub    $0x8,%esp
80103056:	8d 44 18 01          	lea    0x1(%eax,%ebx,1),%eax
8010305a:	50                   	push   %eax
8010305b:	ff 35 04 27 11 80    	push   0x80112704
80103061:	e8 6a d0 ff ff       	call   801000d0 <bread>
80103066:	89 c6                	mov    %eax,%esi
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
80103068:	58                   	pop    %eax
80103069:	5a                   	pop    %edx
8010306a:	ff 34 9d 0c 27 11 80 	push   -0x7feed8f4(,%ebx,4)
80103071:	ff 35 04 27 11 80    	push   0x80112704
  for (tail = 0; tail < log.lh.n; tail++) {
80103077:	83 c3 01             	add    $0x1,%ebx
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
8010307a:	e8 51 d0 ff ff       	call   801000d0 <bread>
    memmove(to->data, from->data, BSIZE);
8010307f:	83 c4 0c             	add    $0xc,%esp
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
80103082:	89 c7                	mov    %eax,%edi
    memmove(to->data, from->data, BSIZE);
80103084:	8d 40 5c             	lea    0x5c(%eax),%eax
80103087:	68 00 02 00 00       	push   $0x200
8010308c:	50                   	push   %eax
8010308d:	8d 46 5c             	lea    0x5c(%esi),%eax
80103090:	50                   	push   %eax
80103091:	e8 6a 1a 00 00       	call   80104b00 <memmove>
    bwrite(to);  // write the log
80103096:	89 34 24             	mov    %esi,(%esp)
80103099:	e8 22 d1 ff ff       	call   801001c0 <bwrite>
    brelse(from);
8010309e:	89 3c 24             	mov    %edi,(%esp)
801030a1:	e8 5a d1 ff ff       	call   80100200 <brelse>
    brelse(to);
801030a6:	89 34 24             	mov    %esi,(%esp)
801030a9:	e8 52 d1 ff ff       	call   80100200 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
801030ae:	83 c4 10             	add    $0x10,%esp
801030b1:	3b 1d 08 27 11 80    	cmp    0x80112708,%ebx
801030b7:	7c 95                	jl     8010304e <end_op+0x9e>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
801030b9:	e8 62 fd ff ff       	call   80102e20 <write_head>
    install_trans(); // Now install writes to home locations
801030be:	e8 bd fc ff ff       	call   80102d80 <install_trans>
    log.lh.n = 0;
801030c3:	c7 05 08 27 11 80 00 	movl   $0x0,0x80112708
801030ca:	00 00 00 
    write_head();    // Erase the transaction from the log
801030cd:	e8 4e fd ff ff       	call   80102e20 <write_head>
801030d2:	8b 75 f8             	mov    -0x8(%ebp),%esi
801030d5:	8b 7d fc             	mov    -0x4(%ebp),%edi
801030d8:	e9 30 ff ff ff       	jmp    8010300d <end_op+0x5d>
801030dd:	8d 76 00             	lea    0x0(%esi),%esi
    wakeup(&log);
801030e0:	83 ec 0c             	sub    $0xc,%esp
801030e3:	68 c0 26 11 80       	push   $0x801126c0
801030e8:	e8 e3 12 00 00       	call   801043d0 <wakeup>
  release(&log.lock);
801030ed:	c7 04 24 c0 26 11 80 	movl   $0x801126c0,(%esp)
801030f4:	e8 e7 17 00 00       	call   801048e0 <release>
}
801030f9:	8b 5d f4             	mov    -0xc(%ebp),%ebx
  release(&log.lock);
801030fc:	83 c4 10             	add    $0x10,%esp
}
801030ff:	c9                   	leave
80103100:	c3                   	ret
    panic("log.committing");
80103101:	83 ec 0c             	sub    $0xc,%esp
80103104:	89 75 f8             	mov    %esi,-0x8(%ebp)
80103107:	68 1b 7b 10 80       	push   $0x80107b1b
8010310c:	89 7d fc             	mov    %edi,-0x4(%ebp)
8010310f:	e8 8c d2 ff ff       	call   801003a0 <panic>
80103114:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80103118:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010311f:	00 

80103120 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
80103120:	55                   	push   %ebp
80103121:	89 e5                	mov    %esp,%ebp
80103123:	53                   	push   %ebx
80103124:	83 ec 04             	sub    $0x4,%esp
  int i;

  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
80103127:	8b 15 08 27 11 80    	mov    0x80112708,%edx
{
8010312d:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
80103130:	83 fa 1d             	cmp    $0x1d,%edx
80103133:	7f 7d                	jg     801031b2 <log_write+0x92>
80103135:	a1 f8 26 11 80       	mov    0x801126f8,%eax
8010313a:	83 e8 01             	sub    $0x1,%eax
8010313d:	39 c2                	cmp    %eax,%edx
8010313f:	7d 71                	jge    801031b2 <log_write+0x92>
    panic("too big a transaction");
  if (log.outstanding < 1)
80103141:	a1 fc 26 11 80       	mov    0x801126fc,%eax
80103146:	85 c0                	test   %eax,%eax
80103148:	7e 75                	jle    801031bf <log_write+0x9f>
    panic("log_write outside of trans");

  acquire(&log.lock);
8010314a:	83 ec 0c             	sub    $0xc,%esp
8010314d:	68 c0 26 11 80       	push   $0x801126c0
80103152:	e8 e9 17 00 00       	call   80104940 <acquire>
  for (i = 0; i < log.lh.n; i++) {
    if (log.lh.block[i] == b->blockno)   // log absorbtion
      break;
  }
  log.lh.block[i] = b->blockno;
80103157:	8b 4b 08             	mov    0x8(%ebx),%ecx
  for (i = 0; i < log.lh.n; i++) {
8010315a:	83 c4 10             	add    $0x10,%esp
8010315d:	31 c0                	xor    %eax,%eax
8010315f:	8b 15 08 27 11 80    	mov    0x80112708,%edx
80103165:	85 d2                	test   %edx,%edx
80103167:	7f 0e                	jg     80103177 <log_write+0x57>
80103169:	eb 15                	jmp    80103180 <log_write+0x60>
8010316b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80103170:	83 c0 01             	add    $0x1,%eax
80103173:	39 d0                	cmp    %edx,%eax
80103175:	74 29                	je     801031a0 <log_write+0x80>
    if (log.lh.block[i] == b->blockno)   // log absorbtion
80103177:	39 0c 85 0c 27 11 80 	cmp    %ecx,-0x7feed8f4(,%eax,4)
8010317e:	75 f0                	jne    80103170 <log_write+0x50>
  log.lh.block[i] = b->blockno;
80103180:	89 0c 85 0c 27 11 80 	mov    %ecx,-0x7feed8f4(,%eax,4)
  if (i == log.lh.n)
80103187:	39 c2                	cmp    %eax,%edx
80103189:	74 1c                	je     801031a7 <log_write+0x87>
    log.lh.n++;
  b->flags |= B_DIRTY; // prevent eviction
8010318b:	83 0b 04             	orl    $0x4,(%ebx)
  release(&log.lock);
}
8010318e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
  release(&log.lock);
80103191:	c7 45 08 c0 26 11 80 	movl   $0x801126c0,0x8(%ebp)
}
80103198:	c9                   	leave
  release(&log.lock);
80103199:	e9 42 17 00 00       	jmp    801048e0 <release>
8010319e:	66 90                	xchg   %ax,%ax
  log.lh.block[i] = b->blockno;
801031a0:	89 0c 95 0c 27 11 80 	mov    %ecx,-0x7feed8f4(,%edx,4)
    log.lh.n++;
801031a7:	83 c2 01             	add    $0x1,%edx
801031aa:	89 15 08 27 11 80    	mov    %edx,0x80112708
801031b0:	eb d9                	jmp    8010318b <log_write+0x6b>
    panic("too big a transaction");
801031b2:	83 ec 0c             	sub    $0xc,%esp
801031b5:	68 2a 7b 10 80       	push   $0x80107b2a
801031ba:	e8 e1 d1 ff ff       	call   801003a0 <panic>
    panic("log_write outside of trans");
801031bf:	83 ec 0c             	sub    $0xc,%esp
801031c2:	68 40 7b 10 80       	push   $0x80107b40
801031c7:	e8 d4 d1 ff ff       	call   801003a0 <panic>
801031cc:	66 90                	xchg   %ax,%ax
801031ce:	66 90                	xchg   %ax,%ax

801031d0 <mpmain>:
}

// Common CPU setup code.
static void
mpmain(void)
{
801031d0:	55                   	push   %ebp
801031d1:	89 e5                	mov    %esp,%ebp
801031d3:	53                   	push   %ebx
801031d4:	83 ec 04             	sub    $0x4,%esp
  cprintf("cpu%d: starting %d\n", cpuid(), cpuid());
801031d7:	e8 a4 09 00 00       	call   80103b80 <cpuid>
801031dc:	89 c3                	mov    %eax,%ebx
801031de:	e8 9d 09 00 00       	call   80103b80 <cpuid>
801031e3:	83 ec 04             	sub    $0x4,%esp
801031e6:	53                   	push   %ebx
801031e7:	50                   	push   %eax
801031e8:	68 5b 7b 10 80       	push   $0x80107b5b
801031ed:	e8 fe d4 ff ff       	call   801006f0 <cprintf>
  idtinit();       // load idt register
801031f2:	e8 79 2d 00 00       	call   80105f70 <idtinit>
  xchg(&(mycpu()->started), 1); // tell startothers() we're up
801031f7:	e8 14 09 00 00       	call   80103b10 <mycpu>
801031fc:	89 c2                	mov    %eax,%edx
xchg(volatile uint *addr, uint newval)
{
  uint result;

  // The + in "+m" denotes a read-modify-write operand.
  asm volatile("lock; xchgl %0, %1" :
801031fe:	b8 01 00 00 00       	mov    $0x1,%eax
80103203:	f0 87 82 a0 00 00 00 	lock xchg %eax,0xa0(%edx)
  scheduler();     // start running processes
8010320a:	e8 61 0c 00 00       	call   80103e70 <scheduler>
8010320f:	90                   	nop

80103210 <mpenter>:
{
80103210:	55                   	push   %ebp
80103211:	89 e5                	mov    %esp,%ebp
80103213:	83 ec 08             	sub    $0x8,%esp
  switchkvm();
80103216:	e8 65 3f 00 00       	call   80107180 <switchkvm>
  seginit();
8010321b:	e8 e0 3d 00 00       	call   80107000 <seginit>
  lapicinit();
80103220:	e8 4b f7 ff ff       	call   80102970 <lapicinit>
  mpmain();
80103225:	e8 a6 ff ff ff       	call   801031d0 <mpmain>
8010322a:	66 90                	xchg   %ax,%ax
8010322c:	66 90                	xchg   %ax,%ax
8010322e:	66 90                	xchg   %ax,%ax

80103230 <main>:
{
80103230:	8d 4c 24 04          	lea    0x4(%esp),%ecx
80103234:	83 e4 f0             	and    $0xfffffff0,%esp
80103237:	ff 71 fc             	push   -0x4(%ecx)
8010323a:	55                   	push   %ebp
8010323b:	89 e5                	mov    %esp,%ebp
8010323d:	53                   	push   %ebx
8010323e:	51                   	push   %ecx
  kinit1(end, P2V(4*1024*1024)); // phys page allocator
8010323f:	83 ec 08             	sub    $0x8,%esp
80103242:	68 00 00 40 80       	push   $0x80400000
80103247:	68 f0 65 11 80       	push   $0x801165f0
8010324c:	e8 4f f5 ff ff       	call   801027a0 <kinit1>
  kvmalloc();      // kernel page table
80103251:	e8 1a 44 00 00       	call   80107670 <kvmalloc>
  mpinit();        // detect other processors
80103256:	e8 85 01 00 00       	call   801033e0 <mpinit>
  lapicinit();     // interrupt controller
8010325b:	e8 10 f7 ff ff       	call   80102970 <lapicinit>
  seginit();       // segment descriptors
80103260:	e8 9b 3d 00 00       	call   80107000 <seginit>
  picinit();       // disable pic
80103265:	e8 66 03 00 00       	call   801035d0 <picinit>
  ioapicinit();    // another interrupt controller
8010326a:	e8 d1 f2 ff ff       	call   80102540 <ioapicinit>
  consoleinit();   // console hardware
8010326f:	e8 8c d8 ff ff       	call   80100b00 <consoleinit>
  uartinit();      // serial port
80103274:	e8 d7 2f 00 00       	call   80106250 <uartinit>
  pinit();         // process table
80103279:	e8 72 08 00 00       	call   80103af0 <pinit>
  tvinit();        // trap vectors
8010327e:	e8 3d 2c 00 00       	call   80105ec0 <tvinit>
  binit();         // buffer cache
80103283:	e8 b8 cd ff ff       	call   80100040 <binit>
  fileinit();      // file table
80103288:	e8 33 dc ff ff       	call   80100ec0 <fileinit>
  ideinit();       // disk 
8010328d:	e8 6e f0 ff ff       	call   80102300 <ideinit>

  // Write entry code to unused memory at 0x7000.
  // The linker has placed the image of entryother.S in
  // _binary_entryother_start.
  code = P2V(0x7000);
  memmove(code, _binary_entryother_start, (uint)_binary_entryother_size);
80103292:	83 c4 0c             	add    $0xc,%esp
80103295:	68 8a 00 00 00       	push   $0x8a
8010329a:	68 b4 b4 10 80       	push   $0x8010b4b4
8010329f:	68 00 70 00 80       	push   $0x80007000
801032a4:	e8 57 18 00 00       	call   80104b00 <memmove>

  for(c = cpus; c < cpus+ncpu; c++){
801032a9:	83 c4 10             	add    $0x10,%esp
801032ac:	69 05 a4 27 11 80 b0 	imul   $0xb0,0x801127a4,%eax
801032b3:	00 00 00 
801032b6:	05 c0 27 11 80       	add    $0x801127c0,%eax
801032bb:	3d c0 27 11 80       	cmp    $0x801127c0,%eax
801032c0:	76 7e                	jbe    80103340 <main+0x110>
801032c2:	bb c0 27 11 80       	mov    $0x801127c0,%ebx
801032c7:	eb 20                	jmp    801032e9 <main+0xb9>
801032c9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
801032d0:	69 05 a4 27 11 80 b0 	imul   $0xb0,0x801127a4,%eax
801032d7:	00 00 00 
801032da:	81 c3 b0 00 00 00    	add    $0xb0,%ebx
801032e0:	05 c0 27 11 80       	add    $0x801127c0,%eax
801032e5:	39 c3                	cmp    %eax,%ebx
801032e7:	73 57                	jae    80103340 <main+0x110>
    if(c == mycpu())  // We've started already.
801032e9:	e8 22 08 00 00       	call   80103b10 <mycpu>
801032ee:	39 d8                	cmp    %ebx,%eax
801032f0:	74 de                	je     801032d0 <main+0xa0>
      continue;

    // Tell entryother.S what stack to use, where to enter, and what
    // pgdir to use. We cannot use kpgdir yet, because the AP processor
    // is running in low  memory, so we use entrypgdir for the APs too.
    stack = kalloc();
801032f2:	e8 19 f5 ff ff       	call   80102810 <kalloc>
    *(void**)(code-4) = stack + KSTACKSIZE;
    *(void(**)(void))(code-8) = mpenter;
    *(int**)(code-12) = (void *) V2P(entrypgdir);

    lapicstartap(c->apicid, V2P(code));
801032f7:	83 ec 08             	sub    $0x8,%esp
    *(void(**)(void))(code-8) = mpenter;
801032fa:	c7 05 f8 6f 00 80 10 	movl   $0x80103210,0x80006ff8
80103301:	32 10 80 
    *(int**)(code-12) = (void *) V2P(entrypgdir);
80103304:	c7 05 f4 6f 00 80 00 	movl   $0x10a000,0x80006ff4
8010330b:	a0 10 00 
    *(void**)(code-4) = stack + KSTACKSIZE;
8010330e:	05 00 10 00 00       	add    $0x1000,%eax
80103313:	a3 fc 6f 00 80       	mov    %eax,0x80006ffc
    lapicstartap(c->apicid, V2P(code));
80103318:	0f b6 03             	movzbl (%ebx),%eax
8010331b:	68 00 70 00 00       	push   $0x7000
80103320:	50                   	push   %eax
80103321:	e8 9a f7 ff ff       	call   80102ac0 <lapicstartap>

    // wait for cpu to finish mpmain()
    while(c->started == 0)
80103326:	83 c4 10             	add    $0x10,%esp
80103329:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80103330:	8b 83 a0 00 00 00    	mov    0xa0(%ebx),%eax
80103336:	85 c0                	test   %eax,%eax
80103338:	74 f6                	je     80103330 <main+0x100>
8010333a:	eb 94                	jmp    801032d0 <main+0xa0>
8010333c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  kinit2(P2V(4*1024*1024), P2V(PHYSTOP)); // must come after startothers()
80103340:	83 ec 08             	sub    $0x8,%esp
80103343:	68 00 00 00 8e       	push   $0x8e000000
80103348:	68 00 00 40 80       	push   $0x80400000
8010334d:	e8 ee f3 ff ff       	call   80102740 <kinit2>
  userinit();      // first user process
80103352:	e8 79 08 00 00       	call   80103bd0 <userinit>
  mpmain();        // finish this processor's setup
80103357:	e8 74 fe ff ff       	call   801031d0 <mpmain>
8010335c:	66 90                	xchg   %ax,%ax
8010335e:	66 90                	xchg   %ax,%ax

80103360 <mpsearch1>:
}

// Look for an MP structure in the len bytes at addr.
static struct mp*
mpsearch1(uint a, int len)
{
80103360:	55                   	push   %ebp
80103361:	89 e5                	mov    %esp,%ebp
80103363:	83 ec 18             	sub    $0x18,%esp
80103366:	89 75 f8             	mov    %esi,-0x8(%ebp)
  uchar *e, *p, *addr;

  addr = P2V(a);
80103369:	8d b0 00 00 00 80    	lea    -0x80000000(%eax),%esi
{
8010336f:	89 5d f4             	mov    %ebx,-0xc(%ebp)
  e = addr+len;
80103372:	8d 1c 16             	lea    (%esi,%edx,1),%ebx
  for(p = addr; p < e; p += sizeof(struct mp))
80103375:	39 de                	cmp    %ebx,%esi
80103377:	73 5a                	jae    801033d3 <mpsearch1+0x73>
80103379:	89 7d fc             	mov    %edi,-0x4(%ebp)
8010337c:	eb 08                	jmp    80103386 <mpsearch1+0x26>
8010337e:	66 90                	xchg   %ax,%ax
80103380:	89 fe                	mov    %edi,%esi
80103382:	39 df                	cmp    %ebx,%edi
80103384:	73 4a                	jae    801033d0 <mpsearch1+0x70>
    if(memcmp(p, "_MP_", 4) == 0 && sum(p, sizeof(struct mp)) == 0)
80103386:	83 ec 04             	sub    $0x4,%esp
80103389:	8d 7e 10             	lea    0x10(%esi),%edi
8010338c:	6a 04                	push   $0x4
8010338e:	68 6f 7b 10 80       	push   $0x80107b6f
80103393:	56                   	push   %esi
80103394:	e8 07 17 00 00       	call   80104aa0 <memcmp>
80103399:	83 c4 10             	add    $0x10,%esp
8010339c:	85 c0                	test   %eax,%eax
8010339e:	75 e0                	jne    80103380 <mpsearch1+0x20>
801033a0:	89 f2                	mov    %esi,%edx
801033a2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
801033a8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801033af:	00 
    sum += addr[i];
801033b0:	0f b6 0a             	movzbl (%edx),%ecx
  for(i=0; i<len; i++)
801033b3:	83 c2 01             	add    $0x1,%edx
    sum += addr[i];
801033b6:	01 c8                	add    %ecx,%eax
  for(i=0; i<len; i++)
801033b8:	39 fa                	cmp    %edi,%edx
801033ba:	75 f4                	jne    801033b0 <mpsearch1+0x50>
    if(memcmp(p, "_MP_", 4) == 0 && sum(p, sizeof(struct mp)) == 0)
801033bc:	84 c0                	test   %al,%al
801033be:	75 c0                	jne    80103380 <mpsearch1+0x20>
      return (struct mp*)p;
  return 0;
}
801033c0:	89 f0                	mov    %esi,%eax
801033c2:	8b 7d fc             	mov    -0x4(%ebp),%edi
801033c5:	8b 5d f4             	mov    -0xc(%ebp),%ebx
801033c8:	8b 75 f8             	mov    -0x8(%ebp),%esi
801033cb:	c9                   	leave
801033cc:	c3                   	ret
801033cd:	8d 76 00             	lea    0x0(%esi),%esi
801033d0:	8b 7d fc             	mov    -0x4(%ebp),%edi
  return 0;
801033d3:	31 f6                	xor    %esi,%esi
}
801033d5:	8b 5d f4             	mov    -0xc(%ebp),%ebx
801033d8:	89 f0                	mov    %esi,%eax
801033da:	8b 75 f8             	mov    -0x8(%ebp),%esi
801033dd:	c9                   	leave
801033de:	c3                   	ret
801033df:	90                   	nop

801033e0 <mpinit>:
  return conf;
}

void
mpinit(void)
{
801033e0:	55                   	push   %ebp
801033e1:	89 e5                	mov    %esp,%ebp
801033e3:	57                   	push   %edi
801033e4:	56                   	push   %esi
801033e5:	53                   	push   %ebx
801033e6:	83 ec 1c             	sub    $0x1c,%esp
  if((p = ((bda[0x0F]<<8)| bda[0x0E]) << 4)){
801033e9:	0f b6 05 0f 04 00 80 	movzbl 0x8000040f,%eax
801033f0:	0f b6 15 0e 04 00 80 	movzbl 0x8000040e,%edx
801033f7:	c1 e0 08             	shl    $0x8,%eax
801033fa:	09 d0                	or     %edx,%eax
801033fc:	c1 e0 04             	shl    $0x4,%eax
801033ff:	75 1b                	jne    8010341c <mpinit+0x3c>
    p = ((bda[0x14]<<8)|bda[0x13])*1024;
80103401:	0f b6 05 14 04 00 80 	movzbl 0x80000414,%eax
80103408:	0f b6 15 13 04 00 80 	movzbl 0x80000413,%edx
8010340f:	c1 e0 08             	shl    $0x8,%eax
80103412:	09 d0                	or     %edx,%eax
80103414:	c1 e0 0a             	shl    $0xa,%eax
    if((mp = mpsearch1(p-1024, 1024)))
80103417:	2d 00 04 00 00       	sub    $0x400,%eax
    if((mp = mpsearch1(p, 1024)))
8010341c:	ba 00 04 00 00       	mov    $0x400,%edx
80103421:	e8 3a ff ff ff       	call   80103360 <mpsearch1>
80103426:	89 c3                	mov    %eax,%ebx
80103428:	85 c0                	test   %eax,%eax
8010342a:	0f 84 48 01 00 00    	je     80103578 <mpinit+0x198>
  if((mp = mpsearch()) == 0 || mp->physaddr == 0)
80103430:	8b 73 04             	mov    0x4(%ebx),%esi
80103433:	85 f6                	test   %esi,%esi
80103435:	0f 84 2d 01 00 00    	je     80103568 <mpinit+0x188>
  if(memcmp(conf, "PCMP", 4) != 0)
8010343b:	83 ec 04             	sub    $0x4,%esp
  conf = (struct mpconf*) P2V((uint) mp->physaddr);
8010343e:	8d 86 00 00 00 80    	lea    -0x80000000(%esi),%eax
80103444:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  if(memcmp(conf, "PCMP", 4) != 0)
80103447:	6a 04                	push   $0x4
80103449:	68 74 7b 10 80       	push   $0x80107b74
8010344e:	50                   	push   %eax
8010344f:	e8 4c 16 00 00       	call   80104aa0 <memcmp>
80103454:	83 c4 10             	add    $0x10,%esp
80103457:	89 c2                	mov    %eax,%edx
80103459:	85 c0                	test   %eax,%eax
8010345b:	0f 85 07 01 00 00    	jne    80103568 <mpinit+0x188>
  if(conf->version != 1 && conf->version != 4)
80103461:	0f b6 86 06 00 00 80 	movzbl -0x7ffffffa(%esi),%eax
80103468:	3c 01                	cmp    $0x1,%al
8010346a:	74 08                	je     80103474 <mpinit+0x94>
8010346c:	3c 04                	cmp    $0x4,%al
8010346e:	0f 85 f4 00 00 00    	jne    80103568 <mpinit+0x188>
  if(sum((uchar*)conf, conf->length) != 0)
80103474:	0f b7 8e 04 00 00 80 	movzwl -0x7ffffffc(%esi),%ecx
  for(i=0; i<len; i++)
8010347b:	66 85 c9             	test   %cx,%cx
8010347e:	74 28                	je     801034a8 <mpinit+0xc8>
80103480:	89 f0                	mov    %esi,%eax
80103482:	8d 3c 31             	lea    (%ecx,%esi,1),%edi
80103485:	8d 76 00             	lea    0x0(%esi),%esi
80103488:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010348f:	00 
    sum += addr[i];
80103490:	0f b6 88 00 00 00 80 	movzbl -0x80000000(%eax),%ecx
  for(i=0; i<len; i++)
80103497:	83 c0 01             	add    $0x1,%eax
    sum += addr[i];
8010349a:	01 ca                	add    %ecx,%edx
  for(i=0; i<len; i++)
8010349c:	39 c7                	cmp    %eax,%edi
8010349e:	75 f0                	jne    80103490 <mpinit+0xb0>
  if(sum((uchar*)conf, conf->length) != 0)
801034a0:	84 d2                	test   %dl,%dl
801034a2:	0f 85 c0 00 00 00    	jne    80103568 <mpinit+0x188>
  struct mpioapic *ioapic;

  if((conf = mpconfig(&mp)) == 0)
    panic("Expect to run on an SMP");
  ismp = 1;
  lapic = (uint*)conf->lapicaddr;
801034a8:	8b 86 24 00 00 80    	mov    -0x7fffffdc(%esi),%eax
  for(p=(uchar*)(conf+1), e=(uchar*)conf+conf->length; p<e; ){
801034ae:	8b 7d e4             	mov    -0x1c(%ebp),%edi
  lapic = (uint*)conf->lapicaddr;
801034b1:	a3 a0 26 11 80       	mov    %eax,0x801126a0
  for(p=(uchar*)(conf+1), e=(uchar*)conf+conf->length; p<e; ){
801034b6:	0f b7 8e 04 00 00 80 	movzwl -0x7ffffffc(%esi),%ecx
801034bd:	8d 86 2c 00 00 80    	lea    -0x7fffffd4(%esi),%eax
801034c3:	01 f9                	add    %edi,%ecx
801034c5:	39 c8                	cmp    %ecx,%eax
801034c7:	72 14                	jb     801034dd <mpinit+0xfd>
801034c9:	eb 2b                	jmp    801034f6 <mpinit+0x116>
801034cb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    switch(*p){
801034d0:	77 7e                	ja     80103550 <mpinit+0x170>
801034d2:	84 d2                	test   %dl,%dl
801034d4:	74 4a                	je     80103520 <mpinit+0x140>
      p += sizeof(struct mpioapic);
      continue;
    case MPBUS:
    case MPIOINTR:
    case MPLINTR:
      p += 8;
801034d6:	83 c0 08             	add    $0x8,%eax
  for(p=(uchar*)(conf+1), e=(uchar*)conf+conf->length; p<e; ){
801034d9:	39 c8                	cmp    %ecx,%eax
801034db:	73 19                	jae    801034f6 <mpinit+0x116>
    switch(*p){
801034dd:	0f b6 10             	movzbl (%eax),%edx
801034e0:	80 fa 02             	cmp    $0x2,%dl
801034e3:	75 eb                	jne    801034d0 <mpinit+0xf0>
      ioapicid = ioapic->apicno;
801034e5:	0f b6 50 01          	movzbl 0x1(%eax),%edx
      p += sizeof(struct mpioapic);
801034e9:	83 c0 08             	add    $0x8,%eax
      ioapicid = ioapic->apicno;
801034ec:	88 15 a0 27 11 80    	mov    %dl,0x801127a0
  for(p=(uchar*)(conf+1), e=(uchar*)conf+conf->length; p<e; ){
801034f2:	39 c8                	cmp    %ecx,%eax
801034f4:	72 e7                	jb     801034dd <mpinit+0xfd>
    }
  }
  if(!ismp)
    panic("Didn't find a suitable machine");

  if(mp->imcrp){
801034f6:	80 7b 0c 00          	cmpb   $0x0,0xc(%ebx)
801034fa:	74 15                	je     80103511 <mpinit+0x131>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801034fc:	b8 70 00 00 00       	mov    $0x70,%eax
80103501:	ba 22 00 00 00       	mov    $0x22,%edx
80103506:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80103507:	ba 23 00 00 00       	mov    $0x23,%edx
8010350c:	ec                   	in     (%dx),%al
    // Bochs doesn't support IMCR, so this doesn't run on Bochs.
    // But it would on real hardware.
    outb(0x22, 0x70);   // Select IMCR
    outb(0x23, inb(0x23) | 1);  // Mask external interrupts.
8010350d:	83 c8 01             	or     $0x1,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80103510:	ee                   	out    %al,(%dx)
  }
}
80103511:	8d 65 f4             	lea    -0xc(%ebp),%esp
80103514:	5b                   	pop    %ebx
80103515:	5e                   	pop    %esi
80103516:	5f                   	pop    %edi
80103517:	5d                   	pop    %ebp
80103518:	c3                   	ret
80103519:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
      if(ncpu < NCPU) {
80103520:	8b 35 a4 27 11 80    	mov    0x801127a4,%esi
80103526:	83 fe 07             	cmp    $0x7,%esi
80103529:	7f 19                	jg     80103544 <mpinit+0x164>
        cpus[ncpu].apicid = proc->apicid;  // apicid may differ from ncpu
8010352b:	69 fe b0 00 00 00    	imul   $0xb0,%esi,%edi
80103531:	0f b6 50 01          	movzbl 0x1(%eax),%edx
        ncpu++;
80103535:	83 c6 01             	add    $0x1,%esi
80103538:	89 35 a4 27 11 80    	mov    %esi,0x801127a4
        cpus[ncpu].apicid = proc->apicid;  // apicid may differ from ncpu
8010353e:	88 97 c0 27 11 80    	mov    %dl,-0x7feed840(%edi)
      p += sizeof(struct mpproc);
80103544:	83 c0 14             	add    $0x14,%eax
      continue;
80103547:	eb 90                	jmp    801034d9 <mpinit+0xf9>
80103549:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    switch(*p){
80103550:	83 ea 03             	sub    $0x3,%edx
80103553:	80 fa 01             	cmp    $0x1,%dl
80103556:	0f 86 7a ff ff ff    	jbe    801034d6 <mpinit+0xf6>
8010355c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80103560:	eb fe                	jmp    80103560 <mpinit+0x180>
80103562:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    panic("Expect to run on an SMP");
80103568:	83 ec 0c             	sub    $0xc,%esp
8010356b:	68 79 7b 10 80       	push   $0x80107b79
80103570:	e8 2b ce ff ff       	call   801003a0 <panic>
80103575:	8d 76 00             	lea    0x0(%esi),%esi
  for(p = addr; p < e; p += sizeof(struct mp))
80103578:	bb 00 00 0f 80       	mov    $0x800f0000,%ebx
8010357d:	eb 0b                	jmp    8010358a <mpinit+0x1aa>
8010357f:	90                   	nop
80103580:	89 f3                	mov    %esi,%ebx
80103582:	81 fe 00 00 10 80    	cmp    $0x80100000,%esi
80103588:	74 de                	je     80103568 <mpinit+0x188>
    if(memcmp(p, "_MP_", 4) == 0 && sum(p, sizeof(struct mp)) == 0)
8010358a:	83 ec 04             	sub    $0x4,%esp
8010358d:	8d 73 10             	lea    0x10(%ebx),%esi
80103590:	6a 04                	push   $0x4
80103592:	68 6f 7b 10 80       	push   $0x80107b6f
80103597:	53                   	push   %ebx
80103598:	e8 03 15 00 00       	call   80104aa0 <memcmp>
8010359d:	83 c4 10             	add    $0x10,%esp
801035a0:	85 c0                	test   %eax,%eax
801035a2:	75 dc                	jne    80103580 <mpinit+0x1a0>
801035a4:	89 da                	mov    %ebx,%edx
801035a6:	66 90                	xchg   %ax,%ax
801035a8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801035af:	00 
    sum += addr[i];
801035b0:	0f b6 0a             	movzbl (%edx),%ecx
  for(i=0; i<len; i++)
801035b3:	83 c2 01             	add    $0x1,%edx
    sum += addr[i];
801035b6:	01 c8                	add    %ecx,%eax
  for(i=0; i<len; i++)
801035b8:	39 d6                	cmp    %edx,%esi
801035ba:	75 f4                	jne    801035b0 <mpinit+0x1d0>
    if(memcmp(p, "_MP_", 4) == 0 && sum(p, sizeof(struct mp)) == 0)
801035bc:	84 c0                	test   %al,%al
801035be:	75 c0                	jne    80103580 <mpinit+0x1a0>
801035c0:	e9 6b fe ff ff       	jmp    80103430 <mpinit+0x50>
801035c5:	66 90                	xchg   %ax,%ax
801035c7:	66 90                	xchg   %ax,%ax
801035c9:	66 90                	xchg   %ax,%ax
801035cb:	66 90                	xchg   %ax,%ax
801035cd:	66 90                	xchg   %ax,%ax
801035cf:	90                   	nop

801035d0 <picinit>:
801035d0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801035d5:	ba 21 00 00 00       	mov    $0x21,%edx
801035da:	ee                   	out    %al,(%dx)
801035db:	ba a1 00 00 00       	mov    $0xa1,%edx
801035e0:	ee                   	out    %al,(%dx)
picinit(void)
{
  // mask all interrupts
  outb(IO_PIC1+1, 0xFF);
  outb(IO_PIC2+1, 0xFF);
}
801035e1:	c3                   	ret
801035e2:	66 90                	xchg   %ax,%ax
801035e4:	66 90                	xchg   %ax,%ax
801035e6:	66 90                	xchg   %ax,%ax
801035e8:	66 90                	xchg   %ax,%ax
801035ea:	66 90                	xchg   %ax,%ax
801035ec:	66 90                	xchg   %ax,%ax
801035ee:	66 90                	xchg   %ax,%ax
801035f0:	66 90                	xchg   %ax,%ax
801035f2:	66 90                	xchg   %ax,%ax
801035f4:	66 90                	xchg   %ax,%ax
801035f6:	66 90                	xchg   %ax,%ax
801035f8:	66 90                	xchg   %ax,%ax
801035fa:	66 90                	xchg   %ax,%ax
801035fc:	66 90                	xchg   %ax,%ax
801035fe:	66 90                	xchg   %ax,%ax

80103600 <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
80103600:	55                   	push   %ebp
80103601:	89 e5                	mov    %esp,%ebp
80103603:	56                   	push   %esi
80103604:	53                   	push   %ebx
80103605:	83 ec 10             	sub    $0x10,%esp
80103608:	8b 5d 08             	mov    0x8(%ebp),%ebx
8010360b:	8b 75 0c             	mov    0xc(%ebp),%esi
  struct pipe *p;

  p = 0;
  *f0 = *f1 = 0;
8010360e:	c7 06 00 00 00 00    	movl   $0x0,(%esi)
80103614:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
8010361a:	e8 c1 d8 ff ff       	call   80100ee0 <filealloc>
8010361f:	89 03                	mov    %eax,(%ebx)
80103621:	85 c0                	test   %eax,%eax
80103623:	0f 84 a9 00 00 00    	je     801036d2 <pipealloc+0xd2>
80103629:	e8 b2 d8 ff ff       	call   80100ee0 <filealloc>
8010362e:	89 06                	mov    %eax,(%esi)
80103630:	85 c0                	test   %eax,%eax
80103632:	0f 84 88 00 00 00    	je     801036c0 <pipealloc+0xc0>
    goto bad;
  if((p = (struct pipe*)kalloc()) == 0)
80103638:	e8 d3 f1 ff ff       	call   80102810 <kalloc>
8010363d:	85 c0                	test   %eax,%eax
8010363f:	0f 84 ab 00 00 00    	je     801036f0 <pipealloc+0xf0>
    goto bad;
  p->readopen = 1;
80103645:	c7 80 3c 02 00 00 01 	movl   $0x1,0x23c(%eax)
8010364c:	00 00 00 
  p->writeopen = 1;
  p->nwrite = 0;
  p->nread = 0;
  initlock(&p->lock, "pipe");
8010364f:	83 ec 08             	sub    $0x8,%esp
  p->writeopen = 1;
80103652:	c7 80 40 02 00 00 01 	movl   $0x1,0x240(%eax)
80103659:	00 00 00 
  p->nwrite = 0;
8010365c:	c7 80 38 02 00 00 00 	movl   $0x0,0x238(%eax)
80103663:	00 00 00 
  p->nread = 0;
80103666:	c7 80 34 02 00 00 00 	movl   $0x0,0x234(%eax)
8010366d:	00 00 00 
  initlock(&p->lock, "pipe");
80103670:	68 91 7b 10 80       	push   $0x80107b91
80103675:	50                   	push   %eax
80103676:	89 45 f4             	mov    %eax,-0xc(%ebp)
80103679:	e8 a2 10 00 00       	call   80104720 <initlock>
  (*f0)->type = FD_PIPE;
8010367e:	8b 13                	mov    (%ebx),%edx
  (*f0)->readable = 1;
  (*f0)->writable = 0;
  (*f0)->pipe = p;
80103680:	8b 45 f4             	mov    -0xc(%ebp),%eax
  (*f1)->type = FD_PIPE;
  (*f1)->readable = 0;
  (*f1)->writable = 1;
  (*f1)->pipe = p;
  return 0;
80103683:	83 c4 10             	add    $0x10,%esp
  (*f0)->type = FD_PIPE;
80103686:	c7 02 01 00 00 00    	movl   $0x1,(%edx)
  (*f0)->readable = 1;
8010368c:	8b 13                	mov    (%ebx),%edx
8010368e:	c6 42 08 01          	movb   $0x1,0x8(%edx)
  (*f0)->writable = 0;
80103692:	8b 13                	mov    (%ebx),%edx
80103694:	c6 42 09 00          	movb   $0x0,0x9(%edx)
  (*f0)->pipe = p;
80103698:	8b 13                	mov    (%ebx),%edx
8010369a:	89 42 0c             	mov    %eax,0xc(%edx)
  (*f1)->type = FD_PIPE;
8010369d:	8b 16                	mov    (%esi),%edx
8010369f:	c7 02 01 00 00 00    	movl   $0x1,(%edx)
  (*f1)->readable = 0;
801036a5:	8b 16                	mov    (%esi),%edx
801036a7:	c6 42 08 00          	movb   $0x0,0x8(%edx)
  (*f1)->writable = 1;
801036ab:	8b 16                	mov    (%esi),%edx
801036ad:	c6 42 09 01          	movb   $0x1,0x9(%edx)
  (*f1)->pipe = p;
801036b1:	8b 16                	mov    (%esi),%edx
801036b3:	89 42 0c             	mov    %eax,0xc(%edx)
  if(*f0)
    fileclose(*f0);
  if(*f1)
    fileclose(*f1);
  return -1;
}
801036b6:	8d 65 f8             	lea    -0x8(%ebp),%esp
  return 0;
801036b9:	31 c0                	xor    %eax,%eax
}
801036bb:	5b                   	pop    %ebx
801036bc:	5e                   	pop    %esi
801036bd:	5d                   	pop    %ebp
801036be:	c3                   	ret
801036bf:	90                   	nop
  if(*f0)
801036c0:	8b 03                	mov    (%ebx),%eax
801036c2:	85 c0                	test   %eax,%eax
801036c4:	74 1e                	je     801036e4 <pipealloc+0xe4>
    fileclose(*f0);
801036c6:	83 ec 0c             	sub    $0xc,%esp
801036c9:	50                   	push   %eax
801036ca:	e8 d1 d8 ff ff       	call   80100fa0 <fileclose>
801036cf:	83 c4 10             	add    $0x10,%esp
  if(*f1)
801036d2:	8b 06                	mov    (%esi),%eax
801036d4:	85 c0                	test   %eax,%eax
801036d6:	74 0c                	je     801036e4 <pipealloc+0xe4>
    fileclose(*f1);
801036d8:	83 ec 0c             	sub    $0xc,%esp
801036db:	50                   	push   %eax
801036dc:	e8 bf d8 ff ff       	call   80100fa0 <fileclose>
801036e1:	83 c4 10             	add    $0x10,%esp
}
801036e4:	8d 65 f8             	lea    -0x8(%ebp),%esp
  return -1;
801036e7:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
801036ec:	5b                   	pop    %ebx
801036ed:	5e                   	pop    %esi
801036ee:	5d                   	pop    %ebp
801036ef:	c3                   	ret
  if(*f0)
801036f0:	8b 03                	mov    (%ebx),%eax
801036f2:	85 c0                	test   %eax,%eax
801036f4:	75 d0                	jne    801036c6 <pipealloc+0xc6>
801036f6:	eb da                	jmp    801036d2 <pipealloc+0xd2>
801036f8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801036ff:	00 

80103700 <pipeclose>:

void
pipeclose(struct pipe *p, int writable)
{
80103700:	55                   	push   %ebp
80103701:	89 e5                	mov    %esp,%ebp
80103703:	56                   	push   %esi
80103704:	53                   	push   %ebx
80103705:	8b 5d 08             	mov    0x8(%ebp),%ebx
80103708:	8b 75 0c             	mov    0xc(%ebp),%esi
  acquire(&p->lock);
8010370b:	83 ec 0c             	sub    $0xc,%esp
8010370e:	53                   	push   %ebx
8010370f:	e8 2c 12 00 00       	call   80104940 <acquire>
  if(writable){
80103714:	83 c4 10             	add    $0x10,%esp
80103717:	85 f6                	test   %esi,%esi
80103719:	74 45                	je     80103760 <pipeclose+0x60>
    p->writeopen = 0;
    wakeup(&p->nread);
8010371b:	83 ec 0c             	sub    $0xc,%esp
8010371e:	8d 83 34 02 00 00    	lea    0x234(%ebx),%eax
    p->writeopen = 0;
80103724:	c7 83 40 02 00 00 00 	movl   $0x0,0x240(%ebx)
8010372b:	00 00 00 
    wakeup(&p->nread);
8010372e:	50                   	push   %eax
8010372f:	e8 9c 0c 00 00       	call   801043d0 <wakeup>
80103734:	83 c4 10             	add    $0x10,%esp
  } else {
    p->readopen = 0;
    wakeup(&p->nwrite);
  }
  if(p->readopen == 0 && p->writeopen == 0){
80103737:	8b 93 3c 02 00 00    	mov    0x23c(%ebx),%edx
8010373d:	85 d2                	test   %edx,%edx
8010373f:	75 0a                	jne    8010374b <pipeclose+0x4b>
80103741:	8b 83 40 02 00 00    	mov    0x240(%ebx),%eax
80103747:	85 c0                	test   %eax,%eax
80103749:	74 35                	je     80103780 <pipeclose+0x80>
    release(&p->lock);
    kfree((char*)p);
  } else
    release(&p->lock);
8010374b:	89 5d 08             	mov    %ebx,0x8(%ebp)
}
8010374e:	8d 65 f8             	lea    -0x8(%ebp),%esp
80103751:	5b                   	pop    %ebx
80103752:	5e                   	pop    %esi
80103753:	5d                   	pop    %ebp
    release(&p->lock);
80103754:	e9 87 11 00 00       	jmp    801048e0 <release>
80103759:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    wakeup(&p->nwrite);
80103760:	83 ec 0c             	sub    $0xc,%esp
80103763:	8d 83 38 02 00 00    	lea    0x238(%ebx),%eax
    p->readopen = 0;
80103769:	c7 83 3c 02 00 00 00 	movl   $0x0,0x23c(%ebx)
80103770:	00 00 00 
    wakeup(&p->nwrite);
80103773:	50                   	push   %eax
80103774:	e8 57 0c 00 00       	call   801043d0 <wakeup>
80103779:	83 c4 10             	add    $0x10,%esp
8010377c:	eb b9                	jmp    80103737 <pipeclose+0x37>
8010377e:	66 90                	xchg   %ax,%ax
    release(&p->lock);
80103780:	83 ec 0c             	sub    $0xc,%esp
80103783:	53                   	push   %ebx
80103784:	e8 57 11 00 00       	call   801048e0 <release>
    kfree((char*)p);
80103789:	83 c4 10             	add    $0x10,%esp
8010378c:	89 5d 08             	mov    %ebx,0x8(%ebp)
}
8010378f:	8d 65 f8             	lea    -0x8(%ebp),%esp
80103792:	5b                   	pop    %ebx
80103793:	5e                   	pop    %esi
80103794:	5d                   	pop    %ebp
    kfree((char*)p);
80103795:	e9 a6 ee ff ff       	jmp    80102640 <kfree>
8010379a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

801037a0 <pipewrite>:

//PAGEBREAK: 40
int
pipewrite(struct pipe *p, char *addr, int n)
{
801037a0:	55                   	push   %ebp
801037a1:	89 e5                	mov    %esp,%ebp
801037a3:	83 ec 34             	sub    $0x34,%esp
801037a6:	89 5d f4             	mov    %ebx,-0xc(%ebp)
801037a9:	8b 5d 08             	mov    0x8(%ebp),%ebx
801037ac:	89 7d fc             	mov    %edi,-0x4(%ebp)
801037af:	8b 7d 10             	mov    0x10(%ebp),%edi
  int i;

  acquire(&p->lock);
801037b2:	53                   	push   %ebx
801037b3:	e8 88 11 00 00       	call   80104940 <acquire>
  for(i = 0; i < n; i++){
801037b8:	83 c4 10             	add    $0x10,%esp
801037bb:	85 ff                	test   %edi,%edi
801037bd:	0f 8e d4 00 00 00    	jle    80103897 <pipewrite+0xf7>
801037c3:	89 75 f8             	mov    %esi,-0x8(%ebp)
    while(p->nwrite == p->nread + PIPESIZE){  //DOC: pipewrite-full
801037c6:	8b 83 38 02 00 00    	mov    0x238(%ebx),%eax
801037cc:	8b 4d 0c             	mov    0xc(%ebp),%ecx
801037cf:	89 7d 10             	mov    %edi,0x10(%ebp)
801037d2:	89 45 e4             	mov    %eax,-0x1c(%ebp)
801037d5:	8d 34 39             	lea    (%ecx,%edi,1),%esi
801037d8:	89 75 e0             	mov    %esi,-0x20(%ebp)
      if(p->readopen == 0 || myproc()->killed){
        release(&p->lock);
        return -1;
      }
      wakeup(&p->nread);
801037db:	8d b3 34 02 00 00    	lea    0x234(%ebx),%esi
    while(p->nwrite == p->nread + PIPESIZE){  //DOC: pipewrite-full
801037e1:	8b 83 34 02 00 00    	mov    0x234(%ebx),%eax
      sleep(&p->nwrite, &p->lock);  //DOC: pipewrite-sleep
801037e7:	8d bb 38 02 00 00    	lea    0x238(%ebx),%edi
    while(p->nwrite == p->nread + PIPESIZE){  //DOC: pipewrite-full
801037ed:	8d 90 00 02 00 00    	lea    0x200(%eax),%edx
801037f3:	39 55 e4             	cmp    %edx,-0x1c(%ebp)
801037f6:	0f 85 b9 00 00 00    	jne    801038b5 <pipewrite+0x115>
801037fc:	89 4d e4             	mov    %ecx,-0x1c(%ebp)
801037ff:	eb 3d                	jmp    8010383e <pipewrite+0x9e>
80103801:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
      if(p->readopen == 0 || myproc()->killed){
80103808:	e8 93 03 00 00       	call   80103ba0 <myproc>
8010380d:	8b 48 24             	mov    0x24(%eax),%ecx
80103810:	85 c9                	test   %ecx,%ecx
80103812:	75 34                	jne    80103848 <pipewrite+0xa8>
      wakeup(&p->nread);
80103814:	83 ec 0c             	sub    $0xc,%esp
80103817:	56                   	push   %esi
80103818:	e8 b3 0b 00 00       	call   801043d0 <wakeup>
      sleep(&p->nwrite, &p->lock);  //DOC: pipewrite-sleep
8010381d:	58                   	pop    %eax
8010381e:	5a                   	pop    %edx
8010381f:	53                   	push   %ebx
80103820:	57                   	push   %edi
80103821:	e8 ea 0a 00 00       	call   80104310 <sleep>
    while(p->nwrite == p->nread + PIPESIZE){  //DOC: pipewrite-full
80103826:	8b 83 34 02 00 00    	mov    0x234(%ebx),%eax
8010382c:	8b 93 38 02 00 00    	mov    0x238(%ebx),%edx
80103832:	83 c4 10             	add    $0x10,%esp
80103835:	05 00 02 00 00       	add    $0x200,%eax
8010383a:	39 c2                	cmp    %eax,%edx
8010383c:	75 2a                	jne    80103868 <pipewrite+0xc8>
      if(p->readopen == 0 || myproc()->killed){
8010383e:	8b 83 3c 02 00 00    	mov    0x23c(%ebx),%eax
80103844:	85 c0                	test   %eax,%eax
80103846:	75 c0                	jne    80103808 <pipewrite+0x68>
        release(&p->lock);
80103848:	83 ec 0c             	sub    $0xc,%esp
8010384b:	53                   	push   %ebx
8010384c:	e8 8f 10 00 00       	call   801048e0 <release>
        return -1;
80103851:	8b 75 f8             	mov    -0x8(%ebp),%esi
80103854:	83 c4 10             	add    $0x10,%esp
80103857:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    p->data[p->nwrite++ % PIPESIZE] = addr[i];
  }
  wakeup(&p->nread);  //DOC: pipewrite-wakeup1
  release(&p->lock);
  return n;
}
8010385c:	8b 5d f4             	mov    -0xc(%ebp),%ebx
8010385f:	8b 7d fc             	mov    -0x4(%ebp),%edi
80103862:	c9                   	leave
80103863:	c3                   	ret
80103864:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80103868:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
    p->data[p->nwrite++ % PIPESIZE] = addr[i];
8010386b:	8d 42 01             	lea    0x1(%edx),%eax
8010386e:	81 e2 ff 01 00 00    	and    $0x1ff,%edx
  for(i = 0; i < n; i++){
80103874:	83 c1 01             	add    $0x1,%ecx
    p->data[p->nwrite++ % PIPESIZE] = addr[i];
80103877:	89 83 38 02 00 00    	mov    %eax,0x238(%ebx)
8010387d:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80103880:	0f b6 41 ff          	movzbl -0x1(%ecx),%eax
80103884:	88 44 13 34          	mov    %al,0x34(%ebx,%edx,1)
  for(i = 0; i < n; i++){
80103888:	3b 4d e0             	cmp    -0x20(%ebp),%ecx
8010388b:	0f 85 50 ff ff ff    	jne    801037e1 <pipewrite+0x41>
80103891:	8b 7d 10             	mov    0x10(%ebp),%edi
80103894:	8b 75 f8             	mov    -0x8(%ebp),%esi
  wakeup(&p->nread);  //DOC: pipewrite-wakeup1
80103897:	83 ec 0c             	sub    $0xc,%esp
8010389a:	8d 83 34 02 00 00    	lea    0x234(%ebx),%eax
801038a0:	50                   	push   %eax
801038a1:	e8 2a 0b 00 00       	call   801043d0 <wakeup>
  release(&p->lock);
801038a6:	89 1c 24             	mov    %ebx,(%esp)
801038a9:	e8 32 10 00 00       	call   801048e0 <release>
  return n;
801038ae:	83 c4 10             	add    $0x10,%esp
801038b1:	89 f8                	mov    %edi,%eax
801038b3:	eb a7                	jmp    8010385c <pipewrite+0xbc>
    while(p->nwrite == p->nread + PIPESIZE){  //DOC: pipewrite-full
801038b5:	8b 55 e4             	mov    -0x1c(%ebp),%edx
801038b8:	eb b1                	jmp    8010386b <pipewrite+0xcb>
801038ba:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

801038c0 <piperead>:

int
piperead(struct pipe *p, char *addr, int n)
{
801038c0:	55                   	push   %ebp
801038c1:	89 e5                	mov    %esp,%ebp
801038c3:	57                   	push   %edi
801038c4:	56                   	push   %esi
801038c5:	53                   	push   %ebx
801038c6:	83 ec 18             	sub    $0x18,%esp
801038c9:	8b 75 08             	mov    0x8(%ebp),%esi
801038cc:	8b 7d 0c             	mov    0xc(%ebp),%edi
  int i;

  acquire(&p->lock);
801038cf:	56                   	push   %esi
801038d0:	8d 9e 34 02 00 00    	lea    0x234(%esi),%ebx
801038d6:	e8 65 10 00 00       	call   80104940 <acquire>
  while(p->nread == p->nwrite && p->writeopen){  //DOC: pipe-empty
801038db:	8b 86 34 02 00 00    	mov    0x234(%esi),%eax
801038e1:	83 c4 10             	add    $0x10,%esp
801038e4:	3b 86 38 02 00 00    	cmp    0x238(%esi),%eax
801038ea:	74 2f                	je     8010391b <piperead+0x5b>
801038ec:	eb 37                	jmp    80103925 <piperead+0x65>
801038ee:	66 90                	xchg   %ax,%ax
    if(myproc()->killed){
801038f0:	e8 ab 02 00 00       	call   80103ba0 <myproc>
801038f5:	8b 48 24             	mov    0x24(%eax),%ecx
801038f8:	85 c9                	test   %ecx,%ecx
801038fa:	0f 85 90 00 00 00    	jne    80103990 <piperead+0xd0>
      release(&p->lock);
      return -1;
    }
    sleep(&p->nread, &p->lock); //DOC: piperead-sleep
80103900:	83 ec 08             	sub    $0x8,%esp
80103903:	56                   	push   %esi
80103904:	53                   	push   %ebx
80103905:	e8 06 0a 00 00       	call   80104310 <sleep>
  while(p->nread == p->nwrite && p->writeopen){  //DOC: pipe-empty
8010390a:	8b 86 34 02 00 00    	mov    0x234(%esi),%eax
80103910:	83 c4 10             	add    $0x10,%esp
80103913:	3b 86 38 02 00 00    	cmp    0x238(%esi),%eax
80103919:	75 0a                	jne    80103925 <piperead+0x65>
8010391b:	8b 96 40 02 00 00    	mov    0x240(%esi),%edx
80103921:	85 d2                	test   %edx,%edx
80103923:	75 cb                	jne    801038f0 <piperead+0x30>
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
80103925:	8b 55 10             	mov    0x10(%ebp),%edx
80103928:	31 db                	xor    %ebx,%ebx
8010392a:	85 d2                	test   %edx,%edx
8010392c:	7f 36                	jg     80103964 <piperead+0xa4>
8010392e:	eb 3c                	jmp    8010396c <piperead+0xac>
80103930:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80103937:	00 
80103938:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010393f:	00 
    if(p->nread == p->nwrite)
      break;
    addr[i] = p->data[p->nread++ % PIPESIZE];
80103940:	8d 48 01             	lea    0x1(%eax),%ecx
80103943:	25 ff 01 00 00       	and    $0x1ff,%eax
80103948:	89 8e 34 02 00 00    	mov    %ecx,0x234(%esi)
8010394e:	0f b6 44 06 34       	movzbl 0x34(%esi,%eax,1),%eax
80103953:	88 04 1f             	mov    %al,(%edi,%ebx,1)
  for(i = 0; i < n; i++){  //DOC: piperead-copy
80103956:	83 c3 01             	add    $0x1,%ebx
80103959:	39 5d 10             	cmp    %ebx,0x10(%ebp)
8010395c:	74 0e                	je     8010396c <piperead+0xac>
8010395e:	8b 86 34 02 00 00    	mov    0x234(%esi),%eax
    if(p->nread == p->nwrite)
80103964:	3b 86 38 02 00 00    	cmp    0x238(%esi),%eax
8010396a:	75 d4                	jne    80103940 <piperead+0x80>
  }
  wakeup(&p->nwrite);  //DOC: piperead-wakeup
8010396c:	83 ec 0c             	sub    $0xc,%esp
8010396f:	8d 86 38 02 00 00    	lea    0x238(%esi),%eax
80103975:	50                   	push   %eax
80103976:	e8 55 0a 00 00       	call   801043d0 <wakeup>
  release(&p->lock);
8010397b:	89 34 24             	mov    %esi,(%esp)
8010397e:	e8 5d 0f 00 00       	call   801048e0 <release>
  return i;
80103983:	83 c4 10             	add    $0x10,%esp
}
80103986:	8d 65 f4             	lea    -0xc(%ebp),%esp
80103989:	89 d8                	mov    %ebx,%eax
8010398b:	5b                   	pop    %ebx
8010398c:	5e                   	pop    %esi
8010398d:	5f                   	pop    %edi
8010398e:	5d                   	pop    %ebp
8010398f:	c3                   	ret
      release(&p->lock);
80103990:	83 ec 0c             	sub    $0xc,%esp
      return -1;
80103993:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
      release(&p->lock);
80103998:	56                   	push   %esi
80103999:	e8 42 0f 00 00       	call   801048e0 <release>
      return -1;
8010399e:	83 c4 10             	add    $0x10,%esp
}
801039a1:	8d 65 f4             	lea    -0xc(%ebp),%esp
801039a4:	89 d8                	mov    %ebx,%eax
801039a6:	5b                   	pop    %ebx
801039a7:	5e                   	pop    %esi
801039a8:	5f                   	pop    %edi
801039a9:	5d                   	pop    %ebp
801039aa:	c3                   	ret
801039ab:	66 90                	xchg   %ax,%ax
801039ad:	66 90                	xchg   %ax,%ax
801039af:	66 90                	xchg   %ax,%ax
801039b1:	66 90                	xchg   %ax,%ax
801039b3:	66 90                	xchg   %ax,%ax
801039b5:	66 90                	xchg   %ax,%ax
801039b7:	66 90                	xchg   %ax,%ax
801039b9:	66 90                	xchg   %ax,%ax
801039bb:	66 90                	xchg   %ax,%ax
801039bd:	66 90                	xchg   %ax,%ax
801039bf:	90                   	nop

801039c0 <allocproc>:
//  If found, change state to EMBRYO and initialize
//  state required to run in the kernel.
//  Otherwise return 0.
static struct proc *
allocproc(void)
{
801039c0:	55                   	push   %ebp
801039c1:	89 e5                	mov    %esp,%ebp
801039c3:	53                   	push   %ebx
  struct proc *p;
  char *sp;

  acquire(&ptable.lock);

  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
801039c4:	bb 74 2d 11 80       	mov    $0x80112d74,%ebx
{
801039c9:	83 ec 10             	sub    $0x10,%esp
  acquire(&ptable.lock);
801039cc:	68 40 2d 11 80       	push   $0x80112d40
801039d1:	e8 6a 0f 00 00       	call   80104940 <acquire>
801039d6:	83 c4 10             	add    $0x10,%esp
801039d9:	eb 14                	jmp    801039ef <allocproc+0x2f>
801039db:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
801039e0:	83 eb 80             	sub    $0xffffff80,%ebx
801039e3:	81 fb 74 4d 11 80    	cmp    $0x80114d74,%ebx
801039e9:	0f 84 81 00 00 00    	je     80103a70 <allocproc+0xb0>
    if (p->state == UNUSED)
801039ef:	8b 43 0c             	mov    0xc(%ebx),%eax
801039f2:	85 c0                	test   %eax,%eax
801039f4:	75 ea                	jne    801039e0 <allocproc+0x20>
  release(&ptable.lock);
  return 0;

found:
  p->state = EMBRYO;
  p->pid = nextpid++;
801039f6:	a1 04 b0 10 80       	mov    0x8010b004,%eax

  release(&ptable.lock);
801039fb:	83 ec 0c             	sub    $0xc,%esp
  p->state = EMBRYO;
801039fe:	c7 43 0c 01 00 00 00 	movl   $0x1,0xc(%ebx)
  p->pid = nextpid++;
80103a05:	89 43 10             	mov    %eax,0x10(%ebx)
80103a08:	8d 50 01             	lea    0x1(%eax),%edx
  release(&ptable.lock);
80103a0b:	68 40 2d 11 80       	push   $0x80112d40
  p->pid = nextpid++;
80103a10:	89 15 04 b0 10 80    	mov    %edx,0x8010b004
  release(&ptable.lock);
80103a16:	e8 c5 0e 00 00       	call   801048e0 <release>

  // Allocate kernel stack.
  if ((p->kstack = kalloc()) == 0)
80103a1b:	e8 f0 ed ff ff       	call   80102810 <kalloc>
80103a20:	83 c4 10             	add    $0x10,%esp
80103a23:	89 43 08             	mov    %eax,0x8(%ebx)
80103a26:	85 c0                	test   %eax,%eax
80103a28:	74 5f                	je     80103a89 <allocproc+0xc9>
    return 0;
  }
  sp = p->kstack + KSTACKSIZE;

  // Leave room for trap frame.
  sp -= sizeof *p->tf;
80103a2a:	8d 90 b4 0f 00 00    	lea    0xfb4(%eax),%edx
  sp -= 4;
  *(uint *)sp = (uint)trapret;

  sp -= sizeof *p->context;
  p->context = (struct context *)sp;
  memset(p->context, 0, sizeof *p->context);
80103a30:	83 ec 04             	sub    $0x4,%esp
  sp -= sizeof *p->context;
80103a33:	05 9c 0f 00 00       	add    $0xf9c,%eax
  sp -= sizeof *p->tf;
80103a38:	89 53 18             	mov    %edx,0x18(%ebx)
  *(uint *)sp = (uint)trapret;
80103a3b:	c7 40 14 a7 5e 10 80 	movl   $0x80105ea7,0x14(%eax)
  p->context = (struct context *)sp;
80103a42:	89 43 1c             	mov    %eax,0x1c(%ebx)
  memset(p->context, 0, sizeof *p->context);
80103a45:	6a 14                	push   $0x14
80103a47:	6a 00                	push   $0x0
80103a49:	50                   	push   %eax
80103a4a:	e8 11 10 00 00       	call   80104a60 <memset>
  p->context->eip = (uint)forkret;
80103a4f:	8b 43 1c             	mov    0x1c(%ebx),%eax
  // For priority scheduling
  p->priority = 10; // default val

  return p;
80103a52:	83 c4 10             	add    $0x10,%esp
  p->context->eip = (uint)forkret;
80103a55:	c7 40 10 a0 3a 10 80 	movl   $0x80103aa0,0x10(%eax)
}
80103a5c:	89 d8                	mov    %ebx,%eax
  p->priority = 10; // default val
80103a5e:	c7 43 7c 0a 00 00 00 	movl   $0xa,0x7c(%ebx)
}
80103a65:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103a68:	c9                   	leave
80103a69:	c3                   	ret
80103a6a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  release(&ptable.lock);
80103a70:	83 ec 0c             	sub    $0xc,%esp
  return 0;
80103a73:	31 db                	xor    %ebx,%ebx
  release(&ptable.lock);
80103a75:	68 40 2d 11 80       	push   $0x80112d40
80103a7a:	e8 61 0e 00 00       	call   801048e0 <release>
}
80103a7f:	89 d8                	mov    %ebx,%eax
  return 0;
80103a81:	83 c4 10             	add    $0x10,%esp
}
80103a84:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103a87:	c9                   	leave
80103a88:	c3                   	ret
    p->state = UNUSED;
80103a89:	c7 43 0c 00 00 00 00 	movl   $0x0,0xc(%ebx)
  return 0;
80103a90:	31 db                	xor    %ebx,%ebx
}
80103a92:	89 d8                	mov    %ebx,%eax
80103a94:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103a97:	c9                   	leave
80103a98:	c3                   	ret
80103a99:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80103aa0 <forkret>:
}

// A fork child's very first scheduling by scheduler()
// will swtch here.  "Return" to user space.
void forkret(void)
{
80103aa0:	55                   	push   %ebp
80103aa1:	89 e5                	mov    %esp,%ebp
80103aa3:	83 ec 14             	sub    $0x14,%esp
  static int first = 1;
  // Still holding ptable.lock from scheduler.
  release(&ptable.lock);
80103aa6:	68 40 2d 11 80       	push   $0x80112d40
80103aab:	e8 30 0e 00 00       	call   801048e0 <release>

  if (first)
80103ab0:	a1 00 b0 10 80       	mov    0x8010b000,%eax
80103ab5:	83 c4 10             	add    $0x10,%esp
80103ab8:	85 c0                	test   %eax,%eax
80103aba:	75 04                	jne    80103ac0 <forkret+0x20>
    iinit(ROOTDEV);
    initlog(ROOTDEV);
  }

  // Return to "caller", actually trapret (see allocproc).
}
80103abc:	c9                   	leave
80103abd:	c3                   	ret
80103abe:	66 90                	xchg   %ax,%ax
    first = 0;
80103ac0:	c7 05 00 b0 10 80 00 	movl   $0x0,0x8010b000
80103ac7:	00 00 00 
    iinit(ROOTDEV);
80103aca:	83 ec 0c             	sub    $0xc,%esp
80103acd:	6a 01                	push   $0x1
80103acf:	e8 5c db ff ff       	call   80101630 <iinit>
    initlog(ROOTDEV);
80103ad4:	c7 04 24 01 00 00 00 	movl   $0x1,(%esp)
80103adb:	e8 b0 f3 ff ff       	call   80102e90 <initlog>
80103ae0:	83 c4 10             	add    $0x10,%esp
}
80103ae3:	c9                   	leave
80103ae4:	c3                   	ret
80103ae5:	8d 76 00             	lea    0x0(%esi),%esi
80103ae8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80103aef:	00 

80103af0 <pinit>:
{
80103af0:	55                   	push   %ebp
80103af1:	89 e5                	mov    %esp,%ebp
80103af3:	83 ec 10             	sub    $0x10,%esp
  initlock(&ptable.lock, "ptable");
80103af6:	68 96 7b 10 80       	push   $0x80107b96
80103afb:	68 40 2d 11 80       	push   $0x80112d40
80103b00:	e8 1b 0c 00 00       	call   80104720 <initlock>
}
80103b05:	83 c4 10             	add    $0x10,%esp
80103b08:	c9                   	leave
80103b09:	c3                   	ret
80103b0a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80103b10 <mycpu>:
{
80103b10:	55                   	push   %ebp
80103b11:	89 e5                	mov    %esp,%ebp
80103b13:	56                   	push   %esi
80103b14:	53                   	push   %ebx
  asm volatile("pushfl; popl %0" : "=r" (eflags));
80103b15:	9c                   	pushf
80103b16:	58                   	pop    %eax
  if (readeflags() & FL_IF)
80103b17:	f6 c4 02             	test   $0x2,%ah
80103b1a:	75 55                	jne    80103b71 <mycpu+0x61>
  apicid = lapicid();
80103b1c:	e8 4f ef ff ff       	call   80102a70 <lapicid>
  for (i = 0; i < ncpu; ++i)
80103b21:	8b 1d a4 27 11 80    	mov    0x801127a4,%ebx
  apicid = lapicid();
80103b27:	89 c6                	mov    %eax,%esi
  for (i = 0; i < ncpu; ++i)
80103b29:	85 db                	test   %ebx,%ebx
80103b2b:	7e 37                	jle    80103b64 <mycpu+0x54>
80103b2d:	31 d2                	xor    %edx,%edx
80103b2f:	eb 16                	jmp    80103b47 <mycpu+0x37>
80103b31:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80103b38:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80103b3f:	00 
80103b40:	83 c2 01             	add    $0x1,%edx
80103b43:	39 da                	cmp    %ebx,%edx
80103b45:	74 1d                	je     80103b64 <mycpu+0x54>
    if (cpus[i].apicid == apicid)
80103b47:	69 c2 b0 00 00 00    	imul   $0xb0,%edx,%eax
80103b4d:	0f b6 88 c0 27 11 80 	movzbl -0x7feed840(%eax),%ecx
80103b54:	39 f1                	cmp    %esi,%ecx
80103b56:	75 e8                	jne    80103b40 <mycpu+0x30>
}
80103b58:	8d 65 f8             	lea    -0x8(%ebp),%esp
      return &cpus[i];
80103b5b:	05 c0 27 11 80       	add    $0x801127c0,%eax
}
80103b60:	5b                   	pop    %ebx
80103b61:	5e                   	pop    %esi
80103b62:	5d                   	pop    %ebp
80103b63:	c3                   	ret
  panic("unknown apicid\n");
80103b64:	83 ec 0c             	sub    $0xc,%esp
80103b67:	68 9d 7b 10 80       	push   $0x80107b9d
80103b6c:	e8 2f c8 ff ff       	call   801003a0 <panic>
    panic("mycpu called with interrupts enabled\n");
80103b71:	83 ec 0c             	sub    $0xc,%esp
80103b74:	68 dc 7e 10 80       	push   $0x80107edc
80103b79:	e8 22 c8 ff ff       	call   801003a0 <panic>
80103b7e:	66 90                	xchg   %ax,%ax

80103b80 <cpuid>:
{
80103b80:	55                   	push   %ebp
80103b81:	89 e5                	mov    %esp,%ebp
80103b83:	83 ec 08             	sub    $0x8,%esp
  return mycpu() - cpus;
80103b86:	e8 85 ff ff ff       	call   80103b10 <mycpu>
}
80103b8b:	c9                   	leave
  return mycpu() - cpus;
80103b8c:	2d c0 27 11 80       	sub    $0x801127c0,%eax
80103b91:	c1 f8 04             	sar    $0x4,%eax
80103b94:	69 c0 a3 8b 2e ba    	imul   $0xba2e8ba3,%eax,%eax
}
80103b9a:	c3                   	ret
80103b9b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80103ba0 <myproc>:
{
80103ba0:	55                   	push   %ebp
80103ba1:	89 e5                	mov    %esp,%ebp
80103ba3:	53                   	push   %ebx
80103ba4:	83 ec 04             	sub    $0x4,%esp
  pushcli();
80103ba7:	e8 34 0c 00 00       	call   801047e0 <pushcli>
  c = mycpu();
80103bac:	e8 5f ff ff ff       	call   80103b10 <mycpu>
  p = c->proc;
80103bb1:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
80103bb7:	e8 74 0c 00 00       	call   80104830 <popcli>
}
80103bbc:	89 d8                	mov    %ebx,%eax
80103bbe:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103bc1:	c9                   	leave
80103bc2:	c3                   	ret
80103bc3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80103bc8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80103bcf:	00 

80103bd0 <userinit>:
{
80103bd0:	55                   	push   %ebp
80103bd1:	89 e5                	mov    %esp,%ebp
80103bd3:	53                   	push   %ebx
80103bd4:	83 ec 04             	sub    $0x4,%esp
  p = allocproc();
80103bd7:	e8 e4 fd ff ff       	call   801039c0 <allocproc>
80103bdc:	89 c3                	mov    %eax,%ebx
  initproc = p;
80103bde:	a3 74 4d 11 80       	mov    %eax,0x80114d74
  if ((p->pgdir = setupkvm()) == 0)
80103be3:	e8 08 3a 00 00       	call   801075f0 <setupkvm>
80103be8:	89 43 04             	mov    %eax,0x4(%ebx)
80103beb:	85 c0                	test   %eax,%eax
80103bed:	0f 84 bd 00 00 00    	je     80103cb0 <userinit+0xe0>
  inituvm(p->pgdir, _binary_initcode_start, (int)_binary_initcode_size);
80103bf3:	83 ec 04             	sub    $0x4,%esp
80103bf6:	68 54 00 00 00       	push   $0x54
80103bfb:	68 60 b4 10 80       	push   $0x8010b460
80103c00:	50                   	push   %eax
80103c01:	e8 9a 36 00 00       	call   801072a0 <inituvm>
  memset(p->tf, 0, sizeof(*p->tf));
80103c06:	83 c4 0c             	add    $0xc,%esp
  p->sz = PGSIZE;
80103c09:	c7 03 00 10 00 00    	movl   $0x1000,(%ebx)
  memset(p->tf, 0, sizeof(*p->tf));
80103c0f:	6a 4c                	push   $0x4c
80103c11:	6a 00                	push   $0x0
80103c13:	ff 73 18             	push   0x18(%ebx)
80103c16:	e8 45 0e 00 00       	call   80104a60 <memset>
  p->tf->cs = (SEG_UCODE << 3) | DPL_USER;
80103c1b:	8b 43 18             	mov    0x18(%ebx),%eax
80103c1e:	ba 1b 00 00 00       	mov    $0x1b,%edx
  safestrcpy(p->name, "initcode", sizeof(p->name));
80103c23:	83 c4 0c             	add    $0xc,%esp
  p->tf->ds = (SEG_UDATA << 3) | DPL_USER;
80103c26:	b9 23 00 00 00       	mov    $0x23,%ecx
  p->tf->cs = (SEG_UCODE << 3) | DPL_USER;
80103c2b:	66 89 50 3c          	mov    %dx,0x3c(%eax)
  p->tf->ds = (SEG_UDATA << 3) | DPL_USER;
80103c2f:	8b 43 18             	mov    0x18(%ebx),%eax
80103c32:	66 89 48 2c          	mov    %cx,0x2c(%eax)
  p->tf->es = p->tf->ds;
80103c36:	8b 43 18             	mov    0x18(%ebx),%eax
80103c39:	0f b7 50 2c          	movzwl 0x2c(%eax),%edx
80103c3d:	66 89 50 28          	mov    %dx,0x28(%eax)
  p->tf->ss = p->tf->ds;
80103c41:	8b 43 18             	mov    0x18(%ebx),%eax
80103c44:	0f b7 50 2c          	movzwl 0x2c(%eax),%edx
80103c48:	66 89 50 48          	mov    %dx,0x48(%eax)
  p->tf->eflags = FL_IF;
80103c4c:	8b 43 18             	mov    0x18(%ebx),%eax
80103c4f:	c7 40 40 00 02 00 00 	movl   $0x200,0x40(%eax)
  p->tf->esp = PGSIZE;
80103c56:	8b 43 18             	mov    0x18(%ebx),%eax
80103c59:	c7 40 44 00 10 00 00 	movl   $0x1000,0x44(%eax)
  p->tf->eip = 0; // beginning of initcode.S
80103c60:	8b 43 18             	mov    0x18(%ebx),%eax
80103c63:	c7 40 38 00 00 00 00 	movl   $0x0,0x38(%eax)
  safestrcpy(p->name, "initcode", sizeof(p->name));
80103c6a:	8d 43 6c             	lea    0x6c(%ebx),%eax
80103c6d:	6a 10                	push   $0x10
80103c6f:	68 c6 7b 10 80       	push   $0x80107bc6
80103c74:	50                   	push   %eax
80103c75:	e8 b6 0f 00 00       	call   80104c30 <safestrcpy>
  p->cwd = namei("/");
80103c7a:	c7 04 24 cf 7b 10 80 	movl   $0x80107bcf,(%esp)
80103c81:	e8 6a e5 ff ff       	call   801021f0 <namei>
80103c86:	89 43 68             	mov    %eax,0x68(%ebx)
  acquire(&ptable.lock);
80103c89:	c7 04 24 40 2d 11 80 	movl   $0x80112d40,(%esp)
80103c90:	e8 ab 0c 00 00       	call   80104940 <acquire>
  p->state = RUNNABLE;
80103c95:	c7 43 0c 03 00 00 00 	movl   $0x3,0xc(%ebx)
  release(&ptable.lock);
80103c9c:	c7 04 24 40 2d 11 80 	movl   $0x80112d40,(%esp)
80103ca3:	e8 38 0c 00 00       	call   801048e0 <release>
}
80103ca8:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103cab:	83 c4 10             	add    $0x10,%esp
80103cae:	c9                   	leave
80103caf:	c3                   	ret
    panic("userinit: out of memory?");
80103cb0:	83 ec 0c             	sub    $0xc,%esp
80103cb3:	68 ad 7b 10 80       	push   $0x80107bad
80103cb8:	e8 e3 c6 ff ff       	call   801003a0 <panic>
80103cbd:	8d 76 00             	lea    0x0(%esi),%esi

80103cc0 <growproc>:
{
80103cc0:	55                   	push   %ebp
80103cc1:	89 e5                	mov    %esp,%ebp
80103cc3:	53                   	push   %ebx
80103cc4:	83 ec 04             	sub    $0x4,%esp
  pushcli();
80103cc7:	e8 14 0b 00 00       	call   801047e0 <pushcli>
  c = mycpu();
80103ccc:	e8 3f fe ff ff       	call   80103b10 <mycpu>
  p = c->proc;
80103cd1:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
80103cd7:	e8 54 0b 00 00       	call   80104830 <popcli>
  if (n > 0)
80103cdc:	8b 55 08             	mov    0x8(%ebp),%edx
  sz = curproc->sz;
80103cdf:	8b 03                	mov    (%ebx),%eax
  if (n > 0)
80103ce1:	85 d2                	test   %edx,%edx
80103ce3:	7f 1b                	jg     80103d00 <growproc+0x40>
  else if (n < 0)
80103ce5:	75 39                	jne    80103d20 <growproc+0x60>
  switchuvm(curproc);
80103ce7:	83 ec 0c             	sub    $0xc,%esp
  curproc->sz = sz;
80103cea:	89 03                	mov    %eax,(%ebx)
  switchuvm(curproc);
80103cec:	53                   	push   %ebx
80103ced:	e8 9e 34 00 00       	call   80107190 <switchuvm>
  return 0;
80103cf2:	83 c4 10             	add    $0x10,%esp
80103cf5:	31 c0                	xor    %eax,%eax
}
80103cf7:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103cfa:	c9                   	leave
80103cfb:	c3                   	ret
80103cfc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    if ((sz = allocuvm(curproc->pgdir, sz, sz + n)) == 0)
80103d00:	8b 55 08             	mov    0x8(%ebp),%edx
80103d03:	83 ec 04             	sub    $0x4,%esp
80103d06:	01 c2                	add    %eax,%edx
80103d08:	52                   	push   %edx
80103d09:	50                   	push   %eax
80103d0a:	ff 73 04             	push   0x4(%ebx)
80103d0d:	e8 ee 36 00 00       	call   80107400 <allocuvm>
80103d12:	83 c4 10             	add    $0x10,%esp
80103d15:	85 c0                	test   %eax,%eax
80103d17:	75 ce                	jne    80103ce7 <growproc+0x27>
      return -1;
80103d19:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80103d1e:	eb d7                	jmp    80103cf7 <growproc+0x37>
    if ((sz = deallocuvm(curproc->pgdir, sz, sz + n)) == 0)
80103d20:	8b 55 08             	mov    0x8(%ebp),%edx
80103d23:	83 ec 04             	sub    $0x4,%esp
80103d26:	01 c2                	add    %eax,%edx
80103d28:	52                   	push   %edx
80103d29:	50                   	push   %eax
80103d2a:	ff 73 04             	push   0x4(%ebx)
80103d2d:	e8 0e 38 00 00       	call   80107540 <deallocuvm>
80103d32:	83 c4 10             	add    $0x10,%esp
80103d35:	85 c0                	test   %eax,%eax
80103d37:	75 ae                	jne    80103ce7 <growproc+0x27>
80103d39:	eb de                	jmp    80103d19 <growproc+0x59>
80103d3b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80103d40 <fork>:
{
80103d40:	55                   	push   %ebp
80103d41:	89 e5                	mov    %esp,%ebp
80103d43:	83 ec 28             	sub    $0x28,%esp
80103d46:	89 5d f4             	mov    %ebx,-0xc(%ebp)
  pushcli();
80103d49:	e8 92 0a 00 00       	call   801047e0 <pushcli>
  c = mycpu();
80103d4e:	e8 bd fd ff ff       	call   80103b10 <mycpu>
  p = c->proc;
80103d53:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
80103d59:	e8 d2 0a 00 00       	call   80104830 <popcli>
  if ((np = allocproc()) == 0)
80103d5e:	e8 5d fc ff ff       	call   801039c0 <allocproc>
80103d63:	85 c0                	test   %eax,%eax
80103d65:	0f 84 f6 00 00 00    	je     80103e61 <fork+0x121>
80103d6b:	89 75 f8             	mov    %esi,-0x8(%ebp)
  if ((np->pgdir = copyuvm(curproc->pgdir, curproc->sz)) == 0)
80103d6e:	83 ec 08             	sub    $0x8,%esp
80103d71:	89 c6                	mov    %eax,%esi
80103d73:	ff 33                	push   (%ebx)
80103d75:	ff 73 04             	push   0x4(%ebx)
80103d78:	e8 63 39 00 00       	call   801076e0 <copyuvm>
80103d7d:	83 c4 10             	add    $0x10,%esp
80103d80:	89 46 04             	mov    %eax,0x4(%esi)
80103d83:	85 c0                	test   %eax,%eax
80103d85:	0f 84 b7 00 00 00    	je     80103e42 <fork+0x102>
80103d8b:	89 7d fc             	mov    %edi,-0x4(%ebp)
  np->sz = curproc->sz;
80103d8e:	8b 03                	mov    (%ebx),%eax
  *np->tf = *curproc->tf;
80103d90:	89 5d e4             	mov    %ebx,-0x1c(%ebp)
80103d93:	8b 56 18             	mov    0x18(%esi),%edx
  np->sz = curproc->sz;
80103d96:	89 06                	mov    %eax,(%esi)
  *np->tf = *curproc->tf;
80103d98:	31 c0                	xor    %eax,%eax
  np->parent = curproc;
80103d9a:	89 5e 14             	mov    %ebx,0x14(%esi)
  *np->tf = *curproc->tf;
80103d9d:	8b 4b 18             	mov    0x18(%ebx),%ecx
80103da0:	8b 7c 01 04          	mov    0x4(%ecx,%eax,1),%edi
80103da4:	8b 1c 01             	mov    (%ecx,%eax,1),%ebx
80103da7:	89 7c 02 04          	mov    %edi,0x4(%edx,%eax,1)
80103dab:	89 1c 02             	mov    %ebx,(%edx,%eax,1)
80103dae:	83 c0 08             	add    $0x8,%eax
80103db1:	83 f8 48             	cmp    $0x48,%eax
80103db4:	72 ea                	jb     80103da0 <fork+0x60>
80103db6:	8b 0c 01             	mov    (%ecx,%eax,1),%ecx
80103db9:	8b 5d e4             	mov    -0x1c(%ebp),%ebx
  for (i = 0; i < NOFILE; i++)
80103dbc:	31 ff                	xor    %edi,%edi
  *np->tf = *curproc->tf;
80103dbe:	89 0c 02             	mov    %ecx,(%edx,%eax,1)
  np->tf->eax = 0;
80103dc1:	8b 46 18             	mov    0x18(%esi),%eax
80103dc4:	c7 40 1c 00 00 00 00 	movl   $0x0,0x1c(%eax)
  for (i = 0; i < NOFILE; i++)
80103dcb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    if (curproc->ofile[i])
80103dd0:	8b 44 bb 28          	mov    0x28(%ebx,%edi,4),%eax
80103dd4:	85 c0                	test   %eax,%eax
80103dd6:	74 10                	je     80103de8 <fork+0xa8>
      np->ofile[i] = filedup(curproc->ofile[i]);
80103dd8:	83 ec 0c             	sub    $0xc,%esp
80103ddb:	50                   	push   %eax
80103ddc:	e8 6f d1 ff ff       	call   80100f50 <filedup>
80103de1:	83 c4 10             	add    $0x10,%esp
80103de4:	89 44 be 28          	mov    %eax,0x28(%esi,%edi,4)
  for (i = 0; i < NOFILE; i++)
80103de8:	83 c7 01             	add    $0x1,%edi
80103deb:	83 ff 10             	cmp    $0x10,%edi
80103dee:	75 e0                	jne    80103dd0 <fork+0x90>
  np->cwd = idup(curproc->cwd);
80103df0:	83 ec 0c             	sub    $0xc,%esp
80103df3:	ff 73 68             	push   0x68(%ebx)
  safestrcpy(np->name, curproc->name, sizeof(curproc->name));
80103df6:	83 c3 6c             	add    $0x6c,%ebx
  np->cwd = idup(curproc->cwd);
80103df9:	e8 32 da ff ff       	call   80101830 <idup>
  safestrcpy(np->name, curproc->name, sizeof(curproc->name));
80103dfe:	83 c4 0c             	add    $0xc,%esp
  np->cwd = idup(curproc->cwd);
80103e01:	89 46 68             	mov    %eax,0x68(%esi)
  safestrcpy(np->name, curproc->name, sizeof(curproc->name));
80103e04:	8d 46 6c             	lea    0x6c(%esi),%eax
80103e07:	6a 10                	push   $0x10
80103e09:	53                   	push   %ebx
80103e0a:	50                   	push   %eax
80103e0b:	e8 20 0e 00 00       	call   80104c30 <safestrcpy>
  pid = np->pid;
80103e10:	8b 5e 10             	mov    0x10(%esi),%ebx
  acquire(&ptable.lock);
80103e13:	c7 04 24 40 2d 11 80 	movl   $0x80112d40,(%esp)
80103e1a:	e8 21 0b 00 00       	call   80104940 <acquire>
  np->state = RUNNABLE;
80103e1f:	c7 46 0c 03 00 00 00 	movl   $0x3,0xc(%esi)
  release(&ptable.lock);
80103e26:	c7 04 24 40 2d 11 80 	movl   $0x80112d40,(%esp)
80103e2d:	e8 ae 0a 00 00       	call   801048e0 <release>
  return pid;
80103e32:	8b 75 f8             	mov    -0x8(%ebp),%esi
80103e35:	8b 7d fc             	mov    -0x4(%ebp),%edi
80103e38:	83 c4 10             	add    $0x10,%esp
}
80103e3b:	89 d8                	mov    %ebx,%eax
80103e3d:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80103e40:	c9                   	leave
80103e41:	c3                   	ret
    kfree(np->kstack);
80103e42:	83 ec 0c             	sub    $0xc,%esp
80103e45:	ff 76 08             	push   0x8(%esi)
80103e48:	e8 f3 e7 ff ff       	call   80102640 <kfree>
    np->kstack = 0;
80103e4d:	c7 46 08 00 00 00 00 	movl   $0x0,0x8(%esi)
    return -1;
80103e54:	83 c4 10             	add    $0x10,%esp
    np->state = UNUSED;
80103e57:	c7 46 0c 00 00 00 00 	movl   $0x0,0xc(%esi)
    return -1;
80103e5e:	8b 75 f8             	mov    -0x8(%ebp),%esi
    return -1;
80103e61:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
80103e66:	eb d3                	jmp    80103e3b <fork+0xfb>
80103e68:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80103e6f:	00 

80103e70 <scheduler>:
{
80103e70:	55                   	push   %ebp
80103e71:	89 e5                	mov    %esp,%ebp
80103e73:	57                   	push   %edi
80103e74:	56                   	push   %esi
80103e75:	53                   	push   %ebx
80103e76:	83 ec 0c             	sub    $0xc,%esp
  struct cpu *c = mycpu();
80103e79:	e8 92 fc ff ff       	call   80103b10 <mycpu>
  c->proc = 0;
80103e7e:	c7 80 ac 00 00 00 00 	movl   $0x0,0xac(%eax)
80103e85:	00 00 00 
  struct cpu *c = mycpu();
80103e88:	89 c3                	mov    %eax,%ebx
  c->proc = 0;
80103e8a:	8d 70 04             	lea    0x4(%eax),%esi
80103e8d:	8d 76 00             	lea    0x0(%esi),%esi
  asm volatile("sti");
80103e90:	fb                   	sti
    acquire(&ptable.lock);
80103e91:	83 ec 0c             	sub    $0xc,%esp
    best = 0;
80103e94:	31 ff                	xor    %edi,%edi
    acquire(&ptable.lock);
80103e96:	68 40 2d 11 80       	push   $0x80112d40
80103e9b:	e8 a0 0a 00 00       	call   80104940 <acquire>
80103ea0:	83 c4 10             	add    $0x10,%esp
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80103ea3:	b8 74 2d 11 80       	mov    $0x80112d74,%eax
80103ea8:	eb 10                	jmp    80103eba <scheduler+0x4a>
80103eaa:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80103eb0:	83 e8 80             	sub    $0xffffff80,%eax
80103eb3:	3d 74 4d 11 80       	cmp    $0x80114d74,%eax
80103eb8:	74 56                	je     80103f10 <scheduler+0xa0>
      if(p->state == RUNNABLE){
80103eba:	83 78 0c 03          	cmpl   $0x3,0xc(%eax)
80103ebe:	75 f0                	jne    80103eb0 <scheduler+0x40>
        if(best == 0 || p->priority < best->priority)
80103ec0:	85 ff                	test   %edi,%edi
80103ec2:	0f 84 98 00 00 00    	je     80103f60 <scheduler+0xf0>
80103ec8:	8b 4f 7c             	mov    0x7c(%edi),%ecx
80103ecb:	39 48 7c             	cmp    %ecx,0x7c(%eax)
80103ece:	7c 1c                	jl     80103eec <scheduler+0x7c>
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80103ed0:	83 e8 80             	sub    $0xffffff80,%eax
80103ed3:	3d 74 4d 11 80       	cmp    $0x80114d74,%eax
80103ed8:	74 36                	je     80103f10 <scheduler+0xa0>
      if(p->state == RUNNABLE){
80103eda:	83 78 0c 03          	cmpl   $0x3,0xc(%eax)
80103ede:	75 d0                	jne    80103eb0 <scheduler+0x40>
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80103ee0:	89 c2                	mov    %eax,%edx
80103ee2:	89 d0                	mov    %edx,%eax
        if(best == 0 || p->priority < best->priority)
80103ee4:	8b 4f 7c             	mov    0x7c(%edi),%ecx
80103ee7:	39 48 7c             	cmp    %ecx,0x7c(%eax)
80103eea:	7d e4                	jge    80103ed0 <scheduler+0x60>
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80103eec:	8d 90 80 00 00 00    	lea    0x80(%eax),%edx
          best = p;
80103ef2:	89 c7                	mov    %eax,%edi
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80103ef4:	3d f4 4c 11 80       	cmp    $0x80114cf4,%eax
80103ef9:	74 19                	je     80103f14 <scheduler+0xa4>
      if(p->state == RUNNABLE){
80103efb:	83 7a 0c 03          	cmpl   $0x3,0xc(%edx)
80103eff:	74 e1                	je     80103ee2 <scheduler+0x72>
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80103f01:	89 d0                	mov    %edx,%eax
80103f03:	83 e8 80             	sub    $0xffffff80,%eax
80103f06:	3d 74 4d 11 80       	cmp    $0x80114d74,%eax
80103f0b:	75 ad                	jne    80103eba <scheduler+0x4a>
80103f0d:	8d 76 00             	lea    0x0(%esi),%esi
    if(best != 0){
80103f10:	85 ff                	test   %edi,%edi
80103f12:	74 33                	je     80103f47 <scheduler+0xd7>
      switchuvm(p);
80103f14:	83 ec 0c             	sub    $0xc,%esp
      c->proc = p;
80103f17:	89 bb ac 00 00 00    	mov    %edi,0xac(%ebx)
      switchuvm(p);
80103f1d:	57                   	push   %edi
80103f1e:	e8 6d 32 00 00       	call   80107190 <switchuvm>
      p->state = RUNNING;
80103f23:	c7 47 0c 04 00 00 00 	movl   $0x4,0xc(%edi)
      swtch(&c->scheduler, p->context);
80103f2a:	58                   	pop    %eax
80103f2b:	5a                   	pop    %edx
80103f2c:	ff 77 1c             	push   0x1c(%edi)
80103f2f:	56                   	push   %esi
80103f30:	e8 66 0d 00 00       	call   80104c9b <swtch>
      switchkvm();
80103f35:	e8 46 32 00 00       	call   80107180 <switchkvm>
      c->proc = 0;
80103f3a:	83 c4 10             	add    $0x10,%esp
80103f3d:	c7 83 ac 00 00 00 00 	movl   $0x0,0xac(%ebx)
80103f44:	00 00 00 
    release(&ptable.lock);
80103f47:	83 ec 0c             	sub    $0xc,%esp
80103f4a:	68 40 2d 11 80       	push   $0x80112d40
80103f4f:	e8 8c 09 00 00       	call   801048e0 <release>
    sti();
80103f54:	83 c4 10             	add    $0x10,%esp
80103f57:	e9 34 ff ff ff       	jmp    80103e90 <scheduler+0x20>
80103f5c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
          best = p;
80103f60:	89 c7                	mov    %eax,%edi
80103f62:	e9 49 ff ff ff       	jmp    80103eb0 <scheduler+0x40>
80103f67:	90                   	nop
80103f68:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80103f6f:	00 

80103f70 <sched>:
{
80103f70:	55                   	push   %ebp
80103f71:	89 e5                	mov    %esp,%ebp
80103f73:	56                   	push   %esi
80103f74:	53                   	push   %ebx
  pushcli();
80103f75:	e8 66 08 00 00       	call   801047e0 <pushcli>
  c = mycpu();
80103f7a:	e8 91 fb ff ff       	call   80103b10 <mycpu>
  p = c->proc;
80103f7f:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
80103f85:	e8 a6 08 00 00       	call   80104830 <popcli>
  if (!holding(&ptable.lock))
80103f8a:	83 ec 0c             	sub    $0xc,%esp
80103f8d:	68 40 2d 11 80       	push   $0x80112d40
80103f92:	e8 f9 08 00 00       	call   80104890 <holding>
80103f97:	83 c4 10             	add    $0x10,%esp
80103f9a:	85 c0                	test   %eax,%eax
80103f9c:	74 4f                	je     80103fed <sched+0x7d>
  if (mycpu()->ncli != 1)
80103f9e:	e8 6d fb ff ff       	call   80103b10 <mycpu>
80103fa3:	83 b8 a4 00 00 00 01 	cmpl   $0x1,0xa4(%eax)
80103faa:	75 68                	jne    80104014 <sched+0xa4>
  if (p->state == RUNNING)
80103fac:	83 7b 0c 04          	cmpl   $0x4,0xc(%ebx)
80103fb0:	74 55                	je     80104007 <sched+0x97>
  asm volatile("pushfl; popl %0" : "=r" (eflags));
80103fb2:	9c                   	pushf
80103fb3:	58                   	pop    %eax
  if (readeflags() & FL_IF)
80103fb4:	f6 c4 02             	test   $0x2,%ah
80103fb7:	75 41                	jne    80103ffa <sched+0x8a>
  intena = mycpu()->intena;
80103fb9:	e8 52 fb ff ff       	call   80103b10 <mycpu>
  swtch(&p->context, mycpu()->scheduler);
80103fbe:	83 c3 1c             	add    $0x1c,%ebx
  intena = mycpu()->intena;
80103fc1:	8b b0 a8 00 00 00    	mov    0xa8(%eax),%esi
  swtch(&p->context, mycpu()->scheduler);
80103fc7:	e8 44 fb ff ff       	call   80103b10 <mycpu>
80103fcc:	83 ec 08             	sub    $0x8,%esp
80103fcf:	ff 70 04             	push   0x4(%eax)
80103fd2:	53                   	push   %ebx
80103fd3:	e8 c3 0c 00 00       	call   80104c9b <swtch>
  mycpu()->intena = intena;
80103fd8:	e8 33 fb ff ff       	call   80103b10 <mycpu>
}
80103fdd:	83 c4 10             	add    $0x10,%esp
  mycpu()->intena = intena;
80103fe0:	89 b0 a8 00 00 00    	mov    %esi,0xa8(%eax)
}
80103fe6:	8d 65 f8             	lea    -0x8(%ebp),%esp
80103fe9:	5b                   	pop    %ebx
80103fea:	5e                   	pop    %esi
80103feb:	5d                   	pop    %ebp
80103fec:	c3                   	ret
    panic("sched ptable.lock");
80103fed:	83 ec 0c             	sub    $0xc,%esp
80103ff0:	68 d1 7b 10 80       	push   $0x80107bd1
80103ff5:	e8 a6 c3 ff ff       	call   801003a0 <panic>
    panic("sched interruptible");
80103ffa:	83 ec 0c             	sub    $0xc,%esp
80103ffd:	68 fd 7b 10 80       	push   $0x80107bfd
80104002:	e8 99 c3 ff ff       	call   801003a0 <panic>
    panic("sched running");
80104007:	83 ec 0c             	sub    $0xc,%esp
8010400a:	68 ef 7b 10 80       	push   $0x80107bef
8010400f:	e8 8c c3 ff ff       	call   801003a0 <panic>
    panic("sched locks");
80104014:	83 ec 0c             	sub    $0xc,%esp
80104017:	68 e3 7b 10 80       	push   $0x80107be3
8010401c:	e8 7f c3 ff ff       	call   801003a0 <panic>
80104021:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80104028:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010402f:	00 

80104030 <exit>:
{
80104030:	55                   	push   %ebp
80104031:	89 e5                	mov    %esp,%ebp
80104033:	83 ec 18             	sub    $0x18,%esp
80104036:	89 75 f8             	mov    %esi,-0x8(%ebp)
  pushcli();
80104039:	e8 a2 07 00 00       	call   801047e0 <pushcli>
  c = mycpu();
8010403e:	e8 cd fa ff ff       	call   80103b10 <mycpu>
  p = c->proc;
80104043:	8b b0 ac 00 00 00    	mov    0xac(%eax),%esi
  popcli();
80104049:	e8 e2 07 00 00       	call   80104830 <popcli>
  if (curproc == initproc)
8010404e:	39 35 74 4d 11 80    	cmp    %esi,0x80114d74
80104054:	89 5d f4             	mov    %ebx,-0xc(%ebp)
80104057:	89 7d fc             	mov    %edi,-0x4(%ebp)
8010405a:	0f 84 07 01 00 00    	je     80104167 <exit+0x137>
80104060:	8d 5e 28             	lea    0x28(%esi),%ebx
80104063:	8d 7e 68             	lea    0x68(%esi),%edi
80104066:	66 90                	xchg   %ax,%ax
80104068:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010406f:	00 
    if (curproc->ofile[fd])
80104070:	8b 03                	mov    (%ebx),%eax
80104072:	85 c0                	test   %eax,%eax
80104074:	74 12                	je     80104088 <exit+0x58>
      fileclose(curproc->ofile[fd]);
80104076:	83 ec 0c             	sub    $0xc,%esp
80104079:	50                   	push   %eax
8010407a:	e8 21 cf ff ff       	call   80100fa0 <fileclose>
      curproc->ofile[fd] = 0;
8010407f:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
80104085:	83 c4 10             	add    $0x10,%esp
  for (fd = 0; fd < NOFILE; fd++)
80104088:	83 c3 04             	add    $0x4,%ebx
8010408b:	39 df                	cmp    %ebx,%edi
8010408d:	75 e1                	jne    80104070 <exit+0x40>
  begin_op();
8010408f:	e8 ac ee ff ff       	call   80102f40 <begin_op>
  iput(curproc->cwd);
80104094:	83 ec 0c             	sub    $0xc,%esp
80104097:	ff 76 68             	push   0x68(%esi)
8010409a:	e8 f1 d8 ff ff       	call   80101990 <iput>
  end_op();
8010409f:	e8 0c ef ff ff       	call   80102fb0 <end_op>
  curproc->cwd = 0;
801040a4:	c7 46 68 00 00 00 00 	movl   $0x0,0x68(%esi)
  acquire(&ptable.lock);
801040ab:	c7 04 24 40 2d 11 80 	movl   $0x80112d40,(%esp)
801040b2:	e8 89 08 00 00       	call   80104940 <acquire>
  wakeup1(curproc->parent);
801040b7:	8b 56 14             	mov    0x14(%esi),%edx
801040ba:	83 c4 10             	add    $0x10,%esp
static void
wakeup1(void *chan)
{
  struct proc *p;

  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
801040bd:	b8 74 2d 11 80       	mov    $0x80112d74,%eax
801040c2:	eb 16                	jmp    801040da <exit+0xaa>
801040c4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
801040c8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801040cf:	00 
801040d0:	83 e8 80             	sub    $0xffffff80,%eax
801040d3:	3d 74 4d 11 80       	cmp    $0x80114d74,%eax
801040d8:	74 1c                	je     801040f6 <exit+0xc6>
    if (p->state == SLEEPING && p->chan == chan)
801040da:	83 78 0c 02          	cmpl   $0x2,0xc(%eax)
801040de:	75 f0                	jne    801040d0 <exit+0xa0>
801040e0:	3b 50 20             	cmp    0x20(%eax),%edx
801040e3:	75 eb                	jne    801040d0 <exit+0xa0>
      p->state = RUNNABLE;
801040e5:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)
  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
801040ec:	83 e8 80             	sub    $0xffffff80,%eax
801040ef:	3d 74 4d 11 80       	cmp    $0x80114d74,%eax
801040f4:	75 e4                	jne    801040da <exit+0xaa>
      p->parent = initproc;
801040f6:	8b 0d 74 4d 11 80    	mov    0x80114d74,%ecx
  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
801040fc:	ba 74 2d 11 80       	mov    $0x80112d74,%edx
80104101:	eb 18                	jmp    8010411b <exit+0xeb>
80104103:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80104108:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010410f:	00 
80104110:	83 ea 80             	sub    $0xffffff80,%edx
80104113:	81 fa 74 4d 11 80    	cmp    $0x80114d74,%edx
80104119:	74 33                	je     8010414e <exit+0x11e>
    if (p->parent == curproc)
8010411b:	39 72 14             	cmp    %esi,0x14(%edx)
8010411e:	75 f0                	jne    80104110 <exit+0xe0>
      p->parent = initproc;
80104120:	89 4a 14             	mov    %ecx,0x14(%edx)
      if (p->state == ZOMBIE)
80104123:	83 7a 0c 05          	cmpl   $0x5,0xc(%edx)
80104127:	75 e7                	jne    80104110 <exit+0xe0>
  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
80104129:	b8 74 2d 11 80       	mov    $0x80112d74,%eax
8010412e:	eb 0a                	jmp    8010413a <exit+0x10a>
80104130:	83 e8 80             	sub    $0xffffff80,%eax
80104133:	3d 74 4d 11 80       	cmp    $0x80114d74,%eax
80104138:	74 d6                	je     80104110 <exit+0xe0>
    if (p->state == SLEEPING && p->chan == chan)
8010413a:	83 78 0c 02          	cmpl   $0x2,0xc(%eax)
8010413e:	75 f0                	jne    80104130 <exit+0x100>
80104140:	3b 48 20             	cmp    0x20(%eax),%ecx
80104143:	75 eb                	jne    80104130 <exit+0x100>
      p->state = RUNNABLE;
80104145:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)
8010414c:	eb e2                	jmp    80104130 <exit+0x100>
  curproc->state = ZOMBIE;
8010414e:	c7 46 0c 05 00 00 00 	movl   $0x5,0xc(%esi)
  sched();
80104155:	e8 16 fe ff ff       	call   80103f70 <sched>
  panic("zombie exit");
8010415a:	83 ec 0c             	sub    $0xc,%esp
8010415d:	68 1e 7c 10 80       	push   $0x80107c1e
80104162:	e8 39 c2 ff ff       	call   801003a0 <panic>
    panic("init exiting");
80104167:	83 ec 0c             	sub    $0xc,%esp
8010416a:	68 11 7c 10 80       	push   $0x80107c11
8010416f:	e8 2c c2 ff ff       	call   801003a0 <panic>
80104174:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80104178:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010417f:	00 

80104180 <wait>:
{
80104180:	55                   	push   %ebp
80104181:	89 e5                	mov    %esp,%ebp
80104183:	56                   	push   %esi
80104184:	53                   	push   %ebx
  pushcli();
80104185:	e8 56 06 00 00       	call   801047e0 <pushcli>
  c = mycpu();
8010418a:	e8 81 f9 ff ff       	call   80103b10 <mycpu>
  p = c->proc;
8010418f:	8b b0 ac 00 00 00    	mov    0xac(%eax),%esi
  popcli();
80104195:	e8 96 06 00 00       	call   80104830 <popcli>
  acquire(&ptable.lock);
8010419a:	83 ec 0c             	sub    $0xc,%esp
8010419d:	68 40 2d 11 80       	push   $0x80112d40
801041a2:	e8 99 07 00 00       	call   80104940 <acquire>
801041a7:	83 c4 10             	add    $0x10,%esp
    havekids = 0;
801041aa:	31 c0                	xor    %eax,%eax
    for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
801041ac:	bb 74 2d 11 80       	mov    $0x80112d74,%ebx
801041b1:	eb 18                	jmp    801041cb <wait+0x4b>
801041b3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
801041b8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801041bf:	00 
801041c0:	83 eb 80             	sub    $0xffffff80,%ebx
801041c3:	81 fb 74 4d 11 80    	cmp    $0x80114d74,%ebx
801041c9:	74 1b                	je     801041e6 <wait+0x66>
      if (p->parent != curproc)
801041cb:	39 73 14             	cmp    %esi,0x14(%ebx)
801041ce:	75 f0                	jne    801041c0 <wait+0x40>
      if (p->state == ZOMBIE)
801041d0:	83 7b 0c 05          	cmpl   $0x5,0xc(%ebx)
801041d4:	74 62                	je     80104238 <wait+0xb8>
    for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
801041d6:	83 eb 80             	sub    $0xffffff80,%ebx
      havekids = 1;
801041d9:	b8 01 00 00 00       	mov    $0x1,%eax
    for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
801041de:	81 fb 74 4d 11 80    	cmp    $0x80114d74,%ebx
801041e4:	75 e5                	jne    801041cb <wait+0x4b>
    if (!havekids || curproc->killed)
801041e6:	85 c0                	test   %eax,%eax
801041e8:	0f 84 a0 00 00 00    	je     8010428e <wait+0x10e>
801041ee:	8b 46 24             	mov    0x24(%esi),%eax
801041f1:	85 c0                	test   %eax,%eax
801041f3:	0f 85 95 00 00 00    	jne    8010428e <wait+0x10e>
  pushcli();
801041f9:	e8 e2 05 00 00       	call   801047e0 <pushcli>
  c = mycpu();
801041fe:	e8 0d f9 ff ff       	call   80103b10 <mycpu>
  p = c->proc;
80104203:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
80104209:	e8 22 06 00 00       	call   80104830 <popcli>
  if (p == 0)
8010420e:	85 db                	test   %ebx,%ebx
80104210:	0f 84 8f 00 00 00    	je     801042a5 <wait+0x125>
  p->chan = chan;
80104216:	89 73 20             	mov    %esi,0x20(%ebx)
  p->state = SLEEPING;
80104219:	c7 43 0c 02 00 00 00 	movl   $0x2,0xc(%ebx)
  sched();
80104220:	e8 4b fd ff ff       	call   80103f70 <sched>
  p->chan = 0;
80104225:	c7 43 20 00 00 00 00 	movl   $0x0,0x20(%ebx)
    havekids = 0;
8010422c:	e9 79 ff ff ff       	jmp    801041aa <wait+0x2a>
80104231:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
        kfree(p->kstack);
80104238:	83 ec 0c             	sub    $0xc,%esp
        pid = p->pid;
8010423b:	8b 73 10             	mov    0x10(%ebx),%esi
        kfree(p->kstack);
8010423e:	ff 73 08             	push   0x8(%ebx)
80104241:	e8 fa e3 ff ff       	call   80102640 <kfree>
        p->kstack = 0;
80104246:	c7 43 08 00 00 00 00 	movl   $0x0,0x8(%ebx)
        freevm(p->pgdir);
8010424d:	5a                   	pop    %edx
8010424e:	ff 73 04             	push   0x4(%ebx)
80104251:	e8 1a 33 00 00       	call   80107570 <freevm>
        p->pid = 0;
80104256:	c7 43 10 00 00 00 00 	movl   $0x0,0x10(%ebx)
        p->parent = 0;
8010425d:	c7 43 14 00 00 00 00 	movl   $0x0,0x14(%ebx)
        p->name[0] = 0;
80104264:	c6 43 6c 00          	movb   $0x0,0x6c(%ebx)
        p->killed = 0;
80104268:	c7 43 24 00 00 00 00 	movl   $0x0,0x24(%ebx)
        p->state = UNUSED;
8010426f:	c7 43 0c 00 00 00 00 	movl   $0x0,0xc(%ebx)
        release(&ptable.lock);
80104276:	c7 04 24 40 2d 11 80 	movl   $0x80112d40,(%esp)
8010427d:	e8 5e 06 00 00       	call   801048e0 <release>
        return pid;
80104282:	83 c4 10             	add    $0x10,%esp
}
80104285:	8d 65 f8             	lea    -0x8(%ebp),%esp
80104288:	89 f0                	mov    %esi,%eax
8010428a:	5b                   	pop    %ebx
8010428b:	5e                   	pop    %esi
8010428c:	5d                   	pop    %ebp
8010428d:	c3                   	ret
      release(&ptable.lock);
8010428e:	83 ec 0c             	sub    $0xc,%esp
      return -1;
80104291:	be ff ff ff ff       	mov    $0xffffffff,%esi
      release(&ptable.lock);
80104296:	68 40 2d 11 80       	push   $0x80112d40
8010429b:	e8 40 06 00 00       	call   801048e0 <release>
      return -1;
801042a0:	83 c4 10             	add    $0x10,%esp
801042a3:	eb e0                	jmp    80104285 <wait+0x105>
    panic("sleep");
801042a5:	83 ec 0c             	sub    $0xc,%esp
801042a8:	68 2a 7c 10 80       	push   $0x80107c2a
801042ad:	e8 ee c0 ff ff       	call   801003a0 <panic>
801042b2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
801042b8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801042bf:	00 

801042c0 <yield>:
{
801042c0:	55                   	push   %ebp
801042c1:	89 e5                	mov    %esp,%ebp
801042c3:	53                   	push   %ebx
801042c4:	83 ec 10             	sub    $0x10,%esp
  acquire(&ptable.lock); // DOC: yieldlock
801042c7:	68 40 2d 11 80       	push   $0x80112d40
801042cc:	e8 6f 06 00 00       	call   80104940 <acquire>
  pushcli();
801042d1:	e8 0a 05 00 00       	call   801047e0 <pushcli>
  c = mycpu();
801042d6:	e8 35 f8 ff ff       	call   80103b10 <mycpu>
  p = c->proc;
801042db:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
801042e1:	e8 4a 05 00 00       	call   80104830 <popcli>
  myproc()->state = RUNNABLE;
801042e6:	c7 43 0c 03 00 00 00 	movl   $0x3,0xc(%ebx)
  sched();
801042ed:	e8 7e fc ff ff       	call   80103f70 <sched>
  release(&ptable.lock);
801042f2:	c7 04 24 40 2d 11 80 	movl   $0x80112d40,(%esp)
801042f9:	e8 e2 05 00 00       	call   801048e0 <release>
}
801042fe:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104301:	83 c4 10             	add    $0x10,%esp
80104304:	c9                   	leave
80104305:	c3                   	ret
80104306:	66 90                	xchg   %ax,%ax
80104308:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010430f:	00 

80104310 <sleep>:
{
80104310:	55                   	push   %ebp
80104311:	89 e5                	mov    %esp,%ebp
80104313:	57                   	push   %edi
80104314:	56                   	push   %esi
80104315:	53                   	push   %ebx
80104316:	83 ec 0c             	sub    $0xc,%esp
80104319:	8b 7d 08             	mov    0x8(%ebp),%edi
8010431c:	8b 75 0c             	mov    0xc(%ebp),%esi
  pushcli();
8010431f:	e8 bc 04 00 00       	call   801047e0 <pushcli>
  c = mycpu();
80104324:	e8 e7 f7 ff ff       	call   80103b10 <mycpu>
  p = c->proc;
80104329:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
8010432f:	e8 fc 04 00 00       	call   80104830 <popcli>
  if (p == 0)
80104334:	85 db                	test   %ebx,%ebx
80104336:	0f 84 87 00 00 00    	je     801043c3 <sleep+0xb3>
  if (lk == 0)
8010433c:	85 f6                	test   %esi,%esi
8010433e:	74 76                	je     801043b6 <sleep+0xa6>
  if (lk != &ptable.lock)
80104340:	81 fe 40 2d 11 80    	cmp    $0x80112d40,%esi
80104346:	74 50                	je     80104398 <sleep+0x88>
    acquire(&ptable.lock); // DOC: sleeplock1
80104348:	83 ec 0c             	sub    $0xc,%esp
8010434b:	68 40 2d 11 80       	push   $0x80112d40
80104350:	e8 eb 05 00 00       	call   80104940 <acquire>
    release(lk);
80104355:	89 34 24             	mov    %esi,(%esp)
80104358:	e8 83 05 00 00       	call   801048e0 <release>
  p->chan = chan;
8010435d:	89 7b 20             	mov    %edi,0x20(%ebx)
  p->state = SLEEPING;
80104360:	c7 43 0c 02 00 00 00 	movl   $0x2,0xc(%ebx)
  sched();
80104367:	e8 04 fc ff ff       	call   80103f70 <sched>
  p->chan = 0;
8010436c:	c7 43 20 00 00 00 00 	movl   $0x0,0x20(%ebx)
    release(&ptable.lock);
80104373:	c7 04 24 40 2d 11 80 	movl   $0x80112d40,(%esp)
8010437a:	e8 61 05 00 00       	call   801048e0 <release>
    acquire(lk);
8010437f:	83 c4 10             	add    $0x10,%esp
80104382:	89 75 08             	mov    %esi,0x8(%ebp)
}
80104385:	8d 65 f4             	lea    -0xc(%ebp),%esp
80104388:	5b                   	pop    %ebx
80104389:	5e                   	pop    %esi
8010438a:	5f                   	pop    %edi
8010438b:	5d                   	pop    %ebp
    acquire(lk);
8010438c:	e9 af 05 00 00       	jmp    80104940 <acquire>
80104391:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  p->chan = chan;
80104398:	89 7b 20             	mov    %edi,0x20(%ebx)
  p->state = SLEEPING;
8010439b:	c7 43 0c 02 00 00 00 	movl   $0x2,0xc(%ebx)
  sched();
801043a2:	e8 c9 fb ff ff       	call   80103f70 <sched>
  p->chan = 0;
801043a7:	c7 43 20 00 00 00 00 	movl   $0x0,0x20(%ebx)
}
801043ae:	8d 65 f4             	lea    -0xc(%ebp),%esp
801043b1:	5b                   	pop    %ebx
801043b2:	5e                   	pop    %esi
801043b3:	5f                   	pop    %edi
801043b4:	5d                   	pop    %ebp
801043b5:	c3                   	ret
    panic("sleep without lk");
801043b6:	83 ec 0c             	sub    $0xc,%esp
801043b9:	68 30 7c 10 80       	push   $0x80107c30
801043be:	e8 dd bf ff ff       	call   801003a0 <panic>
    panic("sleep");
801043c3:	83 ec 0c             	sub    $0xc,%esp
801043c6:	68 2a 7c 10 80       	push   $0x80107c2a
801043cb:	e8 d0 bf ff ff       	call   801003a0 <panic>

801043d0 <wakeup>:
}

// Wake up all processes sleeping on chan.
void wakeup(void *chan)
{
801043d0:	55                   	push   %ebp
801043d1:	89 e5                	mov    %esp,%ebp
801043d3:	53                   	push   %ebx
801043d4:	83 ec 10             	sub    $0x10,%esp
801043d7:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&ptable.lock);
801043da:	68 40 2d 11 80       	push   $0x80112d40
801043df:	e8 5c 05 00 00       	call   80104940 <acquire>
801043e4:	83 c4 10             	add    $0x10,%esp
  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
801043e7:	b8 74 2d 11 80       	mov    $0x80112d74,%eax
801043ec:	eb 0c                	jmp    801043fa <wakeup+0x2a>
801043ee:	66 90                	xchg   %ax,%ax
801043f0:	83 e8 80             	sub    $0xffffff80,%eax
801043f3:	3d 74 4d 11 80       	cmp    $0x80114d74,%eax
801043f8:	74 1c                	je     80104416 <wakeup+0x46>
    if (p->state == SLEEPING && p->chan == chan)
801043fa:	83 78 0c 02          	cmpl   $0x2,0xc(%eax)
801043fe:	75 f0                	jne    801043f0 <wakeup+0x20>
80104400:	3b 58 20             	cmp    0x20(%eax),%ebx
80104403:	75 eb                	jne    801043f0 <wakeup+0x20>
      p->state = RUNNABLE;
80104405:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)
  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
8010440c:	83 e8 80             	sub    $0xffffff80,%eax
8010440f:	3d 74 4d 11 80       	cmp    $0x80114d74,%eax
80104414:	75 e4                	jne    801043fa <wakeup+0x2a>
  wakeup1(chan);
  release(&ptable.lock);
80104416:	c7 45 08 40 2d 11 80 	movl   $0x80112d40,0x8(%ebp)
}
8010441d:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104420:	c9                   	leave
  release(&ptable.lock);
80104421:	e9 ba 04 00 00       	jmp    801048e0 <release>
80104426:	66 90                	xchg   %ax,%ax
80104428:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010442f:	00 

80104430 <kill>:

// Kill the process with the given pid.
// Process won't exit until it returns
// to user space (see trap in trap.c).
int kill(int pid)
{
80104430:	55                   	push   %ebp
80104431:	89 e5                	mov    %esp,%ebp
80104433:	53                   	push   %ebx
80104434:	83 ec 10             	sub    $0x10,%esp
80104437:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct proc *p;

  acquire(&ptable.lock);
8010443a:	68 40 2d 11 80       	push   $0x80112d40
8010443f:	e8 fc 04 00 00       	call   80104940 <acquire>
80104444:	83 c4 10             	add    $0x10,%esp
  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
80104447:	b8 74 2d 11 80       	mov    $0x80112d74,%eax
8010444c:	eb 0c                	jmp    8010445a <kill+0x2a>
8010444e:	66 90                	xchg   %ax,%ax
80104450:	83 e8 80             	sub    $0xffffff80,%eax
80104453:	3d 74 4d 11 80       	cmp    $0x80114d74,%eax
80104458:	74 36                	je     80104490 <kill+0x60>
  {
    if (p->pid == pid)
8010445a:	39 58 10             	cmp    %ebx,0x10(%eax)
8010445d:	75 f1                	jne    80104450 <kill+0x20>
    {
      p->killed = 1;
8010445f:	c7 40 24 01 00 00 00 	movl   $0x1,0x24(%eax)
      // Wake process from sleep if necessary.
      if (p->state == SLEEPING)
80104466:	83 78 0c 02          	cmpl   $0x2,0xc(%eax)
8010446a:	75 07                	jne    80104473 <kill+0x43>
        p->state = RUNNABLE;
8010446c:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)
      release(&ptable.lock);
80104473:	83 ec 0c             	sub    $0xc,%esp
80104476:	68 40 2d 11 80       	push   $0x80112d40
8010447b:	e8 60 04 00 00       	call   801048e0 <release>
      return 0;
    }
  }
  release(&ptable.lock);
  return -1;
}
80104480:	8b 5d fc             	mov    -0x4(%ebp),%ebx
      return 0;
80104483:	83 c4 10             	add    $0x10,%esp
80104486:	31 c0                	xor    %eax,%eax
}
80104488:	c9                   	leave
80104489:	c3                   	ret
8010448a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  release(&ptable.lock);
80104490:	83 ec 0c             	sub    $0xc,%esp
80104493:	68 40 2d 11 80       	push   $0x80112d40
80104498:	e8 43 04 00 00       	call   801048e0 <release>
}
8010449d:	8b 5d fc             	mov    -0x4(%ebp),%ebx
  return -1;
801044a0:	83 c4 10             	add    $0x10,%esp
801044a3:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
801044a8:	c9                   	leave
801044a9:	c3                   	ret
801044aa:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

801044b0 <procdump>:
// PAGEBREAK: 36
//  Print a process listing to console.  For debugging.
//  Runs when user types ^P on console.
//  No lock to avoid wedging a stuck machine further.
void procdump(void)
{
801044b0:	55                   	push   %ebp
801044b1:	89 e5                	mov    %esp,%ebp
801044b3:	57                   	push   %edi
801044b4:	56                   	push   %esi
    else
      state = "???";
    cprintf("%d %s %s", p->pid, state, p->name);
    if (p->state == SLEEPING)
    {
      getcallerpcs((uint *)p->context->ebp + 2, pc);
801044b5:	8d 75 c0             	lea    -0x40(%ebp),%esi
{
801044b8:	53                   	push   %ebx
801044b9:	bb e0 2d 11 80       	mov    $0x80112de0,%ebx
801044be:	83 ec 3c             	sub    $0x3c,%esp
801044c1:	eb 20                	jmp    801044e3 <procdump+0x33>
801044c3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
      for (i = 0; i < 10 && pc[i] != 0; i++)
        cprintf(" %p", pc[i]);
    }
    cprintf("\n");
801044c8:	83 ec 0c             	sub    $0xc,%esp
801044cb:	68 ef 7d 10 80       	push   $0x80107def
801044d0:	e8 1b c2 ff ff       	call   801006f0 <cprintf>
801044d5:	83 c4 10             	add    $0x10,%esp
  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
801044d8:	83 eb 80             	sub    $0xffffff80,%ebx
801044db:	81 fb e0 4d 11 80    	cmp    $0x80114de0,%ebx
801044e1:	74 7d                	je     80104560 <procdump+0xb0>
    if (p->state == UNUSED)
801044e3:	8b 43 a0             	mov    -0x60(%ebx),%eax
801044e6:	85 c0                	test   %eax,%eax
801044e8:	74 ee                	je     801044d8 <procdump+0x28>
      state = "???";
801044ea:	ba 41 7c 10 80       	mov    $0x80107c41,%edx
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
801044ef:	83 f8 05             	cmp    $0x5,%eax
801044f2:	77 07                	ja     801044fb <procdump+0x4b>
801044f4:	8b 14 85 00 82 10 80 	mov    -0x7fef7e00(,%eax,4),%edx
    cprintf("%d %s %s", p->pid, state, p->name);
801044fb:	53                   	push   %ebx
801044fc:	52                   	push   %edx
801044fd:	ff 73 a4             	push   -0x5c(%ebx)
80104500:	68 45 7c 10 80       	push   $0x80107c45
80104505:	e8 e6 c1 ff ff       	call   801006f0 <cprintf>
    if (p->state == SLEEPING)
8010450a:	83 c4 10             	add    $0x10,%esp
8010450d:	83 7b a0 02          	cmpl   $0x2,-0x60(%ebx)
80104511:	75 b5                	jne    801044c8 <procdump+0x18>
      getcallerpcs((uint *)p->context->ebp + 2, pc);
80104513:	83 ec 08             	sub    $0x8,%esp
80104516:	89 f7                	mov    %esi,%edi
80104518:	56                   	push   %esi
80104519:	8b 43 b0             	mov    -0x50(%ebx),%eax
8010451c:	8b 40 0c             	mov    0xc(%eax),%eax
8010451f:	83 c0 08             	add    $0x8,%eax
80104522:	50                   	push   %eax
80104523:	e8 18 02 00 00       	call   80104740 <getcallerpcs>
      for (i = 0; i < 10 && pc[i] != 0; i++)
80104528:	83 c4 10             	add    $0x10,%esp
8010452b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80104530:	8b 07                	mov    (%edi),%eax
80104532:	85 c0                	test   %eax,%eax
80104534:	74 92                	je     801044c8 <procdump+0x18>
        cprintf(" %p", pc[i]);
80104536:	83 ec 08             	sub    $0x8,%esp
      for (i = 0; i < 10 && pc[i] != 0; i++)
80104539:	83 c7 04             	add    $0x4,%edi
        cprintf(" %p", pc[i]);
8010453c:	50                   	push   %eax
8010453d:	68 81 79 10 80       	push   $0x80107981
80104542:	e8 a9 c1 ff ff       	call   801006f0 <cprintf>
      for (i = 0; i < 10 && pc[i] != 0; i++)
80104547:	8d 45 e8             	lea    -0x18(%ebp),%eax
8010454a:	83 c4 10             	add    $0x10,%esp
8010454d:	39 c7                	cmp    %eax,%edi
8010454f:	75 df                	jne    80104530 <procdump+0x80>
80104551:	e9 72 ff ff ff       	jmp    801044c8 <procdump+0x18>
80104556:	66 90                	xchg   %ax,%ax
80104558:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010455f:	00 
  }
}
80104560:	8d 65 f4             	lea    -0xc(%ebp),%esp
80104563:	5b                   	pop    %ebx
80104564:	5e                   	pop    %esi
80104565:	5f                   	pop    %edi
80104566:	5d                   	pop    %ebp
80104567:	c3                   	ret
80104568:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010456f:	00 

80104570 <set_priority>:
// for priority scheduling
int
set_priority(int pid, int priority)
{
80104570:	55                   	push   %ebp
80104571:	89 e5                	mov    %esp,%ebp
80104573:	53                   	push   %ebx
80104574:	83 ec 04             	sub    $0x4,%esp
  struct proc *p;
  int old_priority = -1;

  if(priority < 1 || priority > 20)
80104577:	8b 45 0c             	mov    0xc(%ebp),%eax
{
8010457a:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(priority < 1 || priority > 20)
8010457d:	83 e8 01             	sub    $0x1,%eax
80104580:	83 f8 13             	cmp    $0x13,%eax
80104583:	77 62                	ja     801045e7 <set_priority+0x77>
    return -1;

  acquire(&ptable.lock);
80104585:	83 ec 0c             	sub    $0xc,%esp
80104588:	68 40 2d 11 80       	push   $0x80112d40
8010458d:	e8 ae 03 00 00       	call   80104940 <acquire>
80104592:	83 c4 10             	add    $0x10,%esp

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80104595:	b8 74 2d 11 80       	mov    $0x80112d74,%eax
8010459a:	eb 0e                	jmp    801045aa <set_priority+0x3a>
8010459c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
801045a0:	83 e8 80             	sub    $0xffffff80,%eax
801045a3:	3d 74 4d 11 80       	cmp    $0x80114d74,%eax
801045a8:	74 36                	je     801045e0 <set_priority+0x70>
    if(p->pid == pid && p->state != UNUSED){
801045aa:	39 58 10             	cmp    %ebx,0x10(%eax)
801045ad:	75 f1                	jne    801045a0 <set_priority+0x30>
801045af:	8b 50 0c             	mov    0xc(%eax),%edx
801045b2:	85 d2                	test   %edx,%edx
801045b4:	74 ea                	je     801045a0 <set_priority+0x30>
      old_priority = p->priority;
      p->priority = priority;
801045b6:	8b 55 0c             	mov    0xc(%ebp),%edx
      old_priority = p->priority;
801045b9:	8b 58 7c             	mov    0x7c(%eax),%ebx
      p->priority = priority;
801045bc:	89 50 7c             	mov    %edx,0x7c(%eax)
      break;
    }
  }

  release(&ptable.lock);
801045bf:	83 ec 0c             	sub    $0xc,%esp
801045c2:	68 40 2d 11 80       	push   $0x80112d40
801045c7:	e8 14 03 00 00       	call   801048e0 <release>

  return old_priority;
801045cc:	83 c4 10             	add    $0x10,%esp
801045cf:	89 d8                	mov    %ebx,%eax
801045d1:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801045d4:	c9                   	leave
801045d5:	c3                   	ret
801045d6:	66 90                	xchg   %ax,%ax
801045d8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801045df:	00 
  int old_priority = -1;
801045e0:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
801045e5:	eb d8                	jmp    801045bf <set_priority+0x4f>
    return -1;
801045e7:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
801045ec:	eb e1                	jmp    801045cf <set_priority+0x5f>
801045ee:	66 90                	xchg   %ax,%ax

801045f0 <initsleeplock>:
#include "spinlock.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
801045f0:	55                   	push   %ebp
801045f1:	89 e5                	mov    %esp,%ebp
801045f3:	53                   	push   %ebx
801045f4:	83 ec 0c             	sub    $0xc,%esp
801045f7:	8b 5d 08             	mov    0x8(%ebp),%ebx
  initlock(&lk->lk, "sleep lock");
801045fa:	68 78 7c 10 80       	push   $0x80107c78
801045ff:	8d 43 04             	lea    0x4(%ebx),%eax
80104602:	50                   	push   %eax
80104603:	e8 18 01 00 00       	call   80104720 <initlock>
  lk->name = name;
80104608:	8b 45 0c             	mov    0xc(%ebp),%eax
  lk->locked = 0;
8010460b:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
  lk->pid = 0;
}
80104611:	83 c4 10             	add    $0x10,%esp
  lk->pid = 0;
80104614:	c7 43 3c 00 00 00 00 	movl   $0x0,0x3c(%ebx)
  lk->name = name;
8010461b:	89 43 38             	mov    %eax,0x38(%ebx)
}
8010461e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104621:	c9                   	leave
80104622:	c3                   	ret
80104623:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80104628:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010462f:	00 

80104630 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
80104630:	55                   	push   %ebp
80104631:	89 e5                	mov    %esp,%ebp
80104633:	56                   	push   %esi
80104634:	53                   	push   %ebx
80104635:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&lk->lk);
80104638:	8d 73 04             	lea    0x4(%ebx),%esi
8010463b:	83 ec 0c             	sub    $0xc,%esp
8010463e:	56                   	push   %esi
8010463f:	e8 fc 02 00 00       	call   80104940 <acquire>
  while (lk->locked) {
80104644:	8b 13                	mov    (%ebx),%edx
80104646:	83 c4 10             	add    $0x10,%esp
80104649:	85 d2                	test   %edx,%edx
8010464b:	74 16                	je     80104663 <acquiresleep+0x33>
8010464d:	8d 76 00             	lea    0x0(%esi),%esi
    sleep(lk, &lk->lk);
80104650:	83 ec 08             	sub    $0x8,%esp
80104653:	56                   	push   %esi
80104654:	53                   	push   %ebx
80104655:	e8 b6 fc ff ff       	call   80104310 <sleep>
  while (lk->locked) {
8010465a:	8b 03                	mov    (%ebx),%eax
8010465c:	83 c4 10             	add    $0x10,%esp
8010465f:	85 c0                	test   %eax,%eax
80104661:	75 ed                	jne    80104650 <acquiresleep+0x20>
  }
  lk->locked = 1;
80104663:	c7 03 01 00 00 00    	movl   $0x1,(%ebx)
  lk->pid = myproc()->pid;
80104669:	e8 32 f5 ff ff       	call   80103ba0 <myproc>
8010466e:	8b 40 10             	mov    0x10(%eax),%eax
80104671:	89 43 3c             	mov    %eax,0x3c(%ebx)
  release(&lk->lk);
80104674:	89 75 08             	mov    %esi,0x8(%ebp)
}
80104677:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010467a:	5b                   	pop    %ebx
8010467b:	5e                   	pop    %esi
8010467c:	5d                   	pop    %ebp
  release(&lk->lk);
8010467d:	e9 5e 02 00 00       	jmp    801048e0 <release>
80104682:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80104688:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010468f:	00 

80104690 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
80104690:	55                   	push   %ebp
80104691:	89 e5                	mov    %esp,%ebp
80104693:	56                   	push   %esi
80104694:	53                   	push   %ebx
80104695:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&lk->lk);
80104698:	8d 73 04             	lea    0x4(%ebx),%esi
8010469b:	83 ec 0c             	sub    $0xc,%esp
8010469e:	56                   	push   %esi
8010469f:	e8 9c 02 00 00       	call   80104940 <acquire>
  lk->locked = 0;
801046a4:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
  lk->pid = 0;
801046aa:	c7 43 3c 00 00 00 00 	movl   $0x0,0x3c(%ebx)
  wakeup(lk);
801046b1:	89 1c 24             	mov    %ebx,(%esp)
801046b4:	e8 17 fd ff ff       	call   801043d0 <wakeup>
  release(&lk->lk);
801046b9:	83 c4 10             	add    $0x10,%esp
801046bc:	89 75 08             	mov    %esi,0x8(%ebp)
}
801046bf:	8d 65 f8             	lea    -0x8(%ebp),%esp
801046c2:	5b                   	pop    %ebx
801046c3:	5e                   	pop    %esi
801046c4:	5d                   	pop    %ebp
  release(&lk->lk);
801046c5:	e9 16 02 00 00       	jmp    801048e0 <release>
801046ca:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

801046d0 <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
801046d0:	55                   	push   %ebp
801046d1:	89 e5                	mov    %esp,%ebp
801046d3:	57                   	push   %edi
801046d4:	31 ff                	xor    %edi,%edi
801046d6:	56                   	push   %esi
801046d7:	53                   	push   %ebx
801046d8:	83 ec 18             	sub    $0x18,%esp
801046db:	8b 5d 08             	mov    0x8(%ebp),%ebx
  int r;
  
  acquire(&lk->lk);
801046de:	8d 73 04             	lea    0x4(%ebx),%esi
801046e1:	56                   	push   %esi
801046e2:	e8 59 02 00 00       	call   80104940 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
801046e7:	8b 03                	mov    (%ebx),%eax
801046e9:	83 c4 10             	add    $0x10,%esp
801046ec:	85 c0                	test   %eax,%eax
801046ee:	75 18                	jne    80104708 <holdingsleep+0x38>
  release(&lk->lk);
801046f0:	83 ec 0c             	sub    $0xc,%esp
801046f3:	56                   	push   %esi
801046f4:	e8 e7 01 00 00       	call   801048e0 <release>
  return r;
}
801046f9:	8d 65 f4             	lea    -0xc(%ebp),%esp
801046fc:	89 f8                	mov    %edi,%eax
801046fe:	5b                   	pop    %ebx
801046ff:	5e                   	pop    %esi
80104700:	5f                   	pop    %edi
80104701:	5d                   	pop    %ebp
80104702:	c3                   	ret
80104703:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  r = lk->locked && (lk->pid == myproc()->pid);
80104708:	8b 5b 3c             	mov    0x3c(%ebx),%ebx
8010470b:	e8 90 f4 ff ff       	call   80103ba0 <myproc>
80104710:	39 58 10             	cmp    %ebx,0x10(%eax)
80104713:	0f 94 c0             	sete   %al
80104716:	0f b6 c0             	movzbl %al,%eax
80104719:	89 c7                	mov    %eax,%edi
8010471b:	eb d3                	jmp    801046f0 <holdingsleep+0x20>
8010471d:	66 90                	xchg   %ax,%ax
8010471f:	90                   	nop

80104720 <initlock>:
#include "proc.h"
#include "spinlock.h"

void
initlock(struct spinlock *lk, char *name)
{
80104720:	55                   	push   %ebp
80104721:	89 e5                	mov    %esp,%ebp
80104723:	8b 45 08             	mov    0x8(%ebp),%eax
  lk->name = name;
80104726:	8b 55 0c             	mov    0xc(%ebp),%edx
  lk->locked = 0;
80104729:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  lk->name = name;
8010472f:	89 50 04             	mov    %edx,0x4(%eax)
  lk->cpu = 0;
80104732:	c7 40 08 00 00 00 00 	movl   $0x0,0x8(%eax)
}
80104739:	5d                   	pop    %ebp
8010473a:	c3                   	ret
8010473b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80104740 <getcallerpcs>:
}

// Record the current call stack in pcs[] by following the %ebp chain.
void
getcallerpcs(void *v, uint pcs[])
{
80104740:	55                   	push   %ebp
  uint *ebp;
  int i;

  ebp = (uint*)v - 2;
  for(i = 0; i < 10; i++){
80104741:	31 d2                	xor    %edx,%edx
{
80104743:	89 e5                	mov    %esp,%ebp
80104745:	53                   	push   %ebx
  ebp = (uint*)v - 2;
80104746:	8b 45 08             	mov    0x8(%ebp),%eax
{
80104749:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  ebp = (uint*)v - 2;
8010474c:	83 e8 08             	sub    $0x8,%eax
  for(i = 0; i < 10; i++){
8010474f:	90                   	nop
80104750:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104757:	00 
80104758:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010475f:	00 
    if(ebp == 0 || ebp < (uint*)KERNBASE || ebp == (uint*)0xffffffff)
80104760:	8d 98 00 00 00 80    	lea    -0x80000000(%eax),%ebx
80104766:	81 fb fe ff ff 7f    	cmp    $0x7ffffffe,%ebx
8010476c:	77 1a                	ja     80104788 <getcallerpcs+0x48>
      break;
    pcs[i] = ebp[1];     // saved %eip
8010476e:	8b 58 04             	mov    0x4(%eax),%ebx
80104771:	89 1c 91             	mov    %ebx,(%ecx,%edx,4)
  for(i = 0; i < 10; i++){
80104774:	83 c2 01             	add    $0x1,%edx
    ebp = (uint*)ebp[0]; // saved %ebp
80104777:	8b 00                	mov    (%eax),%eax
  for(i = 0; i < 10; i++){
80104779:	83 fa 0a             	cmp    $0xa,%edx
8010477c:	75 e2                	jne    80104760 <getcallerpcs+0x20>
  }
  for(; i < 10; i++)
    pcs[i] = 0;
}
8010477e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104781:	c9                   	leave
80104782:	c3                   	ret
80104783:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  for(; i < 10; i++)
80104788:	8d 04 91             	lea    (%ecx,%edx,4),%eax
8010478b:	83 c1 28             	add    $0x28,%ecx
8010478e:	89 ca                	mov    %ecx,%edx
80104790:	29 c2                	sub    %eax,%edx
80104792:	83 e2 04             	and    $0x4,%edx
80104795:	74 29                	je     801047c0 <getcallerpcs+0x80>
    pcs[i] = 0;
80104797:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  for(; i < 10; i++)
8010479d:	83 c0 04             	add    $0x4,%eax
801047a0:	39 c8                	cmp    %ecx,%eax
801047a2:	74 da                	je     8010477e <getcallerpcs+0x3e>
801047a4:	eb 1a                	jmp    801047c0 <getcallerpcs+0x80>
801047a6:	66 90                	xchg   %ax,%ax
801047a8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801047af:	00 
801047b0:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801047b7:	00 
801047b8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801047bf:	00 
    pcs[i] = 0;
801047c0:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  for(; i < 10; i++)
801047c6:	83 c0 08             	add    $0x8,%eax
    pcs[i] = 0;
801047c9:	c7 40 fc 00 00 00 00 	movl   $0x0,-0x4(%eax)
  for(; i < 10; i++)
801047d0:	39 c8                	cmp    %ecx,%eax
801047d2:	75 ec                	jne    801047c0 <getcallerpcs+0x80>
801047d4:	eb a8                	jmp    8010477e <getcallerpcs+0x3e>
801047d6:	66 90                	xchg   %ax,%ax
801047d8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801047df:	00 

801047e0 <pushcli>:
// it takes two popcli to undo two pushcli.  Also, if interrupts
// are off, then pushcli, popcli leaves them off.

void
pushcli(void)
{
801047e0:	55                   	push   %ebp
801047e1:	89 e5                	mov    %esp,%ebp
801047e3:	53                   	push   %ebx
801047e4:	83 ec 04             	sub    $0x4,%esp
801047e7:	9c                   	pushf
801047e8:	5b                   	pop    %ebx
  asm volatile("cli");
801047e9:	fa                   	cli
  int eflags;

  eflags = readeflags();
  cli();
  if(mycpu()->ncli == 0)
801047ea:	e8 21 f3 ff ff       	call   80103b10 <mycpu>
801047ef:	8b 80 a4 00 00 00    	mov    0xa4(%eax),%eax
801047f5:	85 c0                	test   %eax,%eax
801047f7:	74 17                	je     80104810 <pushcli+0x30>
    mycpu()->intena = eflags & FL_IF;
  mycpu()->ncli += 1;
801047f9:	e8 12 f3 ff ff       	call   80103b10 <mycpu>
801047fe:	83 80 a4 00 00 00 01 	addl   $0x1,0xa4(%eax)
}
80104805:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104808:	c9                   	leave
80104809:	c3                   	ret
8010480a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    mycpu()->intena = eflags & FL_IF;
80104810:	e8 fb f2 ff ff       	call   80103b10 <mycpu>
80104815:	81 e3 00 02 00 00    	and    $0x200,%ebx
8010481b:	89 98 a8 00 00 00    	mov    %ebx,0xa8(%eax)
80104821:	eb d6                	jmp    801047f9 <pushcli+0x19>
80104823:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80104828:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010482f:	00 

80104830 <popcli>:

void
popcli(void)
{
80104830:	55                   	push   %ebp
80104831:	89 e5                	mov    %esp,%ebp
80104833:	83 ec 08             	sub    $0x8,%esp
  asm volatile("pushfl; popl %0" : "=r" (eflags));
80104836:	9c                   	pushf
80104837:	58                   	pop    %eax
  if(readeflags()&FL_IF)
80104838:	f6 c4 02             	test   $0x2,%ah
8010483b:	75 35                	jne    80104872 <popcli+0x42>
    panic("popcli - interruptible");
  if(--mycpu()->ncli < 0)
8010483d:	e8 ce f2 ff ff       	call   80103b10 <mycpu>
80104842:	83 a8 a4 00 00 00 01 	subl   $0x1,0xa4(%eax)
80104849:	78 34                	js     8010487f <popcli+0x4f>
    panic("popcli");
  if(mycpu()->ncli == 0 && mycpu()->intena)
8010484b:	e8 c0 f2 ff ff       	call   80103b10 <mycpu>
80104850:	8b 90 a4 00 00 00    	mov    0xa4(%eax),%edx
80104856:	85 d2                	test   %edx,%edx
80104858:	74 06                	je     80104860 <popcli+0x30>
    sti();
}
8010485a:	c9                   	leave
8010485b:	c3                   	ret
8010485c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  if(mycpu()->ncli == 0 && mycpu()->intena)
80104860:	e8 ab f2 ff ff       	call   80103b10 <mycpu>
80104865:	8b 80 a8 00 00 00    	mov    0xa8(%eax),%eax
8010486b:	85 c0                	test   %eax,%eax
8010486d:	74 eb                	je     8010485a <popcli+0x2a>
  asm volatile("sti");
8010486f:	fb                   	sti
}
80104870:	c9                   	leave
80104871:	c3                   	ret
    panic("popcli - interruptible");
80104872:	83 ec 0c             	sub    $0xc,%esp
80104875:	68 83 7c 10 80       	push   $0x80107c83
8010487a:	e8 21 bb ff ff       	call   801003a0 <panic>
    panic("popcli");
8010487f:	83 ec 0c             	sub    $0xc,%esp
80104882:	68 9a 7c 10 80       	push   $0x80107c9a
80104887:	e8 14 bb ff ff       	call   801003a0 <panic>
8010488c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80104890 <holding>:
{
80104890:	55                   	push   %ebp
80104891:	89 e5                	mov    %esp,%ebp
80104893:	53                   	push   %ebx
80104894:	31 db                	xor    %ebx,%ebx
80104896:	83 ec 04             	sub    $0x4,%esp
  pushcli();
80104899:	e8 42 ff ff ff       	call   801047e0 <pushcli>
  r = lock->locked && lock->cpu == mycpu();
8010489e:	8b 45 08             	mov    0x8(%ebp),%eax
801048a1:	8b 10                	mov    (%eax),%edx
801048a3:	85 d2                	test   %edx,%edx
801048a5:	75 11                	jne    801048b8 <holding+0x28>
  popcli();
801048a7:	e8 84 ff ff ff       	call   80104830 <popcli>
}
801048ac:	89 d8                	mov    %ebx,%eax
801048ae:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801048b1:	c9                   	leave
801048b2:	c3                   	ret
801048b3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  r = lock->locked && lock->cpu == mycpu();
801048b8:	8b 58 08             	mov    0x8(%eax),%ebx
801048bb:	e8 50 f2 ff ff       	call   80103b10 <mycpu>
801048c0:	39 c3                	cmp    %eax,%ebx
801048c2:	0f 94 c3             	sete   %bl
  popcli();
801048c5:	e8 66 ff ff ff       	call   80104830 <popcli>
  r = lock->locked && lock->cpu == mycpu();
801048ca:	0f b6 db             	movzbl %bl,%ebx
}
801048cd:	89 d8                	mov    %ebx,%eax
801048cf:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801048d2:	c9                   	leave
801048d3:	c3                   	ret
801048d4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
801048d8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801048df:	00 

801048e0 <release>:
{
801048e0:	55                   	push   %ebp
801048e1:	89 e5                	mov    %esp,%ebp
801048e3:	56                   	push   %esi
801048e4:	53                   	push   %ebx
801048e5:	8b 5d 08             	mov    0x8(%ebp),%ebx
  pushcli();
801048e8:	e8 f3 fe ff ff       	call   801047e0 <pushcli>
  r = lock->locked && lock->cpu == mycpu();
801048ed:	8b 03                	mov    (%ebx),%eax
801048ef:	85 c0                	test   %eax,%eax
801048f1:	75 15                	jne    80104908 <release+0x28>
  popcli();
801048f3:	e8 38 ff ff ff       	call   80104830 <popcli>
    panic("release");
801048f8:	83 ec 0c             	sub    $0xc,%esp
801048fb:	68 a1 7c 10 80       	push   $0x80107ca1
80104900:	e8 9b ba ff ff       	call   801003a0 <panic>
80104905:	8d 76 00             	lea    0x0(%esi),%esi
  r = lock->locked && lock->cpu == mycpu();
80104908:	8b 73 08             	mov    0x8(%ebx),%esi
8010490b:	e8 00 f2 ff ff       	call   80103b10 <mycpu>
80104910:	39 c6                	cmp    %eax,%esi
80104912:	75 df                	jne    801048f3 <release+0x13>
  popcli();
80104914:	e8 17 ff ff ff       	call   80104830 <popcli>
  lk->pcs[0] = 0;
80104919:	c7 43 0c 00 00 00 00 	movl   $0x0,0xc(%ebx)
  lk->cpu = 0;
80104920:	c7 43 08 00 00 00 00 	movl   $0x0,0x8(%ebx)
  __sync_synchronize();
80104927:	f0 83 0c 24 00       	lock orl $0x0,(%esp)
  asm volatile("movl $0, %0" : "+m" (lk->locked) : );
8010492c:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
}
80104932:	8d 65 f8             	lea    -0x8(%ebp),%esp
80104935:	5b                   	pop    %ebx
80104936:	5e                   	pop    %esi
80104937:	5d                   	pop    %ebp
  popcli();
80104938:	e9 f3 fe ff ff       	jmp    80104830 <popcli>
8010493d:	8d 76 00             	lea    0x0(%esi),%esi

80104940 <acquire>:
{
80104940:	55                   	push   %ebp
80104941:	89 e5                	mov    %esp,%ebp
80104943:	83 ec 08             	sub    $0x8,%esp
80104946:	89 5d f8             	mov    %ebx,-0x8(%ebp)
  pushcli(); // disable interrupts to avoid deadlock.
80104949:	e8 92 fe ff ff       	call   801047e0 <pushcli>
  if(holding(lk))
8010494e:	8b 5d 08             	mov    0x8(%ebp),%ebx
  pushcli();
80104951:	e8 8a fe ff ff       	call   801047e0 <pushcli>
  r = lock->locked && lock->cpu == mycpu();
80104956:	8b 03                	mov    (%ebx),%eax
80104958:	85 c0                	test   %eax,%eax
8010495a:	0f 85 c0 00 00 00    	jne    80104a20 <acquire+0xe0>
  popcli();
80104960:	e8 cb fe ff ff       	call   80104830 <popcli>
  asm volatile("lock; xchgl %0, %1" :
80104965:	b8 01 00 00 00       	mov    $0x1,%eax
8010496a:	f0 87 03             	lock xchg %eax,(%ebx)
               "+m" (*addr), "=a" (result) :
               "1" (newval) :
               "cc");
  return result;
8010496d:	8b 55 08             	mov    0x8(%ebp),%edx
  while(xchg(&lk->locked, 1) != 0)
80104970:	85 c0                	test   %eax,%eax
80104972:	74 18                	je     8010498c <acquire+0x4c>
80104974:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80104978:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010497f:	00 
  asm volatile("lock; xchgl %0, %1" :
80104980:	b8 01 00 00 00       	mov    $0x1,%eax
80104985:	f0 87 02             	lock xchg %eax,(%edx)
80104988:	85 c0                	test   %eax,%eax
8010498a:	75 f4                	jne    80104980 <acquire+0x40>
  __sync_synchronize();
8010498c:	f0 83 0c 24 00       	lock orl $0x0,(%esp)
  lk->cpu = mycpu();
80104991:	8b 5d 08             	mov    0x8(%ebp),%ebx
80104994:	e8 77 f1 ff ff       	call   80103b10 <mycpu>
  ebp = (uint*)v - 2;
80104999:	89 ea                	mov    %ebp,%edx
  lk->cpu = mycpu();
8010499b:	89 43 08             	mov    %eax,0x8(%ebx)
  for(i = 0; i < 10; i++){
8010499e:	31 c0                	xor    %eax,%eax
    if(ebp == 0 || ebp < (uint*)KERNBASE || ebp == (uint*)0xffffffff)
801049a0:	8d 8a 00 00 00 80    	lea    -0x80000000(%edx),%ecx
801049a6:	81 f9 fe ff ff 7f    	cmp    $0x7ffffffe,%ecx
801049ac:	77 1a                	ja     801049c8 <acquire+0x88>
    pcs[i] = ebp[1];     // saved %eip
801049ae:	8b 4a 04             	mov    0x4(%edx),%ecx
801049b1:	89 4c 83 0c          	mov    %ecx,0xc(%ebx,%eax,4)
  for(i = 0; i < 10; i++){
801049b5:	83 c0 01             	add    $0x1,%eax
    ebp = (uint*)ebp[0]; // saved %ebp
801049b8:	8b 12                	mov    (%edx),%edx
  for(i = 0; i < 10; i++){
801049ba:	83 f8 0a             	cmp    $0xa,%eax
801049bd:	75 e1                	jne    801049a0 <acquire+0x60>
}
801049bf:	8b 5d f8             	mov    -0x8(%ebp),%ebx
801049c2:	c9                   	leave
801049c3:	c3                   	ret
801049c4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  for(; i < 10; i++)
801049c8:	8d 44 83 0c          	lea    0xc(%ebx,%eax,4),%eax
801049cc:	83 c3 34             	add    $0x34,%ebx
801049cf:	89 da                	mov    %ebx,%edx
801049d1:	29 c2                	sub    %eax,%edx
801049d3:	83 e2 04             	and    $0x4,%edx
801049d6:	74 28                	je     80104a00 <acquire+0xc0>
    pcs[i] = 0;
801049d8:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  for(; i < 10; i++)
801049de:	83 c0 04             	add    $0x4,%eax
801049e1:	39 d8                	cmp    %ebx,%eax
801049e3:	74 da                	je     801049bf <acquire+0x7f>
801049e5:	eb 19                	jmp    80104a00 <acquire+0xc0>
801049e7:	90                   	nop
801049e8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801049ef:	00 
801049f0:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801049f7:	00 
801049f8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801049ff:	00 
    pcs[i] = 0;
80104a00:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  for(; i < 10; i++)
80104a06:	83 c0 08             	add    $0x8,%eax
    pcs[i] = 0;
80104a09:	c7 40 fc 00 00 00 00 	movl   $0x0,-0x4(%eax)
  for(; i < 10; i++)
80104a10:	39 d8                	cmp    %ebx,%eax
80104a12:	75 ec                	jne    80104a00 <acquire+0xc0>
80104a14:	eb a9                	jmp    801049bf <acquire+0x7f>
80104a16:	66 90                	xchg   %ax,%ax
80104a18:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104a1f:	00 
80104a20:	89 75 fc             	mov    %esi,-0x4(%ebp)
  r = lock->locked && lock->cpu == mycpu();
80104a23:	8b 73 08             	mov    0x8(%ebx),%esi
80104a26:	e8 e5 f0 ff ff       	call   80103b10 <mycpu>
80104a2b:	39 c6                	cmp    %eax,%esi
80104a2d:	74 11                	je     80104a40 <acquire+0x100>
80104a2f:	8b 75 fc             	mov    -0x4(%ebp),%esi
80104a32:	e9 29 ff ff ff       	jmp    80104960 <acquire+0x20>
80104a37:	90                   	nop
80104a38:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104a3f:	00 
  popcli();
80104a40:	e8 eb fd ff ff       	call   80104830 <popcli>
    panic("acquire");
80104a45:	83 ec 0c             	sub    $0xc,%esp
80104a48:	68 a9 7c 10 80       	push   $0x80107ca9
80104a4d:	e8 4e b9 ff ff       	call   801003a0 <panic>
80104a52:	66 90                	xchg   %ax,%ax
80104a54:	66 90                	xchg   %ax,%ax
80104a56:	66 90                	xchg   %ax,%ax
80104a58:	66 90                	xchg   %ax,%ax
80104a5a:	66 90                	xchg   %ax,%ax
80104a5c:	66 90                	xchg   %ax,%ax
80104a5e:	66 90                	xchg   %ax,%ax

80104a60 <memset>:
#include "types.h"
#include "x86.h"

void*
memset(void *dst, int c, uint n)
{
80104a60:	55                   	push   %ebp
80104a61:	89 e5                	mov    %esp,%ebp
80104a63:	57                   	push   %edi
80104a64:	8b 55 08             	mov    0x8(%ebp),%edx
80104a67:	8b 4d 10             	mov    0x10(%ebp),%ecx
  if ((int)dst%4 == 0 && n%4 == 0){
80104a6a:	89 d0                	mov    %edx,%eax
80104a6c:	09 c8                	or     %ecx,%eax
80104a6e:	a8 03                	test   $0x3,%al
80104a70:	75 1e                	jne    80104a90 <memset+0x30>
    c &= 0xFF;
80104a72:	0f b6 45 0c          	movzbl 0xc(%ebp),%eax
    stosl(dst, (c<<24)|(c<<16)|(c<<8)|c, n/4);
80104a76:	c1 e9 02             	shr    $0x2,%ecx
  asm volatile("cld; rep stosl" :
80104a79:	89 d7                	mov    %edx,%edi
80104a7b:	69 c0 01 01 01 01    	imul   $0x1010101,%eax,%eax
80104a81:	fc                   	cld
80104a82:	f3 ab                	rep stos %eax,%es:(%edi)
  } else
    stosb(dst, c, n);
  return dst;
}
80104a84:	8b 7d fc             	mov    -0x4(%ebp),%edi
80104a87:	89 d0                	mov    %edx,%eax
80104a89:	c9                   	leave
80104a8a:	c3                   	ret
80104a8b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  asm volatile("cld; rep stosb" :
80104a90:	8b 45 0c             	mov    0xc(%ebp),%eax
80104a93:	89 d7                	mov    %edx,%edi
80104a95:	fc                   	cld
80104a96:	f3 aa                	rep stos %al,%es:(%edi)
80104a98:	8b 7d fc             	mov    -0x4(%ebp),%edi
80104a9b:	89 d0                	mov    %edx,%eax
80104a9d:	c9                   	leave
80104a9e:	c3                   	ret
80104a9f:	90                   	nop

80104aa0 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
80104aa0:	55                   	push   %ebp
80104aa1:	89 e5                	mov    %esp,%ebp
80104aa3:	83 ec 08             	sub    $0x8,%esp
80104aa6:	8b 45 08             	mov    0x8(%ebp),%eax
80104aa9:	8b 4d 10             	mov    0x10(%ebp),%ecx
80104aac:	89 75 fc             	mov    %esi,-0x4(%ebp)
80104aaf:	8b 55 0c             	mov    0xc(%ebp),%edx
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
80104ab2:	8d 34 08             	lea    (%eax,%ecx,1),%esi
80104ab5:	85 c9                	test   %ecx,%ecx
80104ab7:	74 32                	je     80104aeb <memcmp+0x4b>
80104ab9:	89 5d f8             	mov    %ebx,-0x8(%ebp)
80104abc:	eb 0c                	jmp    80104aca <memcmp+0x2a>
80104abe:	66 90                	xchg   %ax,%ax
    if(*s1 != *s2)
      return *s1 - *s2;
    s1++, s2++;
80104ac0:	83 c0 01             	add    $0x1,%eax
80104ac3:	83 c2 01             	add    $0x1,%edx
  while(n-- > 0){
80104ac6:	39 f0                	cmp    %esi,%eax
80104ac8:	74 1e                	je     80104ae8 <memcmp+0x48>
    if(*s1 != *s2)
80104aca:	0f b6 08             	movzbl (%eax),%ecx
80104acd:	0f b6 1a             	movzbl (%edx),%ebx
80104ad0:	38 d9                	cmp    %bl,%cl
80104ad2:	74 ec                	je     80104ac0 <memcmp+0x20>
      return *s1 - *s2;
80104ad4:	0f b6 c1             	movzbl %cl,%eax
  }

  return 0;
}
80104ad7:	8b 75 fc             	mov    -0x4(%ebp),%esi
      return *s1 - *s2;
80104ada:	29 d8                	sub    %ebx,%eax
80104adc:	8b 5d f8             	mov    -0x8(%ebp),%ebx
}
80104adf:	c9                   	leave
80104ae0:	c3                   	ret
80104ae1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80104ae8:	8b 5d f8             	mov    -0x8(%ebp),%ebx
80104aeb:	8b 75 fc             	mov    -0x4(%ebp),%esi
  return 0;
80104aee:	31 c0                	xor    %eax,%eax
}
80104af0:	c9                   	leave
80104af1:	c3                   	ret
80104af2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80104af8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104aff:	00 

80104b00 <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
80104b00:	55                   	push   %ebp
80104b01:	89 e5                	mov    %esp,%ebp
80104b03:	57                   	push   %edi
80104b04:	8b 55 08             	mov    0x8(%ebp),%edx
80104b07:	8b 4d 10             	mov    0x10(%ebp),%ecx
80104b0a:	56                   	push   %esi
80104b0b:	8b 75 0c             	mov    0xc(%ebp),%esi
  const char *s;
  char *d;

  s = src;
  d = dst;
  if(s < d && s + n > d){
80104b0e:	39 d6                	cmp    %edx,%esi
80104b10:	73 36                	jae    80104b48 <memmove+0x48>
80104b12:	8d 3c 0e             	lea    (%esi,%ecx,1),%edi
80104b15:	39 fa                	cmp    %edi,%edx
80104b17:	73 2f                	jae    80104b48 <memmove+0x48>
    s += n;
    d += n;
    while(n-- > 0)
80104b19:	85 c9                	test   %ecx,%ecx
80104b1b:	74 1f                	je     80104b3c <memmove+0x3c>
      *--d = *--s;
80104b1d:	29 cf                	sub    %ecx,%edi
    while(n-- > 0)
80104b1f:	8d 41 ff             	lea    -0x1(%ecx),%eax
      *--d = *--s;
80104b22:	89 fe                	mov    %edi,%esi
80104b24:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80104b28:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104b2f:	00 
80104b30:	0f b6 0c 06          	movzbl (%esi,%eax,1),%ecx
80104b34:	88 0c 02             	mov    %cl,(%edx,%eax,1)
    while(n-- > 0)
80104b37:	83 e8 01             	sub    $0x1,%eax
80104b3a:	73 f4                	jae    80104b30 <memmove+0x30>
  } else
    while(n-- > 0)
      *d++ = *s++;

  return dst;
}
80104b3c:	5e                   	pop    %esi
80104b3d:	89 d0                	mov    %edx,%eax
80104b3f:	5f                   	pop    %edi
80104b40:	5d                   	pop    %ebp
80104b41:	c3                   	ret
80104b42:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    while(n-- > 0)
80104b48:	8d 04 0e             	lea    (%esi,%ecx,1),%eax
80104b4b:	89 d7                	mov    %edx,%edi
80104b4d:	85 c9                	test   %ecx,%ecx
80104b4f:	74 eb                	je     80104b3c <memmove+0x3c>
80104b51:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80104b58:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104b5f:	00 
      *d++ = *s++;
80104b60:	a4                   	movsb  %ds:(%esi),%es:(%edi)
    while(n-- > 0)
80104b61:	39 f0                	cmp    %esi,%eax
80104b63:	75 fb                	jne    80104b60 <memmove+0x60>
}
80104b65:	5e                   	pop    %esi
80104b66:	89 d0                	mov    %edx,%eax
80104b68:	5f                   	pop    %edi
80104b69:	5d                   	pop    %ebp
80104b6a:	c3                   	ret
80104b6b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80104b70 <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
  return memmove(dst, src, n);
80104b70:	eb 8e                	jmp    80104b00 <memmove>
80104b72:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80104b78:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104b7f:	00 

80104b80 <strncmp>:
}

int
strncmp(const char *p, const char *q, uint n)
{
80104b80:	55                   	push   %ebp
80104b81:	89 e5                	mov    %esp,%ebp
80104b83:	53                   	push   %ebx
80104b84:	8b 55 10             	mov    0x10(%ebp),%edx
80104b87:	8b 45 08             	mov    0x8(%ebp),%eax
80104b8a:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  while(n > 0 && *p && *p == *q)
80104b8d:	85 d2                	test   %edx,%edx
80104b8f:	75 16                	jne    80104ba7 <strncmp+0x27>
80104b91:	eb 2d                	jmp    80104bc0 <strncmp+0x40>
80104b93:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80104b98:	3a 19                	cmp    (%ecx),%bl
80104b9a:	75 12                	jne    80104bae <strncmp+0x2e>
    n--, p++, q++;
80104b9c:	83 c0 01             	add    $0x1,%eax
80104b9f:	83 c1 01             	add    $0x1,%ecx
  while(n > 0 && *p && *p == *q)
80104ba2:	83 ea 01             	sub    $0x1,%edx
80104ba5:	74 19                	je     80104bc0 <strncmp+0x40>
80104ba7:	0f b6 18             	movzbl (%eax),%ebx
80104baa:	84 db                	test   %bl,%bl
80104bac:	75 ea                	jne    80104b98 <strncmp+0x18>
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
80104bae:	0f b6 00             	movzbl (%eax),%eax
80104bb1:	0f b6 11             	movzbl (%ecx),%edx
}
80104bb4:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104bb7:	c9                   	leave
  return (uchar)*p - (uchar)*q;
80104bb8:	29 d0                	sub    %edx,%eax
}
80104bba:	c3                   	ret
80104bbb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80104bc0:	8b 5d fc             	mov    -0x4(%ebp),%ebx
    return 0;
80104bc3:	31 c0                	xor    %eax,%eax
}
80104bc5:	c9                   	leave
80104bc6:	c3                   	ret
80104bc7:	90                   	nop
80104bc8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104bcf:	00 

80104bd0 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
80104bd0:	55                   	push   %ebp
80104bd1:	89 e5                	mov    %esp,%ebp
80104bd3:	53                   	push   %ebx
80104bd4:	8b 4d 0c             	mov    0xc(%ebp),%ecx
80104bd7:	8b 55 10             	mov    0x10(%ebp),%edx
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
80104bda:	8b 45 08             	mov    0x8(%ebp),%eax
80104bdd:	eb 14                	jmp    80104bf3 <strncpy+0x23>
80104bdf:	90                   	nop
80104be0:	0f b6 19             	movzbl (%ecx),%ebx
80104be3:	83 c1 01             	add    $0x1,%ecx
80104be6:	83 c0 01             	add    $0x1,%eax
80104be9:	88 58 ff             	mov    %bl,-0x1(%eax)
80104bec:	84 db                	test   %bl,%bl
80104bee:	74 10                	je     80104c00 <strncpy+0x30>
80104bf0:	83 ea 01             	sub    $0x1,%edx
80104bf3:	85 d2                	test   %edx,%edx
80104bf5:	7f e9                	jg     80104be0 <strncpy+0x10>
    ;
  while(n-- > 0)
    *s++ = 0;
  return os;
}
80104bf7:	8b 45 08             	mov    0x8(%ebp),%eax
80104bfa:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104bfd:	c9                   	leave
80104bfe:	c3                   	ret
80104bff:	90                   	nop
  while(n-- > 0)
80104c00:	8d 4c 10 ff          	lea    -0x1(%eax,%edx,1),%ecx
80104c04:	83 fa 01             	cmp    $0x1,%edx
80104c07:	74 ee                	je     80104bf7 <strncpy+0x27>
80104c09:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    *s++ = 0;
80104c10:	83 c0 01             	add    $0x1,%eax
80104c13:	89 ca                	mov    %ecx,%edx
80104c15:	c6 40 ff 00          	movb   $0x0,-0x1(%eax)
  while(n-- > 0)
80104c19:	29 c2                	sub    %eax,%edx
80104c1b:	85 d2                	test   %edx,%edx
80104c1d:	7f f1                	jg     80104c10 <strncpy+0x40>
}
80104c1f:	8b 45 08             	mov    0x8(%ebp),%eax
80104c22:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104c25:	c9                   	leave
80104c26:	c3                   	ret
80104c27:	90                   	nop
80104c28:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104c2f:	00 

80104c30 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
80104c30:	55                   	push   %ebp
80104c31:	89 e5                	mov    %esp,%ebp
80104c33:	53                   	push   %ebx
80104c34:	8b 55 10             	mov    0x10(%ebp),%edx
80104c37:	8b 45 0c             	mov    0xc(%ebp),%eax
  char *os;

  os = s;
  if(n <= 0)
80104c3a:	85 d2                	test   %edx,%edx
80104c3c:	7e 39                	jle    80104c77 <safestrcpy+0x47>
80104c3e:	8d 5c 10 ff          	lea    -0x1(%eax,%edx,1),%ebx
80104c42:	8b 55 08             	mov    0x8(%ebp),%edx
80104c45:	eb 29                	jmp    80104c70 <safestrcpy+0x40>
80104c47:	eb 17                	jmp    80104c60 <safestrcpy+0x30>
80104c49:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80104c50:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104c57:	00 
80104c58:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104c5f:	00 
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
80104c60:	0f b6 08             	movzbl (%eax),%ecx
80104c63:	83 c0 01             	add    $0x1,%eax
80104c66:	83 c2 01             	add    $0x1,%edx
80104c69:	88 4a ff             	mov    %cl,-0x1(%edx)
80104c6c:	84 c9                	test   %cl,%cl
80104c6e:	74 04                	je     80104c74 <safestrcpy+0x44>
80104c70:	39 d8                	cmp    %ebx,%eax
80104c72:	75 ec                	jne    80104c60 <safestrcpy+0x30>
    ;
  *s = 0;
80104c74:	c6 02 00             	movb   $0x0,(%edx)
  return os;
}
80104c77:	8b 45 08             	mov    0x8(%ebp),%eax
80104c7a:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104c7d:	c9                   	leave
80104c7e:	c3                   	ret
80104c7f:	90                   	nop

80104c80 <strlen>:

int
strlen(const char *s)
{
80104c80:	55                   	push   %ebp
  int n;

  for(n = 0; s[n]; n++)
80104c81:	31 c0                	xor    %eax,%eax
{
80104c83:	89 e5                	mov    %esp,%ebp
80104c85:	8b 55 08             	mov    0x8(%ebp),%edx
  for(n = 0; s[n]; n++)
80104c88:	80 3a 00             	cmpb   $0x0,(%edx)
80104c8b:	74 0c                	je     80104c99 <strlen+0x19>
80104c8d:	8d 76 00             	lea    0x0(%esi),%esi
80104c90:	83 c0 01             	add    $0x1,%eax
80104c93:	80 3c 02 00          	cmpb   $0x0,(%edx,%eax,1)
80104c97:	75 f7                	jne    80104c90 <strlen+0x10>
    ;
  return n;
}
80104c99:	5d                   	pop    %ebp
80104c9a:	c3                   	ret

80104c9b <swtch>:
# a struct context, and save its address in *old.
# Switch stacks to new and pop previously-saved registers.

.globl swtch
swtch:
  movl 4(%esp), %eax
80104c9b:	8b 44 24 04          	mov    0x4(%esp),%eax
  movl 8(%esp), %edx
80104c9f:	8b 54 24 08          	mov    0x8(%esp),%edx

  # Save old callee-saved registers
  pushl %ebp
80104ca3:	55                   	push   %ebp
  pushl %ebx
80104ca4:	53                   	push   %ebx
  pushl %esi
80104ca5:	56                   	push   %esi
  pushl %edi
80104ca6:	57                   	push   %edi

  # Switch stacks
  movl %esp, (%eax)
80104ca7:	89 20                	mov    %esp,(%eax)
  movl %edx, %esp
80104ca9:	89 d4                	mov    %edx,%esp

  # Load new callee-saved registers
  popl %edi
80104cab:	5f                   	pop    %edi
  popl %esi
80104cac:	5e                   	pop    %esi
  popl %ebx
80104cad:	5b                   	pop    %ebx
  popl %ebp
80104cae:	5d                   	pop    %ebp
  ret
80104caf:	c3                   	ret

80104cb0 <fetchint>:
// to a saved program counter, and then the first argument.

// Fetch the int at addr from the current process.
int
fetchint(uint addr, int *ip)
{
80104cb0:	55                   	push   %ebp
80104cb1:	89 e5                	mov    %esp,%ebp
80104cb3:	53                   	push   %ebx
80104cb4:	83 ec 04             	sub    $0x4,%esp
80104cb7:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct proc *curproc = myproc();
80104cba:	e8 e1 ee ff ff       	call   80103ba0 <myproc>

  if(addr >= curproc->sz || addr+4 > curproc->sz)
80104cbf:	8b 00                	mov    (%eax),%eax
80104cc1:	39 c3                	cmp    %eax,%ebx
80104cc3:	73 1b                	jae    80104ce0 <fetchint+0x30>
80104cc5:	8d 53 04             	lea    0x4(%ebx),%edx
80104cc8:	39 d0                	cmp    %edx,%eax
80104cca:	72 14                	jb     80104ce0 <fetchint+0x30>
    return -1;
  *ip = *(int*)(addr);
80104ccc:	8b 45 0c             	mov    0xc(%ebp),%eax
80104ccf:	8b 13                	mov    (%ebx),%edx
80104cd1:	89 10                	mov    %edx,(%eax)
  return 0;
80104cd3:	31 c0                	xor    %eax,%eax
}
80104cd5:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104cd8:	c9                   	leave
80104cd9:	c3                   	ret
80104cda:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    return -1;
80104ce0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104ce5:	eb ee                	jmp    80104cd5 <fetchint+0x25>
80104ce7:	90                   	nop
80104ce8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104cef:	00 

80104cf0 <fetchstr>:
// Fetch the nul-terminated string at addr from the current process.
// Doesn't actually copy the string - just sets *pp to point at it.
// Returns length of string, not including nul.
int
fetchstr(uint addr, char **pp)
{
80104cf0:	55                   	push   %ebp
80104cf1:	89 e5                	mov    %esp,%ebp
80104cf3:	53                   	push   %ebx
80104cf4:	83 ec 04             	sub    $0x4,%esp
80104cf7:	8b 5d 08             	mov    0x8(%ebp),%ebx
  char *s, *ep;
  struct proc *curproc = myproc();
80104cfa:	e8 a1 ee ff ff       	call   80103ba0 <myproc>

  if(addr >= curproc->sz)
80104cff:	3b 18                	cmp    (%eax),%ebx
80104d01:	73 35                	jae    80104d38 <fetchstr+0x48>
    return -1;
  *pp = (char*)addr;
80104d03:	8b 55 0c             	mov    0xc(%ebp),%edx
80104d06:	89 1a                	mov    %ebx,(%edx)
  ep = (char*)curproc->sz;
80104d08:	8b 10                	mov    (%eax),%edx
  for(s = *pp; s < ep; s++){
80104d0a:	39 d3                	cmp    %edx,%ebx
80104d0c:	73 2a                	jae    80104d38 <fetchstr+0x48>
80104d0e:	89 d8                	mov    %ebx,%eax
80104d10:	eb 15                	jmp    80104d27 <fetchstr+0x37>
80104d12:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80104d18:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104d1f:	00 
80104d20:	83 c0 01             	add    $0x1,%eax
80104d23:	39 d0                	cmp    %edx,%eax
80104d25:	73 11                	jae    80104d38 <fetchstr+0x48>
    if(*s == 0)
80104d27:	80 38 00             	cmpb   $0x0,(%eax)
80104d2a:	75 f4                	jne    80104d20 <fetchstr+0x30>
      return s - *pp;
80104d2c:	29 d8                	sub    %ebx,%eax
  }
  return -1;
}
80104d2e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104d31:	c9                   	leave
80104d32:	c3                   	ret
80104d33:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80104d38:	8b 5d fc             	mov    -0x4(%ebp),%ebx
    return -1;
80104d3b:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80104d40:	c9                   	leave
80104d41:	c3                   	ret
80104d42:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80104d48:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104d4f:	00 

80104d50 <argint>:

// Fetch the nth 32-bit system call argument.
int
argint(int n, int *ip)
{
80104d50:	55                   	push   %ebp
80104d51:	89 e5                	mov    %esp,%ebp
80104d53:	56                   	push   %esi
80104d54:	53                   	push   %ebx
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
80104d55:	e8 46 ee ff ff       	call   80103ba0 <myproc>
80104d5a:	8b 55 08             	mov    0x8(%ebp),%edx
80104d5d:	8b 40 18             	mov    0x18(%eax),%eax
80104d60:	8b 40 44             	mov    0x44(%eax),%eax
80104d63:	8d 1c 90             	lea    (%eax,%edx,4),%ebx
  struct proc *curproc = myproc();
80104d66:	e8 35 ee ff ff       	call   80103ba0 <myproc>
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
80104d6b:	8d 73 04             	lea    0x4(%ebx),%esi
  if(addr >= curproc->sz || addr+4 > curproc->sz)
80104d6e:	8b 00                	mov    (%eax),%eax
80104d70:	39 c6                	cmp    %eax,%esi
80104d72:	73 1c                	jae    80104d90 <argint+0x40>
80104d74:	8d 53 08             	lea    0x8(%ebx),%edx
80104d77:	39 d0                	cmp    %edx,%eax
80104d79:	72 15                	jb     80104d90 <argint+0x40>
  *ip = *(int*)(addr);
80104d7b:	8b 45 0c             	mov    0xc(%ebp),%eax
80104d7e:	8b 53 04             	mov    0x4(%ebx),%edx
80104d81:	89 10                	mov    %edx,(%eax)
  return 0;
80104d83:	31 c0                	xor    %eax,%eax
}
80104d85:	5b                   	pop    %ebx
80104d86:	5e                   	pop    %esi
80104d87:	5d                   	pop    %ebp
80104d88:	c3                   	ret
80104d89:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    return -1;
80104d90:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104d95:	eb ee                	jmp    80104d85 <argint+0x35>
80104d97:	90                   	nop
80104d98:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104d9f:	00 

80104da0 <argptr>:
// Fetch the nth word-sized system call argument as a pointer
// to a block of memory of size bytes.  Check that the pointer
// lies within the process address space.
int
argptr(int n, char **pp, int size)
{
80104da0:	55                   	push   %ebp
80104da1:	89 e5                	mov    %esp,%ebp
80104da3:	57                   	push   %edi
80104da4:	56                   	push   %esi
80104da5:	53                   	push   %ebx
80104da6:	83 ec 0c             	sub    $0xc,%esp
  int i;
  struct proc *curproc = myproc();
80104da9:	e8 f2 ed ff ff       	call   80103ba0 <myproc>
80104dae:	89 c6                	mov    %eax,%esi
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
80104db0:	e8 eb ed ff ff       	call   80103ba0 <myproc>
80104db5:	8b 55 08             	mov    0x8(%ebp),%edx
80104db8:	8b 40 18             	mov    0x18(%eax),%eax
80104dbb:	8b 40 44             	mov    0x44(%eax),%eax
80104dbe:	8d 3c 90             	lea    (%eax,%edx,4),%edi
  struct proc *curproc = myproc();
80104dc1:	e8 da ed ff ff       	call   80103ba0 <myproc>
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
80104dc6:	8d 5f 04             	lea    0x4(%edi),%ebx
  if(addr >= curproc->sz || addr+4 > curproc->sz)
80104dc9:	8b 00                	mov    (%eax),%eax
80104dcb:	39 c3                	cmp    %eax,%ebx
80104dcd:	73 31                	jae    80104e00 <argptr+0x60>
80104dcf:	8d 57 08             	lea    0x8(%edi),%edx
80104dd2:	39 d0                	cmp    %edx,%eax
80104dd4:	72 2a                	jb     80104e00 <argptr+0x60>
 
  if(argint(n, &i) < 0)
    return -1;
  if(size < 0 || (uint)i >= curproc->sz || (uint)i+size > curproc->sz)
80104dd6:	8b 45 10             	mov    0x10(%ebp),%eax
80104dd9:	85 c0                	test   %eax,%eax
80104ddb:	78 23                	js     80104e00 <argptr+0x60>
  *ip = *(int*)(addr);
80104ddd:	8b 57 04             	mov    0x4(%edi),%edx
  if(size < 0 || (uint)i >= curproc->sz || (uint)i+size > curproc->sz)
80104de0:	8b 0e                	mov    (%esi),%ecx
80104de2:	39 ca                	cmp    %ecx,%edx
80104de4:	73 1a                	jae    80104e00 <argptr+0x60>
80104de6:	8b 45 10             	mov    0x10(%ebp),%eax
80104de9:	01 d0                	add    %edx,%eax
80104deb:	39 c1                	cmp    %eax,%ecx
80104ded:	72 11                	jb     80104e00 <argptr+0x60>
    return -1;
  *pp = (char*)i;
80104def:	8b 45 0c             	mov    0xc(%ebp),%eax
80104df2:	89 10                	mov    %edx,(%eax)
  return 0;
80104df4:	31 c0                	xor    %eax,%eax
}
80104df6:	83 c4 0c             	add    $0xc,%esp
80104df9:	5b                   	pop    %ebx
80104dfa:	5e                   	pop    %esi
80104dfb:	5f                   	pop    %edi
80104dfc:	5d                   	pop    %ebp
80104dfd:	c3                   	ret
80104dfe:	66 90                	xchg   %ax,%ax
    return -1;
80104e00:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104e05:	eb ef                	jmp    80104df6 <argptr+0x56>
80104e07:	90                   	nop
80104e08:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104e0f:	00 

80104e10 <argstr>:
// Check that the pointer is valid and the string is nul-terminated.
// (There is no shared writable memory, so the string can't change
// between this check and being used by the kernel.)
int
argstr(int n, char **pp)
{
80104e10:	55                   	push   %ebp
80104e11:	89 e5                	mov    %esp,%ebp
80104e13:	56                   	push   %esi
80104e14:	53                   	push   %ebx
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
80104e15:	e8 86 ed ff ff       	call   80103ba0 <myproc>
80104e1a:	8b 55 08             	mov    0x8(%ebp),%edx
80104e1d:	8b 40 18             	mov    0x18(%eax),%eax
80104e20:	8b 40 44             	mov    0x44(%eax),%eax
80104e23:	8d 1c 90             	lea    (%eax,%edx,4),%ebx
  struct proc *curproc = myproc();
80104e26:	e8 75 ed ff ff       	call   80103ba0 <myproc>
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
80104e2b:	8d 73 04             	lea    0x4(%ebx),%esi
  if(addr >= curproc->sz || addr+4 > curproc->sz)
80104e2e:	8b 00                	mov    (%eax),%eax
80104e30:	39 c6                	cmp    %eax,%esi
80104e32:	73 44                	jae    80104e78 <argstr+0x68>
80104e34:	8d 53 08             	lea    0x8(%ebx),%edx
80104e37:	39 d0                	cmp    %edx,%eax
80104e39:	72 3d                	jb     80104e78 <argstr+0x68>
  *ip = *(int*)(addr);
80104e3b:	8b 5b 04             	mov    0x4(%ebx),%ebx
  struct proc *curproc = myproc();
80104e3e:	e8 5d ed ff ff       	call   80103ba0 <myproc>
  if(addr >= curproc->sz)
80104e43:	3b 18                	cmp    (%eax),%ebx
80104e45:	73 31                	jae    80104e78 <argstr+0x68>
  *pp = (char*)addr;
80104e47:	8b 55 0c             	mov    0xc(%ebp),%edx
80104e4a:	89 1a                	mov    %ebx,(%edx)
  ep = (char*)curproc->sz;
80104e4c:	8b 10                	mov    (%eax),%edx
  for(s = *pp; s < ep; s++){
80104e4e:	39 d3                	cmp    %edx,%ebx
80104e50:	73 26                	jae    80104e78 <argstr+0x68>
80104e52:	89 d8                	mov    %ebx,%eax
80104e54:	eb 11                	jmp    80104e67 <argstr+0x57>
80104e56:	66 90                	xchg   %ax,%ax
80104e58:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104e5f:	00 
80104e60:	83 c0 01             	add    $0x1,%eax
80104e63:	39 d0                	cmp    %edx,%eax
80104e65:	73 11                	jae    80104e78 <argstr+0x68>
    if(*s == 0)
80104e67:	80 38 00             	cmpb   $0x0,(%eax)
80104e6a:	75 f4                	jne    80104e60 <argstr+0x50>
      return s - *pp;
80104e6c:	29 d8                	sub    %ebx,%eax
  int addr;
  if(argint(n, &addr) < 0)
    return -1;
  return fetchstr(addr, pp);
}
80104e6e:	5b                   	pop    %ebx
80104e6f:	5e                   	pop    %esi
80104e70:	5d                   	pop    %ebp
80104e71:	c3                   	ret
80104e72:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80104e78:	5b                   	pop    %ebx
    return -1;
80104e79:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80104e7e:	5e                   	pop    %esi
80104e7f:	5d                   	pop    %ebp
80104e80:	c3                   	ret
80104e81:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80104e88:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104e8f:	00 

80104e90 <syscall>:
[SYS_munprotect] sys_munprotect,
};

void
syscall(void)
{
80104e90:	55                   	push   %ebp
80104e91:	89 e5                	mov    %esp,%ebp
80104e93:	53                   	push   %ebx
80104e94:	83 ec 04             	sub    $0x4,%esp
  int num;
  struct proc *curproc = myproc();
80104e97:	e8 04 ed ff ff       	call   80103ba0 <myproc>
80104e9c:	89 c3                	mov    %eax,%ebx

  num = curproc->tf->eax;
80104e9e:	8b 40 18             	mov    0x18(%eax),%eax
80104ea1:	8b 40 1c             	mov    0x1c(%eax),%eax
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
80104ea4:	8d 50 ff             	lea    -0x1(%eax),%edx
80104ea7:	83 fa 17             	cmp    $0x17,%edx
80104eaa:	77 24                	ja     80104ed0 <syscall+0x40>
80104eac:	8b 14 85 20 82 10 80 	mov    -0x7fef7de0(,%eax,4),%edx
80104eb3:	85 d2                	test   %edx,%edx
80104eb5:	74 19                	je     80104ed0 <syscall+0x40>
    curproc->tf->eax = syscalls[num]();
80104eb7:	ff d2                	call   *%edx
80104eb9:	89 c2                	mov    %eax,%edx
80104ebb:	8b 43 18             	mov    0x18(%ebx),%eax
80104ebe:	89 50 1c             	mov    %edx,0x1c(%eax)
  } else {
    cprintf("%d %s: unknown sys call %d\n",
            curproc->pid, curproc->name, num);
    curproc->tf->eax = -1;
  }
}
80104ec1:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104ec4:	c9                   	leave
80104ec5:	c3                   	ret
80104ec6:	66 90                	xchg   %ax,%ax
80104ec8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104ecf:	00 
    cprintf("%d %s: unknown sys call %d\n",
80104ed0:	50                   	push   %eax
            curproc->pid, curproc->name, num);
80104ed1:	8d 43 6c             	lea    0x6c(%ebx),%eax
    cprintf("%d %s: unknown sys call %d\n",
80104ed4:	50                   	push   %eax
80104ed5:	ff 73 10             	push   0x10(%ebx)
80104ed8:	68 b1 7c 10 80       	push   $0x80107cb1
80104edd:	e8 0e b8 ff ff       	call   801006f0 <cprintf>
    curproc->tf->eax = -1;
80104ee2:	8b 43 18             	mov    0x18(%ebx),%eax
80104ee5:	83 c4 10             	add    $0x10,%esp
80104ee8:	c7 40 1c ff ff ff ff 	movl   $0xffffffff,0x1c(%eax)
}
80104eef:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104ef2:	c9                   	leave
80104ef3:	c3                   	ret
80104ef4:	66 90                	xchg   %ax,%ax
80104ef6:	66 90                	xchg   %ax,%ax
80104ef8:	66 90                	xchg   %ax,%ax
80104efa:	66 90                	xchg   %ax,%ax
80104efc:	66 90                	xchg   %ax,%ax
80104efe:	66 90                	xchg   %ax,%ax

80104f00 <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
80104f00:	55                   	push   %ebp
80104f01:	89 e5                	mov    %esp,%ebp
80104f03:	83 ec 40             	sub    $0x40,%esp
80104f06:	89 5d f4             	mov    %ebx,-0xc(%ebp)
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
80104f09:	8d 5d da             	lea    -0x26(%ebp),%ebx
80104f0c:	53                   	push   %ebx
80104f0d:	50                   	push   %eax
{
80104f0e:	89 7d fc             	mov    %edi,-0x4(%ebp)
80104f11:	66 89 55 d6          	mov    %dx,-0x2a(%ebp)
80104f15:	66 89 4d d4          	mov    %cx,-0x2c(%ebp)
  if((dp = nameiparent(path, name)) == 0)
80104f19:	e8 f2 d2 ff ff       	call   80102210 <nameiparent>
80104f1e:	83 c4 10             	add    $0x10,%esp
80104f21:	85 c0                	test   %eax,%eax
80104f23:	0f 84 47 01 00 00    	je     80105070 <create+0x170>
    return 0;
  ilock(dp);
80104f29:	83 ec 0c             	sub    $0xc,%esp
80104f2c:	89 75 f8             	mov    %esi,-0x8(%ebp)
80104f2f:	89 c6                	mov    %eax,%esi
80104f31:	50                   	push   %eax
80104f32:	e8 29 c9 ff ff       	call   80101860 <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
80104f37:	83 c4 0c             	add    $0xc,%esp
80104f3a:	6a 00                	push   $0x0
80104f3c:	53                   	push   %ebx
80104f3d:	56                   	push   %esi
80104f3e:	e8 bd ce ff ff       	call   80101e00 <dirlookup>
80104f43:	83 c4 10             	add    $0x10,%esp
80104f46:	89 c7                	mov    %eax,%edi
80104f48:	85 c0                	test   %eax,%eax
80104f4a:	74 54                	je     80104fa0 <create+0xa0>
    iunlockput(dp);
80104f4c:	83 ec 0c             	sub    $0xc,%esp
80104f4f:	56                   	push   %esi
80104f50:	e8 bb cb ff ff       	call   80101b10 <iunlockput>
    ilock(ip);
80104f55:	89 3c 24             	mov    %edi,(%esp)
80104f58:	e8 03 c9 ff ff       	call   80101860 <ilock>
    if(type == T_FILE && ip->type == T_FILE)
80104f5d:	83 c4 10             	add    $0x10,%esp
80104f60:	66 83 7d d6 02       	cmpw   $0x2,-0x2a(%ebp)
80104f65:	75 19                	jne    80104f80 <create+0x80>
80104f67:	66 83 7f 50 02       	cmpw   $0x2,0x50(%edi)
80104f6c:	75 12                	jne    80104f80 <create+0x80>
    panic("create: dirlink");

  iunlockput(dp);

  return ip;
}
80104f6e:	89 f8                	mov    %edi,%eax
80104f70:	8b 75 f8             	mov    -0x8(%ebp),%esi
80104f73:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80104f76:	8b 7d fc             	mov    -0x4(%ebp),%edi
80104f79:	c9                   	leave
80104f7a:	c3                   	ret
80104f7b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    iunlockput(ip);
80104f80:	83 ec 0c             	sub    $0xc,%esp
80104f83:	57                   	push   %edi
    return 0;
80104f84:	31 ff                	xor    %edi,%edi
    iunlockput(ip);
80104f86:	e8 85 cb ff ff       	call   80101b10 <iunlockput>
}
80104f8b:	89 f8                	mov    %edi,%eax
    return 0;
80104f8d:	8b 75 f8             	mov    -0x8(%ebp),%esi
}
80104f90:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80104f93:	8b 7d fc             	mov    -0x4(%ebp),%edi
    return 0;
80104f96:	83 c4 10             	add    $0x10,%esp
}
80104f99:	c9                   	leave
80104f9a:	c3                   	ret
80104f9b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  if((ip = ialloc(dp->dev, type)) == 0)
80104fa0:	0f bf 45 d6          	movswl -0x2a(%ebp),%eax
80104fa4:	83 ec 08             	sub    $0x8,%esp
80104fa7:	50                   	push   %eax
80104fa8:	ff 36                	push   (%esi)
80104faa:	e8 31 c7 ff ff       	call   801016e0 <ialloc>
80104faf:	83 c4 10             	add    $0x10,%esp
80104fb2:	89 c7                	mov    %eax,%edi
80104fb4:	85 c0                	test   %eax,%eax
80104fb6:	0f 84 cd 00 00 00    	je     80105089 <create+0x189>
  ilock(ip);
80104fbc:	83 ec 0c             	sub    $0xc,%esp
80104fbf:	50                   	push   %eax
80104fc0:	e8 9b c8 ff ff       	call   80101860 <ilock>
  ip->major = major;
80104fc5:	0f b7 45 d4          	movzwl -0x2c(%ebp),%eax
80104fc9:	66 89 47 52          	mov    %ax,0x52(%edi)
  ip->minor = minor;
80104fcd:	0f b7 45 08          	movzwl 0x8(%ebp),%eax
80104fd1:	66 89 47 54          	mov    %ax,0x54(%edi)
  ip->nlink = 1;
80104fd5:	b8 01 00 00 00       	mov    $0x1,%eax
80104fda:	66 89 47 56          	mov    %ax,0x56(%edi)
  iupdate(ip);
80104fde:	89 3c 24             	mov    %edi,(%esp)
80104fe1:	e8 ba c7 ff ff       	call   801017a0 <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
80104fe6:	83 c4 10             	add    $0x10,%esp
80104fe9:	66 83 7d d6 01       	cmpw   $0x1,-0x2a(%ebp)
80104fee:	74 30                	je     80105020 <create+0x120>
  if(dirlink(dp, name, ip->inum) < 0)
80104ff0:	83 ec 04             	sub    $0x4,%esp
80104ff3:	ff 77 04             	push   0x4(%edi)
80104ff6:	53                   	push   %ebx
80104ff7:	56                   	push   %esi
80104ff8:	e8 33 d1 ff ff       	call   80102130 <dirlink>
80104ffd:	83 c4 10             	add    $0x10,%esp
80105000:	85 c0                	test   %eax,%eax
80105002:	78 78                	js     8010507c <create+0x17c>
  iunlockput(dp);
80105004:	83 ec 0c             	sub    $0xc,%esp
80105007:	56                   	push   %esi
80105008:	e8 03 cb ff ff       	call   80101b10 <iunlockput>
}
8010500d:	89 f8                	mov    %edi,%eax
  return ip;
8010500f:	8b 75 f8             	mov    -0x8(%ebp),%esi
}
80105012:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80105015:	8b 7d fc             	mov    -0x4(%ebp),%edi
  return ip;
80105018:	83 c4 10             	add    $0x10,%esp
}
8010501b:	c9                   	leave
8010501c:	c3                   	ret
8010501d:	8d 76 00             	lea    0x0(%esi),%esi
    iupdate(dp);
80105020:	83 ec 0c             	sub    $0xc,%esp
    dp->nlink++;  // for ".."
80105023:	66 83 46 56 01       	addw   $0x1,0x56(%esi)
    iupdate(dp);
80105028:	56                   	push   %esi
80105029:	e8 72 c7 ff ff       	call   801017a0 <iupdate>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
8010502e:	83 c4 0c             	add    $0xc,%esp
80105031:	ff 77 04             	push   0x4(%edi)
80105034:	68 e9 7c 10 80       	push   $0x80107ce9
80105039:	57                   	push   %edi
8010503a:	e8 f1 d0 ff ff       	call   80102130 <dirlink>
8010503f:	83 c4 10             	add    $0x10,%esp
80105042:	85 c0                	test   %eax,%eax
80105044:	78 18                	js     8010505e <create+0x15e>
80105046:	83 ec 04             	sub    $0x4,%esp
80105049:	ff 76 04             	push   0x4(%esi)
8010504c:	68 e8 7c 10 80       	push   $0x80107ce8
80105051:	57                   	push   %edi
80105052:	e8 d9 d0 ff ff       	call   80102130 <dirlink>
80105057:	83 c4 10             	add    $0x10,%esp
8010505a:	85 c0                	test   %eax,%eax
8010505c:	79 92                	jns    80104ff0 <create+0xf0>
      panic("create dots");
8010505e:	83 ec 0c             	sub    $0xc,%esp
80105061:	68 dc 7c 10 80       	push   $0x80107cdc
80105066:	e8 35 b3 ff ff       	call   801003a0 <panic>
8010506b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    return 0;
80105070:	31 ff                	xor    %edi,%edi
}
80105072:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80105075:	89 f8                	mov    %edi,%eax
80105077:	8b 7d fc             	mov    -0x4(%ebp),%edi
8010507a:	c9                   	leave
8010507b:	c3                   	ret
    panic("create: dirlink");
8010507c:	83 ec 0c             	sub    $0xc,%esp
8010507f:	68 eb 7c 10 80       	push   $0x80107ceb
80105084:	e8 17 b3 ff ff       	call   801003a0 <panic>
    panic("create: ialloc");
80105089:	83 ec 0c             	sub    $0xc,%esp
8010508c:	68 cd 7c 10 80       	push   $0x80107ccd
80105091:	e8 0a b3 ff ff       	call   801003a0 <panic>
80105096:	66 90                	xchg   %ax,%ax
80105098:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010509f:	00 

801050a0 <sys_dup>:
{
801050a0:	55                   	push   %ebp
801050a1:	89 e5                	mov    %esp,%ebp
801050a3:	83 ec 20             	sub    $0x20,%esp
  if(argint(n, &fd) < 0)
801050a6:	8d 45 f4             	lea    -0xc(%ebp),%eax
{
801050a9:	89 5d f8             	mov    %ebx,-0x8(%ebp)
  if(argint(n, &fd) < 0)
801050ac:	50                   	push   %eax
801050ad:	6a 00                	push   $0x0
801050af:	e8 9c fc ff ff       	call   80104d50 <argint>
801050b4:	83 c4 10             	add    $0x10,%esp
801050b7:	85 c0                	test   %eax,%eax
801050b9:	78 38                	js     801050f3 <sys_dup+0x53>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
801050bb:	83 7d f4 0f          	cmpl   $0xf,-0xc(%ebp)
801050bf:	77 32                	ja     801050f3 <sys_dup+0x53>
801050c1:	89 75 fc             	mov    %esi,-0x4(%ebp)
801050c4:	e8 d7 ea ff ff       	call   80103ba0 <myproc>
801050c9:	8b 55 f4             	mov    -0xc(%ebp),%edx
801050cc:	8b 74 90 28          	mov    0x28(%eax,%edx,4),%esi
801050d0:	85 f6                	test   %esi,%esi
801050d2:	74 1c                	je     801050f0 <sys_dup+0x50>
  struct proc *curproc = myproc();
801050d4:	e8 c7 ea ff ff       	call   80103ba0 <myproc>
  for(fd = 0; fd < NOFILE; fd++){
801050d9:	31 db                	xor    %ebx,%ebx
801050db:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    if(curproc->ofile[fd] == 0){
801050e0:	8b 54 98 28          	mov    0x28(%eax,%ebx,4),%edx
801050e4:	85 d2                	test   %edx,%edx
801050e6:	74 18                	je     80105100 <sys_dup+0x60>
  for(fd = 0; fd < NOFILE; fd++){
801050e8:	83 c3 01             	add    $0x1,%ebx
801050eb:	83 fb 10             	cmp    $0x10,%ebx
801050ee:	75 f0                	jne    801050e0 <sys_dup+0x40>
801050f0:	8b 75 fc             	mov    -0x4(%ebp),%esi
    return -1;
801050f3:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
}
801050f8:	89 d8                	mov    %ebx,%eax
801050fa:	8b 5d f8             	mov    -0x8(%ebp),%ebx
801050fd:	c9                   	leave
801050fe:	c3                   	ret
801050ff:	90                   	nop
  filedup(f);
80105100:	83 ec 0c             	sub    $0xc,%esp
      curproc->ofile[fd] = f;
80105103:	89 74 98 28          	mov    %esi,0x28(%eax,%ebx,4)
  filedup(f);
80105107:	56                   	push   %esi
80105108:	e8 43 be ff ff       	call   80100f50 <filedup>
}
8010510d:	89 d8                	mov    %ebx,%eax
  return fd;
8010510f:	8b 75 fc             	mov    -0x4(%ebp),%esi
}
80105112:	8b 5d f8             	mov    -0x8(%ebp),%ebx
  return fd;
80105115:	83 c4 10             	add    $0x10,%esp
}
80105118:	c9                   	leave
80105119:	c3                   	ret
8010511a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80105120 <sys_read>:
{
80105120:	55                   	push   %ebp
80105121:	89 e5                	mov    %esp,%ebp
80105123:	83 ec 20             	sub    $0x20,%esp
80105126:	89 5d f8             	mov    %ebx,-0x8(%ebp)
  if(argint(n, &fd) < 0)
80105129:	8d 5d f4             	lea    -0xc(%ebp),%ebx
8010512c:	53                   	push   %ebx
8010512d:	6a 00                	push   $0x0
8010512f:	e8 1c fc ff ff       	call   80104d50 <argint>
80105134:	83 c4 10             	add    $0x10,%esp
80105137:	85 c0                	test   %eax,%eax
80105139:	78 68                	js     801051a3 <sys_read+0x83>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
8010513b:	83 7d f4 0f          	cmpl   $0xf,-0xc(%ebp)
8010513f:	77 62                	ja     801051a3 <sys_read+0x83>
80105141:	89 75 fc             	mov    %esi,-0x4(%ebp)
80105144:	e8 57 ea ff ff       	call   80103ba0 <myproc>
80105149:	8b 55 f4             	mov    -0xc(%ebp),%edx
8010514c:	8b 74 90 28          	mov    0x28(%eax,%edx,4),%esi
80105150:	85 f6                	test   %esi,%esi
80105152:	74 4c                	je     801051a0 <sys_read+0x80>
  if(argfd(0, 0, &f) < 0 || argint(2, &n) < 0 || argptr(1, &p, n) < 0)
80105154:	83 ec 08             	sub    $0x8,%esp
80105157:	8d 45 f0             	lea    -0x10(%ebp),%eax
8010515a:	50                   	push   %eax
8010515b:	6a 02                	push   $0x2
8010515d:	e8 ee fb ff ff       	call   80104d50 <argint>
80105162:	83 c4 10             	add    $0x10,%esp
80105165:	85 c0                	test   %eax,%eax
80105167:	78 37                	js     801051a0 <sys_read+0x80>
80105169:	83 ec 04             	sub    $0x4,%esp
8010516c:	ff 75 f0             	push   -0x10(%ebp)
8010516f:	53                   	push   %ebx
80105170:	6a 01                	push   $0x1
80105172:	e8 29 fc ff ff       	call   80104da0 <argptr>
80105177:	83 c4 10             	add    $0x10,%esp
8010517a:	85 c0                	test   %eax,%eax
8010517c:	78 22                	js     801051a0 <sys_read+0x80>
  return fileread(f, p, n);
8010517e:	83 ec 04             	sub    $0x4,%esp
80105181:	ff 75 f0             	push   -0x10(%ebp)
80105184:	ff 75 f4             	push   -0xc(%ebp)
80105187:	56                   	push   %esi
80105188:	e8 43 bf ff ff       	call   801010d0 <fileread>
8010518d:	8b 75 fc             	mov    -0x4(%ebp),%esi
80105190:	83 c4 10             	add    $0x10,%esp
}
80105193:	8b 5d f8             	mov    -0x8(%ebp),%ebx
80105196:	c9                   	leave
80105197:	c3                   	ret
80105198:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010519f:	00 
801051a0:	8b 75 fc             	mov    -0x4(%ebp),%esi
    return -1;
801051a3:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801051a8:	eb e9                	jmp    80105193 <sys_read+0x73>
801051aa:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

801051b0 <sys_write>:
{
801051b0:	55                   	push   %ebp
801051b1:	89 e5                	mov    %esp,%ebp
801051b3:	83 ec 20             	sub    $0x20,%esp
801051b6:	89 5d f8             	mov    %ebx,-0x8(%ebp)
  if(argint(n, &fd) < 0)
801051b9:	8d 5d f4             	lea    -0xc(%ebp),%ebx
801051bc:	53                   	push   %ebx
801051bd:	6a 00                	push   $0x0
801051bf:	e8 8c fb ff ff       	call   80104d50 <argint>
801051c4:	83 c4 10             	add    $0x10,%esp
801051c7:	85 c0                	test   %eax,%eax
801051c9:	78 68                	js     80105233 <sys_write+0x83>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
801051cb:	83 7d f4 0f          	cmpl   $0xf,-0xc(%ebp)
801051cf:	77 62                	ja     80105233 <sys_write+0x83>
801051d1:	89 75 fc             	mov    %esi,-0x4(%ebp)
801051d4:	e8 c7 e9 ff ff       	call   80103ba0 <myproc>
801051d9:	8b 55 f4             	mov    -0xc(%ebp),%edx
801051dc:	8b 74 90 28          	mov    0x28(%eax,%edx,4),%esi
801051e0:	85 f6                	test   %esi,%esi
801051e2:	74 4c                	je     80105230 <sys_write+0x80>
  if(argfd(0, 0, &f) < 0 || argint(2, &n) < 0 || argptr(1, &p, n) < 0)
801051e4:	83 ec 08             	sub    $0x8,%esp
801051e7:	8d 45 f0             	lea    -0x10(%ebp),%eax
801051ea:	50                   	push   %eax
801051eb:	6a 02                	push   $0x2
801051ed:	e8 5e fb ff ff       	call   80104d50 <argint>
801051f2:	83 c4 10             	add    $0x10,%esp
801051f5:	85 c0                	test   %eax,%eax
801051f7:	78 37                	js     80105230 <sys_write+0x80>
801051f9:	83 ec 04             	sub    $0x4,%esp
801051fc:	ff 75 f0             	push   -0x10(%ebp)
801051ff:	53                   	push   %ebx
80105200:	6a 01                	push   $0x1
80105202:	e8 99 fb ff ff       	call   80104da0 <argptr>
80105207:	83 c4 10             	add    $0x10,%esp
8010520a:	85 c0                	test   %eax,%eax
8010520c:	78 22                	js     80105230 <sys_write+0x80>
  return filewrite(f, p, n);
8010520e:	83 ec 04             	sub    $0x4,%esp
80105211:	ff 75 f0             	push   -0x10(%ebp)
80105214:	ff 75 f4             	push   -0xc(%ebp)
80105217:	56                   	push   %esi
80105218:	e8 43 bf ff ff       	call   80101160 <filewrite>
8010521d:	8b 75 fc             	mov    -0x4(%ebp),%esi
80105220:	83 c4 10             	add    $0x10,%esp
}
80105223:	8b 5d f8             	mov    -0x8(%ebp),%ebx
80105226:	c9                   	leave
80105227:	c3                   	ret
80105228:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010522f:	00 
80105230:	8b 75 fc             	mov    -0x4(%ebp),%esi
    return -1;
80105233:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105238:	eb e9                	jmp    80105223 <sys_write+0x73>
8010523a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80105240 <sys_close>:
{
80105240:	55                   	push   %ebp
80105241:	89 e5                	mov    %esp,%ebp
80105243:	83 ec 20             	sub    $0x20,%esp
  if(argint(n, &fd) < 0)
80105246:	8d 45 f4             	lea    -0xc(%ebp),%eax
80105249:	50                   	push   %eax
8010524a:	6a 00                	push   $0x0
8010524c:	e8 ff fa ff ff       	call   80104d50 <argint>
80105251:	83 c4 10             	add    $0x10,%esp
80105254:	85 c0                	test   %eax,%eax
80105256:	78 48                	js     801052a0 <sys_close+0x60>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
80105258:	83 7d f4 0f          	cmpl   $0xf,-0xc(%ebp)
8010525c:	77 42                	ja     801052a0 <sys_close+0x60>
8010525e:	89 5d f8             	mov    %ebx,-0x8(%ebp)
80105261:	89 75 fc             	mov    %esi,-0x4(%ebp)
80105264:	e8 37 e9 ff ff       	call   80103ba0 <myproc>
80105269:	8b 55 f4             	mov    -0xc(%ebp),%edx
8010526c:	8d 5a 08             	lea    0x8(%edx),%ebx
8010526f:	8b 74 98 08          	mov    0x8(%eax,%ebx,4),%esi
80105273:	85 f6                	test   %esi,%esi
80105275:	74 23                	je     8010529a <sys_close+0x5a>
  myproc()->ofile[fd] = 0;
80105277:	e8 24 e9 ff ff       	call   80103ba0 <myproc>
  fileclose(f);
8010527c:	83 ec 0c             	sub    $0xc,%esp
  myproc()->ofile[fd] = 0;
8010527f:	c7 44 98 08 00 00 00 	movl   $0x0,0x8(%eax,%ebx,4)
80105286:	00 
  fileclose(f);
80105287:	56                   	push   %esi
80105288:	e8 13 bd ff ff       	call   80100fa0 <fileclose>
  return 0;
8010528d:	8b 5d f8             	mov    -0x8(%ebp),%ebx
80105290:	8b 75 fc             	mov    -0x4(%ebp),%esi
80105293:	83 c4 10             	add    $0x10,%esp
}
80105296:	c9                   	leave
  return 0;
80105297:	31 c0                	xor    %eax,%eax
}
80105299:	c3                   	ret
8010529a:	8b 5d f8             	mov    -0x8(%ebp),%ebx
8010529d:	8b 75 fc             	mov    -0x4(%ebp),%esi
801052a0:	c9                   	leave
    return -1;
801052a1:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
801052a6:	c3                   	ret
801052a7:	90                   	nop
801052a8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801052af:	00 

801052b0 <sys_fstat>:
{
801052b0:	55                   	push   %ebp
801052b1:	89 e5                	mov    %esp,%ebp
801052b3:	83 ec 20             	sub    $0x20,%esp
801052b6:	89 5d f8             	mov    %ebx,-0x8(%ebp)
  if(argint(n, &fd) < 0)
801052b9:	8d 5d f4             	lea    -0xc(%ebp),%ebx
801052bc:	53                   	push   %ebx
801052bd:	6a 00                	push   $0x0
801052bf:	e8 8c fa ff ff       	call   80104d50 <argint>
801052c4:	83 c4 10             	add    $0x10,%esp
801052c7:	85 c0                	test   %eax,%eax
801052c9:	78 48                	js     80105313 <sys_fstat+0x63>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
801052cb:	83 7d f4 0f          	cmpl   $0xf,-0xc(%ebp)
801052cf:	77 42                	ja     80105313 <sys_fstat+0x63>
801052d1:	89 75 fc             	mov    %esi,-0x4(%ebp)
801052d4:	e8 c7 e8 ff ff       	call   80103ba0 <myproc>
801052d9:	8b 55 f4             	mov    -0xc(%ebp),%edx
801052dc:	8b 74 90 28          	mov    0x28(%eax,%edx,4),%esi
801052e0:	85 f6                	test   %esi,%esi
801052e2:	74 2c                	je     80105310 <sys_fstat+0x60>
  if(argfd(0, 0, &f) < 0 || argptr(1, (void*)&st, sizeof(*st)) < 0)
801052e4:	83 ec 04             	sub    $0x4,%esp
801052e7:	6a 14                	push   $0x14
801052e9:	53                   	push   %ebx
801052ea:	6a 01                	push   $0x1
801052ec:	e8 af fa ff ff       	call   80104da0 <argptr>
801052f1:	83 c4 10             	add    $0x10,%esp
801052f4:	85 c0                	test   %eax,%eax
801052f6:	78 18                	js     80105310 <sys_fstat+0x60>
  return filestat(f, st);
801052f8:	83 ec 08             	sub    $0x8,%esp
801052fb:	ff 75 f4             	push   -0xc(%ebp)
801052fe:	56                   	push   %esi
801052ff:	e8 7c bd ff ff       	call   80101080 <filestat>
80105304:	8b 75 fc             	mov    -0x4(%ebp),%esi
80105307:	83 c4 10             	add    $0x10,%esp
}
8010530a:	8b 5d f8             	mov    -0x8(%ebp),%ebx
8010530d:	c9                   	leave
8010530e:	c3                   	ret
8010530f:	90                   	nop
80105310:	8b 75 fc             	mov    -0x4(%ebp),%esi
    return -1;
80105313:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105318:	eb f0                	jmp    8010530a <sys_fstat+0x5a>
8010531a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80105320 <sys_link>:
{
80105320:	55                   	push   %ebp
80105321:	89 e5                	mov    %esp,%ebp
80105323:	83 ec 40             	sub    $0x40,%esp
  if(argstr(0, &old) < 0 || argstr(1, &new) < 0)
80105326:	8d 45 d4             	lea    -0x2c(%ebp),%eax
80105329:	50                   	push   %eax
8010532a:	6a 00                	push   $0x0
8010532c:	e8 df fa ff ff       	call   80104e10 <argstr>
80105331:	83 c4 10             	add    $0x10,%esp
80105334:	85 c0                	test   %eax,%eax
80105336:	0f 88 0f 01 00 00    	js     8010544b <sys_link+0x12b>
8010533c:	83 ec 08             	sub    $0x8,%esp
8010533f:	8d 45 d0             	lea    -0x30(%ebp),%eax
80105342:	50                   	push   %eax
80105343:	6a 01                	push   $0x1
80105345:	e8 c6 fa ff ff       	call   80104e10 <argstr>
8010534a:	83 c4 10             	add    $0x10,%esp
8010534d:	85 c0                	test   %eax,%eax
8010534f:	0f 88 f6 00 00 00    	js     8010544b <sys_link+0x12b>
80105355:	89 5d f4             	mov    %ebx,-0xc(%ebp)
  begin_op();
80105358:	e8 e3 db ff ff       	call   80102f40 <begin_op>
  if((ip = namei(old)) == 0){
8010535d:	83 ec 0c             	sub    $0xc,%esp
80105360:	ff 75 d4             	push   -0x2c(%ebp)
80105363:	e8 88 ce ff ff       	call   801021f0 <namei>
80105368:	83 c4 10             	add    $0x10,%esp
8010536b:	89 c3                	mov    %eax,%ebx
8010536d:	85 c0                	test   %eax,%eax
8010536f:	0f 84 f3 00 00 00    	je     80105468 <sys_link+0x148>
  ilock(ip);
80105375:	83 ec 0c             	sub    $0xc,%esp
80105378:	50                   	push   %eax
80105379:	e8 e2 c4 ff ff       	call   80101860 <ilock>
  if(ip->type == T_DIR){
8010537e:	83 c4 10             	add    $0x10,%esp
80105381:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
80105386:	0f 84 c6 00 00 00    	je     80105452 <sys_link+0x132>
  iupdate(ip);
8010538c:	83 ec 0c             	sub    $0xc,%esp
8010538f:	89 75 f8             	mov    %esi,-0x8(%ebp)
80105392:	89 7d fc             	mov    %edi,-0x4(%ebp)
  if((dp = nameiparent(new, name)) == 0)
80105395:	8d 7d da             	lea    -0x26(%ebp),%edi
  ip->nlink++;
80105398:	66 83 43 56 01       	addw   $0x1,0x56(%ebx)
  iupdate(ip);
8010539d:	53                   	push   %ebx
8010539e:	e8 fd c3 ff ff       	call   801017a0 <iupdate>
  iunlock(ip);
801053a3:	89 1c 24             	mov    %ebx,(%esp)
801053a6:	e8 95 c5 ff ff       	call   80101940 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
801053ab:	58                   	pop    %eax
801053ac:	5a                   	pop    %edx
801053ad:	57                   	push   %edi
801053ae:	ff 75 d0             	push   -0x30(%ebp)
801053b1:	e8 5a ce ff ff       	call   80102210 <nameiparent>
801053b6:	83 c4 10             	add    $0x10,%esp
801053b9:	89 c6                	mov    %eax,%esi
801053bb:	85 c0                	test   %eax,%eax
801053bd:	74 5d                	je     8010541c <sys_link+0xfc>
  ilock(dp);
801053bf:	83 ec 0c             	sub    $0xc,%esp
801053c2:	50                   	push   %eax
801053c3:	e8 98 c4 ff ff       	call   80101860 <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
801053c8:	8b 03                	mov    (%ebx),%eax
801053ca:	83 c4 10             	add    $0x10,%esp
801053cd:	39 06                	cmp    %eax,(%esi)
801053cf:	75 3f                	jne    80105410 <sys_link+0xf0>
801053d1:	83 ec 04             	sub    $0x4,%esp
801053d4:	ff 73 04             	push   0x4(%ebx)
801053d7:	57                   	push   %edi
801053d8:	56                   	push   %esi
801053d9:	e8 52 cd ff ff       	call   80102130 <dirlink>
801053de:	83 c4 10             	add    $0x10,%esp
801053e1:	85 c0                	test   %eax,%eax
801053e3:	78 2b                	js     80105410 <sys_link+0xf0>
  iunlockput(dp);
801053e5:	83 ec 0c             	sub    $0xc,%esp
801053e8:	56                   	push   %esi
801053e9:	e8 22 c7 ff ff       	call   80101b10 <iunlockput>
  iput(ip);
801053ee:	89 1c 24             	mov    %ebx,(%esp)
801053f1:	e8 9a c5 ff ff       	call   80101990 <iput>
  end_op();
801053f6:	e8 b5 db ff ff       	call   80102fb0 <end_op>
  return 0;
801053fb:	8b 5d f4             	mov    -0xc(%ebp),%ebx
801053fe:	8b 75 f8             	mov    -0x8(%ebp),%esi
80105401:	83 c4 10             	add    $0x10,%esp
80105404:	8b 7d fc             	mov    -0x4(%ebp),%edi
80105407:	31 c0                	xor    %eax,%eax
}
80105409:	c9                   	leave
8010540a:	c3                   	ret
8010540b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    iunlockput(dp);
80105410:	83 ec 0c             	sub    $0xc,%esp
80105413:	56                   	push   %esi
80105414:	e8 f7 c6 ff ff       	call   80101b10 <iunlockput>
    goto bad;
80105419:	83 c4 10             	add    $0x10,%esp
  ilock(ip);
8010541c:	83 ec 0c             	sub    $0xc,%esp
8010541f:	53                   	push   %ebx
80105420:	e8 3b c4 ff ff       	call   80101860 <ilock>
  ip->nlink--;
80105425:	66 83 6b 56 01       	subw   $0x1,0x56(%ebx)
  iupdate(ip);
8010542a:	89 1c 24             	mov    %ebx,(%esp)
8010542d:	e8 6e c3 ff ff       	call   801017a0 <iupdate>
  iunlockput(ip);
80105432:	89 1c 24             	mov    %ebx,(%esp)
80105435:	e8 d6 c6 ff ff       	call   80101b10 <iunlockput>
  end_op();
8010543a:	e8 71 db ff ff       	call   80102fb0 <end_op>
  return -1;
8010543f:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80105442:	8b 75 f8             	mov    -0x8(%ebp),%esi
80105445:	83 c4 10             	add    $0x10,%esp
80105448:	8b 7d fc             	mov    -0x4(%ebp),%edi
}
8010544b:	c9                   	leave
    return -1;
8010544c:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80105451:	c3                   	ret
    iunlockput(ip);
80105452:	83 ec 0c             	sub    $0xc,%esp
80105455:	53                   	push   %ebx
80105456:	e8 b5 c6 ff ff       	call   80101b10 <iunlockput>
    end_op();
8010545b:	e8 50 db ff ff       	call   80102fb0 <end_op>
    return -1;
80105460:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80105463:	83 c4 10             	add    $0x10,%esp
80105466:	eb e3                	jmp    8010544b <sys_link+0x12b>
    end_op();
80105468:	e8 43 db ff ff       	call   80102fb0 <end_op>
    return -1;
8010546d:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80105470:	eb d9                	jmp    8010544b <sys_link+0x12b>
80105472:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80105478:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010547f:	00 

80105480 <sys_unlink>:
{
80105480:	55                   	push   %ebp
80105481:	89 e5                	mov    %esp,%ebp
80105483:	83 ec 60             	sub    $0x60,%esp
  if(argstr(0, &path) < 0)
80105486:	8d 45 c0             	lea    -0x40(%ebp),%eax
80105489:	50                   	push   %eax
8010548a:	6a 00                	push   $0x0
8010548c:	e8 7f f9 ff ff       	call   80104e10 <argstr>
80105491:	83 c4 10             	add    $0x10,%esp
80105494:	85 c0                	test   %eax,%eax
80105496:	0f 88 6d 01 00 00    	js     80105609 <sys_unlink+0x189>
8010549c:	89 5d f4             	mov    %ebx,-0xc(%ebp)
  if((dp = nameiparent(path, name)) == 0){
8010549f:	8d 5d ca             	lea    -0x36(%ebp),%ebx
  begin_op();
801054a2:	e8 99 da ff ff       	call   80102f40 <begin_op>
  if((dp = nameiparent(path, name)) == 0){
801054a7:	83 ec 08             	sub    $0x8,%esp
801054aa:	53                   	push   %ebx
801054ab:	ff 75 c0             	push   -0x40(%ebp)
801054ae:	e8 5d cd ff ff       	call   80102210 <nameiparent>
801054b3:	83 c4 10             	add    $0x10,%esp
801054b6:	89 45 b4             	mov    %eax,-0x4c(%ebp)
801054b9:	85 c0                	test   %eax,%eax
801054bb:	0f 84 77 01 00 00    	je     80105638 <sys_unlink+0x1b8>
801054c1:	89 7d fc             	mov    %edi,-0x4(%ebp)
  ilock(dp);
801054c4:	8b 7d b4             	mov    -0x4c(%ebp),%edi
801054c7:	83 ec 0c             	sub    $0xc,%esp
801054ca:	57                   	push   %edi
801054cb:	e8 90 c3 ff ff       	call   80101860 <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
801054d0:	58                   	pop    %eax
801054d1:	5a                   	pop    %edx
801054d2:	68 e9 7c 10 80       	push   $0x80107ce9
801054d7:	53                   	push   %ebx
801054d8:	e8 03 c9 ff ff       	call   80101de0 <namecmp>
801054dd:	83 c4 10             	add    $0x10,%esp
801054e0:	85 c0                	test   %eax,%eax
801054e2:	0f 84 08 01 00 00    	je     801055f0 <sys_unlink+0x170>
801054e8:	83 ec 08             	sub    $0x8,%esp
801054eb:	68 e8 7c 10 80       	push   $0x80107ce8
801054f0:	53                   	push   %ebx
801054f1:	e8 ea c8 ff ff       	call   80101de0 <namecmp>
801054f6:	83 c4 10             	add    $0x10,%esp
801054f9:	85 c0                	test   %eax,%eax
801054fb:	0f 84 ef 00 00 00    	je     801055f0 <sys_unlink+0x170>
  if((ip = dirlookup(dp, name, &off)) == 0)
80105501:	83 ec 04             	sub    $0x4,%esp
80105504:	8d 45 c4             	lea    -0x3c(%ebp),%eax
80105507:	50                   	push   %eax
80105508:	53                   	push   %ebx
80105509:	57                   	push   %edi
8010550a:	e8 f1 c8 ff ff       	call   80101e00 <dirlookup>
8010550f:	83 c4 10             	add    $0x10,%esp
80105512:	89 c3                	mov    %eax,%ebx
80105514:	85 c0                	test   %eax,%eax
80105516:	0f 84 d4 00 00 00    	je     801055f0 <sys_unlink+0x170>
  ilock(ip);
8010551c:	83 ec 0c             	sub    $0xc,%esp
8010551f:	50                   	push   %eax
80105520:	e8 3b c3 ff ff       	call   80101860 <ilock>
  if(ip->nlink < 1)
80105525:	83 c4 10             	add    $0x10,%esp
80105528:	66 83 7b 56 00       	cmpw   $0x0,0x56(%ebx)
8010552d:	0f 8e 2c 01 00 00    	jle    8010565f <sys_unlink+0x1df>
  if(ip->type == T_DIR && !isdirempty(ip)){
80105533:	8d 7d d8             	lea    -0x28(%ebp),%edi
80105536:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
8010553b:	74 6b                	je     801055a8 <sys_unlink+0x128>
  memset(&de, 0, sizeof(de));
8010553d:	83 ec 04             	sub    $0x4,%esp
80105540:	6a 10                	push   $0x10
80105542:	6a 00                	push   $0x0
80105544:	57                   	push   %edi
80105545:	e8 16 f5 ff ff       	call   80104a60 <memset>
  if(writei(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
8010554a:	6a 10                	push   $0x10
8010554c:	ff 75 c4             	push   -0x3c(%ebp)
8010554f:	57                   	push   %edi
80105550:	ff 75 b4             	push   -0x4c(%ebp)
80105553:	e8 58 c7 ff ff       	call   80101cb0 <writei>
80105558:	83 c4 20             	add    $0x20,%esp
8010555b:	83 f8 10             	cmp    $0x10,%eax
8010555e:	0f 85 eb 00 00 00    	jne    8010564f <sys_unlink+0x1cf>
  if(ip->type == T_DIR){
80105564:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
80105569:	0f 84 a1 00 00 00    	je     80105610 <sys_unlink+0x190>
  iunlockput(dp);
8010556f:	83 ec 0c             	sub    $0xc,%esp
80105572:	ff 75 b4             	push   -0x4c(%ebp)
80105575:	e8 96 c5 ff ff       	call   80101b10 <iunlockput>
  ip->nlink--;
8010557a:	66 83 6b 56 01       	subw   $0x1,0x56(%ebx)
  iupdate(ip);
8010557f:	89 1c 24             	mov    %ebx,(%esp)
80105582:	e8 19 c2 ff ff       	call   801017a0 <iupdate>
  iunlockput(ip);
80105587:	89 1c 24             	mov    %ebx,(%esp)
8010558a:	e8 81 c5 ff ff       	call   80101b10 <iunlockput>
  end_op();
8010558f:	e8 1c da ff ff       	call   80102fb0 <end_op>
  return 0;
80105594:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80105597:	8b 7d fc             	mov    -0x4(%ebp),%edi
8010559a:	83 c4 10             	add    $0x10,%esp
}
8010559d:	c9                   	leave
  return 0;
8010559e:	31 c0                	xor    %eax,%eax
}
801055a0:	c3                   	ret
801055a1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
801055a8:	83 7b 58 20          	cmpl   $0x20,0x58(%ebx)
801055ac:	76 8f                	jbe    8010553d <sys_unlink+0xbd>
801055ae:	89 75 f8             	mov    %esi,-0x8(%ebp)
801055b1:	be 20 00 00 00       	mov    $0x20,%esi
801055b6:	eb 10                	jmp    801055c8 <sys_unlink+0x148>
801055b8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801055bf:	00 
801055c0:	83 c6 10             	add    $0x10,%esi
801055c3:	3b 73 58             	cmp    0x58(%ebx),%esi
801055c6:	73 68                	jae    80105630 <sys_unlink+0x1b0>
    if(readi(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
801055c8:	6a 10                	push   $0x10
801055ca:	56                   	push   %esi
801055cb:	57                   	push   %edi
801055cc:	53                   	push   %ebx
801055cd:	e8 be c5 ff ff       	call   80101b90 <readi>
801055d2:	83 c4 10             	add    $0x10,%esp
801055d5:	83 f8 10             	cmp    $0x10,%eax
801055d8:	75 68                	jne    80105642 <sys_unlink+0x1c2>
    if(de.inum != 0)
801055da:	66 83 7d d8 00       	cmpw   $0x0,-0x28(%ebp)
801055df:	74 df                	je     801055c0 <sys_unlink+0x140>
    iunlockput(ip);
801055e1:	83 ec 0c             	sub    $0xc,%esp
801055e4:	53                   	push   %ebx
801055e5:	e8 26 c5 ff ff       	call   80101b10 <iunlockput>
    goto bad;
801055ea:	8b 75 f8             	mov    -0x8(%ebp),%esi
801055ed:	83 c4 10             	add    $0x10,%esp
  iunlockput(dp);
801055f0:	83 ec 0c             	sub    $0xc,%esp
801055f3:	ff 75 b4             	push   -0x4c(%ebp)
801055f6:	e8 15 c5 ff ff       	call   80101b10 <iunlockput>
  end_op();
801055fb:	e8 b0 d9 ff ff       	call   80102fb0 <end_op>
  return -1;
80105600:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80105603:	8b 7d fc             	mov    -0x4(%ebp),%edi
80105606:	83 c4 10             	add    $0x10,%esp
}
80105609:	c9                   	leave
    return -1;
8010560a:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
8010560f:	c3                   	ret
    dp->nlink--;
80105610:	8b 45 b4             	mov    -0x4c(%ebp),%eax
    iupdate(dp);
80105613:	83 ec 0c             	sub    $0xc,%esp
    dp->nlink--;
80105616:	66 83 68 56 01       	subw   $0x1,0x56(%eax)
    iupdate(dp);
8010561b:	50                   	push   %eax
8010561c:	e8 7f c1 ff ff       	call   801017a0 <iupdate>
80105621:	83 c4 10             	add    $0x10,%esp
80105624:	e9 46 ff ff ff       	jmp    8010556f <sys_unlink+0xef>
80105629:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80105630:	8b 75 f8             	mov    -0x8(%ebp),%esi
80105633:	e9 05 ff ff ff       	jmp    8010553d <sys_unlink+0xbd>
    end_op();
80105638:	e8 73 d9 ff ff       	call   80102fb0 <end_op>
8010563d:	8b 5d f4             	mov    -0xc(%ebp),%ebx
    return -1;
80105640:	eb c7                	jmp    80105609 <sys_unlink+0x189>
      panic("isdirempty: readi");
80105642:	83 ec 0c             	sub    $0xc,%esp
80105645:	68 0d 7d 10 80       	push   $0x80107d0d
8010564a:	e8 51 ad ff ff       	call   801003a0 <panic>
    panic("unlink: writei");
8010564f:	83 ec 0c             	sub    $0xc,%esp
80105652:	89 75 f8             	mov    %esi,-0x8(%ebp)
80105655:	68 1f 7d 10 80       	push   $0x80107d1f
8010565a:	e8 41 ad ff ff       	call   801003a0 <panic>
    panic("unlink: nlink < 1");
8010565f:	83 ec 0c             	sub    $0xc,%esp
80105662:	89 75 f8             	mov    %esi,-0x8(%ebp)
80105665:	68 fb 7c 10 80       	push   $0x80107cfb
8010566a:	e8 31 ad ff ff       	call   801003a0 <panic>
8010566f:	90                   	nop

80105670 <sys_open>:

int
sys_open(void)
{
80105670:	55                   	push   %ebp
80105671:	89 e5                	mov    %esp,%ebp
80105673:	83 ec 30             	sub    $0x30,%esp
  char *path;
  int fd, omode;
  struct file *f;
  struct inode *ip;

  if(argstr(0, &path) < 0 || argint(1, &omode) < 0)
80105676:	8d 45 e0             	lea    -0x20(%ebp),%eax
{
80105679:	89 5d f4             	mov    %ebx,-0xc(%ebp)
  if(argstr(0, &path) < 0 || argint(1, &omode) < 0)
8010567c:	50                   	push   %eax
8010567d:	6a 00                	push   $0x0
8010567f:	e8 8c f7 ff ff       	call   80104e10 <argstr>
80105684:	83 c4 10             	add    $0x10,%esp
80105687:	85 c0                	test   %eax,%eax
80105689:	0f 88 a4 00 00 00    	js     80105733 <sys_open+0xc3>
8010568f:	83 ec 08             	sub    $0x8,%esp
80105692:	8d 45 e4             	lea    -0x1c(%ebp),%eax
80105695:	50                   	push   %eax
80105696:	6a 01                	push   $0x1
80105698:	e8 b3 f6 ff ff       	call   80104d50 <argint>
8010569d:	83 c4 10             	add    $0x10,%esp
801056a0:	85 c0                	test   %eax,%eax
801056a2:	0f 88 8b 00 00 00    	js     80105733 <sys_open+0xc3>
801056a8:	89 7d fc             	mov    %edi,-0x4(%ebp)
    return -1;

  begin_op();
801056ab:	e8 90 d8 ff ff       	call   80102f40 <begin_op>

  if(omode & O_CREATE){
    ip = create(path, T_FILE, 0, 0);
801056b0:	8b 45 e0             	mov    -0x20(%ebp),%eax
  if(omode & O_CREATE){
801056b3:	f6 45 e5 02          	testb  $0x2,-0x1b(%ebp)
801056b7:	0f 85 83 00 00 00    	jne    80105740 <sys_open+0xd0>
    if(ip == 0){
      end_op();
      return -1;
    }
  } else {
    if((ip = namei(path)) == 0){
801056bd:	83 ec 0c             	sub    $0xc,%esp
801056c0:	50                   	push   %eax
801056c1:	e8 2a cb ff ff       	call   801021f0 <namei>
801056c6:	83 c4 10             	add    $0x10,%esp
801056c9:	89 c7                	mov    %eax,%edi
801056cb:	85 c0                	test   %eax,%eax
801056cd:	0f 84 87 00 00 00    	je     8010575a <sys_open+0xea>
      end_op();
      return -1;
    }
    ilock(ip);
801056d3:	83 ec 0c             	sub    $0xc,%esp
801056d6:	50                   	push   %eax
801056d7:	e8 84 c1 ff ff       	call   80101860 <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
801056dc:	83 c4 10             	add    $0x10,%esp
801056df:	66 83 7f 50 01       	cmpw   $0x1,0x50(%edi)
801056e4:	0f 84 c6 00 00 00    	je     801057b0 <sys_open+0x140>
801056ea:	89 75 f8             	mov    %esi,-0x8(%ebp)
      end_op();
      return -1;
    }
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
801056ed:	e8 ee b7 ff ff       	call   80100ee0 <filealloc>
801056f2:	89 c6                	mov    %eax,%esi
801056f4:	85 c0                	test   %eax,%eax
801056f6:	74 24                	je     8010571c <sys_open+0xac>
  struct proc *curproc = myproc();
801056f8:	e8 a3 e4 ff ff       	call   80103ba0 <myproc>
  for(fd = 0; fd < NOFILE; fd++){
801056fd:	31 db                	xor    %ebx,%ebx
801056ff:	90                   	nop
    if(curproc->ofile[fd] == 0){
80105700:	8b 54 98 28          	mov    0x28(%eax,%ebx,4),%edx
80105704:	85 d2                	test   %edx,%edx
80105706:	74 60                	je     80105768 <sys_open+0xf8>
  for(fd = 0; fd < NOFILE; fd++){
80105708:	83 c3 01             	add    $0x1,%ebx
8010570b:	83 fb 10             	cmp    $0x10,%ebx
8010570e:	75 f0                	jne    80105700 <sys_open+0x90>
    if(f)
      fileclose(f);
80105710:	83 ec 0c             	sub    $0xc,%esp
80105713:	56                   	push   %esi
80105714:	e8 87 b8 ff ff       	call   80100fa0 <fileclose>
80105719:	83 c4 10             	add    $0x10,%esp
    iunlockput(ip);
8010571c:	83 ec 0c             	sub    $0xc,%esp
8010571f:	57                   	push   %edi
80105720:	e8 eb c3 ff ff       	call   80101b10 <iunlockput>
    end_op();
80105725:	e8 86 d8 ff ff       	call   80102fb0 <end_op>
    return -1;
8010572a:	8b 75 f8             	mov    -0x8(%ebp),%esi
8010572d:	8b 7d fc             	mov    -0x4(%ebp),%edi
80105730:	83 c4 10             	add    $0x10,%esp
    return -1;
80105733:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
80105738:	eb 6d                	jmp    801057a7 <sys_open+0x137>
8010573a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    ip = create(path, T_FILE, 0, 0);
80105740:	83 ec 0c             	sub    $0xc,%esp
80105743:	31 c9                	xor    %ecx,%ecx
80105745:	ba 02 00 00 00       	mov    $0x2,%edx
8010574a:	6a 00                	push   $0x0
8010574c:	e8 af f7 ff ff       	call   80104f00 <create>
    if(ip == 0){
80105751:	83 c4 10             	add    $0x10,%esp
    ip = create(path, T_FILE, 0, 0);
80105754:	89 c7                	mov    %eax,%edi
    if(ip == 0){
80105756:	85 c0                	test   %eax,%eax
80105758:	75 90                	jne    801056ea <sys_open+0x7a>
      end_op();
8010575a:	e8 51 d8 ff ff       	call   80102fb0 <end_op>
8010575f:	8b 7d fc             	mov    -0x4(%ebp),%edi
      return -1;
80105762:	eb cf                	jmp    80105733 <sys_open+0xc3>
80105764:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  }
  iunlock(ip);
80105768:	83 ec 0c             	sub    $0xc,%esp
      curproc->ofile[fd] = f;
8010576b:	89 74 98 28          	mov    %esi,0x28(%eax,%ebx,4)
  iunlock(ip);
8010576f:	57                   	push   %edi
80105770:	e8 cb c1 ff ff       	call   80101940 <iunlock>
  end_op();
80105775:	e8 36 d8 ff ff       	call   80102fb0 <end_op>

  f->type = FD_INODE;
8010577a:	c7 06 02 00 00 00    	movl   $0x2,(%esi)
  f->ip = ip;
  f->off = 0;
  f->readable = !(omode & O_WRONLY);
80105780:	8b 55 e4             	mov    -0x1c(%ebp),%edx
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
80105783:	83 c4 10             	add    $0x10,%esp
  f->ip = ip;
80105786:	89 7e 10             	mov    %edi,0x10(%esi)
  f->readable = !(omode & O_WRONLY);
80105789:	89 d0                	mov    %edx,%eax
  f->off = 0;
8010578b:	c7 46 14 00 00 00 00 	movl   $0x0,0x14(%esi)
  f->readable = !(omode & O_WRONLY);
80105792:	f7 d0                	not    %eax
80105794:	83 e0 01             	and    $0x1,%eax
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
80105797:	83 e2 03             	and    $0x3,%edx
  f->readable = !(omode & O_WRONLY);
8010579a:	88 46 08             	mov    %al,0x8(%esi)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
8010579d:	0f 95 46 09          	setne  0x9(%esi)
  return fd;
801057a1:	8b 75 f8             	mov    -0x8(%ebp),%esi
801057a4:	8b 7d fc             	mov    -0x4(%ebp),%edi
}
801057a7:	89 d8                	mov    %ebx,%eax
801057a9:	8b 5d f4             	mov    -0xc(%ebp),%ebx
801057ac:	c9                   	leave
801057ad:	c3                   	ret
801057ae:	66 90                	xchg   %ax,%ax
    if(ip->type == T_DIR && omode != O_RDONLY){
801057b0:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
801057b3:	85 c9                	test   %ecx,%ecx
801057b5:	0f 84 2f ff ff ff    	je     801056ea <sys_open+0x7a>
      iunlockput(ip);
801057bb:	83 ec 0c             	sub    $0xc,%esp
801057be:	57                   	push   %edi
801057bf:	e8 4c c3 ff ff       	call   80101b10 <iunlockput>
      end_op();
801057c4:	e8 e7 d7 ff ff       	call   80102fb0 <end_op>
      return -1;
801057c9:	8b 7d fc             	mov    -0x4(%ebp),%edi
801057cc:	83 c4 10             	add    $0x10,%esp
801057cf:	e9 5f ff ff ff       	jmp    80105733 <sys_open+0xc3>
801057d4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
801057d8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801057df:	00 

801057e0 <sys_mkdir>:

int
sys_mkdir(void)
{
801057e0:	55                   	push   %ebp
801057e1:	89 e5                	mov    %esp,%ebp
801057e3:	83 ec 18             	sub    $0x18,%esp
  char *path;
  struct inode *ip;

  begin_op();
801057e6:	e8 55 d7 ff ff       	call   80102f40 <begin_op>
  if(argstr(0, &path) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
801057eb:	83 ec 08             	sub    $0x8,%esp
801057ee:	8d 45 f4             	lea    -0xc(%ebp),%eax
801057f1:	50                   	push   %eax
801057f2:	6a 00                	push   $0x0
801057f4:	e8 17 f6 ff ff       	call   80104e10 <argstr>
801057f9:	83 c4 10             	add    $0x10,%esp
801057fc:	85 c0                	test   %eax,%eax
801057fe:	78 30                	js     80105830 <sys_mkdir+0x50>
80105800:	83 ec 0c             	sub    $0xc,%esp
80105803:	8b 45 f4             	mov    -0xc(%ebp),%eax
80105806:	31 c9                	xor    %ecx,%ecx
80105808:	ba 01 00 00 00       	mov    $0x1,%edx
8010580d:	6a 00                	push   $0x0
8010580f:	e8 ec f6 ff ff       	call   80104f00 <create>
80105814:	83 c4 10             	add    $0x10,%esp
80105817:	85 c0                	test   %eax,%eax
80105819:	74 15                	je     80105830 <sys_mkdir+0x50>
    end_op();
    return -1;
  }
  iunlockput(ip);
8010581b:	83 ec 0c             	sub    $0xc,%esp
8010581e:	50                   	push   %eax
8010581f:	e8 ec c2 ff ff       	call   80101b10 <iunlockput>
  end_op();
80105824:	e8 87 d7 ff ff       	call   80102fb0 <end_op>
  return 0;
80105829:	83 c4 10             	add    $0x10,%esp
8010582c:	31 c0                	xor    %eax,%eax
}
8010582e:	c9                   	leave
8010582f:	c3                   	ret
    end_op();
80105830:	e8 7b d7 ff ff       	call   80102fb0 <end_op>
    return -1;
80105835:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
8010583a:	c9                   	leave
8010583b:	c3                   	ret
8010583c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80105840 <sys_mknod>:

int
sys_mknod(void)
{
80105840:	55                   	push   %ebp
80105841:	89 e5                	mov    %esp,%ebp
80105843:	83 ec 18             	sub    $0x18,%esp
  struct inode *ip;
  char *path;
  int major, minor;

  begin_op();
80105846:	e8 f5 d6 ff ff       	call   80102f40 <begin_op>
  if((argstr(0, &path)) < 0 ||
8010584b:	83 ec 08             	sub    $0x8,%esp
8010584e:	8d 45 ec             	lea    -0x14(%ebp),%eax
80105851:	50                   	push   %eax
80105852:	6a 00                	push   $0x0
80105854:	e8 b7 f5 ff ff       	call   80104e10 <argstr>
80105859:	83 c4 10             	add    $0x10,%esp
8010585c:	85 c0                	test   %eax,%eax
8010585e:	78 60                	js     801058c0 <sys_mknod+0x80>
     argint(1, &major) < 0 ||
80105860:	83 ec 08             	sub    $0x8,%esp
80105863:	8d 45 f0             	lea    -0x10(%ebp),%eax
80105866:	50                   	push   %eax
80105867:	6a 01                	push   $0x1
80105869:	e8 e2 f4 ff ff       	call   80104d50 <argint>
  if((argstr(0, &path)) < 0 ||
8010586e:	83 c4 10             	add    $0x10,%esp
80105871:	85 c0                	test   %eax,%eax
80105873:	78 4b                	js     801058c0 <sys_mknod+0x80>
     argint(2, &minor) < 0 ||
80105875:	83 ec 08             	sub    $0x8,%esp
80105878:	8d 45 f4             	lea    -0xc(%ebp),%eax
8010587b:	50                   	push   %eax
8010587c:	6a 02                	push   $0x2
8010587e:	e8 cd f4 ff ff       	call   80104d50 <argint>
     argint(1, &major) < 0 ||
80105883:	83 c4 10             	add    $0x10,%esp
80105886:	85 c0                	test   %eax,%eax
80105888:	78 36                	js     801058c0 <sys_mknod+0x80>
     (ip = create(path, T_DEV, major, minor)) == 0){
8010588a:	0f bf 45 f4          	movswl -0xc(%ebp),%eax
8010588e:	83 ec 0c             	sub    $0xc,%esp
80105891:	0f bf 4d f0          	movswl -0x10(%ebp),%ecx
80105895:	ba 03 00 00 00       	mov    $0x3,%edx
8010589a:	50                   	push   %eax
8010589b:	8b 45 ec             	mov    -0x14(%ebp),%eax
8010589e:	e8 5d f6 ff ff       	call   80104f00 <create>
     argint(2, &minor) < 0 ||
801058a3:	83 c4 10             	add    $0x10,%esp
801058a6:	85 c0                	test   %eax,%eax
801058a8:	74 16                	je     801058c0 <sys_mknod+0x80>
    end_op();
    return -1;
  }
  iunlockput(ip);
801058aa:	83 ec 0c             	sub    $0xc,%esp
801058ad:	50                   	push   %eax
801058ae:	e8 5d c2 ff ff       	call   80101b10 <iunlockput>
  end_op();
801058b3:	e8 f8 d6 ff ff       	call   80102fb0 <end_op>
  return 0;
801058b8:	83 c4 10             	add    $0x10,%esp
801058bb:	31 c0                	xor    %eax,%eax
}
801058bd:	c9                   	leave
801058be:	c3                   	ret
801058bf:	90                   	nop
    end_op();
801058c0:	e8 eb d6 ff ff       	call   80102fb0 <end_op>
    return -1;
801058c5:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
801058ca:	c9                   	leave
801058cb:	c3                   	ret
801058cc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

801058d0 <sys_chdir>:

int
sys_chdir(void)
{
801058d0:	55                   	push   %ebp
801058d1:	89 e5                	mov    %esp,%ebp
801058d3:	83 ec 18             	sub    $0x18,%esp
801058d6:	89 75 fc             	mov    %esi,-0x4(%ebp)
  char *path;
  struct inode *ip;
  struct proc *curproc = myproc();
801058d9:	e8 c2 e2 ff ff       	call   80103ba0 <myproc>
801058de:	89 c6                	mov    %eax,%esi
  
  begin_op();
801058e0:	e8 5b d6 ff ff       	call   80102f40 <begin_op>
  if(argstr(0, &path) < 0 || (ip = namei(path)) == 0){
801058e5:	83 ec 08             	sub    $0x8,%esp
801058e8:	8d 45 f4             	lea    -0xc(%ebp),%eax
801058eb:	50                   	push   %eax
801058ec:	6a 00                	push   $0x0
801058ee:	e8 1d f5 ff ff       	call   80104e10 <argstr>
801058f3:	83 c4 10             	add    $0x10,%esp
801058f6:	85 c0                	test   %eax,%eax
801058f8:	78 74                	js     8010596e <sys_chdir+0x9e>
801058fa:	83 ec 0c             	sub    $0xc,%esp
801058fd:	ff 75 f4             	push   -0xc(%ebp)
80105900:	89 5d f8             	mov    %ebx,-0x8(%ebp)
80105903:	e8 e8 c8 ff ff       	call   801021f0 <namei>
80105908:	83 c4 10             	add    $0x10,%esp
8010590b:	89 c3                	mov    %eax,%ebx
8010590d:	85 c0                	test   %eax,%eax
8010590f:	74 5a                	je     8010596b <sys_chdir+0x9b>
    end_op();
    return -1;
  }
  ilock(ip);
80105911:	83 ec 0c             	sub    $0xc,%esp
80105914:	50                   	push   %eax
80105915:	e8 46 bf ff ff       	call   80101860 <ilock>
  if(ip->type != T_DIR){
8010591a:	83 c4 10             	add    $0x10,%esp
8010591d:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
80105922:	75 2c                	jne    80105950 <sys_chdir+0x80>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
80105924:	83 ec 0c             	sub    $0xc,%esp
80105927:	53                   	push   %ebx
80105928:	e8 13 c0 ff ff       	call   80101940 <iunlock>
  iput(curproc->cwd);
8010592d:	58                   	pop    %eax
8010592e:	ff 76 68             	push   0x68(%esi)
80105931:	e8 5a c0 ff ff       	call   80101990 <iput>
  end_op();
80105936:	e8 75 d6 ff ff       	call   80102fb0 <end_op>
  curproc->cwd = ip;
8010593b:	89 5e 68             	mov    %ebx,0x68(%esi)
  return 0;
8010593e:	8b 5d f8             	mov    -0x8(%ebp),%ebx
80105941:	83 c4 10             	add    $0x10,%esp
80105944:	31 c0                	xor    %eax,%eax
}
80105946:	8b 75 fc             	mov    -0x4(%ebp),%esi
80105949:	c9                   	leave
8010594a:	c3                   	ret
8010594b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    iunlockput(ip);
80105950:	83 ec 0c             	sub    $0xc,%esp
80105953:	53                   	push   %ebx
80105954:	e8 b7 c1 ff ff       	call   80101b10 <iunlockput>
    end_op();
80105959:	e8 52 d6 ff ff       	call   80102fb0 <end_op>
    return -1;
8010595e:	8b 5d f8             	mov    -0x8(%ebp),%ebx
80105961:	83 c4 10             	add    $0x10,%esp
    return -1;
80105964:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105969:	eb db                	jmp    80105946 <sys_chdir+0x76>
8010596b:	8b 5d f8             	mov    -0x8(%ebp),%ebx
    end_op();
8010596e:	e8 3d d6 ff ff       	call   80102fb0 <end_op>
    return -1;
80105973:	eb ef                	jmp    80105964 <sys_chdir+0x94>
80105975:	8d 76 00             	lea    0x0(%esi),%esi
80105978:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010597f:	00 

80105980 <sys_exec>:

int
sys_exec(void)
{
80105980:	55                   	push   %ebp
80105981:	89 e5                	mov    %esp,%ebp
80105983:	81 ec b0 00 00 00    	sub    $0xb0,%esp
  char *path, *argv[MAXARG];
  int i;
  uint uargv, uarg;

  if(argstr(0, &path) < 0 || argint(1, (int*)&uargv) < 0){
80105989:	8d 85 5c ff ff ff    	lea    -0xa4(%ebp),%eax
8010598f:	50                   	push   %eax
80105990:	6a 00                	push   $0x0
80105992:	e8 79 f4 ff ff       	call   80104e10 <argstr>
80105997:	83 c4 10             	add    $0x10,%esp
8010599a:	85 c0                	test   %eax,%eax
8010599c:	0f 88 8e 00 00 00    	js     80105a30 <sys_exec+0xb0>
801059a2:	83 ec 08             	sub    $0x8,%esp
801059a5:	8d 85 60 ff ff ff    	lea    -0xa0(%ebp),%eax
801059ab:	50                   	push   %eax
801059ac:	6a 01                	push   $0x1
801059ae:	e8 9d f3 ff ff       	call   80104d50 <argint>
801059b3:	83 c4 10             	add    $0x10,%esp
801059b6:	85 c0                	test   %eax,%eax
801059b8:	78 76                	js     80105a30 <sys_exec+0xb0>
    return -1;
  }
  memset(argv, 0, sizeof(argv));
801059ba:	83 ec 04             	sub    $0x4,%esp
801059bd:	89 75 f8             	mov    %esi,-0x8(%ebp)
801059c0:	8d b5 68 ff ff ff    	lea    -0x98(%ebp),%esi
801059c6:	68 80 00 00 00       	push   $0x80
801059cb:	6a 00                	push   $0x0
801059cd:	56                   	push   %esi
801059ce:	89 5d f4             	mov    %ebx,-0xc(%ebp)
  for(i=0;; i++){
801059d1:	31 db                	xor    %ebx,%ebx
  memset(argv, 0, sizeof(argv));
801059d3:	e8 88 f0 ff ff       	call   80104a60 <memset>
801059d8:	83 c4 10             	add    $0x10,%esp
801059db:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    if(i >= NELEM(argv))
      return -1;
    if(fetchint(uargv+4*i, (int*)&uarg) < 0)
801059e0:	83 ec 08             	sub    $0x8,%esp
801059e3:	8d 85 64 ff ff ff    	lea    -0x9c(%ebp),%eax
801059e9:	50                   	push   %eax
801059ea:	8d 04 9d 00 00 00 00 	lea    0x0(,%ebx,4),%eax
801059f1:	03 85 60 ff ff ff    	add    -0xa0(%ebp),%eax
801059f7:	50                   	push   %eax
801059f8:	e8 b3 f2 ff ff       	call   80104cb0 <fetchint>
801059fd:	83 c4 10             	add    $0x10,%esp
80105a00:	85 c0                	test   %eax,%eax
80105a02:	78 26                	js     80105a2a <sys_exec+0xaa>
      return -1;
    if(uarg == 0){
80105a04:	8b 85 64 ff ff ff    	mov    -0x9c(%ebp),%eax
80105a0a:	85 c0                	test   %eax,%eax
80105a0c:	74 32                	je     80105a40 <sys_exec+0xc0>
      argv[i] = 0;
      break;
    }
    if(fetchstr(uarg, &argv[i]) < 0)
80105a0e:	83 ec 08             	sub    $0x8,%esp
80105a11:	8d 14 9e             	lea    (%esi,%ebx,4),%edx
80105a14:	52                   	push   %edx
80105a15:	50                   	push   %eax
80105a16:	e8 d5 f2 ff ff       	call   80104cf0 <fetchstr>
80105a1b:	83 c4 10             	add    $0x10,%esp
80105a1e:	85 c0                	test   %eax,%eax
80105a20:	78 08                	js     80105a2a <sys_exec+0xaa>
  for(i=0;; i++){
80105a22:	83 c3 01             	add    $0x1,%ebx
    if(i >= NELEM(argv))
80105a25:	83 fb 20             	cmp    $0x20,%ebx
80105a28:	75 b6                	jne    801059e0 <sys_exec+0x60>
80105a2a:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80105a2d:	8b 75 f8             	mov    -0x8(%ebp),%esi
      return -1;
  }
  return exec(path, argv);
}
80105a30:	c9                   	leave
    return -1;
80105a31:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80105a36:	c3                   	ret
80105a37:	90                   	nop
80105a38:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105a3f:	00 
      argv[i] = 0;
80105a40:	c7 84 9d 68 ff ff ff 	movl   $0x0,-0x98(%ebp,%ebx,4)
80105a47:	00 00 00 00 
  return exec(path, argv);
80105a4b:	83 ec 08             	sub    $0x8,%esp
80105a4e:	56                   	push   %esi
80105a4f:	ff b5 5c ff ff ff    	push   -0xa4(%ebp)
80105a55:	e8 f6 b0 ff ff       	call   80100b50 <exec>
80105a5a:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80105a5d:	8b 75 f8             	mov    -0x8(%ebp),%esi
80105a60:	83 c4 10             	add    $0x10,%esp
}
80105a63:	c9                   	leave
80105a64:	c3                   	ret
80105a65:	8d 76 00             	lea    0x0(%esi),%esi
80105a68:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105a6f:	00 

80105a70 <sys_pipe>:

int
sys_pipe(void)
{
80105a70:	55                   	push   %ebp
80105a71:	89 e5                	mov    %esp,%ebp
80105a73:	83 ec 2c             	sub    $0x2c,%esp
  int *fd;
  struct file *rf, *wf;
  int fd0, fd1;

  if(argptr(0, (void*)&fd, 2*sizeof(fd[0])) < 0)
80105a76:	8d 45 dc             	lea    -0x24(%ebp),%eax
80105a79:	6a 08                	push   $0x8
80105a7b:	50                   	push   %eax
80105a7c:	6a 00                	push   $0x0
80105a7e:	e8 1d f3 ff ff       	call   80104da0 <argptr>
80105a83:	83 c4 10             	add    $0x10,%esp
80105a86:	85 c0                	test   %eax,%eax
80105a88:	0f 88 af 00 00 00    	js     80105b3d <sys_pipe+0xcd>
    return -1;
  if(pipealloc(&rf, &wf) < 0)
80105a8e:	83 ec 08             	sub    $0x8,%esp
80105a91:	8d 45 e4             	lea    -0x1c(%ebp),%eax
80105a94:	50                   	push   %eax
80105a95:	8d 45 e0             	lea    -0x20(%ebp),%eax
80105a98:	50                   	push   %eax
80105a99:	e8 62 db ff ff       	call   80103600 <pipealloc>
80105a9e:	83 c4 10             	add    $0x10,%esp
80105aa1:	85 c0                	test   %eax,%eax
80105aa3:	0f 88 94 00 00 00    	js     80105b3d <sys_pipe+0xcd>
80105aa9:	89 5d f4             	mov    %ebx,-0xc(%ebp)
  for(fd = 0; fd < NOFILE; fd++){
80105aac:	31 db                	xor    %ebx,%ebx
80105aae:	89 7d fc             	mov    %edi,-0x4(%ebp)
    return -1;
  fd0 = -1;
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
80105ab1:	8b 7d e0             	mov    -0x20(%ebp),%edi
  struct proc *curproc = myproc();
80105ab4:	e8 e7 e0 ff ff       	call   80103ba0 <myproc>
    if(curproc->ofile[fd] == 0){
80105ab9:	8b 54 98 28          	mov    0x28(%eax,%ebx,4),%edx
80105abd:	85 d2                	test   %edx,%edx
80105abf:	74 1f                	je     80105ae0 <sys_pipe+0x70>
80105ac1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80105ac8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105acf:	00 
  for(fd = 0; fd < NOFILE; fd++){
80105ad0:	83 c3 01             	add    $0x1,%ebx
80105ad3:	83 fb 10             	cmp    $0x10,%ebx
80105ad6:	74 48                	je     80105b20 <sys_pipe+0xb0>
    if(curproc->ofile[fd] == 0){
80105ad8:	8b 54 98 28          	mov    0x28(%eax,%ebx,4),%edx
80105adc:	85 d2                	test   %edx,%edx
80105ade:	75 f0                	jne    80105ad0 <sys_pipe+0x60>
80105ae0:	89 75 f8             	mov    %esi,-0x8(%ebp)
      curproc->ofile[fd] = f;
80105ae3:	8d 73 08             	lea    0x8(%ebx),%esi
80105ae6:	89 7c b0 08          	mov    %edi,0x8(%eax,%esi,4)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
80105aea:	8b 7d e4             	mov    -0x1c(%ebp),%edi
  struct proc *curproc = myproc();
80105aed:	e8 ae e0 ff ff       	call   80103ba0 <myproc>
80105af2:	89 c2                	mov    %eax,%edx
  for(fd = 0; fd < NOFILE; fd++){
80105af4:	31 c0                	xor    %eax,%eax
80105af6:	66 90                	xchg   %ax,%ax
80105af8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105aff:	00 
    if(curproc->ofile[fd] == 0){
80105b00:	8b 4c 82 28          	mov    0x28(%edx,%eax,4),%ecx
80105b04:	85 c9                	test   %ecx,%ecx
80105b06:	74 40                	je     80105b48 <sys_pipe+0xd8>
  for(fd = 0; fd < NOFILE; fd++){
80105b08:	83 c0 01             	add    $0x1,%eax
80105b0b:	83 f8 10             	cmp    $0x10,%eax
80105b0e:	75 f0                	jne    80105b00 <sys_pipe+0x90>
    if(fd0 >= 0)
      myproc()->ofile[fd0] = 0;
80105b10:	e8 8b e0 ff ff       	call   80103ba0 <myproc>
80105b15:	c7 44 b0 08 00 00 00 	movl   $0x0,0x8(%eax,%esi,4)
80105b1c:	00 
80105b1d:	8b 75 f8             	mov    -0x8(%ebp),%esi
    fileclose(rf);
80105b20:	83 ec 0c             	sub    $0xc,%esp
80105b23:	ff 75 e0             	push   -0x20(%ebp)
80105b26:	e8 75 b4 ff ff       	call   80100fa0 <fileclose>
    fileclose(wf);
80105b2b:	58                   	pop    %eax
80105b2c:	ff 75 e4             	push   -0x1c(%ebp)
80105b2f:	e8 6c b4 ff ff       	call   80100fa0 <fileclose>
    return -1;
80105b34:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80105b37:	8b 7d fc             	mov    -0x4(%ebp),%edi
80105b3a:	83 c4 10             	add    $0x10,%esp
  }
  fd[0] = fd0;
  fd[1] = fd1;
  return 0;
}
80105b3d:	c9                   	leave
    return -1;
80105b3e:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80105b43:	c3                   	ret
80105b44:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
      curproc->ofile[fd] = f;
80105b48:	89 7c 82 28          	mov    %edi,0x28(%edx,%eax,4)
  fd[0] = fd0;
80105b4c:	8b 55 dc             	mov    -0x24(%ebp),%edx
80105b4f:	89 1a                	mov    %ebx,(%edx)
  fd[1] = fd1;
80105b51:	8b 55 dc             	mov    -0x24(%ebp),%edx
80105b54:	89 42 04             	mov    %eax,0x4(%edx)
  return 0;
80105b57:	31 c0                	xor    %eax,%eax
80105b59:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80105b5c:	8b 75 f8             	mov    -0x8(%ebp),%esi
80105b5f:	8b 7d fc             	mov    -0x4(%ebp),%edi
}
80105b62:	c9                   	leave
80105b63:	c3                   	ret
80105b64:	66 90                	xchg   %ax,%ax
80105b66:	66 90                	xchg   %ax,%ax
80105b68:	66 90                	xchg   %ax,%ax
80105b6a:	66 90                	xchg   %ax,%ax
80105b6c:	66 90                	xchg   %ax,%ax
80105b6e:	66 90                	xchg   %ax,%ax

80105b70 <sys_fork>:
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
int sys_fork(void)
{
  return fork();
80105b70:	e9 cb e1 ff ff       	jmp    80103d40 <fork>
80105b75:	8d 76 00             	lea    0x0(%esi),%esi
80105b78:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105b7f:	00 

80105b80 <sys_exit>:
}

int sys_exit(void)
{
80105b80:	55                   	push   %ebp
80105b81:	89 e5                	mov    %esp,%ebp
80105b83:	83 ec 08             	sub    $0x8,%esp
  exit();
80105b86:	e8 a5 e4 ff ff       	call   80104030 <exit>
  return 0; // not reached
}
80105b8b:	31 c0                	xor    %eax,%eax
80105b8d:	c9                   	leave
80105b8e:	c3                   	ret
80105b8f:	90                   	nop

80105b90 <sys_wait>:

int sys_wait(void)
{
  return wait();
80105b90:	e9 eb e5 ff ff       	jmp    80104180 <wait>
80105b95:	8d 76 00             	lea    0x0(%esi),%esi
80105b98:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105b9f:	00 

80105ba0 <sys_kill>:
}

int sys_kill(void)
{
80105ba0:	55                   	push   %ebp
80105ba1:	89 e5                	mov    %esp,%ebp
80105ba3:	83 ec 20             	sub    $0x20,%esp
  int pid;

  if (argint(0, &pid) < 0)
80105ba6:	8d 45 f4             	lea    -0xc(%ebp),%eax
80105ba9:	50                   	push   %eax
80105baa:	6a 00                	push   $0x0
80105bac:	e8 9f f1 ff ff       	call   80104d50 <argint>
80105bb1:	83 c4 10             	add    $0x10,%esp
80105bb4:	85 c0                	test   %eax,%eax
80105bb6:	78 18                	js     80105bd0 <sys_kill+0x30>
    return -1;
  return kill(pid);
80105bb8:	83 ec 0c             	sub    $0xc,%esp
80105bbb:	ff 75 f4             	push   -0xc(%ebp)
80105bbe:	e8 6d e8 ff ff       	call   80104430 <kill>
80105bc3:	83 c4 10             	add    $0x10,%esp
}
80105bc6:	c9                   	leave
80105bc7:	c3                   	ret
80105bc8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105bcf:	00 
80105bd0:	c9                   	leave
    return -1;
80105bd1:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80105bd6:	c3                   	ret
80105bd7:	90                   	nop
80105bd8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105bdf:	00 

80105be0 <sys_getpid>:

int sys_getpid(void)
{
80105be0:	55                   	push   %ebp
80105be1:	89 e5                	mov    %esp,%ebp
80105be3:	83 ec 08             	sub    $0x8,%esp
  return myproc()->pid;
80105be6:	e8 b5 df ff ff       	call   80103ba0 <myproc>
80105beb:	8b 40 10             	mov    0x10(%eax),%eax
}
80105bee:	c9                   	leave
80105bef:	c3                   	ret

80105bf0 <sys_sbrk>:

int sys_sbrk(void)
{
80105bf0:	55                   	push   %ebp
80105bf1:	89 e5                	mov    %esp,%ebp
80105bf3:	83 ec 20             	sub    $0x20,%esp
  int addr;
  int n;

  if (argint(0, &n) < 0)
80105bf6:	8d 45 f4             	lea    -0xc(%ebp),%eax
80105bf9:	50                   	push   %eax
80105bfa:	6a 00                	push   $0x0
80105bfc:	e8 4f f1 ff ff       	call   80104d50 <argint>
80105c01:	83 c4 10             	add    $0x10,%esp
80105c04:	85 c0                	test   %eax,%eax
80105c06:	78 26                	js     80105c2e <sys_sbrk+0x3e>
80105c08:	89 5d fc             	mov    %ebx,-0x4(%ebp)
    return -1;
  addr = myproc()->sz;
80105c0b:	e8 90 df ff ff       	call   80103ba0 <myproc>
  if (growproc(n) < 0)
80105c10:	83 ec 0c             	sub    $0xc,%esp
  addr = myproc()->sz;
80105c13:	8b 18                	mov    (%eax),%ebx
  if (growproc(n) < 0)
80105c15:	ff 75 f4             	push   -0xc(%ebp)
80105c18:	e8 a3 e0 ff ff       	call   80103cc0 <growproc>
80105c1d:	83 c4 10             	add    $0x10,%esp
80105c20:	85 c0                	test   %eax,%eax
80105c22:	78 07                	js     80105c2b <sys_sbrk+0x3b>
  addr = myproc()->sz;
80105c24:	89 d8                	mov    %ebx,%eax
80105c26:	8b 5d fc             	mov    -0x4(%ebp),%ebx
    return -1;
  return addr;
}
80105c29:	c9                   	leave
80105c2a:	c3                   	ret
80105c2b:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80105c2e:	c9                   	leave
    return -1;
80105c2f:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80105c34:	c3                   	ret
80105c35:	8d 76 00             	lea    0x0(%esi),%esi
80105c38:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105c3f:	00 

80105c40 <sys_sleep>:

int sys_sleep(void)
{
80105c40:	55                   	push   %ebp
80105c41:	89 e5                	mov    %esp,%ebp
80105c43:	83 ec 20             	sub    $0x20,%esp
  int n;
  uint ticks0;

  if (argint(0, &n) < 0)
80105c46:	8d 45 f4             	lea    -0xc(%ebp),%eax
80105c49:	50                   	push   %eax
80105c4a:	6a 00                	push   $0x0
80105c4c:	e8 ff f0 ff ff       	call   80104d50 <argint>
80105c51:	83 c4 10             	add    $0x10,%esp
80105c54:	85 c0                	test   %eax,%eax
80105c56:	78 68                	js     80105cc0 <sys_sleep+0x80>
    return -1;
  acquire(&tickslock);
80105c58:	83 ec 0c             	sub    $0xc,%esp
80105c5b:	68 a0 4d 11 80       	push   $0x80114da0
80105c60:	e8 db ec ff ff       	call   80104940 <acquire>
  ticks0 = ticks;
  while (ticks - ticks0 < n)
80105c65:	8b 55 f4             	mov    -0xc(%ebp),%edx
80105c68:	83 c4 10             	add    $0x10,%esp
80105c6b:	85 d2                	test   %edx,%edx
80105c6d:	74 64                	je     80105cd3 <sys_sleep+0x93>
80105c6f:	89 5d fc             	mov    %ebx,-0x4(%ebp)
  ticks0 = ticks;
80105c72:	8b 1d 80 4d 11 80    	mov    0x80114d80,%ebx
80105c78:	eb 27                	jmp    80105ca1 <sys_sleep+0x61>
80105c7a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    if (myproc()->killed)
    {
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
80105c80:	83 ec 08             	sub    $0x8,%esp
80105c83:	68 a0 4d 11 80       	push   $0x80114da0
80105c88:	68 80 4d 11 80       	push   $0x80114d80
80105c8d:	e8 7e e6 ff ff       	call   80104310 <sleep>
  while (ticks - ticks0 < n)
80105c92:	a1 80 4d 11 80       	mov    0x80114d80,%eax
80105c97:	83 c4 10             	add    $0x10,%esp
80105c9a:	29 d8                	sub    %ebx,%eax
80105c9c:	3b 45 f4             	cmp    -0xc(%ebp),%eax
80105c9f:	73 2f                	jae    80105cd0 <sys_sleep+0x90>
    if (myproc()->killed)
80105ca1:	e8 fa de ff ff       	call   80103ba0 <myproc>
80105ca6:	8b 40 24             	mov    0x24(%eax),%eax
80105ca9:	85 c0                	test   %eax,%eax
80105cab:	74 d3                	je     80105c80 <sys_sleep+0x40>
      release(&tickslock);
80105cad:	83 ec 0c             	sub    $0xc,%esp
80105cb0:	68 a0 4d 11 80       	push   $0x80114da0
80105cb5:	e8 26 ec ff ff       	call   801048e0 <release>
      return -1;
80105cba:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80105cbd:	83 c4 10             	add    $0x10,%esp
  }
  release(&tickslock);
  return 0;
}
80105cc0:	c9                   	leave
    return -1;
80105cc1:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80105cc6:	c3                   	ret
80105cc7:	90                   	nop
80105cc8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105ccf:	00 
80105cd0:	8b 5d fc             	mov    -0x4(%ebp),%ebx
  release(&tickslock);
80105cd3:	83 ec 0c             	sub    $0xc,%esp
80105cd6:	68 a0 4d 11 80       	push   $0x80114da0
80105cdb:	e8 00 ec ff ff       	call   801048e0 <release>
  return 0;
80105ce0:	83 c4 10             	add    $0x10,%esp
80105ce3:	31 c0                	xor    %eax,%eax
}
80105ce5:	c9                   	leave
80105ce6:	c3                   	ret
80105ce7:	90                   	nop
80105ce8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105cef:	00 

80105cf0 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
int sys_uptime(void)
{
80105cf0:	55                   	push   %ebp
80105cf1:	89 e5                	mov    %esp,%ebp
80105cf3:	53                   	push   %ebx
80105cf4:	83 ec 10             	sub    $0x10,%esp
  uint xticks;

  acquire(&tickslock);
80105cf7:	68 a0 4d 11 80       	push   $0x80114da0
80105cfc:	e8 3f ec ff ff       	call   80104940 <acquire>
  xticks = ticks;
  release(&tickslock);
80105d01:	c7 04 24 a0 4d 11 80 	movl   $0x80114da0,(%esp)
  xticks = ticks;
80105d08:	8b 1d 80 4d 11 80    	mov    0x80114d80,%ebx
  release(&tickslock);
80105d0e:	e8 cd eb ff ff       	call   801048e0 <release>
  return xticks;
}
80105d13:	89 d8                	mov    %ebx,%eax
80105d15:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80105d18:	c9                   	leave
80105d19:	c3                   	ret
80105d1a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80105d20 <sys_set_priority>:

// for priority_scheduling
int
sys_set_priority(void)
{
80105d20:	55                   	push   %ebp
80105d21:	89 e5                	mov    %esp,%ebp
80105d23:	83 ec 20             	sub    $0x20,%esp
  int pid, priority;

  if(argint(0, &pid) < 0)
80105d26:	8d 45 f0             	lea    -0x10(%ebp),%eax
80105d29:	50                   	push   %eax
80105d2a:	6a 00                	push   $0x0
80105d2c:	e8 1f f0 ff ff       	call   80104d50 <argint>
80105d31:	83 c4 10             	add    $0x10,%esp
80105d34:	85 c0                	test   %eax,%eax
80105d36:	78 28                	js     80105d60 <sys_set_priority+0x40>
    return -1;

  if(argint(1, &priority) < 0)
80105d38:	83 ec 08             	sub    $0x8,%esp
80105d3b:	8d 45 f4             	lea    -0xc(%ebp),%eax
80105d3e:	50                   	push   %eax
80105d3f:	6a 01                	push   $0x1
80105d41:	e8 0a f0 ff ff       	call   80104d50 <argint>
80105d46:	83 c4 10             	add    $0x10,%esp
80105d49:	85 c0                	test   %eax,%eax
80105d4b:	78 13                	js     80105d60 <sys_set_priority+0x40>
    return -1;

  return set_priority(pid, priority);
80105d4d:	83 ec 08             	sub    $0x8,%esp
80105d50:	ff 75 f4             	push   -0xc(%ebp)
80105d53:	ff 75 f0             	push   -0x10(%ebp)
80105d56:	e8 15 e8 ff ff       	call   80104570 <set_priority>
80105d5b:	83 c4 10             	add    $0x10,%esp
}
80105d5e:	c9                   	leave
80105d5f:	c3                   	ret
80105d60:	c9                   	leave
    return -1;
80105d61:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80105d66:	c3                   	ret
80105d67:	90                   	nop
80105d68:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105d6f:	00 

80105d70 <sys_mprotect>:
// for q1

int sys_mprotect(void)
{
80105d70:	55                   	push   %ebp
80105d71:	89 e5                	mov    %esp,%ebp
80105d73:	56                   	push   %esi
80105d74:	53                   	push   %ebx
80105d75:	83 ec 10             	sub    $0x10,%esp
  int addr, len;
  struct proc *p = myproc();
80105d78:	e8 23 de ff ff       	call   80103ba0 <myproc>

  if (argint(0, &addr) < 0 || argint(1, &len) < 0)
80105d7d:	83 ec 08             	sub    $0x8,%esp
  struct proc *p = myproc();
80105d80:	89 c3                	mov    %eax,%ebx
  if (argint(0, &addr) < 0 || argint(1, &len) < 0)
80105d82:	8d 45 f0             	lea    -0x10(%ebp),%eax
80105d85:	50                   	push   %eax
80105d86:	6a 00                	push   $0x0
80105d88:	e8 c3 ef ff ff       	call   80104d50 <argint>
80105d8d:	83 c4 10             	add    $0x10,%esp
80105d90:	85 c0                	test   %eax,%eax
80105d92:	78 64                	js     80105df8 <sys_mprotect+0x88>
80105d94:	83 ec 08             	sub    $0x8,%esp
80105d97:	8d 45 f4             	lea    -0xc(%ebp),%eax
80105d9a:	50                   	push   %eax
80105d9b:	6a 01                	push   $0x1
80105d9d:	e8 ae ef ff ff       	call   80104d50 <argint>
80105da2:	83 c4 10             	add    $0x10,%esp
80105da5:	85 c0                	test   %eax,%eax
80105da7:	78 4f                	js     80105df8 <sys_mprotect+0x88>
    return -1;

  if (addr % PGSIZE != 0 || len <= 0)
80105da9:	8b 55 f0             	mov    -0x10(%ebp),%edx
80105dac:	89 d6                	mov    %edx,%esi
80105dae:	81 e6 ff 0f 00 00    	and    $0xfff,%esi
80105db4:	75 42                	jne    80105df8 <sys_mprotect+0x88>
80105db6:	8b 4d f4             	mov    -0xc(%ebp),%ecx
80105db9:	85 c9                	test   %ecx,%ecx
80105dbb:	7e 3b                	jle    80105df8 <sys_mprotect+0x88>
    return -1;

  if ((uint)addr > p->sz)
80105dbd:	8b 03                	mov    (%ebx),%eax
80105dbf:	39 d0                	cmp    %edx,%eax
80105dc1:	72 35                	jb     80105df8 <sys_mprotect+0x88>
    return -1;

  if ((uint)len > (p->sz - (uint)addr) / PGSIZE)
80105dc3:	29 d0                	sub    %edx,%eax
80105dc5:	c1 e8 0c             	shr    $0xc,%eax
80105dc8:	39 c8                	cmp    %ecx,%eax
80105dca:	72 2c                	jb     80105df8 <sys_mprotect+0x88>
    return -1;

  if (change_perm(p->pgdir, (uint)addr, len, 0) < 0)
80105dcc:	6a 00                	push   $0x0
80105dce:	51                   	push   %ecx
80105dcf:	52                   	push   %edx
80105dd0:	ff 73 04             	push   0x4(%ebx)
80105dd3:	e8 b8 12 00 00       	call   80107090 <change_perm>
80105dd8:	83 c4 10             	add    $0x10,%esp
80105ddb:	85 c0                	test   %eax,%eax
80105ddd:	78 19                	js     80105df8 <sys_mprotect+0x88>
    return -1;

  lcr3(V2P(p->pgdir));
80105ddf:	8b 43 04             	mov    0x4(%ebx),%eax
80105de2:	05 00 00 00 80       	add    $0x80000000,%eax
}

static inline void
lcr3(uint val)
{
  asm volatile("movl %0,%%cr3" : : "r" (val));
80105de7:	0f 22 d8             	mov    %eax,%cr3

  return 0;
}
80105dea:	8d 65 f8             	lea    -0x8(%ebp),%esp
80105ded:	89 f0                	mov    %esi,%eax
80105def:	5b                   	pop    %ebx
80105df0:	5e                   	pop    %esi
80105df1:	5d                   	pop    %ebp
80105df2:	c3                   	ret
80105df3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    return -1;
80105df8:	be ff ff ff ff       	mov    $0xffffffff,%esi
80105dfd:	eb eb                	jmp    80105dea <sys_mprotect+0x7a>
80105dff:	90                   	nop

80105e00 <sys_munprotect>:

int
sys_munprotect(void)
{
80105e00:	55                   	push   %ebp
80105e01:	89 e5                	mov    %esp,%ebp
80105e03:	56                   	push   %esi
80105e04:	53                   	push   %ebx
80105e05:	83 ec 10             	sub    $0x10,%esp
  int addr, len;
  struct proc *p = myproc();
80105e08:	e8 93 dd ff ff       	call   80103ba0 <myproc>

  if(argint(0, &addr) < 0 || argint(1, &len) < 0)
80105e0d:	83 ec 08             	sub    $0x8,%esp
  struct proc *p = myproc();
80105e10:	89 c3                	mov    %eax,%ebx
  if(argint(0, &addr) < 0 || argint(1, &len) < 0)
80105e12:	8d 45 f0             	lea    -0x10(%ebp),%eax
80105e15:	50                   	push   %eax
80105e16:	6a 00                	push   $0x0
80105e18:	e8 33 ef ff ff       	call   80104d50 <argint>
80105e1d:	83 c4 10             	add    $0x10,%esp
80105e20:	85 c0                	test   %eax,%eax
80105e22:	78 64                	js     80105e88 <sys_munprotect+0x88>
80105e24:	83 ec 08             	sub    $0x8,%esp
80105e27:	8d 45 f4             	lea    -0xc(%ebp),%eax
80105e2a:	50                   	push   %eax
80105e2b:	6a 01                	push   $0x1
80105e2d:	e8 1e ef ff ff       	call   80104d50 <argint>
80105e32:	83 c4 10             	add    $0x10,%esp
80105e35:	85 c0                	test   %eax,%eax
80105e37:	78 4f                	js     80105e88 <sys_munprotect+0x88>
    return -1;

  if(addr % PGSIZE != 0 || len <= 0)
80105e39:	8b 55 f0             	mov    -0x10(%ebp),%edx
80105e3c:	89 d6                	mov    %edx,%esi
80105e3e:	81 e6 ff 0f 00 00    	and    $0xfff,%esi
80105e44:	75 42                	jne    80105e88 <sys_munprotect+0x88>
80105e46:	8b 4d f4             	mov    -0xc(%ebp),%ecx
80105e49:	85 c9                	test   %ecx,%ecx
80105e4b:	7e 3b                	jle    80105e88 <sys_munprotect+0x88>
    return -1;

  if((uint)addr > p->sz)
80105e4d:	8b 03                	mov    (%ebx),%eax
80105e4f:	39 d0                	cmp    %edx,%eax
80105e51:	72 35                	jb     80105e88 <sys_munprotect+0x88>
    return -1;

  if((uint)len > (p->sz - (uint)addr) / PGSIZE)
80105e53:	29 d0                	sub    %edx,%eax
80105e55:	c1 e8 0c             	shr    $0xc,%eax
80105e58:	39 c8                	cmp    %ecx,%eax
80105e5a:	72 2c                	jb     80105e88 <sys_munprotect+0x88>
    return -1;

  if(change_perm(p->pgdir, (uint)addr, len, 1) < 0)
80105e5c:	6a 01                	push   $0x1
80105e5e:	51                   	push   %ecx
80105e5f:	52                   	push   %edx
80105e60:	ff 73 04             	push   0x4(%ebx)
80105e63:	e8 28 12 00 00       	call   80107090 <change_perm>
80105e68:	83 c4 10             	add    $0x10,%esp
80105e6b:	85 c0                	test   %eax,%eax
80105e6d:	78 19                	js     80105e88 <sys_munprotect+0x88>
    return -1;

  lcr3(V2P(p->pgdir));
80105e6f:	8b 43 04             	mov    0x4(%ebx),%eax
80105e72:	05 00 00 00 80       	add    $0x80000000,%eax
80105e77:	0f 22 d8             	mov    %eax,%cr3

  return 0;
80105e7a:	8d 65 f8             	lea    -0x8(%ebp),%esp
80105e7d:	89 f0                	mov    %esi,%eax
80105e7f:	5b                   	pop    %ebx
80105e80:	5e                   	pop    %esi
80105e81:	5d                   	pop    %ebp
80105e82:	c3                   	ret
80105e83:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    return -1;
80105e88:	be ff ff ff ff       	mov    $0xffffffff,%esi
80105e8d:	eb eb                	jmp    80105e7a <sys_munprotect+0x7a>

80105e8f <alltraps>:

  # vectors.S sends all traps here.
.globl alltraps
alltraps:
  # Build trap frame.
  pushl %ds
80105e8f:	1e                   	push   %ds
  pushl %es
80105e90:	06                   	push   %es
  pushl %fs
80105e91:	0f a0                	push   %fs
  pushl %gs
80105e93:	0f a8                	push   %gs
  pushal
80105e95:	60                   	pusha
  
  # Set up data segments.
  movw $(SEG_KDATA<<3), %ax
80105e96:	66 b8 10 00          	mov    $0x10,%ax
  movw %ax, %ds
80105e9a:	8e d8                	mov    %eax,%ds
  movw %ax, %es
80105e9c:	8e c0                	mov    %eax,%es

  # Call trap(tf), where tf=%esp
  pushl %esp
80105e9e:	54                   	push   %esp
  call trap
80105e9f:	e8 fc 00 00 00       	call   80105fa0 <trap>
  addl $4, %esp
80105ea4:	83 c4 04             	add    $0x4,%esp

80105ea7 <trapret>:

  # Return falls through to trapret...
.globl trapret
trapret:
  popal
80105ea7:	61                   	popa
  popl %gs
80105ea8:	0f a9                	pop    %gs
  popl %fs
80105eaa:	0f a1                	pop    %fs
  popl %es
80105eac:	07                   	pop    %es
  popl %ds
80105ead:	1f                   	pop    %ds
  addl $0x8, %esp  # trapno and errcode
80105eae:	83 c4 08             	add    $0x8,%esp
  iret
80105eb1:	cf                   	iret
80105eb2:	66 90                	xchg   %ax,%ax
80105eb4:	66 90                	xchg   %ax,%ax
80105eb6:	66 90                	xchg   %ax,%ax
80105eb8:	66 90                	xchg   %ax,%ax
80105eba:	66 90                	xchg   %ax,%ax
80105ebc:	66 90                	xchg   %ax,%ax
80105ebe:	66 90                	xchg   %ax,%ax

80105ec0 <tvinit>:
struct spinlock tickslock;
uint ticks;

void
tvinit(void)
{
80105ec0:	55                   	push   %ebp
  int i;

  for(i = 0; i < 256; i++)
80105ec1:	31 c0                	xor    %eax,%eax
{
80105ec3:	89 e5                	mov    %esp,%ebp
80105ec5:	83 ec 08             	sub    $0x8,%esp
80105ec8:	eb 36                	jmp    80105f00 <tvinit+0x40>
80105eca:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80105ed0:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105ed7:	00 
80105ed8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105edf:	00 
80105ee0:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105ee7:	00 
80105ee8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105eef:	00 
80105ef0:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105ef7:	00 
80105ef8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105eff:	00 
    SETGATE(idt[i], 0, SEG_KCODE<<3, vectors[i], 0);
80105f00:	8b 14 85 08 b0 10 80 	mov    -0x7fef4ff8(,%eax,4),%edx
80105f07:	c7 04 c5 e2 4d 11 80 	movl   $0x8e000008,-0x7feeb21e(,%eax,8)
80105f0e:	08 00 00 8e 
80105f12:	66 89 14 c5 e0 4d 11 	mov    %dx,-0x7feeb220(,%eax,8)
80105f19:	80 
80105f1a:	c1 ea 10             	shr    $0x10,%edx
80105f1d:	66 89 14 c5 e6 4d 11 	mov    %dx,-0x7feeb21a(,%eax,8)
80105f24:	80 
  for(i = 0; i < 256; i++)
80105f25:	83 c0 01             	add    $0x1,%eax
80105f28:	3d 00 01 00 00       	cmp    $0x100,%eax
80105f2d:	75 d1                	jne    80105f00 <tvinit+0x40>
  SETGATE(idt[T_SYSCALL], 1, SEG_KCODE<<3, vectors[T_SYSCALL], DPL_USER);

  initlock(&tickslock, "time");
80105f2f:	83 ec 08             	sub    $0x8,%esp
  SETGATE(idt[T_SYSCALL], 1, SEG_KCODE<<3, vectors[T_SYSCALL], DPL_USER);
80105f32:	a1 08 b1 10 80       	mov    0x8010b108,%eax
80105f37:	c7 05 e2 4f 11 80 08 	movl   $0xef000008,0x80114fe2
80105f3e:	00 00 ef 
  initlock(&tickslock, "time");
80105f41:	68 2e 7d 10 80       	push   $0x80107d2e
80105f46:	68 a0 4d 11 80       	push   $0x80114da0
  SETGATE(idt[T_SYSCALL], 1, SEG_KCODE<<3, vectors[T_SYSCALL], DPL_USER);
80105f4b:	66 a3 e0 4f 11 80    	mov    %ax,0x80114fe0
80105f51:	c1 e8 10             	shr    $0x10,%eax
80105f54:	66 a3 e6 4f 11 80    	mov    %ax,0x80114fe6
  initlock(&tickslock, "time");
80105f5a:	e8 c1 e7 ff ff       	call   80104720 <initlock>
}
80105f5f:	83 c4 10             	add    $0x10,%esp
80105f62:	c9                   	leave
80105f63:	c3                   	ret
80105f64:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80105f68:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105f6f:	00 

80105f70 <idtinit>:

void
idtinit(void)
{
80105f70:	55                   	push   %ebp
  pd[0] = size-1;
80105f71:	b8 ff 07 00 00       	mov    $0x7ff,%eax
80105f76:	89 e5                	mov    %esp,%ebp
80105f78:	83 ec 10             	sub    $0x10,%esp
80105f7b:	66 89 45 fa          	mov    %ax,-0x6(%ebp)
  pd[1] = (uint)p;
80105f7f:	b8 e0 4d 11 80       	mov    $0x80114de0,%eax
80105f84:	66 89 45 fc          	mov    %ax,-0x4(%ebp)
  pd[2] = (uint)p >> 16;
80105f88:	c1 e8 10             	shr    $0x10,%eax
80105f8b:	66 89 45 fe          	mov    %ax,-0x2(%ebp)
  asm volatile("lidt (%0)" : : "r" (pd));
80105f8f:	8d 45 fa             	lea    -0x6(%ebp),%eax
80105f92:	0f 01 18             	lidtl  (%eax)
  lidt(idt, sizeof(idt));
}
80105f95:	c9                   	leave
80105f96:	c3                   	ret
80105f97:	90                   	nop
80105f98:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105f9f:	00 

80105fa0 <trap>:

//PAGEBREAK: 41
void
trap(struct trapframe *tf)
{
80105fa0:	55                   	push   %ebp
80105fa1:	89 e5                	mov    %esp,%ebp
80105fa3:	83 ec 28             	sub    $0x28,%esp
80105fa6:	89 5d f4             	mov    %ebx,-0xc(%ebp)
80105fa9:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(tf->trapno == T_SYSCALL){
80105fac:	8b 43 30             	mov    0x30(%ebx),%eax
80105faf:	83 f8 40             	cmp    $0x40,%eax
80105fb2:	0f 84 48 01 00 00    	je     80106100 <trap+0x160>
    if(myproc()->killed)
      exit();
    return;
  }

  switch(tf->trapno){
80105fb8:	83 e8 20             	sub    $0x20,%eax
80105fbb:	83 f8 1f             	cmp    $0x1f,%eax
80105fbe:	77 68                	ja     80106028 <trap+0x88>
80105fc0:	ff 24 85 84 82 10 80 	jmp    *-0x7fef7d7c(,%eax,4)
80105fc7:	90                   	nop
80105fc8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105fcf:	00 
      release(&tickslock);
    }
    lapiceoi();
    break;
  case T_IRQ0 + IRQ_IDE:
    ideintr();
80105fd0:	e8 ab c3 ff ff       	call   80102380 <ideintr>
    lapiceoi();
80105fd5:	e8 b6 ca ff ff       	call   80102a90 <lapiceoi>
  }

  // Force process exit if it has been killed and is in user space.
  // (If it is still executing in the kernel, let it keep running
  // until it gets to the regular system call return.)
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
80105fda:	e8 c1 db ff ff       	call   80103ba0 <myproc>
80105fdf:	85 c0                	test   %eax,%eax
80105fe1:	74 1a                	je     80105ffd <trap+0x5d>
80105fe3:	e8 b8 db ff ff       	call   80103ba0 <myproc>
80105fe8:	8b 50 24             	mov    0x24(%eax),%edx
80105feb:	85 d2                	test   %edx,%edx
80105fed:	74 0e                	je     80105ffd <trap+0x5d>
80105fef:	0f b7 43 3c          	movzwl 0x3c(%ebx),%eax
80105ff3:	f7 d0                	not    %eax
80105ff5:	a8 03                	test   $0x3,%al
80105ff7:	0f 84 cb 01 00 00    	je     801061c8 <trap+0x228>
     tf->trapno == T_IRQ0+IRQ_TIMER)
   yield();  */
   

  // Check if the process has been killed since we yielded
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
80105ffd:	e8 9e db ff ff       	call   80103ba0 <myproc>
80106002:	85 c0                	test   %eax,%eax
80106004:	74 1a                	je     80106020 <trap+0x80>
80106006:	e8 95 db ff ff       	call   80103ba0 <myproc>
8010600b:	8b 40 24             	mov    0x24(%eax),%eax
8010600e:	85 c0                	test   %eax,%eax
80106010:	74 0e                	je     80106020 <trap+0x80>
80106012:	0f b7 43 3c          	movzwl 0x3c(%ebx),%eax
80106016:	f7 d0                	not    %eax
80106018:	a8 03                	test   $0x3,%al
8010601a:	0f 84 0d 01 00 00    	je     8010612d <trap+0x18d>
    exit();
}
80106020:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80106023:	c9                   	leave
80106024:	c3                   	ret
80106025:	8d 76 00             	lea    0x0(%esi),%esi
80106028:	89 75 f8             	mov    %esi,-0x8(%ebp)
8010602b:	89 7d fc             	mov    %edi,-0x4(%ebp)
    if(myproc() == 0 || (tf->cs&3) == 0){
8010602e:	e8 6d db ff ff       	call   80103ba0 <myproc>
    cprintf("pid %d %s: trap %d err %d on cpu %d "
80106033:	8b 73 38             	mov    0x38(%ebx),%esi
80106036:	89 75 e4             	mov    %esi,-0x1c(%ebp)
    if(myproc() == 0 || (tf->cs&3) == 0){
80106039:	85 c0                	test   %eax,%eax
8010603b:	0f 84 a1 01 00 00    	je     801061e2 <trap+0x242>
80106041:	f6 43 3c 03          	testb  $0x3,0x3c(%ebx)
80106045:	0f 84 97 01 00 00    	je     801061e2 <trap+0x242>
  asm volatile("movl %%cr2,%0" : "=r" (val));
8010604b:	0f 20 d7             	mov    %cr2,%edi
    cprintf("pid %d %s: trap %d err %d on cpu %d "
8010604e:	e8 2d db ff ff       	call   80103b80 <cpuid>
80106053:	8b 4b 30             	mov    0x30(%ebx),%ecx
80106056:	89 45 d8             	mov    %eax,-0x28(%ebp)
80106059:	8b 43 34             	mov    0x34(%ebx),%eax
8010605c:	89 4d dc             	mov    %ecx,-0x24(%ebp)
8010605f:	89 45 e0             	mov    %eax,-0x20(%ebp)
            myproc()->pid, myproc()->name, tf->trapno,
80106062:	e8 39 db ff ff       	call   80103ba0 <myproc>
80106067:	8d 70 6c             	lea    0x6c(%eax),%esi
8010606a:	e8 31 db ff ff       	call   80103ba0 <myproc>
    cprintf("pid %d %s: trap %d err %d on cpu %d "
8010606f:	8b 55 d8             	mov    -0x28(%ebp),%edx
80106072:	8b 4d dc             	mov    -0x24(%ebp),%ecx
80106075:	57                   	push   %edi
80106076:	ff 75 e4             	push   -0x1c(%ebp)
80106079:	52                   	push   %edx
8010607a:	ff 75 e0             	push   -0x20(%ebp)
8010607d:	51                   	push   %ecx
8010607e:	56                   	push   %esi
8010607f:	ff 70 10             	push   0x10(%eax)
80106082:	68 5c 7f 10 80       	push   $0x80107f5c
80106087:	e8 64 a6 ff ff       	call   801006f0 <cprintf>
    myproc()->killed = 1;
8010608c:	83 c4 20             	add    $0x20,%esp
8010608f:	e8 0c db ff ff       	call   80103ba0 <myproc>
80106094:	c7 40 24 01 00 00 00 	movl   $0x1,0x24(%eax)
8010609b:	8b 75 f8             	mov    -0x8(%ebp),%esi
8010609e:	8b 7d fc             	mov    -0x4(%ebp),%edi
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
801060a1:	e8 fa da ff ff       	call   80103ba0 <myproc>
801060a6:	85 c0                	test   %eax,%eax
801060a8:	0f 85 35 ff ff ff    	jne    80105fe3 <trap+0x43>
801060ae:	e9 4a ff ff ff       	jmp    80105ffd <trap+0x5d>
801060b3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    cprintf("cpu%d: spurious interrupt at %x:%x\n",
801060b8:	8b 4b 38             	mov    0x38(%ebx),%ecx
801060bb:	0f b7 53 3c          	movzwl 0x3c(%ebx),%edx
801060bf:	89 4d e0             	mov    %ecx,-0x20(%ebp)
801060c2:	89 55 e4             	mov    %edx,-0x1c(%ebp)
801060c5:	e8 b6 da ff ff       	call   80103b80 <cpuid>
801060ca:	8b 4d e0             	mov    -0x20(%ebp),%ecx
801060cd:	8b 55 e4             	mov    -0x1c(%ebp),%edx
801060d0:	51                   	push   %ecx
801060d1:	52                   	push   %edx
801060d2:	50                   	push   %eax
801060d3:	68 04 7f 10 80       	push   $0x80107f04
801060d8:	e8 13 a6 ff ff       	call   801006f0 <cprintf>
    lapiceoi();
801060dd:	e8 ae c9 ff ff       	call   80102a90 <lapiceoi>
    break;
801060e2:	83 c4 10             	add    $0x10,%esp
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
801060e5:	e8 b6 da ff ff       	call   80103ba0 <myproc>
801060ea:	85 c0                	test   %eax,%eax
801060ec:	0f 85 f1 fe ff ff    	jne    80105fe3 <trap+0x43>
801060f2:	e9 06 ff ff ff       	jmp    80105ffd <trap+0x5d>
801060f7:	90                   	nop
801060f8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801060ff:	00 
    if(myproc()->killed)
80106100:	e8 9b da ff ff       	call   80103ba0 <myproc>
80106105:	8b 40 24             	mov    0x24(%eax),%eax
80106108:	85 c0                	test   %eax,%eax
8010610a:	0f 85 c8 00 00 00    	jne    801061d8 <trap+0x238>
    myproc()->tf = tf;
80106110:	e8 8b da ff ff       	call   80103ba0 <myproc>
80106115:	89 58 18             	mov    %ebx,0x18(%eax)
    syscall();
80106118:	e8 73 ed ff ff       	call   80104e90 <syscall>
    if(myproc()->killed)
8010611d:	e8 7e da ff ff       	call   80103ba0 <myproc>
80106122:	8b 48 24             	mov    0x24(%eax),%ecx
80106125:	85 c9                	test   %ecx,%ecx
80106127:	0f 84 f3 fe ff ff    	je     80106020 <trap+0x80>
}
8010612d:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80106130:	c9                   	leave
      exit();
80106131:	e9 fa de ff ff       	jmp    80104030 <exit>
80106136:	66 90                	xchg   %ax,%ax
80106138:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010613f:	00 
    uartintr();
80106140:	e8 5b 02 00 00       	call   801063a0 <uartintr>
    lapiceoi();
80106145:	e8 46 c9 ff ff       	call   80102a90 <lapiceoi>
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
8010614a:	e8 51 da ff ff       	call   80103ba0 <myproc>
8010614f:	85 c0                	test   %eax,%eax
80106151:	0f 85 8c fe ff ff    	jne    80105fe3 <trap+0x43>
80106157:	e9 a1 fe ff ff       	jmp    80105ffd <trap+0x5d>
8010615c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    kbdintr();
80106160:	e8 eb c7 ff ff       	call   80102950 <kbdintr>
    lapiceoi();
80106165:	e8 26 c9 ff ff       	call   80102a90 <lapiceoi>
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
8010616a:	e8 31 da ff ff       	call   80103ba0 <myproc>
8010616f:	85 c0                	test   %eax,%eax
80106171:	0f 85 6c fe ff ff    	jne    80105fe3 <trap+0x43>
80106177:	e9 81 fe ff ff       	jmp    80105ffd <trap+0x5d>
8010617c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    if(cpuid() == 0){
80106180:	e8 fb d9 ff ff       	call   80103b80 <cpuid>
80106185:	85 c0                	test   %eax,%eax
80106187:	0f 85 48 fe ff ff    	jne    80105fd5 <trap+0x35>
      acquire(&tickslock);
8010618d:	83 ec 0c             	sub    $0xc,%esp
80106190:	68 a0 4d 11 80       	push   $0x80114da0
80106195:	e8 a6 e7 ff ff       	call   80104940 <acquire>
      wakeup(&ticks);
8010619a:	c7 04 24 80 4d 11 80 	movl   $0x80114d80,(%esp)
      ticks++;
801061a1:	83 05 80 4d 11 80 01 	addl   $0x1,0x80114d80
      wakeup(&ticks);
801061a8:	e8 23 e2 ff ff       	call   801043d0 <wakeup>
      release(&tickslock);
801061ad:	c7 04 24 a0 4d 11 80 	movl   $0x80114da0,(%esp)
801061b4:	e8 27 e7 ff ff       	call   801048e0 <release>
801061b9:	83 c4 10             	add    $0x10,%esp
    lapiceoi();
801061bc:	e9 14 fe ff ff       	jmp    80105fd5 <trap+0x35>
801061c1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    exit();
801061c8:	e8 63 de ff ff       	call   80104030 <exit>
801061cd:	e9 2b fe ff ff       	jmp    80105ffd <trap+0x5d>
801061d2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      exit();
801061d8:	e8 53 de ff ff       	call   80104030 <exit>
801061dd:	e9 2e ff ff ff       	jmp    80106110 <trap+0x170>
801061e2:	0f 20 d2             	mov    %cr2,%edx
801061e5:	89 55 e0             	mov    %edx,-0x20(%ebp)
      cprintf("unexpected trap %d from cpu %d eip %x (cr2=0x%x)\n",
801061e8:	e8 93 d9 ff ff       	call   80103b80 <cpuid>
801061ed:	8b 55 e0             	mov    -0x20(%ebp),%edx
801061f0:	83 ec 0c             	sub    $0xc,%esp
801061f3:	52                   	push   %edx
801061f4:	ff 75 e4             	push   -0x1c(%ebp)
801061f7:	50                   	push   %eax
801061f8:	ff 73 30             	push   0x30(%ebx)
801061fb:	68 28 7f 10 80       	push   $0x80107f28
80106200:	e8 eb a4 ff ff       	call   801006f0 <cprintf>
      panic("trap");
80106205:	83 c4 14             	add    $0x14,%esp
80106208:	68 33 7d 10 80       	push   $0x80107d33
8010620d:	e8 8e a1 ff ff       	call   801003a0 <panic>
80106212:	66 90                	xchg   %ax,%ax
80106214:	66 90                	xchg   %ax,%ax
80106216:	66 90                	xchg   %ax,%ax
80106218:	66 90                	xchg   %ax,%ax
8010621a:	66 90                	xchg   %ax,%ax
8010621c:	66 90                	xchg   %ax,%ax
8010621e:	66 90                	xchg   %ax,%ax

80106220 <uartgetc>:
}

static int
uartgetc(void)
{
  if(!uart)
80106220:	a1 e0 55 11 80       	mov    0x801155e0,%eax
80106225:	85 c0                	test   %eax,%eax
80106227:	74 17                	je     80106240 <uartgetc+0x20>
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80106229:	ba fd 03 00 00       	mov    $0x3fd,%edx
8010622e:	ec                   	in     (%dx),%al
    return -1;
  if(!(inb(COM1+5) & 0x01))
8010622f:	a8 01                	test   $0x1,%al
80106231:	74 0d                	je     80106240 <uartgetc+0x20>
80106233:	ba f8 03 00 00       	mov    $0x3f8,%edx
80106238:	ec                   	in     (%dx),%al
    return -1;
  return inb(COM1+0);
80106239:	0f b6 c0             	movzbl %al,%eax
}
8010623c:	c3                   	ret
8010623d:	8d 76 00             	lea    0x0(%esi),%esi
    return -1;
80106240:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80106245:	c3                   	ret
80106246:	66 90                	xchg   %ax,%ax
80106248:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010624f:	00 

80106250 <uartinit>:
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80106250:	31 c0                	xor    %eax,%eax
80106252:	ba fa 03 00 00       	mov    $0x3fa,%edx
80106257:	ee                   	out    %al,(%dx)
80106258:	b8 80 ff ff ff       	mov    $0xffffff80,%eax
8010625d:	ba fb 03 00 00       	mov    $0x3fb,%edx
80106262:	ee                   	out    %al,(%dx)
80106263:	b8 0c 00 00 00       	mov    $0xc,%eax
80106268:	ba f8 03 00 00       	mov    $0x3f8,%edx
8010626d:	ee                   	out    %al,(%dx)
8010626e:	31 c0                	xor    %eax,%eax
80106270:	ba f9 03 00 00       	mov    $0x3f9,%edx
80106275:	ee                   	out    %al,(%dx)
80106276:	b8 03 00 00 00       	mov    $0x3,%eax
8010627b:	ba fb 03 00 00       	mov    $0x3fb,%edx
80106280:	ee                   	out    %al,(%dx)
80106281:	ba fc 03 00 00       	mov    $0x3fc,%edx
80106286:	31 c0                	xor    %eax,%eax
80106288:	ee                   	out    %al,(%dx)
80106289:	b8 01 00 00 00       	mov    $0x1,%eax
8010628e:	ba f9 03 00 00       	mov    $0x3f9,%edx
80106293:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80106294:	ba fd 03 00 00       	mov    $0x3fd,%edx
80106299:	ec                   	in     (%dx),%al
  if(inb(COM1+5) == 0xFF)
8010629a:	3c ff                	cmp    $0xff,%al
8010629c:	0f 84 8e 00 00 00    	je     80106330 <uartinit+0xe0>
{
801062a2:	55                   	push   %ebp
801062a3:	ba fa 03 00 00       	mov    $0x3fa,%edx
801062a8:	89 e5                	mov    %esp,%ebp
801062aa:	83 ec 30             	sub    $0x30,%esp
  uart = 1;
801062ad:	c7 05 e0 55 11 80 01 	movl   $0x1,0x801155e0
801062b4:	00 00 00 
{
801062b7:	89 5d f4             	mov    %ebx,-0xc(%ebp)
801062ba:	89 7d fc             	mov    %edi,-0x4(%ebp)
801062bd:	ec                   	in     (%dx),%al
801062be:	ba f8 03 00 00       	mov    $0x3f8,%edx
801062c3:	ec                   	in     (%dx),%al
  ioapicenable(IRQ_COM1, 0);
801062c4:	6a 00                	push   $0x0
  for(p="xv6...\n"; *p; p++)
801062c6:	bf 38 7d 10 80       	mov    $0x80107d38,%edi
  ioapicenable(IRQ_COM1, 0);
801062cb:	6a 04                	push   $0x4
801062cd:	e8 2e c3 ff ff       	call   80102600 <ioapicenable>
801062d2:	83 c4 10             	add    $0x10,%esp
  for(p="xv6...\n"; *p; p++)
801062d5:	c6 45 e7 78          	movb   $0x78,-0x19(%ebp)
801062d9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  if(!uart)
801062e0:	a1 e0 55 11 80       	mov    0x801155e0,%eax
801062e5:	bb 80 00 00 00       	mov    $0x80,%ebx
801062ea:	85 c0                	test   %eax,%eax
801062ec:	75 14                	jne    80106302 <uartinit+0xb2>
801062ee:	eb 26                	jmp    80106316 <uartinit+0xc6>
    microdelay(10);
801062f0:	83 ec 0c             	sub    $0xc,%esp
801062f3:	6a 0a                	push   $0xa
801062f5:	e8 b6 c7 ff ff       	call   80102ab0 <microdelay>
  for(i = 0; i < 128 && !(inb(COM1+5) & 0x20); i++)
801062fa:	83 c4 10             	add    $0x10,%esp
801062fd:	83 eb 01             	sub    $0x1,%ebx
80106300:	74 0a                	je     8010630c <uartinit+0xbc>
80106302:	ba fd 03 00 00       	mov    $0x3fd,%edx
80106307:	ec                   	in     (%dx),%al
80106308:	a8 20                	test   $0x20,%al
8010630a:	74 e4                	je     801062f0 <uartinit+0xa0>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
8010630c:	0f b6 45 e7          	movzbl -0x19(%ebp),%eax
80106310:	ba f8 03 00 00       	mov    $0x3f8,%edx
80106315:	ee                   	out    %al,(%dx)
  for(p="xv6...\n"; *p; p++)
80106316:	0f b6 47 01          	movzbl 0x1(%edi),%eax
8010631a:	83 c7 01             	add    $0x1,%edi
8010631d:	88 45 e7             	mov    %al,-0x19(%ebp)
80106320:	81 ff 3f 7d 10 80    	cmp    $0x80107d3f,%edi
80106326:	75 b8                	jne    801062e0 <uartinit+0x90>
}
80106328:	8b 5d f4             	mov    -0xc(%ebp),%ebx
8010632b:	8b 7d fc             	mov    -0x4(%ebp),%edi
8010632e:	c9                   	leave
8010632f:	c3                   	ret
80106330:	c3                   	ret
80106331:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80106338:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010633f:	00 

80106340 <uartputc>:
  if(!uart)
80106340:	a1 e0 55 11 80       	mov    0x801155e0,%eax
80106345:	85 c0                	test   %eax,%eax
80106347:	74 47                	je     80106390 <uartputc+0x50>
{
80106349:	55                   	push   %ebp
8010634a:	89 e5                	mov    %esp,%ebp
8010634c:	83 ec 08             	sub    $0x8,%esp
8010634f:	89 5d f8             	mov    %ebx,-0x8(%ebp)
  if(!uart)
80106352:	bb 80 00 00 00       	mov    $0x80,%ebx
80106357:	eb 19                	jmp    80106372 <uartputc+0x32>
80106359:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    microdelay(10);
80106360:	83 ec 0c             	sub    $0xc,%esp
80106363:	6a 0a                	push   $0xa
80106365:	e8 46 c7 ff ff       	call   80102ab0 <microdelay>
  for(i = 0; i < 128 && !(inb(COM1+5) & 0x20); i++)
8010636a:	83 c4 10             	add    $0x10,%esp
8010636d:	83 eb 01             	sub    $0x1,%ebx
80106370:	74 0a                	je     8010637c <uartputc+0x3c>
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80106372:	ba fd 03 00 00       	mov    $0x3fd,%edx
80106377:	ec                   	in     (%dx),%al
80106378:	a8 20                	test   $0x20,%al
8010637a:	74 e4                	je     80106360 <uartputc+0x20>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
8010637c:	8b 45 08             	mov    0x8(%ebp),%eax
8010637f:	ba f8 03 00 00       	mov    $0x3f8,%edx
80106384:	ee                   	out    %al,(%dx)
}
80106385:	8b 5d f8             	mov    -0x8(%ebp),%ebx
80106388:	c9                   	leave
80106389:	c3                   	ret
8010638a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80106390:	c3                   	ret
80106391:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80106398:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010639f:	00 

801063a0 <uartintr>:

void
uartintr(void)
{
801063a0:	55                   	push   %ebp
801063a1:	89 e5                	mov    %esp,%ebp
801063a3:	83 ec 14             	sub    $0x14,%esp
  consoleintr(uartgetc);
801063a6:	68 20 62 10 80       	push   $0x80106220
801063ab:	e8 60 a5 ff ff       	call   80100910 <consoleintr>
}
801063b0:	83 c4 10             	add    $0x10,%esp
801063b3:	c9                   	leave
801063b4:	c3                   	ret

801063b5 <vector0>:
# generated by vectors.pl - do not edit
# handlers
.globl alltraps
.globl vector0
vector0:
  pushl $0
801063b5:	6a 00                	push   $0x0
  pushl $0
801063b7:	6a 00                	push   $0x0
  jmp alltraps
801063b9:	e9 d1 fa ff ff       	jmp    80105e8f <alltraps>

801063be <vector1>:
.globl vector1
vector1:
  pushl $0
801063be:	6a 00                	push   $0x0
  pushl $1
801063c0:	6a 01                	push   $0x1
  jmp alltraps
801063c2:	e9 c8 fa ff ff       	jmp    80105e8f <alltraps>

801063c7 <vector2>:
.globl vector2
vector2:
  pushl $0
801063c7:	6a 00                	push   $0x0
  pushl $2
801063c9:	6a 02                	push   $0x2
  jmp alltraps
801063cb:	e9 bf fa ff ff       	jmp    80105e8f <alltraps>

801063d0 <vector3>:
.globl vector3
vector3:
  pushl $0
801063d0:	6a 00                	push   $0x0
  pushl $3
801063d2:	6a 03                	push   $0x3
  jmp alltraps
801063d4:	e9 b6 fa ff ff       	jmp    80105e8f <alltraps>

801063d9 <vector4>:
.globl vector4
vector4:
  pushl $0
801063d9:	6a 00                	push   $0x0
  pushl $4
801063db:	6a 04                	push   $0x4
  jmp alltraps
801063dd:	e9 ad fa ff ff       	jmp    80105e8f <alltraps>

801063e2 <vector5>:
.globl vector5
vector5:
  pushl $0
801063e2:	6a 00                	push   $0x0
  pushl $5
801063e4:	6a 05                	push   $0x5
  jmp alltraps
801063e6:	e9 a4 fa ff ff       	jmp    80105e8f <alltraps>

801063eb <vector6>:
.globl vector6
vector6:
  pushl $0
801063eb:	6a 00                	push   $0x0
  pushl $6
801063ed:	6a 06                	push   $0x6
  jmp alltraps
801063ef:	e9 9b fa ff ff       	jmp    80105e8f <alltraps>

801063f4 <vector7>:
.globl vector7
vector7:
  pushl $0
801063f4:	6a 00                	push   $0x0
  pushl $7
801063f6:	6a 07                	push   $0x7
  jmp alltraps
801063f8:	e9 92 fa ff ff       	jmp    80105e8f <alltraps>

801063fd <vector8>:
.globl vector8
vector8:
  pushl $8
801063fd:	6a 08                	push   $0x8
  jmp alltraps
801063ff:	e9 8b fa ff ff       	jmp    80105e8f <alltraps>

80106404 <vector9>:
.globl vector9
vector9:
  pushl $0
80106404:	6a 00                	push   $0x0
  pushl $9
80106406:	6a 09                	push   $0x9
  jmp alltraps
80106408:	e9 82 fa ff ff       	jmp    80105e8f <alltraps>

8010640d <vector10>:
.globl vector10
vector10:
  pushl $10
8010640d:	6a 0a                	push   $0xa
  jmp alltraps
8010640f:	e9 7b fa ff ff       	jmp    80105e8f <alltraps>

80106414 <vector11>:
.globl vector11
vector11:
  pushl $11
80106414:	6a 0b                	push   $0xb
  jmp alltraps
80106416:	e9 74 fa ff ff       	jmp    80105e8f <alltraps>

8010641b <vector12>:
.globl vector12
vector12:
  pushl $12
8010641b:	6a 0c                	push   $0xc
  jmp alltraps
8010641d:	e9 6d fa ff ff       	jmp    80105e8f <alltraps>

80106422 <vector13>:
.globl vector13
vector13:
  pushl $13
80106422:	6a 0d                	push   $0xd
  jmp alltraps
80106424:	e9 66 fa ff ff       	jmp    80105e8f <alltraps>

80106429 <vector14>:
.globl vector14
vector14:
  pushl $14
80106429:	6a 0e                	push   $0xe
  jmp alltraps
8010642b:	e9 5f fa ff ff       	jmp    80105e8f <alltraps>

80106430 <vector15>:
.globl vector15
vector15:
  pushl $0
80106430:	6a 00                	push   $0x0
  pushl $15
80106432:	6a 0f                	push   $0xf
  jmp alltraps
80106434:	e9 56 fa ff ff       	jmp    80105e8f <alltraps>

80106439 <vector16>:
.globl vector16
vector16:
  pushl $0
80106439:	6a 00                	push   $0x0
  pushl $16
8010643b:	6a 10                	push   $0x10
  jmp alltraps
8010643d:	e9 4d fa ff ff       	jmp    80105e8f <alltraps>

80106442 <vector17>:
.globl vector17
vector17:
  pushl $17
80106442:	6a 11                	push   $0x11
  jmp alltraps
80106444:	e9 46 fa ff ff       	jmp    80105e8f <alltraps>

80106449 <vector18>:
.globl vector18
vector18:
  pushl $0
80106449:	6a 00                	push   $0x0
  pushl $18
8010644b:	6a 12                	push   $0x12
  jmp alltraps
8010644d:	e9 3d fa ff ff       	jmp    80105e8f <alltraps>

80106452 <vector19>:
.globl vector19
vector19:
  pushl $0
80106452:	6a 00                	push   $0x0
  pushl $19
80106454:	6a 13                	push   $0x13
  jmp alltraps
80106456:	e9 34 fa ff ff       	jmp    80105e8f <alltraps>

8010645b <vector20>:
.globl vector20
vector20:
  pushl $0
8010645b:	6a 00                	push   $0x0
  pushl $20
8010645d:	6a 14                	push   $0x14
  jmp alltraps
8010645f:	e9 2b fa ff ff       	jmp    80105e8f <alltraps>

80106464 <vector21>:
.globl vector21
vector21:
  pushl $0
80106464:	6a 00                	push   $0x0
  pushl $21
80106466:	6a 15                	push   $0x15
  jmp alltraps
80106468:	e9 22 fa ff ff       	jmp    80105e8f <alltraps>

8010646d <vector22>:
.globl vector22
vector22:
  pushl $0
8010646d:	6a 00                	push   $0x0
  pushl $22
8010646f:	6a 16                	push   $0x16
  jmp alltraps
80106471:	e9 19 fa ff ff       	jmp    80105e8f <alltraps>

80106476 <vector23>:
.globl vector23
vector23:
  pushl $0
80106476:	6a 00                	push   $0x0
  pushl $23
80106478:	6a 17                	push   $0x17
  jmp alltraps
8010647a:	e9 10 fa ff ff       	jmp    80105e8f <alltraps>

8010647f <vector24>:
.globl vector24
vector24:
  pushl $0
8010647f:	6a 00                	push   $0x0
  pushl $24
80106481:	6a 18                	push   $0x18
  jmp alltraps
80106483:	e9 07 fa ff ff       	jmp    80105e8f <alltraps>

80106488 <vector25>:
.globl vector25
vector25:
  pushl $0
80106488:	6a 00                	push   $0x0
  pushl $25
8010648a:	6a 19                	push   $0x19
  jmp alltraps
8010648c:	e9 fe f9 ff ff       	jmp    80105e8f <alltraps>

80106491 <vector26>:
.globl vector26
vector26:
  pushl $0
80106491:	6a 00                	push   $0x0
  pushl $26
80106493:	6a 1a                	push   $0x1a
  jmp alltraps
80106495:	e9 f5 f9 ff ff       	jmp    80105e8f <alltraps>

8010649a <vector27>:
.globl vector27
vector27:
  pushl $0
8010649a:	6a 00                	push   $0x0
  pushl $27
8010649c:	6a 1b                	push   $0x1b
  jmp alltraps
8010649e:	e9 ec f9 ff ff       	jmp    80105e8f <alltraps>

801064a3 <vector28>:
.globl vector28
vector28:
  pushl $0
801064a3:	6a 00                	push   $0x0
  pushl $28
801064a5:	6a 1c                	push   $0x1c
  jmp alltraps
801064a7:	e9 e3 f9 ff ff       	jmp    80105e8f <alltraps>

801064ac <vector29>:
.globl vector29
vector29:
  pushl $0
801064ac:	6a 00                	push   $0x0
  pushl $29
801064ae:	6a 1d                	push   $0x1d
  jmp alltraps
801064b0:	e9 da f9 ff ff       	jmp    80105e8f <alltraps>

801064b5 <vector30>:
.globl vector30
vector30:
  pushl $0
801064b5:	6a 00                	push   $0x0
  pushl $30
801064b7:	6a 1e                	push   $0x1e
  jmp alltraps
801064b9:	e9 d1 f9 ff ff       	jmp    80105e8f <alltraps>

801064be <vector31>:
.globl vector31
vector31:
  pushl $0
801064be:	6a 00                	push   $0x0
  pushl $31
801064c0:	6a 1f                	push   $0x1f
  jmp alltraps
801064c2:	e9 c8 f9 ff ff       	jmp    80105e8f <alltraps>

801064c7 <vector32>:
.globl vector32
vector32:
  pushl $0
801064c7:	6a 00                	push   $0x0
  pushl $32
801064c9:	6a 20                	push   $0x20
  jmp alltraps
801064cb:	e9 bf f9 ff ff       	jmp    80105e8f <alltraps>

801064d0 <vector33>:
.globl vector33
vector33:
  pushl $0
801064d0:	6a 00                	push   $0x0
  pushl $33
801064d2:	6a 21                	push   $0x21
  jmp alltraps
801064d4:	e9 b6 f9 ff ff       	jmp    80105e8f <alltraps>

801064d9 <vector34>:
.globl vector34
vector34:
  pushl $0
801064d9:	6a 00                	push   $0x0
  pushl $34
801064db:	6a 22                	push   $0x22
  jmp alltraps
801064dd:	e9 ad f9 ff ff       	jmp    80105e8f <alltraps>

801064e2 <vector35>:
.globl vector35
vector35:
  pushl $0
801064e2:	6a 00                	push   $0x0
  pushl $35
801064e4:	6a 23                	push   $0x23
  jmp alltraps
801064e6:	e9 a4 f9 ff ff       	jmp    80105e8f <alltraps>

801064eb <vector36>:
.globl vector36
vector36:
  pushl $0
801064eb:	6a 00                	push   $0x0
  pushl $36
801064ed:	6a 24                	push   $0x24
  jmp alltraps
801064ef:	e9 9b f9 ff ff       	jmp    80105e8f <alltraps>

801064f4 <vector37>:
.globl vector37
vector37:
  pushl $0
801064f4:	6a 00                	push   $0x0
  pushl $37
801064f6:	6a 25                	push   $0x25
  jmp alltraps
801064f8:	e9 92 f9 ff ff       	jmp    80105e8f <alltraps>

801064fd <vector38>:
.globl vector38
vector38:
  pushl $0
801064fd:	6a 00                	push   $0x0
  pushl $38
801064ff:	6a 26                	push   $0x26
  jmp alltraps
80106501:	e9 89 f9 ff ff       	jmp    80105e8f <alltraps>

80106506 <vector39>:
.globl vector39
vector39:
  pushl $0
80106506:	6a 00                	push   $0x0
  pushl $39
80106508:	6a 27                	push   $0x27
  jmp alltraps
8010650a:	e9 80 f9 ff ff       	jmp    80105e8f <alltraps>

8010650f <vector40>:
.globl vector40
vector40:
  pushl $0
8010650f:	6a 00                	push   $0x0
  pushl $40
80106511:	6a 28                	push   $0x28
  jmp alltraps
80106513:	e9 77 f9 ff ff       	jmp    80105e8f <alltraps>

80106518 <vector41>:
.globl vector41
vector41:
  pushl $0
80106518:	6a 00                	push   $0x0
  pushl $41
8010651a:	6a 29                	push   $0x29
  jmp alltraps
8010651c:	e9 6e f9 ff ff       	jmp    80105e8f <alltraps>

80106521 <vector42>:
.globl vector42
vector42:
  pushl $0
80106521:	6a 00                	push   $0x0
  pushl $42
80106523:	6a 2a                	push   $0x2a
  jmp alltraps
80106525:	e9 65 f9 ff ff       	jmp    80105e8f <alltraps>

8010652a <vector43>:
.globl vector43
vector43:
  pushl $0
8010652a:	6a 00                	push   $0x0
  pushl $43
8010652c:	6a 2b                	push   $0x2b
  jmp alltraps
8010652e:	e9 5c f9 ff ff       	jmp    80105e8f <alltraps>

80106533 <vector44>:
.globl vector44
vector44:
  pushl $0
80106533:	6a 00                	push   $0x0
  pushl $44
80106535:	6a 2c                	push   $0x2c
  jmp alltraps
80106537:	e9 53 f9 ff ff       	jmp    80105e8f <alltraps>

8010653c <vector45>:
.globl vector45
vector45:
  pushl $0
8010653c:	6a 00                	push   $0x0
  pushl $45
8010653e:	6a 2d                	push   $0x2d
  jmp alltraps
80106540:	e9 4a f9 ff ff       	jmp    80105e8f <alltraps>

80106545 <vector46>:
.globl vector46
vector46:
  pushl $0
80106545:	6a 00                	push   $0x0
  pushl $46
80106547:	6a 2e                	push   $0x2e
  jmp alltraps
80106549:	e9 41 f9 ff ff       	jmp    80105e8f <alltraps>

8010654e <vector47>:
.globl vector47
vector47:
  pushl $0
8010654e:	6a 00                	push   $0x0
  pushl $47
80106550:	6a 2f                	push   $0x2f
  jmp alltraps
80106552:	e9 38 f9 ff ff       	jmp    80105e8f <alltraps>

80106557 <vector48>:
.globl vector48
vector48:
  pushl $0
80106557:	6a 00                	push   $0x0
  pushl $48
80106559:	6a 30                	push   $0x30
  jmp alltraps
8010655b:	e9 2f f9 ff ff       	jmp    80105e8f <alltraps>

80106560 <vector49>:
.globl vector49
vector49:
  pushl $0
80106560:	6a 00                	push   $0x0
  pushl $49
80106562:	6a 31                	push   $0x31
  jmp alltraps
80106564:	e9 26 f9 ff ff       	jmp    80105e8f <alltraps>

80106569 <vector50>:
.globl vector50
vector50:
  pushl $0
80106569:	6a 00                	push   $0x0
  pushl $50
8010656b:	6a 32                	push   $0x32
  jmp alltraps
8010656d:	e9 1d f9 ff ff       	jmp    80105e8f <alltraps>

80106572 <vector51>:
.globl vector51
vector51:
  pushl $0
80106572:	6a 00                	push   $0x0
  pushl $51
80106574:	6a 33                	push   $0x33
  jmp alltraps
80106576:	e9 14 f9 ff ff       	jmp    80105e8f <alltraps>

8010657b <vector52>:
.globl vector52
vector52:
  pushl $0
8010657b:	6a 00                	push   $0x0
  pushl $52
8010657d:	6a 34                	push   $0x34
  jmp alltraps
8010657f:	e9 0b f9 ff ff       	jmp    80105e8f <alltraps>

80106584 <vector53>:
.globl vector53
vector53:
  pushl $0
80106584:	6a 00                	push   $0x0
  pushl $53
80106586:	6a 35                	push   $0x35
  jmp alltraps
80106588:	e9 02 f9 ff ff       	jmp    80105e8f <alltraps>

8010658d <vector54>:
.globl vector54
vector54:
  pushl $0
8010658d:	6a 00                	push   $0x0
  pushl $54
8010658f:	6a 36                	push   $0x36
  jmp alltraps
80106591:	e9 f9 f8 ff ff       	jmp    80105e8f <alltraps>

80106596 <vector55>:
.globl vector55
vector55:
  pushl $0
80106596:	6a 00                	push   $0x0
  pushl $55
80106598:	6a 37                	push   $0x37
  jmp alltraps
8010659a:	e9 f0 f8 ff ff       	jmp    80105e8f <alltraps>

8010659f <vector56>:
.globl vector56
vector56:
  pushl $0
8010659f:	6a 00                	push   $0x0
  pushl $56
801065a1:	6a 38                	push   $0x38
  jmp alltraps
801065a3:	e9 e7 f8 ff ff       	jmp    80105e8f <alltraps>

801065a8 <vector57>:
.globl vector57
vector57:
  pushl $0
801065a8:	6a 00                	push   $0x0
  pushl $57
801065aa:	6a 39                	push   $0x39
  jmp alltraps
801065ac:	e9 de f8 ff ff       	jmp    80105e8f <alltraps>

801065b1 <vector58>:
.globl vector58
vector58:
  pushl $0
801065b1:	6a 00                	push   $0x0
  pushl $58
801065b3:	6a 3a                	push   $0x3a
  jmp alltraps
801065b5:	e9 d5 f8 ff ff       	jmp    80105e8f <alltraps>

801065ba <vector59>:
.globl vector59
vector59:
  pushl $0
801065ba:	6a 00                	push   $0x0
  pushl $59
801065bc:	6a 3b                	push   $0x3b
  jmp alltraps
801065be:	e9 cc f8 ff ff       	jmp    80105e8f <alltraps>

801065c3 <vector60>:
.globl vector60
vector60:
  pushl $0
801065c3:	6a 00                	push   $0x0
  pushl $60
801065c5:	6a 3c                	push   $0x3c
  jmp alltraps
801065c7:	e9 c3 f8 ff ff       	jmp    80105e8f <alltraps>

801065cc <vector61>:
.globl vector61
vector61:
  pushl $0
801065cc:	6a 00                	push   $0x0
  pushl $61
801065ce:	6a 3d                	push   $0x3d
  jmp alltraps
801065d0:	e9 ba f8 ff ff       	jmp    80105e8f <alltraps>

801065d5 <vector62>:
.globl vector62
vector62:
  pushl $0
801065d5:	6a 00                	push   $0x0
  pushl $62
801065d7:	6a 3e                	push   $0x3e
  jmp alltraps
801065d9:	e9 b1 f8 ff ff       	jmp    80105e8f <alltraps>

801065de <vector63>:
.globl vector63
vector63:
  pushl $0
801065de:	6a 00                	push   $0x0
  pushl $63
801065e0:	6a 3f                	push   $0x3f
  jmp alltraps
801065e2:	e9 a8 f8 ff ff       	jmp    80105e8f <alltraps>

801065e7 <vector64>:
.globl vector64
vector64:
  pushl $0
801065e7:	6a 00                	push   $0x0
  pushl $64
801065e9:	6a 40                	push   $0x40
  jmp alltraps
801065eb:	e9 9f f8 ff ff       	jmp    80105e8f <alltraps>

801065f0 <vector65>:
.globl vector65
vector65:
  pushl $0
801065f0:	6a 00                	push   $0x0
  pushl $65
801065f2:	6a 41                	push   $0x41
  jmp alltraps
801065f4:	e9 96 f8 ff ff       	jmp    80105e8f <alltraps>

801065f9 <vector66>:
.globl vector66
vector66:
  pushl $0
801065f9:	6a 00                	push   $0x0
  pushl $66
801065fb:	6a 42                	push   $0x42
  jmp alltraps
801065fd:	e9 8d f8 ff ff       	jmp    80105e8f <alltraps>

80106602 <vector67>:
.globl vector67
vector67:
  pushl $0
80106602:	6a 00                	push   $0x0
  pushl $67
80106604:	6a 43                	push   $0x43
  jmp alltraps
80106606:	e9 84 f8 ff ff       	jmp    80105e8f <alltraps>

8010660b <vector68>:
.globl vector68
vector68:
  pushl $0
8010660b:	6a 00                	push   $0x0
  pushl $68
8010660d:	6a 44                	push   $0x44
  jmp alltraps
8010660f:	e9 7b f8 ff ff       	jmp    80105e8f <alltraps>

80106614 <vector69>:
.globl vector69
vector69:
  pushl $0
80106614:	6a 00                	push   $0x0
  pushl $69
80106616:	6a 45                	push   $0x45
  jmp alltraps
80106618:	e9 72 f8 ff ff       	jmp    80105e8f <alltraps>

8010661d <vector70>:
.globl vector70
vector70:
  pushl $0
8010661d:	6a 00                	push   $0x0
  pushl $70
8010661f:	6a 46                	push   $0x46
  jmp alltraps
80106621:	e9 69 f8 ff ff       	jmp    80105e8f <alltraps>

80106626 <vector71>:
.globl vector71
vector71:
  pushl $0
80106626:	6a 00                	push   $0x0
  pushl $71
80106628:	6a 47                	push   $0x47
  jmp alltraps
8010662a:	e9 60 f8 ff ff       	jmp    80105e8f <alltraps>

8010662f <vector72>:
.globl vector72
vector72:
  pushl $0
8010662f:	6a 00                	push   $0x0
  pushl $72
80106631:	6a 48                	push   $0x48
  jmp alltraps
80106633:	e9 57 f8 ff ff       	jmp    80105e8f <alltraps>

80106638 <vector73>:
.globl vector73
vector73:
  pushl $0
80106638:	6a 00                	push   $0x0
  pushl $73
8010663a:	6a 49                	push   $0x49
  jmp alltraps
8010663c:	e9 4e f8 ff ff       	jmp    80105e8f <alltraps>

80106641 <vector74>:
.globl vector74
vector74:
  pushl $0
80106641:	6a 00                	push   $0x0
  pushl $74
80106643:	6a 4a                	push   $0x4a
  jmp alltraps
80106645:	e9 45 f8 ff ff       	jmp    80105e8f <alltraps>

8010664a <vector75>:
.globl vector75
vector75:
  pushl $0
8010664a:	6a 00                	push   $0x0
  pushl $75
8010664c:	6a 4b                	push   $0x4b
  jmp alltraps
8010664e:	e9 3c f8 ff ff       	jmp    80105e8f <alltraps>

80106653 <vector76>:
.globl vector76
vector76:
  pushl $0
80106653:	6a 00                	push   $0x0
  pushl $76
80106655:	6a 4c                	push   $0x4c
  jmp alltraps
80106657:	e9 33 f8 ff ff       	jmp    80105e8f <alltraps>

8010665c <vector77>:
.globl vector77
vector77:
  pushl $0
8010665c:	6a 00                	push   $0x0
  pushl $77
8010665e:	6a 4d                	push   $0x4d
  jmp alltraps
80106660:	e9 2a f8 ff ff       	jmp    80105e8f <alltraps>

80106665 <vector78>:
.globl vector78
vector78:
  pushl $0
80106665:	6a 00                	push   $0x0
  pushl $78
80106667:	6a 4e                	push   $0x4e
  jmp alltraps
80106669:	e9 21 f8 ff ff       	jmp    80105e8f <alltraps>

8010666e <vector79>:
.globl vector79
vector79:
  pushl $0
8010666e:	6a 00                	push   $0x0
  pushl $79
80106670:	6a 4f                	push   $0x4f
  jmp alltraps
80106672:	e9 18 f8 ff ff       	jmp    80105e8f <alltraps>

80106677 <vector80>:
.globl vector80
vector80:
  pushl $0
80106677:	6a 00                	push   $0x0
  pushl $80
80106679:	6a 50                	push   $0x50
  jmp alltraps
8010667b:	e9 0f f8 ff ff       	jmp    80105e8f <alltraps>

80106680 <vector81>:
.globl vector81
vector81:
  pushl $0
80106680:	6a 00                	push   $0x0
  pushl $81
80106682:	6a 51                	push   $0x51
  jmp alltraps
80106684:	e9 06 f8 ff ff       	jmp    80105e8f <alltraps>

80106689 <vector82>:
.globl vector82
vector82:
  pushl $0
80106689:	6a 00                	push   $0x0
  pushl $82
8010668b:	6a 52                	push   $0x52
  jmp alltraps
8010668d:	e9 fd f7 ff ff       	jmp    80105e8f <alltraps>

80106692 <vector83>:
.globl vector83
vector83:
  pushl $0
80106692:	6a 00                	push   $0x0
  pushl $83
80106694:	6a 53                	push   $0x53
  jmp alltraps
80106696:	e9 f4 f7 ff ff       	jmp    80105e8f <alltraps>

8010669b <vector84>:
.globl vector84
vector84:
  pushl $0
8010669b:	6a 00                	push   $0x0
  pushl $84
8010669d:	6a 54                	push   $0x54
  jmp alltraps
8010669f:	e9 eb f7 ff ff       	jmp    80105e8f <alltraps>

801066a4 <vector85>:
.globl vector85
vector85:
  pushl $0
801066a4:	6a 00                	push   $0x0
  pushl $85
801066a6:	6a 55                	push   $0x55
  jmp alltraps
801066a8:	e9 e2 f7 ff ff       	jmp    80105e8f <alltraps>

801066ad <vector86>:
.globl vector86
vector86:
  pushl $0
801066ad:	6a 00                	push   $0x0
  pushl $86
801066af:	6a 56                	push   $0x56
  jmp alltraps
801066b1:	e9 d9 f7 ff ff       	jmp    80105e8f <alltraps>

801066b6 <vector87>:
.globl vector87
vector87:
  pushl $0
801066b6:	6a 00                	push   $0x0
  pushl $87
801066b8:	6a 57                	push   $0x57
  jmp alltraps
801066ba:	e9 d0 f7 ff ff       	jmp    80105e8f <alltraps>

801066bf <vector88>:
.globl vector88
vector88:
  pushl $0
801066bf:	6a 00                	push   $0x0
  pushl $88
801066c1:	6a 58                	push   $0x58
  jmp alltraps
801066c3:	e9 c7 f7 ff ff       	jmp    80105e8f <alltraps>

801066c8 <vector89>:
.globl vector89
vector89:
  pushl $0
801066c8:	6a 00                	push   $0x0
  pushl $89
801066ca:	6a 59                	push   $0x59
  jmp alltraps
801066cc:	e9 be f7 ff ff       	jmp    80105e8f <alltraps>

801066d1 <vector90>:
.globl vector90
vector90:
  pushl $0
801066d1:	6a 00                	push   $0x0
  pushl $90
801066d3:	6a 5a                	push   $0x5a
  jmp alltraps
801066d5:	e9 b5 f7 ff ff       	jmp    80105e8f <alltraps>

801066da <vector91>:
.globl vector91
vector91:
  pushl $0
801066da:	6a 00                	push   $0x0
  pushl $91
801066dc:	6a 5b                	push   $0x5b
  jmp alltraps
801066de:	e9 ac f7 ff ff       	jmp    80105e8f <alltraps>

801066e3 <vector92>:
.globl vector92
vector92:
  pushl $0
801066e3:	6a 00                	push   $0x0
  pushl $92
801066e5:	6a 5c                	push   $0x5c
  jmp alltraps
801066e7:	e9 a3 f7 ff ff       	jmp    80105e8f <alltraps>

801066ec <vector93>:
.globl vector93
vector93:
  pushl $0
801066ec:	6a 00                	push   $0x0
  pushl $93
801066ee:	6a 5d                	push   $0x5d
  jmp alltraps
801066f0:	e9 9a f7 ff ff       	jmp    80105e8f <alltraps>

801066f5 <vector94>:
.globl vector94
vector94:
  pushl $0
801066f5:	6a 00                	push   $0x0
  pushl $94
801066f7:	6a 5e                	push   $0x5e
  jmp alltraps
801066f9:	e9 91 f7 ff ff       	jmp    80105e8f <alltraps>

801066fe <vector95>:
.globl vector95
vector95:
  pushl $0
801066fe:	6a 00                	push   $0x0
  pushl $95
80106700:	6a 5f                	push   $0x5f
  jmp alltraps
80106702:	e9 88 f7 ff ff       	jmp    80105e8f <alltraps>

80106707 <vector96>:
.globl vector96
vector96:
  pushl $0
80106707:	6a 00                	push   $0x0
  pushl $96
80106709:	6a 60                	push   $0x60
  jmp alltraps
8010670b:	e9 7f f7 ff ff       	jmp    80105e8f <alltraps>

80106710 <vector97>:
.globl vector97
vector97:
  pushl $0
80106710:	6a 00                	push   $0x0
  pushl $97
80106712:	6a 61                	push   $0x61
  jmp alltraps
80106714:	e9 76 f7 ff ff       	jmp    80105e8f <alltraps>

80106719 <vector98>:
.globl vector98
vector98:
  pushl $0
80106719:	6a 00                	push   $0x0
  pushl $98
8010671b:	6a 62                	push   $0x62
  jmp alltraps
8010671d:	e9 6d f7 ff ff       	jmp    80105e8f <alltraps>

80106722 <vector99>:
.globl vector99
vector99:
  pushl $0
80106722:	6a 00                	push   $0x0
  pushl $99
80106724:	6a 63                	push   $0x63
  jmp alltraps
80106726:	e9 64 f7 ff ff       	jmp    80105e8f <alltraps>

8010672b <vector100>:
.globl vector100
vector100:
  pushl $0
8010672b:	6a 00                	push   $0x0
  pushl $100
8010672d:	6a 64                	push   $0x64
  jmp alltraps
8010672f:	e9 5b f7 ff ff       	jmp    80105e8f <alltraps>

80106734 <vector101>:
.globl vector101
vector101:
  pushl $0
80106734:	6a 00                	push   $0x0
  pushl $101
80106736:	6a 65                	push   $0x65
  jmp alltraps
80106738:	e9 52 f7 ff ff       	jmp    80105e8f <alltraps>

8010673d <vector102>:
.globl vector102
vector102:
  pushl $0
8010673d:	6a 00                	push   $0x0
  pushl $102
8010673f:	6a 66                	push   $0x66
  jmp alltraps
80106741:	e9 49 f7 ff ff       	jmp    80105e8f <alltraps>

80106746 <vector103>:
.globl vector103
vector103:
  pushl $0
80106746:	6a 00                	push   $0x0
  pushl $103
80106748:	6a 67                	push   $0x67
  jmp alltraps
8010674a:	e9 40 f7 ff ff       	jmp    80105e8f <alltraps>

8010674f <vector104>:
.globl vector104
vector104:
  pushl $0
8010674f:	6a 00                	push   $0x0
  pushl $104
80106751:	6a 68                	push   $0x68
  jmp alltraps
80106753:	e9 37 f7 ff ff       	jmp    80105e8f <alltraps>

80106758 <vector105>:
.globl vector105
vector105:
  pushl $0
80106758:	6a 00                	push   $0x0
  pushl $105
8010675a:	6a 69                	push   $0x69
  jmp alltraps
8010675c:	e9 2e f7 ff ff       	jmp    80105e8f <alltraps>

80106761 <vector106>:
.globl vector106
vector106:
  pushl $0
80106761:	6a 00                	push   $0x0
  pushl $106
80106763:	6a 6a                	push   $0x6a
  jmp alltraps
80106765:	e9 25 f7 ff ff       	jmp    80105e8f <alltraps>

8010676a <vector107>:
.globl vector107
vector107:
  pushl $0
8010676a:	6a 00                	push   $0x0
  pushl $107
8010676c:	6a 6b                	push   $0x6b
  jmp alltraps
8010676e:	e9 1c f7 ff ff       	jmp    80105e8f <alltraps>

80106773 <vector108>:
.globl vector108
vector108:
  pushl $0
80106773:	6a 00                	push   $0x0
  pushl $108
80106775:	6a 6c                	push   $0x6c
  jmp alltraps
80106777:	e9 13 f7 ff ff       	jmp    80105e8f <alltraps>

8010677c <vector109>:
.globl vector109
vector109:
  pushl $0
8010677c:	6a 00                	push   $0x0
  pushl $109
8010677e:	6a 6d                	push   $0x6d
  jmp alltraps
80106780:	e9 0a f7 ff ff       	jmp    80105e8f <alltraps>

80106785 <vector110>:
.globl vector110
vector110:
  pushl $0
80106785:	6a 00                	push   $0x0
  pushl $110
80106787:	6a 6e                	push   $0x6e
  jmp alltraps
80106789:	e9 01 f7 ff ff       	jmp    80105e8f <alltraps>

8010678e <vector111>:
.globl vector111
vector111:
  pushl $0
8010678e:	6a 00                	push   $0x0
  pushl $111
80106790:	6a 6f                	push   $0x6f
  jmp alltraps
80106792:	e9 f8 f6 ff ff       	jmp    80105e8f <alltraps>

80106797 <vector112>:
.globl vector112
vector112:
  pushl $0
80106797:	6a 00                	push   $0x0
  pushl $112
80106799:	6a 70                	push   $0x70
  jmp alltraps
8010679b:	e9 ef f6 ff ff       	jmp    80105e8f <alltraps>

801067a0 <vector113>:
.globl vector113
vector113:
  pushl $0
801067a0:	6a 00                	push   $0x0
  pushl $113
801067a2:	6a 71                	push   $0x71
  jmp alltraps
801067a4:	e9 e6 f6 ff ff       	jmp    80105e8f <alltraps>

801067a9 <vector114>:
.globl vector114
vector114:
  pushl $0
801067a9:	6a 00                	push   $0x0
  pushl $114
801067ab:	6a 72                	push   $0x72
  jmp alltraps
801067ad:	e9 dd f6 ff ff       	jmp    80105e8f <alltraps>

801067b2 <vector115>:
.globl vector115
vector115:
  pushl $0
801067b2:	6a 00                	push   $0x0
  pushl $115
801067b4:	6a 73                	push   $0x73
  jmp alltraps
801067b6:	e9 d4 f6 ff ff       	jmp    80105e8f <alltraps>

801067bb <vector116>:
.globl vector116
vector116:
  pushl $0
801067bb:	6a 00                	push   $0x0
  pushl $116
801067bd:	6a 74                	push   $0x74
  jmp alltraps
801067bf:	e9 cb f6 ff ff       	jmp    80105e8f <alltraps>

801067c4 <vector117>:
.globl vector117
vector117:
  pushl $0
801067c4:	6a 00                	push   $0x0
  pushl $117
801067c6:	6a 75                	push   $0x75
  jmp alltraps
801067c8:	e9 c2 f6 ff ff       	jmp    80105e8f <alltraps>

801067cd <vector118>:
.globl vector118
vector118:
  pushl $0
801067cd:	6a 00                	push   $0x0
  pushl $118
801067cf:	6a 76                	push   $0x76
  jmp alltraps
801067d1:	e9 b9 f6 ff ff       	jmp    80105e8f <alltraps>

801067d6 <vector119>:
.globl vector119
vector119:
  pushl $0
801067d6:	6a 00                	push   $0x0
  pushl $119
801067d8:	6a 77                	push   $0x77
  jmp alltraps
801067da:	e9 b0 f6 ff ff       	jmp    80105e8f <alltraps>

801067df <vector120>:
.globl vector120
vector120:
  pushl $0
801067df:	6a 00                	push   $0x0
  pushl $120
801067e1:	6a 78                	push   $0x78
  jmp alltraps
801067e3:	e9 a7 f6 ff ff       	jmp    80105e8f <alltraps>

801067e8 <vector121>:
.globl vector121
vector121:
  pushl $0
801067e8:	6a 00                	push   $0x0
  pushl $121
801067ea:	6a 79                	push   $0x79
  jmp alltraps
801067ec:	e9 9e f6 ff ff       	jmp    80105e8f <alltraps>

801067f1 <vector122>:
.globl vector122
vector122:
  pushl $0
801067f1:	6a 00                	push   $0x0
  pushl $122
801067f3:	6a 7a                	push   $0x7a
  jmp alltraps
801067f5:	e9 95 f6 ff ff       	jmp    80105e8f <alltraps>

801067fa <vector123>:
.globl vector123
vector123:
  pushl $0
801067fa:	6a 00                	push   $0x0
  pushl $123
801067fc:	6a 7b                	push   $0x7b
  jmp alltraps
801067fe:	e9 8c f6 ff ff       	jmp    80105e8f <alltraps>

80106803 <vector124>:
.globl vector124
vector124:
  pushl $0
80106803:	6a 00                	push   $0x0
  pushl $124
80106805:	6a 7c                	push   $0x7c
  jmp alltraps
80106807:	e9 83 f6 ff ff       	jmp    80105e8f <alltraps>

8010680c <vector125>:
.globl vector125
vector125:
  pushl $0
8010680c:	6a 00                	push   $0x0
  pushl $125
8010680e:	6a 7d                	push   $0x7d
  jmp alltraps
80106810:	e9 7a f6 ff ff       	jmp    80105e8f <alltraps>

80106815 <vector126>:
.globl vector126
vector126:
  pushl $0
80106815:	6a 00                	push   $0x0
  pushl $126
80106817:	6a 7e                	push   $0x7e
  jmp alltraps
80106819:	e9 71 f6 ff ff       	jmp    80105e8f <alltraps>

8010681e <vector127>:
.globl vector127
vector127:
  pushl $0
8010681e:	6a 00                	push   $0x0
  pushl $127
80106820:	6a 7f                	push   $0x7f
  jmp alltraps
80106822:	e9 68 f6 ff ff       	jmp    80105e8f <alltraps>

80106827 <vector128>:
.globl vector128
vector128:
  pushl $0
80106827:	6a 00                	push   $0x0
  pushl $128
80106829:	68 80 00 00 00       	push   $0x80
  jmp alltraps
8010682e:	e9 5c f6 ff ff       	jmp    80105e8f <alltraps>

80106833 <vector129>:
.globl vector129
vector129:
  pushl $0
80106833:	6a 00                	push   $0x0
  pushl $129
80106835:	68 81 00 00 00       	push   $0x81
  jmp alltraps
8010683a:	e9 50 f6 ff ff       	jmp    80105e8f <alltraps>

8010683f <vector130>:
.globl vector130
vector130:
  pushl $0
8010683f:	6a 00                	push   $0x0
  pushl $130
80106841:	68 82 00 00 00       	push   $0x82
  jmp alltraps
80106846:	e9 44 f6 ff ff       	jmp    80105e8f <alltraps>

8010684b <vector131>:
.globl vector131
vector131:
  pushl $0
8010684b:	6a 00                	push   $0x0
  pushl $131
8010684d:	68 83 00 00 00       	push   $0x83
  jmp alltraps
80106852:	e9 38 f6 ff ff       	jmp    80105e8f <alltraps>

80106857 <vector132>:
.globl vector132
vector132:
  pushl $0
80106857:	6a 00                	push   $0x0
  pushl $132
80106859:	68 84 00 00 00       	push   $0x84
  jmp alltraps
8010685e:	e9 2c f6 ff ff       	jmp    80105e8f <alltraps>

80106863 <vector133>:
.globl vector133
vector133:
  pushl $0
80106863:	6a 00                	push   $0x0
  pushl $133
80106865:	68 85 00 00 00       	push   $0x85
  jmp alltraps
8010686a:	e9 20 f6 ff ff       	jmp    80105e8f <alltraps>

8010686f <vector134>:
.globl vector134
vector134:
  pushl $0
8010686f:	6a 00                	push   $0x0
  pushl $134
80106871:	68 86 00 00 00       	push   $0x86
  jmp alltraps
80106876:	e9 14 f6 ff ff       	jmp    80105e8f <alltraps>

8010687b <vector135>:
.globl vector135
vector135:
  pushl $0
8010687b:	6a 00                	push   $0x0
  pushl $135
8010687d:	68 87 00 00 00       	push   $0x87
  jmp alltraps
80106882:	e9 08 f6 ff ff       	jmp    80105e8f <alltraps>

80106887 <vector136>:
.globl vector136
vector136:
  pushl $0
80106887:	6a 00                	push   $0x0
  pushl $136
80106889:	68 88 00 00 00       	push   $0x88
  jmp alltraps
8010688e:	e9 fc f5 ff ff       	jmp    80105e8f <alltraps>

80106893 <vector137>:
.globl vector137
vector137:
  pushl $0
80106893:	6a 00                	push   $0x0
  pushl $137
80106895:	68 89 00 00 00       	push   $0x89
  jmp alltraps
8010689a:	e9 f0 f5 ff ff       	jmp    80105e8f <alltraps>

8010689f <vector138>:
.globl vector138
vector138:
  pushl $0
8010689f:	6a 00                	push   $0x0
  pushl $138
801068a1:	68 8a 00 00 00       	push   $0x8a
  jmp alltraps
801068a6:	e9 e4 f5 ff ff       	jmp    80105e8f <alltraps>

801068ab <vector139>:
.globl vector139
vector139:
  pushl $0
801068ab:	6a 00                	push   $0x0
  pushl $139
801068ad:	68 8b 00 00 00       	push   $0x8b
  jmp alltraps
801068b2:	e9 d8 f5 ff ff       	jmp    80105e8f <alltraps>

801068b7 <vector140>:
.globl vector140
vector140:
  pushl $0
801068b7:	6a 00                	push   $0x0
  pushl $140
801068b9:	68 8c 00 00 00       	push   $0x8c
  jmp alltraps
801068be:	e9 cc f5 ff ff       	jmp    80105e8f <alltraps>

801068c3 <vector141>:
.globl vector141
vector141:
  pushl $0
801068c3:	6a 00                	push   $0x0
  pushl $141
801068c5:	68 8d 00 00 00       	push   $0x8d
  jmp alltraps
801068ca:	e9 c0 f5 ff ff       	jmp    80105e8f <alltraps>

801068cf <vector142>:
.globl vector142
vector142:
  pushl $0
801068cf:	6a 00                	push   $0x0
  pushl $142
801068d1:	68 8e 00 00 00       	push   $0x8e
  jmp alltraps
801068d6:	e9 b4 f5 ff ff       	jmp    80105e8f <alltraps>

801068db <vector143>:
.globl vector143
vector143:
  pushl $0
801068db:	6a 00                	push   $0x0
  pushl $143
801068dd:	68 8f 00 00 00       	push   $0x8f
  jmp alltraps
801068e2:	e9 a8 f5 ff ff       	jmp    80105e8f <alltraps>

801068e7 <vector144>:
.globl vector144
vector144:
  pushl $0
801068e7:	6a 00                	push   $0x0
  pushl $144
801068e9:	68 90 00 00 00       	push   $0x90
  jmp alltraps
801068ee:	e9 9c f5 ff ff       	jmp    80105e8f <alltraps>

801068f3 <vector145>:
.globl vector145
vector145:
  pushl $0
801068f3:	6a 00                	push   $0x0
  pushl $145
801068f5:	68 91 00 00 00       	push   $0x91
  jmp alltraps
801068fa:	e9 90 f5 ff ff       	jmp    80105e8f <alltraps>

801068ff <vector146>:
.globl vector146
vector146:
  pushl $0
801068ff:	6a 00                	push   $0x0
  pushl $146
80106901:	68 92 00 00 00       	push   $0x92
  jmp alltraps
80106906:	e9 84 f5 ff ff       	jmp    80105e8f <alltraps>

8010690b <vector147>:
.globl vector147
vector147:
  pushl $0
8010690b:	6a 00                	push   $0x0
  pushl $147
8010690d:	68 93 00 00 00       	push   $0x93
  jmp alltraps
80106912:	e9 78 f5 ff ff       	jmp    80105e8f <alltraps>

80106917 <vector148>:
.globl vector148
vector148:
  pushl $0
80106917:	6a 00                	push   $0x0
  pushl $148
80106919:	68 94 00 00 00       	push   $0x94
  jmp alltraps
8010691e:	e9 6c f5 ff ff       	jmp    80105e8f <alltraps>

80106923 <vector149>:
.globl vector149
vector149:
  pushl $0
80106923:	6a 00                	push   $0x0
  pushl $149
80106925:	68 95 00 00 00       	push   $0x95
  jmp alltraps
8010692a:	e9 60 f5 ff ff       	jmp    80105e8f <alltraps>

8010692f <vector150>:
.globl vector150
vector150:
  pushl $0
8010692f:	6a 00                	push   $0x0
  pushl $150
80106931:	68 96 00 00 00       	push   $0x96
  jmp alltraps
80106936:	e9 54 f5 ff ff       	jmp    80105e8f <alltraps>

8010693b <vector151>:
.globl vector151
vector151:
  pushl $0
8010693b:	6a 00                	push   $0x0
  pushl $151
8010693d:	68 97 00 00 00       	push   $0x97
  jmp alltraps
80106942:	e9 48 f5 ff ff       	jmp    80105e8f <alltraps>

80106947 <vector152>:
.globl vector152
vector152:
  pushl $0
80106947:	6a 00                	push   $0x0
  pushl $152
80106949:	68 98 00 00 00       	push   $0x98
  jmp alltraps
8010694e:	e9 3c f5 ff ff       	jmp    80105e8f <alltraps>

80106953 <vector153>:
.globl vector153
vector153:
  pushl $0
80106953:	6a 00                	push   $0x0
  pushl $153
80106955:	68 99 00 00 00       	push   $0x99
  jmp alltraps
8010695a:	e9 30 f5 ff ff       	jmp    80105e8f <alltraps>

8010695f <vector154>:
.globl vector154
vector154:
  pushl $0
8010695f:	6a 00                	push   $0x0
  pushl $154
80106961:	68 9a 00 00 00       	push   $0x9a
  jmp alltraps
80106966:	e9 24 f5 ff ff       	jmp    80105e8f <alltraps>

8010696b <vector155>:
.globl vector155
vector155:
  pushl $0
8010696b:	6a 00                	push   $0x0
  pushl $155
8010696d:	68 9b 00 00 00       	push   $0x9b
  jmp alltraps
80106972:	e9 18 f5 ff ff       	jmp    80105e8f <alltraps>

80106977 <vector156>:
.globl vector156
vector156:
  pushl $0
80106977:	6a 00                	push   $0x0
  pushl $156
80106979:	68 9c 00 00 00       	push   $0x9c
  jmp alltraps
8010697e:	e9 0c f5 ff ff       	jmp    80105e8f <alltraps>

80106983 <vector157>:
.globl vector157
vector157:
  pushl $0
80106983:	6a 00                	push   $0x0
  pushl $157
80106985:	68 9d 00 00 00       	push   $0x9d
  jmp alltraps
8010698a:	e9 00 f5 ff ff       	jmp    80105e8f <alltraps>

8010698f <vector158>:
.globl vector158
vector158:
  pushl $0
8010698f:	6a 00                	push   $0x0
  pushl $158
80106991:	68 9e 00 00 00       	push   $0x9e
  jmp alltraps
80106996:	e9 f4 f4 ff ff       	jmp    80105e8f <alltraps>

8010699b <vector159>:
.globl vector159
vector159:
  pushl $0
8010699b:	6a 00                	push   $0x0
  pushl $159
8010699d:	68 9f 00 00 00       	push   $0x9f
  jmp alltraps
801069a2:	e9 e8 f4 ff ff       	jmp    80105e8f <alltraps>

801069a7 <vector160>:
.globl vector160
vector160:
  pushl $0
801069a7:	6a 00                	push   $0x0
  pushl $160
801069a9:	68 a0 00 00 00       	push   $0xa0
  jmp alltraps
801069ae:	e9 dc f4 ff ff       	jmp    80105e8f <alltraps>

801069b3 <vector161>:
.globl vector161
vector161:
  pushl $0
801069b3:	6a 00                	push   $0x0
  pushl $161
801069b5:	68 a1 00 00 00       	push   $0xa1
  jmp alltraps
801069ba:	e9 d0 f4 ff ff       	jmp    80105e8f <alltraps>

801069bf <vector162>:
.globl vector162
vector162:
  pushl $0
801069bf:	6a 00                	push   $0x0
  pushl $162
801069c1:	68 a2 00 00 00       	push   $0xa2
  jmp alltraps
801069c6:	e9 c4 f4 ff ff       	jmp    80105e8f <alltraps>

801069cb <vector163>:
.globl vector163
vector163:
  pushl $0
801069cb:	6a 00                	push   $0x0
  pushl $163
801069cd:	68 a3 00 00 00       	push   $0xa3
  jmp alltraps
801069d2:	e9 b8 f4 ff ff       	jmp    80105e8f <alltraps>

801069d7 <vector164>:
.globl vector164
vector164:
  pushl $0
801069d7:	6a 00                	push   $0x0
  pushl $164
801069d9:	68 a4 00 00 00       	push   $0xa4
  jmp alltraps
801069de:	e9 ac f4 ff ff       	jmp    80105e8f <alltraps>

801069e3 <vector165>:
.globl vector165
vector165:
  pushl $0
801069e3:	6a 00                	push   $0x0
  pushl $165
801069e5:	68 a5 00 00 00       	push   $0xa5
  jmp alltraps
801069ea:	e9 a0 f4 ff ff       	jmp    80105e8f <alltraps>

801069ef <vector166>:
.globl vector166
vector166:
  pushl $0
801069ef:	6a 00                	push   $0x0
  pushl $166
801069f1:	68 a6 00 00 00       	push   $0xa6
  jmp alltraps
801069f6:	e9 94 f4 ff ff       	jmp    80105e8f <alltraps>

801069fb <vector167>:
.globl vector167
vector167:
  pushl $0
801069fb:	6a 00                	push   $0x0
  pushl $167
801069fd:	68 a7 00 00 00       	push   $0xa7
  jmp alltraps
80106a02:	e9 88 f4 ff ff       	jmp    80105e8f <alltraps>

80106a07 <vector168>:
.globl vector168
vector168:
  pushl $0
80106a07:	6a 00                	push   $0x0
  pushl $168
80106a09:	68 a8 00 00 00       	push   $0xa8
  jmp alltraps
80106a0e:	e9 7c f4 ff ff       	jmp    80105e8f <alltraps>

80106a13 <vector169>:
.globl vector169
vector169:
  pushl $0
80106a13:	6a 00                	push   $0x0
  pushl $169
80106a15:	68 a9 00 00 00       	push   $0xa9
  jmp alltraps
80106a1a:	e9 70 f4 ff ff       	jmp    80105e8f <alltraps>

80106a1f <vector170>:
.globl vector170
vector170:
  pushl $0
80106a1f:	6a 00                	push   $0x0
  pushl $170
80106a21:	68 aa 00 00 00       	push   $0xaa
  jmp alltraps
80106a26:	e9 64 f4 ff ff       	jmp    80105e8f <alltraps>

80106a2b <vector171>:
.globl vector171
vector171:
  pushl $0
80106a2b:	6a 00                	push   $0x0
  pushl $171
80106a2d:	68 ab 00 00 00       	push   $0xab
  jmp alltraps
80106a32:	e9 58 f4 ff ff       	jmp    80105e8f <alltraps>

80106a37 <vector172>:
.globl vector172
vector172:
  pushl $0
80106a37:	6a 00                	push   $0x0
  pushl $172
80106a39:	68 ac 00 00 00       	push   $0xac
  jmp alltraps
80106a3e:	e9 4c f4 ff ff       	jmp    80105e8f <alltraps>

80106a43 <vector173>:
.globl vector173
vector173:
  pushl $0
80106a43:	6a 00                	push   $0x0
  pushl $173
80106a45:	68 ad 00 00 00       	push   $0xad
  jmp alltraps
80106a4a:	e9 40 f4 ff ff       	jmp    80105e8f <alltraps>

80106a4f <vector174>:
.globl vector174
vector174:
  pushl $0
80106a4f:	6a 00                	push   $0x0
  pushl $174
80106a51:	68 ae 00 00 00       	push   $0xae
  jmp alltraps
80106a56:	e9 34 f4 ff ff       	jmp    80105e8f <alltraps>

80106a5b <vector175>:
.globl vector175
vector175:
  pushl $0
80106a5b:	6a 00                	push   $0x0
  pushl $175
80106a5d:	68 af 00 00 00       	push   $0xaf
  jmp alltraps
80106a62:	e9 28 f4 ff ff       	jmp    80105e8f <alltraps>

80106a67 <vector176>:
.globl vector176
vector176:
  pushl $0
80106a67:	6a 00                	push   $0x0
  pushl $176
80106a69:	68 b0 00 00 00       	push   $0xb0
  jmp alltraps
80106a6e:	e9 1c f4 ff ff       	jmp    80105e8f <alltraps>

80106a73 <vector177>:
.globl vector177
vector177:
  pushl $0
80106a73:	6a 00                	push   $0x0
  pushl $177
80106a75:	68 b1 00 00 00       	push   $0xb1
  jmp alltraps
80106a7a:	e9 10 f4 ff ff       	jmp    80105e8f <alltraps>

80106a7f <vector178>:
.globl vector178
vector178:
  pushl $0
80106a7f:	6a 00                	push   $0x0
  pushl $178
80106a81:	68 b2 00 00 00       	push   $0xb2
  jmp alltraps
80106a86:	e9 04 f4 ff ff       	jmp    80105e8f <alltraps>

80106a8b <vector179>:
.globl vector179
vector179:
  pushl $0
80106a8b:	6a 00                	push   $0x0
  pushl $179
80106a8d:	68 b3 00 00 00       	push   $0xb3
  jmp alltraps
80106a92:	e9 f8 f3 ff ff       	jmp    80105e8f <alltraps>

80106a97 <vector180>:
.globl vector180
vector180:
  pushl $0
80106a97:	6a 00                	push   $0x0
  pushl $180
80106a99:	68 b4 00 00 00       	push   $0xb4
  jmp alltraps
80106a9e:	e9 ec f3 ff ff       	jmp    80105e8f <alltraps>

80106aa3 <vector181>:
.globl vector181
vector181:
  pushl $0
80106aa3:	6a 00                	push   $0x0
  pushl $181
80106aa5:	68 b5 00 00 00       	push   $0xb5
  jmp alltraps
80106aaa:	e9 e0 f3 ff ff       	jmp    80105e8f <alltraps>

80106aaf <vector182>:
.globl vector182
vector182:
  pushl $0
80106aaf:	6a 00                	push   $0x0
  pushl $182
80106ab1:	68 b6 00 00 00       	push   $0xb6
  jmp alltraps
80106ab6:	e9 d4 f3 ff ff       	jmp    80105e8f <alltraps>

80106abb <vector183>:
.globl vector183
vector183:
  pushl $0
80106abb:	6a 00                	push   $0x0
  pushl $183
80106abd:	68 b7 00 00 00       	push   $0xb7
  jmp alltraps
80106ac2:	e9 c8 f3 ff ff       	jmp    80105e8f <alltraps>

80106ac7 <vector184>:
.globl vector184
vector184:
  pushl $0
80106ac7:	6a 00                	push   $0x0
  pushl $184
80106ac9:	68 b8 00 00 00       	push   $0xb8
  jmp alltraps
80106ace:	e9 bc f3 ff ff       	jmp    80105e8f <alltraps>

80106ad3 <vector185>:
.globl vector185
vector185:
  pushl $0
80106ad3:	6a 00                	push   $0x0
  pushl $185
80106ad5:	68 b9 00 00 00       	push   $0xb9
  jmp alltraps
80106ada:	e9 b0 f3 ff ff       	jmp    80105e8f <alltraps>

80106adf <vector186>:
.globl vector186
vector186:
  pushl $0
80106adf:	6a 00                	push   $0x0
  pushl $186
80106ae1:	68 ba 00 00 00       	push   $0xba
  jmp alltraps
80106ae6:	e9 a4 f3 ff ff       	jmp    80105e8f <alltraps>

80106aeb <vector187>:
.globl vector187
vector187:
  pushl $0
80106aeb:	6a 00                	push   $0x0
  pushl $187
80106aed:	68 bb 00 00 00       	push   $0xbb
  jmp alltraps
80106af2:	e9 98 f3 ff ff       	jmp    80105e8f <alltraps>

80106af7 <vector188>:
.globl vector188
vector188:
  pushl $0
80106af7:	6a 00                	push   $0x0
  pushl $188
80106af9:	68 bc 00 00 00       	push   $0xbc
  jmp alltraps
80106afe:	e9 8c f3 ff ff       	jmp    80105e8f <alltraps>

80106b03 <vector189>:
.globl vector189
vector189:
  pushl $0
80106b03:	6a 00                	push   $0x0
  pushl $189
80106b05:	68 bd 00 00 00       	push   $0xbd
  jmp alltraps
80106b0a:	e9 80 f3 ff ff       	jmp    80105e8f <alltraps>

80106b0f <vector190>:
.globl vector190
vector190:
  pushl $0
80106b0f:	6a 00                	push   $0x0
  pushl $190
80106b11:	68 be 00 00 00       	push   $0xbe
  jmp alltraps
80106b16:	e9 74 f3 ff ff       	jmp    80105e8f <alltraps>

80106b1b <vector191>:
.globl vector191
vector191:
  pushl $0
80106b1b:	6a 00                	push   $0x0
  pushl $191
80106b1d:	68 bf 00 00 00       	push   $0xbf
  jmp alltraps
80106b22:	e9 68 f3 ff ff       	jmp    80105e8f <alltraps>

80106b27 <vector192>:
.globl vector192
vector192:
  pushl $0
80106b27:	6a 00                	push   $0x0
  pushl $192
80106b29:	68 c0 00 00 00       	push   $0xc0
  jmp alltraps
80106b2e:	e9 5c f3 ff ff       	jmp    80105e8f <alltraps>

80106b33 <vector193>:
.globl vector193
vector193:
  pushl $0
80106b33:	6a 00                	push   $0x0
  pushl $193
80106b35:	68 c1 00 00 00       	push   $0xc1
  jmp alltraps
80106b3a:	e9 50 f3 ff ff       	jmp    80105e8f <alltraps>

80106b3f <vector194>:
.globl vector194
vector194:
  pushl $0
80106b3f:	6a 00                	push   $0x0
  pushl $194
80106b41:	68 c2 00 00 00       	push   $0xc2
  jmp alltraps
80106b46:	e9 44 f3 ff ff       	jmp    80105e8f <alltraps>

80106b4b <vector195>:
.globl vector195
vector195:
  pushl $0
80106b4b:	6a 00                	push   $0x0
  pushl $195
80106b4d:	68 c3 00 00 00       	push   $0xc3
  jmp alltraps
80106b52:	e9 38 f3 ff ff       	jmp    80105e8f <alltraps>

80106b57 <vector196>:
.globl vector196
vector196:
  pushl $0
80106b57:	6a 00                	push   $0x0
  pushl $196
80106b59:	68 c4 00 00 00       	push   $0xc4
  jmp alltraps
80106b5e:	e9 2c f3 ff ff       	jmp    80105e8f <alltraps>

80106b63 <vector197>:
.globl vector197
vector197:
  pushl $0
80106b63:	6a 00                	push   $0x0
  pushl $197
80106b65:	68 c5 00 00 00       	push   $0xc5
  jmp alltraps
80106b6a:	e9 20 f3 ff ff       	jmp    80105e8f <alltraps>

80106b6f <vector198>:
.globl vector198
vector198:
  pushl $0
80106b6f:	6a 00                	push   $0x0
  pushl $198
80106b71:	68 c6 00 00 00       	push   $0xc6
  jmp alltraps
80106b76:	e9 14 f3 ff ff       	jmp    80105e8f <alltraps>

80106b7b <vector199>:
.globl vector199
vector199:
  pushl $0
80106b7b:	6a 00                	push   $0x0
  pushl $199
80106b7d:	68 c7 00 00 00       	push   $0xc7
  jmp alltraps
80106b82:	e9 08 f3 ff ff       	jmp    80105e8f <alltraps>

80106b87 <vector200>:
.globl vector200
vector200:
  pushl $0
80106b87:	6a 00                	push   $0x0
  pushl $200
80106b89:	68 c8 00 00 00       	push   $0xc8
  jmp alltraps
80106b8e:	e9 fc f2 ff ff       	jmp    80105e8f <alltraps>

80106b93 <vector201>:
.globl vector201
vector201:
  pushl $0
80106b93:	6a 00                	push   $0x0
  pushl $201
80106b95:	68 c9 00 00 00       	push   $0xc9
  jmp alltraps
80106b9a:	e9 f0 f2 ff ff       	jmp    80105e8f <alltraps>

80106b9f <vector202>:
.globl vector202
vector202:
  pushl $0
80106b9f:	6a 00                	push   $0x0
  pushl $202
80106ba1:	68 ca 00 00 00       	push   $0xca
  jmp alltraps
80106ba6:	e9 e4 f2 ff ff       	jmp    80105e8f <alltraps>

80106bab <vector203>:
.globl vector203
vector203:
  pushl $0
80106bab:	6a 00                	push   $0x0
  pushl $203
80106bad:	68 cb 00 00 00       	push   $0xcb
  jmp alltraps
80106bb2:	e9 d8 f2 ff ff       	jmp    80105e8f <alltraps>

80106bb7 <vector204>:
.globl vector204
vector204:
  pushl $0
80106bb7:	6a 00                	push   $0x0
  pushl $204
80106bb9:	68 cc 00 00 00       	push   $0xcc
  jmp alltraps
80106bbe:	e9 cc f2 ff ff       	jmp    80105e8f <alltraps>

80106bc3 <vector205>:
.globl vector205
vector205:
  pushl $0
80106bc3:	6a 00                	push   $0x0
  pushl $205
80106bc5:	68 cd 00 00 00       	push   $0xcd
  jmp alltraps
80106bca:	e9 c0 f2 ff ff       	jmp    80105e8f <alltraps>

80106bcf <vector206>:
.globl vector206
vector206:
  pushl $0
80106bcf:	6a 00                	push   $0x0
  pushl $206
80106bd1:	68 ce 00 00 00       	push   $0xce
  jmp alltraps
80106bd6:	e9 b4 f2 ff ff       	jmp    80105e8f <alltraps>

80106bdb <vector207>:
.globl vector207
vector207:
  pushl $0
80106bdb:	6a 00                	push   $0x0
  pushl $207
80106bdd:	68 cf 00 00 00       	push   $0xcf
  jmp alltraps
80106be2:	e9 a8 f2 ff ff       	jmp    80105e8f <alltraps>

80106be7 <vector208>:
.globl vector208
vector208:
  pushl $0
80106be7:	6a 00                	push   $0x0
  pushl $208
80106be9:	68 d0 00 00 00       	push   $0xd0
  jmp alltraps
80106bee:	e9 9c f2 ff ff       	jmp    80105e8f <alltraps>

80106bf3 <vector209>:
.globl vector209
vector209:
  pushl $0
80106bf3:	6a 00                	push   $0x0
  pushl $209
80106bf5:	68 d1 00 00 00       	push   $0xd1
  jmp alltraps
80106bfa:	e9 90 f2 ff ff       	jmp    80105e8f <alltraps>

80106bff <vector210>:
.globl vector210
vector210:
  pushl $0
80106bff:	6a 00                	push   $0x0
  pushl $210
80106c01:	68 d2 00 00 00       	push   $0xd2
  jmp alltraps
80106c06:	e9 84 f2 ff ff       	jmp    80105e8f <alltraps>

80106c0b <vector211>:
.globl vector211
vector211:
  pushl $0
80106c0b:	6a 00                	push   $0x0
  pushl $211
80106c0d:	68 d3 00 00 00       	push   $0xd3
  jmp alltraps
80106c12:	e9 78 f2 ff ff       	jmp    80105e8f <alltraps>

80106c17 <vector212>:
.globl vector212
vector212:
  pushl $0
80106c17:	6a 00                	push   $0x0
  pushl $212
80106c19:	68 d4 00 00 00       	push   $0xd4
  jmp alltraps
80106c1e:	e9 6c f2 ff ff       	jmp    80105e8f <alltraps>

80106c23 <vector213>:
.globl vector213
vector213:
  pushl $0
80106c23:	6a 00                	push   $0x0
  pushl $213
80106c25:	68 d5 00 00 00       	push   $0xd5
  jmp alltraps
80106c2a:	e9 60 f2 ff ff       	jmp    80105e8f <alltraps>

80106c2f <vector214>:
.globl vector214
vector214:
  pushl $0
80106c2f:	6a 00                	push   $0x0
  pushl $214
80106c31:	68 d6 00 00 00       	push   $0xd6
  jmp alltraps
80106c36:	e9 54 f2 ff ff       	jmp    80105e8f <alltraps>

80106c3b <vector215>:
.globl vector215
vector215:
  pushl $0
80106c3b:	6a 00                	push   $0x0
  pushl $215
80106c3d:	68 d7 00 00 00       	push   $0xd7
  jmp alltraps
80106c42:	e9 48 f2 ff ff       	jmp    80105e8f <alltraps>

80106c47 <vector216>:
.globl vector216
vector216:
  pushl $0
80106c47:	6a 00                	push   $0x0
  pushl $216
80106c49:	68 d8 00 00 00       	push   $0xd8
  jmp alltraps
80106c4e:	e9 3c f2 ff ff       	jmp    80105e8f <alltraps>

80106c53 <vector217>:
.globl vector217
vector217:
  pushl $0
80106c53:	6a 00                	push   $0x0
  pushl $217
80106c55:	68 d9 00 00 00       	push   $0xd9
  jmp alltraps
80106c5a:	e9 30 f2 ff ff       	jmp    80105e8f <alltraps>

80106c5f <vector218>:
.globl vector218
vector218:
  pushl $0
80106c5f:	6a 00                	push   $0x0
  pushl $218
80106c61:	68 da 00 00 00       	push   $0xda
  jmp alltraps
80106c66:	e9 24 f2 ff ff       	jmp    80105e8f <alltraps>

80106c6b <vector219>:
.globl vector219
vector219:
  pushl $0
80106c6b:	6a 00                	push   $0x0
  pushl $219
80106c6d:	68 db 00 00 00       	push   $0xdb
  jmp alltraps
80106c72:	e9 18 f2 ff ff       	jmp    80105e8f <alltraps>

80106c77 <vector220>:
.globl vector220
vector220:
  pushl $0
80106c77:	6a 00                	push   $0x0
  pushl $220
80106c79:	68 dc 00 00 00       	push   $0xdc
  jmp alltraps
80106c7e:	e9 0c f2 ff ff       	jmp    80105e8f <alltraps>

80106c83 <vector221>:
.globl vector221
vector221:
  pushl $0
80106c83:	6a 00                	push   $0x0
  pushl $221
80106c85:	68 dd 00 00 00       	push   $0xdd
  jmp alltraps
80106c8a:	e9 00 f2 ff ff       	jmp    80105e8f <alltraps>

80106c8f <vector222>:
.globl vector222
vector222:
  pushl $0
80106c8f:	6a 00                	push   $0x0
  pushl $222
80106c91:	68 de 00 00 00       	push   $0xde
  jmp alltraps
80106c96:	e9 f4 f1 ff ff       	jmp    80105e8f <alltraps>

80106c9b <vector223>:
.globl vector223
vector223:
  pushl $0
80106c9b:	6a 00                	push   $0x0
  pushl $223
80106c9d:	68 df 00 00 00       	push   $0xdf
  jmp alltraps
80106ca2:	e9 e8 f1 ff ff       	jmp    80105e8f <alltraps>

80106ca7 <vector224>:
.globl vector224
vector224:
  pushl $0
80106ca7:	6a 00                	push   $0x0
  pushl $224
80106ca9:	68 e0 00 00 00       	push   $0xe0
  jmp alltraps
80106cae:	e9 dc f1 ff ff       	jmp    80105e8f <alltraps>

80106cb3 <vector225>:
.globl vector225
vector225:
  pushl $0
80106cb3:	6a 00                	push   $0x0
  pushl $225
80106cb5:	68 e1 00 00 00       	push   $0xe1
  jmp alltraps
80106cba:	e9 d0 f1 ff ff       	jmp    80105e8f <alltraps>

80106cbf <vector226>:
.globl vector226
vector226:
  pushl $0
80106cbf:	6a 00                	push   $0x0
  pushl $226
80106cc1:	68 e2 00 00 00       	push   $0xe2
  jmp alltraps
80106cc6:	e9 c4 f1 ff ff       	jmp    80105e8f <alltraps>

80106ccb <vector227>:
.globl vector227
vector227:
  pushl $0
80106ccb:	6a 00                	push   $0x0
  pushl $227
80106ccd:	68 e3 00 00 00       	push   $0xe3
  jmp alltraps
80106cd2:	e9 b8 f1 ff ff       	jmp    80105e8f <alltraps>

80106cd7 <vector228>:
.globl vector228
vector228:
  pushl $0
80106cd7:	6a 00                	push   $0x0
  pushl $228
80106cd9:	68 e4 00 00 00       	push   $0xe4
  jmp alltraps
80106cde:	e9 ac f1 ff ff       	jmp    80105e8f <alltraps>

80106ce3 <vector229>:
.globl vector229
vector229:
  pushl $0
80106ce3:	6a 00                	push   $0x0
  pushl $229
80106ce5:	68 e5 00 00 00       	push   $0xe5
  jmp alltraps
80106cea:	e9 a0 f1 ff ff       	jmp    80105e8f <alltraps>

80106cef <vector230>:
.globl vector230
vector230:
  pushl $0
80106cef:	6a 00                	push   $0x0
  pushl $230
80106cf1:	68 e6 00 00 00       	push   $0xe6
  jmp alltraps
80106cf6:	e9 94 f1 ff ff       	jmp    80105e8f <alltraps>

80106cfb <vector231>:
.globl vector231
vector231:
  pushl $0
80106cfb:	6a 00                	push   $0x0
  pushl $231
80106cfd:	68 e7 00 00 00       	push   $0xe7
  jmp alltraps
80106d02:	e9 88 f1 ff ff       	jmp    80105e8f <alltraps>

80106d07 <vector232>:
.globl vector232
vector232:
  pushl $0
80106d07:	6a 00                	push   $0x0
  pushl $232
80106d09:	68 e8 00 00 00       	push   $0xe8
  jmp alltraps
80106d0e:	e9 7c f1 ff ff       	jmp    80105e8f <alltraps>

80106d13 <vector233>:
.globl vector233
vector233:
  pushl $0
80106d13:	6a 00                	push   $0x0
  pushl $233
80106d15:	68 e9 00 00 00       	push   $0xe9
  jmp alltraps
80106d1a:	e9 70 f1 ff ff       	jmp    80105e8f <alltraps>

80106d1f <vector234>:
.globl vector234
vector234:
  pushl $0
80106d1f:	6a 00                	push   $0x0
  pushl $234
80106d21:	68 ea 00 00 00       	push   $0xea
  jmp alltraps
80106d26:	e9 64 f1 ff ff       	jmp    80105e8f <alltraps>

80106d2b <vector235>:
.globl vector235
vector235:
  pushl $0
80106d2b:	6a 00                	push   $0x0
  pushl $235
80106d2d:	68 eb 00 00 00       	push   $0xeb
  jmp alltraps
80106d32:	e9 58 f1 ff ff       	jmp    80105e8f <alltraps>

80106d37 <vector236>:
.globl vector236
vector236:
  pushl $0
80106d37:	6a 00                	push   $0x0
  pushl $236
80106d39:	68 ec 00 00 00       	push   $0xec
  jmp alltraps
80106d3e:	e9 4c f1 ff ff       	jmp    80105e8f <alltraps>

80106d43 <vector237>:
.globl vector237
vector237:
  pushl $0
80106d43:	6a 00                	push   $0x0
  pushl $237
80106d45:	68 ed 00 00 00       	push   $0xed
  jmp alltraps
80106d4a:	e9 40 f1 ff ff       	jmp    80105e8f <alltraps>

80106d4f <vector238>:
.globl vector238
vector238:
  pushl $0
80106d4f:	6a 00                	push   $0x0
  pushl $238
80106d51:	68 ee 00 00 00       	push   $0xee
  jmp alltraps
80106d56:	e9 34 f1 ff ff       	jmp    80105e8f <alltraps>

80106d5b <vector239>:
.globl vector239
vector239:
  pushl $0
80106d5b:	6a 00                	push   $0x0
  pushl $239
80106d5d:	68 ef 00 00 00       	push   $0xef
  jmp alltraps
80106d62:	e9 28 f1 ff ff       	jmp    80105e8f <alltraps>

80106d67 <vector240>:
.globl vector240
vector240:
  pushl $0
80106d67:	6a 00                	push   $0x0
  pushl $240
80106d69:	68 f0 00 00 00       	push   $0xf0
  jmp alltraps
80106d6e:	e9 1c f1 ff ff       	jmp    80105e8f <alltraps>

80106d73 <vector241>:
.globl vector241
vector241:
  pushl $0
80106d73:	6a 00                	push   $0x0
  pushl $241
80106d75:	68 f1 00 00 00       	push   $0xf1
  jmp alltraps
80106d7a:	e9 10 f1 ff ff       	jmp    80105e8f <alltraps>

80106d7f <vector242>:
.globl vector242
vector242:
  pushl $0
80106d7f:	6a 00                	push   $0x0
  pushl $242
80106d81:	68 f2 00 00 00       	push   $0xf2
  jmp alltraps
80106d86:	e9 04 f1 ff ff       	jmp    80105e8f <alltraps>

80106d8b <vector243>:
.globl vector243
vector243:
  pushl $0
80106d8b:	6a 00                	push   $0x0
  pushl $243
80106d8d:	68 f3 00 00 00       	push   $0xf3
  jmp alltraps
80106d92:	e9 f8 f0 ff ff       	jmp    80105e8f <alltraps>

80106d97 <vector244>:
.globl vector244
vector244:
  pushl $0
80106d97:	6a 00                	push   $0x0
  pushl $244
80106d99:	68 f4 00 00 00       	push   $0xf4
  jmp alltraps
80106d9e:	e9 ec f0 ff ff       	jmp    80105e8f <alltraps>

80106da3 <vector245>:
.globl vector245
vector245:
  pushl $0
80106da3:	6a 00                	push   $0x0
  pushl $245
80106da5:	68 f5 00 00 00       	push   $0xf5
  jmp alltraps
80106daa:	e9 e0 f0 ff ff       	jmp    80105e8f <alltraps>

80106daf <vector246>:
.globl vector246
vector246:
  pushl $0
80106daf:	6a 00                	push   $0x0
  pushl $246
80106db1:	68 f6 00 00 00       	push   $0xf6
  jmp alltraps
80106db6:	e9 d4 f0 ff ff       	jmp    80105e8f <alltraps>

80106dbb <vector247>:
.globl vector247
vector247:
  pushl $0
80106dbb:	6a 00                	push   $0x0
  pushl $247
80106dbd:	68 f7 00 00 00       	push   $0xf7
  jmp alltraps
80106dc2:	e9 c8 f0 ff ff       	jmp    80105e8f <alltraps>

80106dc7 <vector248>:
.globl vector248
vector248:
  pushl $0
80106dc7:	6a 00                	push   $0x0
  pushl $248
80106dc9:	68 f8 00 00 00       	push   $0xf8
  jmp alltraps
80106dce:	e9 bc f0 ff ff       	jmp    80105e8f <alltraps>

80106dd3 <vector249>:
.globl vector249
vector249:
  pushl $0
80106dd3:	6a 00                	push   $0x0
  pushl $249
80106dd5:	68 f9 00 00 00       	push   $0xf9
  jmp alltraps
80106dda:	e9 b0 f0 ff ff       	jmp    80105e8f <alltraps>

80106ddf <vector250>:
.globl vector250
vector250:
  pushl $0
80106ddf:	6a 00                	push   $0x0
  pushl $250
80106de1:	68 fa 00 00 00       	push   $0xfa
  jmp alltraps
80106de6:	e9 a4 f0 ff ff       	jmp    80105e8f <alltraps>

80106deb <vector251>:
.globl vector251
vector251:
  pushl $0
80106deb:	6a 00                	push   $0x0
  pushl $251
80106ded:	68 fb 00 00 00       	push   $0xfb
  jmp alltraps
80106df2:	e9 98 f0 ff ff       	jmp    80105e8f <alltraps>

80106df7 <vector252>:
.globl vector252
vector252:
  pushl $0
80106df7:	6a 00                	push   $0x0
  pushl $252
80106df9:	68 fc 00 00 00       	push   $0xfc
  jmp alltraps
80106dfe:	e9 8c f0 ff ff       	jmp    80105e8f <alltraps>

80106e03 <vector253>:
.globl vector253
vector253:
  pushl $0
80106e03:	6a 00                	push   $0x0
  pushl $253
80106e05:	68 fd 00 00 00       	push   $0xfd
  jmp alltraps
80106e0a:	e9 80 f0 ff ff       	jmp    80105e8f <alltraps>

80106e0f <vector254>:
.globl vector254
vector254:
  pushl $0
80106e0f:	6a 00                	push   $0x0
  pushl $254
80106e11:	68 fe 00 00 00       	push   $0xfe
  jmp alltraps
80106e16:	e9 74 f0 ff ff       	jmp    80105e8f <alltraps>

80106e1b <vector255>:
.globl vector255
vector255:
  pushl $0
80106e1b:	6a 00                	push   $0x0
  pushl $255
80106e1d:	68 ff 00 00 00       	push   $0xff
  jmp alltraps
80106e22:	e9 68 f0 ff ff       	jmp    80105e8f <alltraps>
80106e27:	66 90                	xchg   %ax,%ax
80106e29:	66 90                	xchg   %ax,%ax
80106e2b:	66 90                	xchg   %ax,%ax
80106e2d:	66 90                	xchg   %ax,%ax
80106e2f:	66 90                	xchg   %ax,%ax
80106e31:	66 90                	xchg   %ax,%ax
80106e33:	66 90                	xchg   %ax,%ax
80106e35:	66 90                	xchg   %ax,%ax
80106e37:	66 90                	xchg   %ax,%ax
80106e39:	66 90                	xchg   %ax,%ax
80106e3b:	66 90                	xchg   %ax,%ax
80106e3d:	66 90                	xchg   %ax,%ax
80106e3f:	90                   	nop

80106e40 <deallocuvm.part.0>:

// Deallocate user pages to bring the process size from oldsz to
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
int deallocuvm(pde_t *pgdir, uint oldsz, uint newsz)
80106e40:	55                   	push   %ebp
80106e41:	89 e5                	mov    %esp,%ebp
80106e43:	83 ec 28             	sub    $0x28,%esp
80106e46:	89 5d f4             	mov    %ebx,-0xc(%ebp)
  uint a, pa;

  if (newsz >= oldsz)
    return oldsz;

  a = PGROUNDUP(newsz);
80106e49:	8d 99 ff 0f 00 00    	lea    0xfff(%ecx),%ebx
80106e4f:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
  for (; a < oldsz; a += PGSIZE)
80106e55:	39 d3                	cmp    %edx,%ebx
80106e57:	73 72                	jae    80106ecb <deallocuvm.part.0+0x8b>
80106e59:	89 75 f8             	mov    %esi,-0x8(%ebp)
80106e5c:	89 c6                	mov    %eax,%esi
80106e5e:	89 7d fc             	mov    %edi,-0x4(%ebp)
80106e61:	89 d7                	mov    %edx,%edi
80106e63:	89 4d e0             	mov    %ecx,-0x20(%ebp)
80106e66:	eb 22                	jmp    80106e8a <deallocuvm.part.0+0x4a>
80106e68:	eb 16                	jmp    80106e80 <deallocuvm.part.0+0x40>
80106e6a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80106e70:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80106e77:	00 
80106e78:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80106e7f:	00 
  {
    pte = walkpgdir(pgdir, (char *)a, 0);
    if (!pte)
      a = PGADDR(PDX(a) + 1, 0, 0) - PGSIZE;
80106e80:	8d 5a 01             	lea    0x1(%edx),%ebx
80106e83:	c1 e3 16             	shl    $0x16,%ebx
  for (; a < oldsz; a += PGSIZE)
80106e86:	39 fb                	cmp    %edi,%ebx
80106e88:	73 38                	jae    80106ec2 <deallocuvm.part.0+0x82>
  pde = &pgdir[PDX(va)];
80106e8a:	89 da                	mov    %ebx,%edx
80106e8c:	c1 ea 16             	shr    $0x16,%edx
  if (*pde & PTE_P)
80106e8f:	8b 04 96             	mov    (%esi,%edx,4),%eax
80106e92:	a8 01                	test   $0x1,%al
80106e94:	74 ea                	je     80106e80 <deallocuvm.part.0+0x40>
  return &pgtab[PTX(va)];
80106e96:	89 d9                	mov    %ebx,%ecx
    pgtab = (pte_t *)P2V(PTE_ADDR(*pde));
80106e98:	25 00 f0 ff ff       	and    $0xfffff000,%eax
  return &pgtab[PTX(va)];
80106e9d:	c1 e9 0a             	shr    $0xa,%ecx
80106ea0:	81 e1 fc 0f 00 00    	and    $0xffc,%ecx
80106ea6:	8d 84 08 00 00 00 80 	lea    -0x80000000(%eax,%ecx,1),%eax
    if (!pte)
80106ead:	85 c0                	test   %eax,%eax
80106eaf:	74 cf                	je     80106e80 <deallocuvm.part.0+0x40>
    else if ((*pte & PTE_P) != 0)
80106eb1:	8b 10                	mov    (%eax),%edx
80106eb3:	f6 c2 01             	test   $0x1,%dl
80106eb6:	75 20                	jne    80106ed8 <deallocuvm.part.0+0x98>
  for (; a < oldsz; a += PGSIZE)
80106eb8:	81 c3 00 10 00 00    	add    $0x1000,%ebx
80106ebe:	39 fb                	cmp    %edi,%ebx
80106ec0:	72 c8                	jb     80106e8a <deallocuvm.part.0+0x4a>
80106ec2:	8b 4d e0             	mov    -0x20(%ebp),%ecx
80106ec5:	8b 75 f8             	mov    -0x8(%ebp),%esi
80106ec8:	8b 7d fc             	mov    -0x4(%ebp),%edi
      kfree(v);
      *pte = 0;
    }
  }
  return newsz;
}
80106ecb:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80106ece:	89 c8                	mov    %ecx,%eax
80106ed0:	c9                   	leave
80106ed1:	c3                   	ret
80106ed2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      if (pa == 0)
80106ed8:	81 e2 00 f0 ff ff    	and    $0xfffff000,%edx
80106ede:	74 26                	je     80106f06 <deallocuvm.part.0+0xc6>
      kfree(v);
80106ee0:	83 ec 0c             	sub    $0xc,%esp
      char *v = P2V(pa);
80106ee3:	81 c2 00 00 00 80    	add    $0x80000000,%edx
80106ee9:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  for (; a < oldsz; a += PGSIZE)
80106eec:	81 c3 00 10 00 00    	add    $0x1000,%ebx
      kfree(v);
80106ef2:	52                   	push   %edx
80106ef3:	e8 48 b7 ff ff       	call   80102640 <kfree>
      *pte = 0;
80106ef8:	8b 45 e4             	mov    -0x1c(%ebp),%eax
  for (; a < oldsz; a += PGSIZE)
80106efb:	83 c4 10             	add    $0x10,%esp
      *pte = 0;
80106efe:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
80106f04:	eb 80                	jmp    80106e86 <deallocuvm.part.0+0x46>
        panic("kfree");
80106f06:	83 ec 0c             	sub    $0xc,%esp
80106f09:	68 0c 7b 10 80       	push   $0x80107b0c
80106f0e:	e8 8d 94 ff ff       	call   801003a0 <panic>
80106f13:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80106f18:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80106f1f:	00 

80106f20 <mappages>:
{
80106f20:	55                   	push   %ebp
80106f21:	89 e5                	mov    %esp,%ebp
80106f23:	57                   	push   %edi
  last = (char *)PGROUNDDOWN(((uint)va) + size - 1);
80106f24:	8d 7c 0a ff          	lea    -0x1(%edx,%ecx,1),%edi
{
80106f28:	56                   	push   %esi
  last = (char *)PGROUNDDOWN(((uint)va) + size - 1);
80106f29:	81 e7 00 f0 ff ff    	and    $0xfffff000,%edi
80106f2f:	89 c6                	mov    %eax,%esi
{
80106f31:	53                   	push   %ebx
  a = (char *)PGROUNDDOWN((uint)va);
80106f32:	89 d3                	mov    %edx,%ebx
80106f34:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
{
80106f3a:	83 ec 1c             	sub    $0x1c,%esp
80106f3d:	8b 4d 08             	mov    0x8(%ebp),%ecx
  last = (char *)PGROUNDDOWN(((uint)va) + size - 1);
80106f40:	89 7d e4             	mov    %edi,-0x1c(%ebp)
80106f43:	29 d9                	sub    %ebx,%ecx
80106f45:	89 4d e0             	mov    %ecx,-0x20(%ebp)
80106f48:	eb 42                	jmp    80106f8c <mappages+0x6c>
80106f4a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  return &pgtab[PTX(va)];
80106f50:	89 da                	mov    %ebx,%edx
    pgtab = (pte_t *)P2V(PTE_ADDR(*pde));
80106f52:	25 00 f0 ff ff       	and    $0xfffff000,%eax
  return &pgtab[PTX(va)];
80106f57:	c1 ea 0a             	shr    $0xa,%edx
80106f5a:	81 e2 fc 0f 00 00    	and    $0xffc,%edx
80106f60:	8d 94 10 00 00 00 80 	lea    -0x80000000(%eax,%edx,1),%edx
    if ((pte = walkpgdir(pgdir, a, 1)) == 0)
80106f67:	85 d2                	test   %edx,%edx
80106f69:	74 6d                	je     80106fd8 <mappages+0xb8>
    if (*pte & PTE_P)
80106f6b:	f6 02 01             	testb  $0x1,(%edx)
80106f6e:	0f 85 7e 00 00 00    	jne    80106ff2 <mappages+0xd2>
    *pte = pa | perm | PTE_P;
80106f74:	8b 45 e0             	mov    -0x20(%ebp),%eax
80106f77:	01 d8                	add    %ebx,%eax
80106f79:	0b 45 0c             	or     0xc(%ebp),%eax
80106f7c:	83 c8 01             	or     $0x1,%eax
80106f7f:	89 02                	mov    %eax,(%edx)
    if (a == last)
80106f81:	3b 5d e4             	cmp    -0x1c(%ebp),%ebx
80106f84:	74 62                	je     80106fe8 <mappages+0xc8>
    a += PGSIZE;
80106f86:	81 c3 00 10 00 00    	add    $0x1000,%ebx
  pde = &pgdir[PDX(va)];
80106f8c:	89 d8                	mov    %ebx,%eax
80106f8e:	c1 e8 16             	shr    $0x16,%eax
80106f91:	8d 3c 86             	lea    (%esi,%eax,4),%edi
  if (*pde & PTE_P)
80106f94:	8b 07                	mov    (%edi),%eax
80106f96:	a8 01                	test   $0x1,%al
80106f98:	75 b6                	jne    80106f50 <mappages+0x30>
    if (!alloc || (pgtab = (pte_t *)kalloc()) == 0)
80106f9a:	e8 71 b8 ff ff       	call   80102810 <kalloc>
80106f9f:	85 c0                	test   %eax,%eax
80106fa1:	74 35                	je     80106fd8 <mappages+0xb8>
    memset(pgtab, 0, PGSIZE);
80106fa3:	83 ec 04             	sub    $0x4,%esp
80106fa6:	68 00 10 00 00       	push   $0x1000
80106fab:	6a 00                	push   $0x0
80106fad:	50                   	push   %eax
80106fae:	89 45 dc             	mov    %eax,-0x24(%ebp)
80106fb1:	e8 aa da ff ff       	call   80104a60 <memset>
    *pde = V2P(pgtab) | PTE_P | PTE_W | PTE_U;
80106fb6:	8b 55 dc             	mov    -0x24(%ebp),%edx
  return &pgtab[PTX(va)];
80106fb9:	83 c4 10             	add    $0x10,%esp
    *pde = V2P(pgtab) | PTE_P | PTE_W | PTE_U;
80106fbc:	8d 82 00 00 00 80    	lea    -0x80000000(%edx),%eax
80106fc2:	83 c8 07             	or     $0x7,%eax
80106fc5:	89 07                	mov    %eax,(%edi)
  return &pgtab[PTX(va)];
80106fc7:	89 d8                	mov    %ebx,%eax
80106fc9:	c1 e8 0a             	shr    $0xa,%eax
80106fcc:	25 fc 0f 00 00       	and    $0xffc,%eax
80106fd1:	01 c2                	add    %eax,%edx
80106fd3:	eb 96                	jmp    80106f6b <mappages+0x4b>
80106fd5:	8d 76 00             	lea    0x0(%esi),%esi
}
80106fd8:	8d 65 f4             	lea    -0xc(%ebp),%esp
      return -1;
80106fdb:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80106fe0:	5b                   	pop    %ebx
80106fe1:	5e                   	pop    %esi
80106fe2:	5f                   	pop    %edi
80106fe3:	5d                   	pop    %ebp
80106fe4:	c3                   	ret
80106fe5:	8d 76 00             	lea    0x0(%esi),%esi
80106fe8:	8d 65 f4             	lea    -0xc(%ebp),%esp
  return 0;
80106feb:	31 c0                	xor    %eax,%eax
}
80106fed:	5b                   	pop    %ebx
80106fee:	5e                   	pop    %esi
80106fef:	5f                   	pop    %edi
80106ff0:	5d                   	pop    %ebp
80106ff1:	c3                   	ret
      panic("remap");
80106ff2:	83 ec 0c             	sub    $0xc,%esp
80106ff5:	68 40 7d 10 80       	push   $0x80107d40
80106ffa:	e8 a1 93 ff ff       	call   801003a0 <panic>
80106fff:	90                   	nop

80107000 <seginit>:
{
80107000:	55                   	push   %ebp
80107001:	89 e5                	mov    %esp,%ebp
80107003:	83 ec 18             	sub    $0x18,%esp
  c = &cpus[cpuid()];
80107006:	e8 75 cb ff ff       	call   80103b80 <cpuid>
  pd[0] = size-1;
8010700b:	ba 2f 00 00 00       	mov    $0x2f,%edx
  c->gdt[SEG_KCODE] = SEG(STA_X | STA_R, 0, 0xffffffff, 0);
80107010:	69 c0 b0 00 00 00    	imul   $0xb0,%eax,%eax
80107016:	c7 80 38 28 11 80 ff 	movl   $0xffff,-0x7feed7c8(%eax)
8010701d:	ff 00 00 
  c->gdt[SEG_KDATA] = SEG(STA_W, 0, 0xffffffff, 0);
80107020:	c7 80 40 28 11 80 ff 	movl   $0xffff,-0x7feed7c0(%eax)
80107027:	ff 00 00 
  c->gdt[SEG_UCODE] = SEG(STA_X | STA_R, 0, 0xffffffff, DPL_USER);
8010702a:	c7 80 48 28 11 80 ff 	movl   $0xffff,-0x7feed7b8(%eax)
80107031:	ff 00 00 
  c->gdt[SEG_UDATA] = SEG(STA_W, 0, 0xffffffff, DPL_USER);
80107034:	c7 80 50 28 11 80 ff 	movl   $0xffff,-0x7feed7b0(%eax)
8010703b:	ff 00 00 
  c->gdt[SEG_KCODE] = SEG(STA_X | STA_R, 0, 0xffffffff, 0);
8010703e:	c7 80 3c 28 11 80 00 	movl   $0xcf9a00,-0x7feed7c4(%eax)
80107045:	9a cf 00 
  c->gdt[SEG_KDATA] = SEG(STA_W, 0, 0xffffffff, 0);
80107048:	c7 80 44 28 11 80 00 	movl   $0xcf9200,-0x7feed7bc(%eax)
8010704f:	92 cf 00 
  c->gdt[SEG_UCODE] = SEG(STA_X | STA_R, 0, 0xffffffff, DPL_USER);
80107052:	c7 80 4c 28 11 80 00 	movl   $0xcffa00,-0x7feed7b4(%eax)
80107059:	fa cf 00 
  c->gdt[SEG_UDATA] = SEG(STA_W, 0, 0xffffffff, DPL_USER);
8010705c:	c7 80 54 28 11 80 00 	movl   $0xcff200,-0x7feed7ac(%eax)
80107063:	f2 cf 00 
  lgdt(c->gdt, sizeof(c->gdt));
80107066:	05 30 28 11 80       	add    $0x80112830,%eax
8010706b:	66 89 55 f2          	mov    %dx,-0xe(%ebp)
  pd[1] = (uint)p;
8010706f:	66 89 45 f4          	mov    %ax,-0xc(%ebp)
  pd[2] = (uint)p >> 16;
80107073:	c1 e8 10             	shr    $0x10,%eax
80107076:	66 89 45 f6          	mov    %ax,-0xa(%ebp)
  asm volatile("lgdt (%0)" : : "r" (pd));
8010707a:	8d 45 f2             	lea    -0xe(%ebp),%eax
8010707d:	0f 01 10             	lgdtl  (%eax)
}
80107080:	c9                   	leave
80107081:	c3                   	ret
80107082:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80107088:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010708f:	00 

80107090 <change_perm>:
{
80107090:	55                   	push   %ebp
80107091:	89 e5                	mov    %esp,%ebp
80107093:	83 ec 0c             	sub    $0xc,%esp
80107096:	89 7d fc             	mov    %edi,-0x4(%ebp)
80107099:	8b 7d 10             	mov    0x10(%ebp),%edi
8010709c:	8b 55 08             	mov    0x8(%ebp),%edx
  for (i = 0; i < len; i++)
8010709f:	85 ff                	test   %edi,%edi
801070a1:	0f 84 ce 00 00 00    	je     80107175 <change_perm+0xe5>
801070a7:	89 5d f4             	mov    %ebx,-0xc(%ebp)
801070aa:	8b 4d 0c             	mov    0xc(%ebp),%ecx
801070ad:	31 db                	xor    %ebx,%ebx
801070af:	89 75 f8             	mov    %esi,-0x8(%ebp)
801070b2:	eb 31                	jmp    801070e5 <change_perm+0x55>
801070b4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  return &pgtab[PTX(va)];
801070b8:	89 ce                	mov    %ecx,%esi
    pgtab = (pte_t *)P2V(PTE_ADDR(*pde));
801070ba:	25 00 f0 ff ff       	and    $0xfffff000,%eax
  return &pgtab[PTX(va)];
801070bf:	c1 ee 0a             	shr    $0xa,%esi
801070c2:	81 e6 fc 0f 00 00    	and    $0xffc,%esi
801070c8:	8d 84 30 00 00 00 80 	lea    -0x80000000(%eax,%esi,1),%eax
    if (pte == 0 || !(*pte & PTE_P))
801070cf:	85 c0                	test   %eax,%eax
801070d1:	74 1e                	je     801070f1 <change_perm+0x61>
801070d3:	f6 00 01             	testb  $0x1,(%eax)
801070d6:	74 19                	je     801070f1 <change_perm+0x61>
  for (i = 0; i < len; i++)
801070d8:	83 c3 01             	add    $0x1,%ebx
801070db:	81 c1 00 10 00 00    	add    $0x1000,%ecx
801070e1:	39 fb                	cmp    %edi,%ebx
801070e3:	74 23                	je     80107108 <change_perm+0x78>
  pde = &pgdir[PDX(va)];
801070e5:	89 c8                	mov    %ecx,%eax
801070e7:	c1 e8 16             	shr    $0x16,%eax
  if (*pde & PTE_P)
801070ea:	8b 04 82             	mov    (%edx,%eax,4),%eax
801070ed:	a8 01                	test   $0x1,%al
801070ef:	75 c7                	jne    801070b8 <change_perm+0x28>
801070f1:	8b 5d f4             	mov    -0xc(%ebp),%ebx
801070f4:	8b 75 f8             	mov    -0x8(%ebp),%esi
      return -1;
801070f7:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
801070fc:	8b 7d fc             	mov    -0x4(%ebp),%edi
801070ff:	c9                   	leave
80107100:	c3                   	ret
80107101:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  for (i = 0; i < len; i++)
80107108:	89 7d 10             	mov    %edi,0x10(%ebp)
8010710b:	31 db                	xor    %ebx,%ebx
8010710d:	89 55 08             	mov    %edx,0x8(%ebp)
80107110:	8b 55 0c             	mov    0xc(%ebp),%edx
80107113:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80107118:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010711f:	00 
  if (*pde & PTE_P)
80107120:	8b 7d 08             	mov    0x8(%ebp),%edi
  pde = &pgdir[PDX(va)];
80107123:	89 d0                	mov    %edx,%eax
  return &pgtab[PTX(va)];
80107125:	89 d1                	mov    %edx,%ecx
  pde = &pgdir[PDX(va)];
80107127:	c1 e8 16             	shr    $0x16,%eax
  return &pgtab[PTX(va)];
8010712a:	c1 e9 0a             	shr    $0xa,%ecx
  if (*pde & PTE_P)
8010712d:	8b 34 87             	mov    (%edi,%eax,4),%esi
  return &pgtab[PTX(va)];
80107130:	81 e1 fc 0f 00 00    	and    $0xffc,%ecx
      return 0;
80107136:	31 c0                	xor    %eax,%eax
  return &pgtab[PTX(va)];
80107138:	89 f7                	mov    %esi,%edi
8010713a:	81 e7 00 f0 ff ff    	and    $0xfffff000,%edi
80107140:	83 e6 01             	and    $0x1,%esi
80107143:	8d 8c 0f 00 00 00 80 	lea    -0x80000000(%edi,%ecx,1),%ecx
      *pte |= PTE_W;
8010714a:	8b 7d 14             	mov    0x14(%ebp),%edi
  return &pgtab[PTX(va)];
8010714d:	0f 45 c1             	cmovne %ecx,%eax
      *pte |= PTE_W;
80107150:	8b 08                	mov    (%eax),%ecx
80107152:	89 ce                	mov    %ecx,%esi
80107154:	83 e1 fd             	and    $0xfffffffd,%ecx
80107157:	83 ce 02             	or     $0x2,%esi
8010715a:	85 ff                	test   %edi,%edi
8010715c:	0f 45 ce             	cmovne %esi,%ecx
  for (i = 0; i < len; i++)
8010715f:	83 c3 01             	add    $0x1,%ebx
80107162:	81 c2 00 10 00 00    	add    $0x1000,%edx
80107168:	89 08                	mov    %ecx,(%eax)
8010716a:	39 5d 10             	cmp    %ebx,0x10(%ebp)
8010716d:	75 b1                	jne    80107120 <change_perm+0x90>
8010716f:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80107172:	8b 75 f8             	mov    -0x8(%ebp),%esi
}
80107175:	8b 7d fc             	mov    -0x4(%ebp),%edi
  return 0;
80107178:	31 c0                	xor    %eax,%eax
}
8010717a:	c9                   	leave
8010717b:	c3                   	ret
8010717c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80107180 <switchkvm>:
  lcr3(V2P(kpgdir)); // switch to the kernel page table
80107180:	a1 e4 55 11 80       	mov    0x801155e4,%eax
80107185:	05 00 00 00 80       	add    $0x80000000,%eax
  asm volatile("movl %0,%%cr3" : : "r" (val));
8010718a:	0f 22 d8             	mov    %eax,%cr3
}
8010718d:	c3                   	ret
8010718e:	66 90                	xchg   %ax,%ax

80107190 <switchuvm>:
{
80107190:	55                   	push   %ebp
80107191:	89 e5                	mov    %esp,%ebp
80107193:	57                   	push   %edi
80107194:	56                   	push   %esi
80107195:	53                   	push   %ebx
80107196:	83 ec 1c             	sub    $0x1c,%esp
80107199:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if (p == 0)
8010719c:	85 db                	test   %ebx,%ebx
8010719e:	0f 84 c9 00 00 00    	je     8010726d <switchuvm+0xdd>
  if (p->kstack == 0)
801071a4:	8b 43 08             	mov    0x8(%ebx),%eax
801071a7:	85 c0                	test   %eax,%eax
801071a9:	0f 84 d8 00 00 00    	je     80107287 <switchuvm+0xf7>
  if (p->pgdir == 0)
801071af:	8b 43 04             	mov    0x4(%ebx),%eax
801071b2:	85 c0                	test   %eax,%eax
801071b4:	0f 84 c0 00 00 00    	je     8010727a <switchuvm+0xea>
  pushcli();
801071ba:	e8 21 d6 ff ff       	call   801047e0 <pushcli>
  mycpu()->gdt[SEG_TSS] = SEG16(STS_T32A, &mycpu()->ts,
801071bf:	e8 4c c9 ff ff       	call   80103b10 <mycpu>
801071c4:	89 c6                	mov    %eax,%esi
801071c6:	e8 45 c9 ff ff       	call   80103b10 <mycpu>
801071cb:	8d 78 08             	lea    0x8(%eax),%edi
801071ce:	e8 3d c9 ff ff       	call   80103b10 <mycpu>
801071d3:	89 45 e4             	mov    %eax,-0x1c(%ebp)
801071d6:	e8 35 c9 ff ff       	call   80103b10 <mycpu>
801071db:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
801071de:	ba 67 00 00 00       	mov    $0x67,%edx
801071e3:	66 89 be 9a 00 00 00 	mov    %di,0x9a(%esi)
801071ea:	83 c0 08             	add    $0x8,%eax
801071ed:	66 89 96 98 00 00 00 	mov    %dx,0x98(%esi)
  mycpu()->ts.iomb = (ushort)0xFFFF;
801071f4:	bf ff ff ff ff       	mov    $0xffffffff,%edi
  mycpu()->gdt[SEG_TSS] = SEG16(STS_T32A, &mycpu()->ts,
801071f9:	83 c1 08             	add    $0x8,%ecx
801071fc:	c1 e8 18             	shr    $0x18,%eax
801071ff:	c1 e9 10             	shr    $0x10,%ecx
80107202:	88 86 9f 00 00 00    	mov    %al,0x9f(%esi)
80107208:	88 8e 9c 00 00 00    	mov    %cl,0x9c(%esi)
8010720e:	b9 99 40 00 00       	mov    $0x4099,%ecx
80107213:	66 89 8e 9d 00 00 00 	mov    %cx,0x9d(%esi)
  mycpu()->ts.ss0 = SEG_KDATA << 3;
8010721a:	be 10 00 00 00       	mov    $0x10,%esi
  mycpu()->gdt[SEG_TSS].s = 0;
8010721f:	e8 ec c8 ff ff       	call   80103b10 <mycpu>
80107224:	80 a0 9d 00 00 00 ef 	andb   $0xef,0x9d(%eax)
  mycpu()->ts.ss0 = SEG_KDATA << 3;
8010722b:	e8 e0 c8 ff ff       	call   80103b10 <mycpu>
80107230:	66 89 70 10          	mov    %si,0x10(%eax)
  mycpu()->ts.esp0 = (uint)p->kstack + KSTACKSIZE;
80107234:	8b 73 08             	mov    0x8(%ebx),%esi
80107237:	81 c6 00 10 00 00    	add    $0x1000,%esi
8010723d:	e8 ce c8 ff ff       	call   80103b10 <mycpu>
80107242:	89 70 0c             	mov    %esi,0xc(%eax)
  mycpu()->ts.iomb = (ushort)0xFFFF;
80107245:	e8 c6 c8 ff ff       	call   80103b10 <mycpu>
8010724a:	66 89 78 6e          	mov    %di,0x6e(%eax)
  asm volatile("ltr %0" : : "r" (sel));
8010724e:	b8 28 00 00 00       	mov    $0x28,%eax
80107253:	0f 00 d8             	ltr    %eax
  lcr3(V2P(p->pgdir)); // switch to process's address space
80107256:	8b 43 04             	mov    0x4(%ebx),%eax
80107259:	05 00 00 00 80       	add    $0x80000000,%eax
  asm volatile("movl %0,%%cr3" : : "r" (val));
8010725e:	0f 22 d8             	mov    %eax,%cr3
}
80107261:	8d 65 f4             	lea    -0xc(%ebp),%esp
80107264:	5b                   	pop    %ebx
80107265:	5e                   	pop    %esi
80107266:	5f                   	pop    %edi
80107267:	5d                   	pop    %ebp
  popcli();
80107268:	e9 c3 d5 ff ff       	jmp    80104830 <popcli>
    panic("switchuvm: no process");
8010726d:	83 ec 0c             	sub    $0xc,%esp
80107270:	68 46 7d 10 80       	push   $0x80107d46
80107275:	e8 26 91 ff ff       	call   801003a0 <panic>
    panic("switchuvm: no pgdir");
8010727a:	83 ec 0c             	sub    $0xc,%esp
8010727d:	68 71 7d 10 80       	push   $0x80107d71
80107282:	e8 19 91 ff ff       	call   801003a0 <panic>
    panic("switchuvm: no kstack");
80107287:	83 ec 0c             	sub    $0xc,%esp
8010728a:	68 5c 7d 10 80       	push   $0x80107d5c
8010728f:	e8 0c 91 ff ff       	call   801003a0 <panic>
80107294:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80107298:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010729f:	00 

801072a0 <inituvm>:
{
801072a0:	55                   	push   %ebp
801072a1:	89 e5                	mov    %esp,%ebp
801072a3:	57                   	push   %edi
801072a4:	56                   	push   %esi
801072a5:	53                   	push   %ebx
801072a6:	83 ec 1c             	sub    $0x1c,%esp
801072a9:	8b 45 08             	mov    0x8(%ebp),%eax
801072ac:	8b 75 10             	mov    0x10(%ebp),%esi
801072af:	8b 7d 0c             	mov    0xc(%ebp),%edi
801072b2:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  if (sz >= PGSIZE)
801072b5:	81 fe ff 0f 00 00    	cmp    $0xfff,%esi
801072bb:	77 49                	ja     80107306 <inituvm+0x66>
  mem = kalloc();
801072bd:	e8 4e b5 ff ff       	call   80102810 <kalloc>
  memset(mem, 0, PGSIZE);
801072c2:	83 ec 04             	sub    $0x4,%esp
801072c5:	68 00 10 00 00       	push   $0x1000
  mem = kalloc();
801072ca:	89 c3                	mov    %eax,%ebx
  memset(mem, 0, PGSIZE);
801072cc:	6a 00                	push   $0x0
801072ce:	50                   	push   %eax
801072cf:	e8 8c d7 ff ff       	call   80104a60 <memset>
  mappages(pgdir, 0, PGSIZE, V2P(mem), PTE_W | PTE_U);
801072d4:	58                   	pop    %eax
801072d5:	8d 83 00 00 00 80    	lea    -0x80000000(%ebx),%eax
801072db:	5a                   	pop    %edx
801072dc:	6a 06                	push   $0x6
801072de:	b9 00 10 00 00       	mov    $0x1000,%ecx
801072e3:	31 d2                	xor    %edx,%edx
801072e5:	50                   	push   %eax
801072e6:	8b 45 e4             	mov    -0x1c(%ebp),%eax
801072e9:	e8 32 fc ff ff       	call   80106f20 <mappages>
  memmove(mem, init, sz);
801072ee:	83 c4 10             	add    $0x10,%esp
801072f1:	89 75 10             	mov    %esi,0x10(%ebp)
801072f4:	89 7d 0c             	mov    %edi,0xc(%ebp)
801072f7:	89 5d 08             	mov    %ebx,0x8(%ebp)
}
801072fa:	8d 65 f4             	lea    -0xc(%ebp),%esp
801072fd:	5b                   	pop    %ebx
801072fe:	5e                   	pop    %esi
801072ff:	5f                   	pop    %edi
80107300:	5d                   	pop    %ebp
  memmove(mem, init, sz);
80107301:	e9 fa d7 ff ff       	jmp    80104b00 <memmove>
    panic("inituvm: more than a page");
80107306:	83 ec 0c             	sub    $0xc,%esp
80107309:	68 85 7d 10 80       	push   $0x80107d85
8010730e:	e8 8d 90 ff ff       	call   801003a0 <panic>
80107313:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80107318:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010731f:	00 

80107320 <loaduvm>:
{
80107320:	55                   	push   %ebp
80107321:	89 e5                	mov    %esp,%ebp
80107323:	83 ec 18             	sub    $0x18,%esp
80107326:	89 75 f8             	mov    %esi,-0x8(%ebp)
  if ((uint)addr % PGSIZE != 0)
80107329:	8b 75 0c             	mov    0xc(%ebp),%esi
{
8010732c:	89 7d fc             	mov    %edi,-0x4(%ebp)
8010732f:	8b 7d 18             	mov    0x18(%ebp),%edi
  if ((uint)addr % PGSIZE != 0)
80107332:	81 e6 ff 0f 00 00    	and    $0xfff,%esi
80107338:	0f 85 b2 00 00 00    	jne    801073f0 <loaduvm+0xd0>
  for (i = 0; i < sz; i += PGSIZE)
8010733e:	85 ff                	test   %edi,%edi
80107340:	0f 84 89 00 00 00    	je     801073cf <loaduvm+0xaf>
80107346:	89 5d f4             	mov    %ebx,-0xc(%ebp)
80107349:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  pde = &pgdir[PDX(va)];
80107350:	8b 45 0c             	mov    0xc(%ebp),%eax
  if (*pde & PTE_P)
80107353:	8b 55 08             	mov    0x8(%ebp),%edx
80107356:	01 f0                	add    %esi,%eax
  pde = &pgdir[PDX(va)];
80107358:	89 c1                	mov    %eax,%ecx
8010735a:	c1 e9 16             	shr    $0x16,%ecx
  if (*pde & PTE_P)
8010735d:	8b 0c 8a             	mov    (%edx,%ecx,4),%ecx
80107360:	f6 c1 01             	test   $0x1,%cl
80107363:	75 13                	jne    80107378 <loaduvm+0x58>
      panic("loaduvm: address should exist");
80107365:	83 ec 0c             	sub    $0xc,%esp
80107368:	68 9f 7d 10 80       	push   $0x80107d9f
8010736d:	e8 2e 90 ff ff       	call   801003a0 <panic>
80107372:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  return &pgtab[PTX(va)];
80107378:	c1 e8 0a             	shr    $0xa,%eax
    pgtab = (pte_t *)P2V(PTE_ADDR(*pde));
8010737b:	81 e1 00 f0 ff ff    	and    $0xfffff000,%ecx
  return &pgtab[PTX(va)];
80107381:	25 fc 0f 00 00       	and    $0xffc,%eax
80107386:	8d 8c 01 00 00 00 80 	lea    -0x80000000(%ecx,%eax,1),%ecx
    if ((pte = walkpgdir(pgdir, addr + i, 0)) == 0)
8010738d:	85 c9                	test   %ecx,%ecx
8010738f:	74 d4                	je     80107365 <loaduvm+0x45>
    if (sz - i < PGSIZE)
80107391:	89 fb                	mov    %edi,%ebx
80107393:	b8 00 10 00 00       	mov    $0x1000,%eax
80107398:	29 f3                	sub    %esi,%ebx
8010739a:	39 c3                	cmp    %eax,%ebx
8010739c:	0f 47 d8             	cmova  %eax,%ebx
    if (readi(ip, P2V(pa), offset + i, n) != n)
8010739f:	8b 45 14             	mov    0x14(%ebp),%eax
801073a2:	01 f0                	add    %esi,%eax
801073a4:	53                   	push   %ebx
801073a5:	50                   	push   %eax
    pa = PTE_ADDR(*pte);
801073a6:	8b 01                	mov    (%ecx),%eax
801073a8:	25 00 f0 ff ff       	and    $0xfffff000,%eax
    if (readi(ip, P2V(pa), offset + i, n) != n)
801073ad:	05 00 00 00 80       	add    $0x80000000,%eax
801073b2:	50                   	push   %eax
801073b3:	ff 75 10             	push   0x10(%ebp)
801073b6:	e8 d5 a7 ff ff       	call   80101b90 <readi>
801073bb:	83 c4 10             	add    $0x10,%esp
801073be:	39 d8                	cmp    %ebx,%eax
801073c0:	75 1e                	jne    801073e0 <loaduvm+0xc0>
  for (i = 0; i < sz; i += PGSIZE)
801073c2:	81 c6 00 10 00 00    	add    $0x1000,%esi
801073c8:	39 fe                	cmp    %edi,%esi
801073ca:	72 84                	jb     80107350 <loaduvm+0x30>
801073cc:	8b 5d f4             	mov    -0xc(%ebp),%ebx
}
801073cf:	8b 75 f8             	mov    -0x8(%ebp),%esi
801073d2:	8b 7d fc             	mov    -0x4(%ebp),%edi
  return 0;
801073d5:	31 c0                	xor    %eax,%eax
}
801073d7:	c9                   	leave
801073d8:	c3                   	ret
801073d9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
      return -1;
801073e0:	8b 5d f4             	mov    -0xc(%ebp),%ebx
}
801073e3:	8b 75 f8             	mov    -0x8(%ebp),%esi
      return -1;
801073e6:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
801073eb:	8b 7d fc             	mov    -0x4(%ebp),%edi
801073ee:	c9                   	leave
801073ef:	c3                   	ret
    panic("loaduvm: addr must be page aligned");
801073f0:	83 ec 0c             	sub    $0xc,%esp
801073f3:	89 5d f4             	mov    %ebx,-0xc(%ebp)
801073f6:	68 a0 7f 10 80       	push   $0x80107fa0
801073fb:	e8 a0 8f ff ff       	call   801003a0 <panic>

80107400 <allocuvm>:
{
80107400:	55                   	push   %ebp
80107401:	89 e5                	mov    %esp,%ebp
80107403:	83 ec 28             	sub    $0x28,%esp
80107406:	89 75 f8             	mov    %esi,-0x8(%ebp)
80107409:	8b 75 10             	mov    0x10(%ebp),%esi
  if (newsz >= KERNBASE)
8010740c:	85 f6                	test   %esi,%esi
8010740e:	0f 88 ac 00 00 00    	js     801074c0 <allocuvm+0xc0>
80107414:	89 f2                	mov    %esi,%edx
  if (newsz < oldsz)
80107416:	3b 75 0c             	cmp    0xc(%ebp),%esi
80107419:	0f 82 b1 00 00 00    	jb     801074d0 <allocuvm+0xd0>
  a = PGROUNDUP(oldsz);
8010741f:	8b 45 0c             	mov    0xc(%ebp),%eax
80107422:	89 7d fc             	mov    %edi,-0x4(%ebp)
80107425:	05 ff 0f 00 00       	add    $0xfff,%eax
8010742a:	25 00 f0 ff ff       	and    $0xfffff000,%eax
8010742f:	89 c7                	mov    %eax,%edi
  for (; a < newsz; a += PGSIZE)
80107431:	39 f0                	cmp    %esi,%eax
80107433:	0f 83 ff 00 00 00    	jae    80107538 <allocuvm+0x138>
80107439:	89 5d f4             	mov    %ebx,-0xc(%ebp)
8010743c:	89 75 e4             	mov    %esi,-0x1c(%ebp)
8010743f:	eb 47                	jmp    80107488 <allocuvm+0x88>
80107441:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    memset(mem, 0, PGSIZE);
80107448:	83 ec 04             	sub    $0x4,%esp
8010744b:	68 00 10 00 00       	push   $0x1000
80107450:	6a 00                	push   $0x0
80107452:	50                   	push   %eax
80107453:	e8 08 d6 ff ff       	call   80104a60 <memset>
    if (mappages(pgdir, (char *)a, PGSIZE, V2P(mem), PTE_W | PTE_U) < 0)
80107458:	58                   	pop    %eax
80107459:	8d 83 00 00 00 80    	lea    -0x80000000(%ebx),%eax
8010745f:	5a                   	pop    %edx
80107460:	6a 06                	push   $0x6
80107462:	b9 00 10 00 00       	mov    $0x1000,%ecx
80107467:	89 fa                	mov    %edi,%edx
80107469:	50                   	push   %eax
8010746a:	8b 45 08             	mov    0x8(%ebp),%eax
8010746d:	e8 ae fa ff ff       	call   80106f20 <mappages>
80107472:	83 c4 10             	add    $0x10,%esp
80107475:	83 f8 ff             	cmp    $0xffffffff,%eax
80107478:	74 66                	je     801074e0 <allocuvm+0xe0>
  for (; a < newsz; a += PGSIZE)
8010747a:	81 c7 00 10 00 00    	add    $0x1000,%edi
80107480:	39 f7                	cmp    %esi,%edi
80107482:	0f 83 98 00 00 00    	jae    80107520 <allocuvm+0x120>
    mem = kalloc();
80107488:	e8 83 b3 ff ff       	call   80102810 <kalloc>
8010748d:	89 c3                	mov    %eax,%ebx
    if (mem == 0)
8010748f:	85 c0                	test   %eax,%eax
80107491:	75 b5                	jne    80107448 <allocuvm+0x48>
      cprintf("allocuvm out of memory\n");
80107493:	83 ec 0c             	sub    $0xc,%esp
80107496:	68 bd 7d 10 80       	push   $0x80107dbd
8010749b:	e8 50 92 ff ff       	call   801006f0 <cprintf>
  if (newsz >= oldsz)
801074a0:	83 c4 10             	add    $0x10,%esp
801074a3:	3b 75 0c             	cmp    0xc(%ebp),%esi
801074a6:	0f 84 84 00 00 00    	je     80107530 <allocuvm+0x130>
  a = PGROUNDUP(newsz);
801074ac:	8b 4d 0c             	mov    0xc(%ebp),%ecx
801074af:	8b 45 08             	mov    0x8(%ebp),%eax
801074b2:	89 f2                	mov    %esi,%edx
801074b4:	e8 87 f9 ff ff       	call   80106e40 <deallocuvm.part.0>
801074b9:	8b 5d f4             	mov    -0xc(%ebp),%ebx
801074bc:	8b 7d fc             	mov    -0x4(%ebp),%edi
801074bf:	90                   	nop
    return 0;
801074c0:	31 d2                	xor    %edx,%edx
}
801074c2:	8b 75 f8             	mov    -0x8(%ebp),%esi
801074c5:	89 d0                	mov    %edx,%eax
801074c7:	c9                   	leave
801074c8:	c3                   	ret
801074c9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    return oldsz;
801074d0:	8b 55 0c             	mov    0xc(%ebp),%edx
}
801074d3:	8b 75 f8             	mov    -0x8(%ebp),%esi
801074d6:	c9                   	leave
801074d7:	89 d0                	mov    %edx,%eax
801074d9:	c3                   	ret
801074da:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      cprintf("allocuvm out of memory (2)\n");
801074e0:	83 ec 0c             	sub    $0xc,%esp
801074e3:	68 d5 7d 10 80       	push   $0x80107dd5
801074e8:	e8 03 92 ff ff       	call   801006f0 <cprintf>
  if (newsz >= oldsz)
801074ed:	83 c4 10             	add    $0x10,%esp
801074f0:	3b 75 0c             	cmp    0xc(%ebp),%esi
801074f3:	74 0d                	je     80107502 <allocuvm+0x102>
  a = PGROUNDUP(newsz);
801074f5:	8b 4d 0c             	mov    0xc(%ebp),%ecx
801074f8:	8b 45 08             	mov    0x8(%ebp),%eax
801074fb:	89 f2                	mov    %esi,%edx
801074fd:	e8 3e f9 ff ff       	call   80106e40 <deallocuvm.part.0>
      kfree(mem);
80107502:	83 ec 0c             	sub    $0xc,%esp
80107505:	53                   	push   %ebx
80107506:	e8 35 b1 ff ff       	call   80102640 <kfree>
      return 0;
8010750b:	8b 5d f4             	mov    -0xc(%ebp),%ebx
8010750e:	8b 7d fc             	mov    -0x4(%ebp),%edi
80107511:	83 c4 10             	add    $0x10,%esp
80107514:	eb aa                	jmp    801074c0 <allocuvm+0xc0>
80107516:	66 90                	xchg   %ax,%ax
80107518:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010751f:	00 
80107520:	8b 55 e4             	mov    -0x1c(%ebp),%edx
80107523:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80107526:	8b 7d fc             	mov    -0x4(%ebp),%edi
}
80107529:	8b 75 f8             	mov    -0x8(%ebp),%esi
8010752c:	c9                   	leave
8010752d:	89 d0                	mov    %edx,%eax
8010752f:	c3                   	ret
80107530:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80107533:	8b 7d fc             	mov    -0x4(%ebp),%edi
80107536:	eb 88                	jmp    801074c0 <allocuvm+0xc0>
80107538:	8b 7d fc             	mov    -0x4(%ebp),%edi
8010753b:	eb 85                	jmp    801074c2 <allocuvm+0xc2>
8010753d:	8d 76 00             	lea    0x0(%esi),%esi

80107540 <deallocuvm>:
{
80107540:	55                   	push   %ebp
80107541:	89 e5                	mov    %esp,%ebp
80107543:	8b 55 0c             	mov    0xc(%ebp),%edx
80107546:	8b 4d 10             	mov    0x10(%ebp),%ecx
80107549:	8b 45 08             	mov    0x8(%ebp),%eax
  if (newsz >= oldsz)
8010754c:	39 d1                	cmp    %edx,%ecx
8010754e:	73 10                	jae    80107560 <deallocuvm+0x20>
}
80107550:	5d                   	pop    %ebp
80107551:	e9 ea f8 ff ff       	jmp    80106e40 <deallocuvm.part.0>
80107556:	66 90                	xchg   %ax,%ax
80107558:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010755f:	00 
80107560:	89 d0                	mov    %edx,%eax
80107562:	5d                   	pop    %ebp
80107563:	c3                   	ret
80107564:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80107568:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010756f:	00 

80107570 <freevm>:

// Free a page table and all the physical memory pages
// in the user part.
void freevm(pde_t *pgdir)
{
80107570:	55                   	push   %ebp
80107571:	89 e5                	mov    %esp,%ebp
80107573:	57                   	push   %edi
80107574:	56                   	push   %esi
80107575:	53                   	push   %ebx
80107576:	83 ec 0c             	sub    $0xc,%esp
80107579:	8b 75 08             	mov    0x8(%ebp),%esi
  uint i;

  if (pgdir == 0)
8010757c:	85 f6                	test   %esi,%esi
8010757e:	74 59                	je     801075d9 <freevm+0x69>
  a = PGROUNDUP(newsz);
80107580:	31 c9                	xor    %ecx,%ecx
80107582:	ba 00 00 00 80       	mov    $0x80000000,%edx
80107587:	89 f0                	mov    %esi,%eax
80107589:	89 f3                	mov    %esi,%ebx
8010758b:	e8 b0 f8 ff ff       	call   80106e40 <deallocuvm.part.0>
    panic("freevm: no pgdir");
  deallocuvm(pgdir, KERNBASE, 0);
  for (i = 0; i < NPDENTRIES; i++)
80107590:	8d be 00 10 00 00    	lea    0x1000(%esi),%edi
80107596:	eb 0f                	jmp    801075a7 <freevm+0x37>
80107598:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010759f:	00 
801075a0:	83 c3 04             	add    $0x4,%ebx
801075a3:	39 fb                	cmp    %edi,%ebx
801075a5:	74 23                	je     801075ca <freevm+0x5a>
  {
    if (pgdir[i] & PTE_P)
801075a7:	8b 03                	mov    (%ebx),%eax
801075a9:	a8 01                	test   $0x1,%al
801075ab:	74 f3                	je     801075a0 <freevm+0x30>
    {
      char *v = P2V(PTE_ADDR(pgdir[i]));
801075ad:	25 00 f0 ff ff       	and    $0xfffff000,%eax
      kfree(v);
801075b2:	83 ec 0c             	sub    $0xc,%esp
  for (i = 0; i < NPDENTRIES; i++)
801075b5:	83 c3 04             	add    $0x4,%ebx
      char *v = P2V(PTE_ADDR(pgdir[i]));
801075b8:	05 00 00 00 80       	add    $0x80000000,%eax
      kfree(v);
801075bd:	50                   	push   %eax
801075be:	e8 7d b0 ff ff       	call   80102640 <kfree>
801075c3:	83 c4 10             	add    $0x10,%esp
  for (i = 0; i < NPDENTRIES; i++)
801075c6:	39 fb                	cmp    %edi,%ebx
801075c8:	75 dd                	jne    801075a7 <freevm+0x37>
    }
  }
  kfree((char *)pgdir);
801075ca:	89 75 08             	mov    %esi,0x8(%ebp)
}
801075cd:	8d 65 f4             	lea    -0xc(%ebp),%esp
801075d0:	5b                   	pop    %ebx
801075d1:	5e                   	pop    %esi
801075d2:	5f                   	pop    %edi
801075d3:	5d                   	pop    %ebp
  kfree((char *)pgdir);
801075d4:	e9 67 b0 ff ff       	jmp    80102640 <kfree>
    panic("freevm: no pgdir");
801075d9:	83 ec 0c             	sub    $0xc,%esp
801075dc:	68 f1 7d 10 80       	push   $0x80107df1
801075e1:	e8 ba 8d ff ff       	call   801003a0 <panic>
801075e6:	66 90                	xchg   %ax,%ax
801075e8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801075ef:	00 

801075f0 <setupkvm>:
{
801075f0:	55                   	push   %ebp
801075f1:	89 e5                	mov    %esp,%ebp
801075f3:	83 ec 08             	sub    $0x8,%esp
801075f6:	89 75 fc             	mov    %esi,-0x4(%ebp)
  if ((pgdir = (pde_t *)kalloc()) == 0)
801075f9:	e8 12 b2 ff ff       	call   80102810 <kalloc>
801075fe:	89 c6                	mov    %eax,%esi
80107600:	85 c0                	test   %eax,%eax
80107602:	74 49                	je     8010764d <setupkvm+0x5d>
  memset(pgdir, 0, PGSIZE);
80107604:	83 ec 04             	sub    $0x4,%esp
80107607:	89 5d f8             	mov    %ebx,-0x8(%ebp)
  for (k = kmap; k < &kmap[NELEM(kmap)]; k++)
8010760a:	bb 20 b4 10 80       	mov    $0x8010b420,%ebx
  memset(pgdir, 0, PGSIZE);
8010760f:	68 00 10 00 00       	push   $0x1000
80107614:	6a 00                	push   $0x0
80107616:	50                   	push   %eax
80107617:	e8 44 d4 ff ff       	call   80104a60 <memset>
8010761c:	83 c4 10             	add    $0x10,%esp
    if (mappages(pgdir, k->virt, k->phys_end - k->phys_start,
8010761f:	8b 43 04             	mov    0x4(%ebx),%eax
80107622:	83 ec 08             	sub    $0x8,%esp
80107625:	8b 4b 08             	mov    0x8(%ebx),%ecx
80107628:	8b 13                	mov    (%ebx),%edx
8010762a:	ff 73 0c             	push   0xc(%ebx)
8010762d:	50                   	push   %eax
8010762e:	29 c1                	sub    %eax,%ecx
80107630:	89 f0                	mov    %esi,%eax
80107632:	e8 e9 f8 ff ff       	call   80106f20 <mappages>
80107637:	83 c4 10             	add    $0x10,%esp
8010763a:	83 f8 ff             	cmp    $0xffffffff,%eax
8010763d:	74 19                	je     80107658 <setupkvm+0x68>
  for (k = kmap; k < &kmap[NELEM(kmap)]; k++)
8010763f:	83 c3 10             	add    $0x10,%ebx
80107642:	81 fb 60 b4 10 80    	cmp    $0x8010b460,%ebx
80107648:	75 d5                	jne    8010761f <setupkvm+0x2f>
8010764a:	8b 5d f8             	mov    -0x8(%ebp),%ebx
}
8010764d:	89 f0                	mov    %esi,%eax
8010764f:	8b 75 fc             	mov    -0x4(%ebp),%esi
80107652:	c9                   	leave
80107653:	c3                   	ret
80107654:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
      freevm(pgdir);
80107658:	83 ec 0c             	sub    $0xc,%esp
8010765b:	56                   	push   %esi
    return 0;
8010765c:	31 f6                	xor    %esi,%esi
      freevm(pgdir);
8010765e:	e8 0d ff ff ff       	call   80107570 <freevm>
}
80107663:	89 f0                	mov    %esi,%eax
      return 0;
80107665:	8b 5d f8             	mov    -0x8(%ebp),%ebx
}
80107668:	8b 75 fc             	mov    -0x4(%ebp),%esi
      return 0;
8010766b:	83 c4 10             	add    $0x10,%esp
}
8010766e:	c9                   	leave
8010766f:	c3                   	ret

80107670 <kvmalloc>:
{
80107670:	55                   	push   %ebp
80107671:	89 e5                	mov    %esp,%ebp
80107673:	83 ec 08             	sub    $0x8,%esp
  kpgdir = setupkvm();
80107676:	e8 75 ff ff ff       	call   801075f0 <setupkvm>
8010767b:	a3 e4 55 11 80       	mov    %eax,0x801155e4
  lcr3(V2P(kpgdir)); // switch to the kernel page table
80107680:	05 00 00 00 80       	add    $0x80000000,%eax
80107685:	0f 22 d8             	mov    %eax,%cr3
}
80107688:	c9                   	leave
80107689:	c3                   	ret
8010768a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80107690 <clearpteu>:

// Clear PTE_U on a page. Used to create an inaccessible
// page beneath the user stack.
void clearpteu(pde_t *pgdir, char *uva)
{
80107690:	55                   	push   %ebp
80107691:	89 e5                	mov    %esp,%ebp
80107693:	83 ec 08             	sub    $0x8,%esp
80107696:	8b 45 0c             	mov    0xc(%ebp),%eax
  if (*pde & PTE_P)
80107699:	8b 55 08             	mov    0x8(%ebp),%edx
  pde = &pgdir[PDX(va)];
8010769c:	89 c1                	mov    %eax,%ecx
8010769e:	c1 e9 16             	shr    $0x16,%ecx
  if (*pde & PTE_P)
801076a1:	8b 14 8a             	mov    (%edx,%ecx,4),%edx
801076a4:	f6 c2 01             	test   $0x1,%dl
801076a7:	75 17                	jne    801076c0 <clearpteu+0x30>
  pte_t *pte;

  pte = walkpgdir(pgdir, uva, 0);
  if (pte == 0)
    panic("clearpteu");
801076a9:	83 ec 0c             	sub    $0xc,%esp
801076ac:	68 02 7e 10 80       	push   $0x80107e02
801076b1:	e8 ea 8c ff ff       	call   801003a0 <panic>
801076b6:	66 90                	xchg   %ax,%ax
801076b8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801076bf:	00 
  return &pgtab[PTX(va)];
801076c0:	c1 e8 0a             	shr    $0xa,%eax
    pgtab = (pte_t *)P2V(PTE_ADDR(*pde));
801076c3:	81 e2 00 f0 ff ff    	and    $0xfffff000,%edx
  return &pgtab[PTX(va)];
801076c9:	25 fc 0f 00 00       	and    $0xffc,%eax
801076ce:	8d 84 02 00 00 00 80 	lea    -0x80000000(%edx,%eax,1),%eax
  if (pte == 0)
801076d5:	85 c0                	test   %eax,%eax
801076d7:	74 d0                	je     801076a9 <clearpteu+0x19>
  *pte &= ~PTE_U;
801076d9:	83 20 fb             	andl   $0xfffffffb,(%eax)
}
801076dc:	c9                   	leave
801076dd:	c3                   	ret
801076de:	66 90                	xchg   %ax,%ax

801076e0 <copyuvm>:

// Given a parent process's page table, create a copy
// of it for a child.
pde_t *
copyuvm(pde_t *pgdir, uint sz)
{
801076e0:	55                   	push   %ebp
801076e1:	89 e5                	mov    %esp,%ebp
801076e3:	83 ec 28             	sub    $0x28,%esp
  pde_t *d;
  pte_t *pte;
  uint pa, i, flags;
  char *mem;

  if ((d = setupkvm()) == 0)
801076e6:	e8 05 ff ff ff       	call   801075f0 <setupkvm>
801076eb:	89 c2                	mov    %eax,%edx
801076ed:	85 c0                	test   %eax,%eax
801076ef:	0f 84 cc 00 00 00    	je     801077c1 <copyuvm+0xe1>
    return 0;
  for (i = 0; i < sz; i += PGSIZE)
801076f5:	8b 4d 0c             	mov    0xc(%ebp),%ecx
801076f8:	85 c9                	test   %ecx,%ecx
801076fa:	0f 84 c1 00 00 00    	je     801077c1 <copyuvm+0xe1>
80107700:	89 5d f4             	mov    %ebx,-0xc(%ebp)
80107703:	89 75 f8             	mov    %esi,-0x8(%ebp)
80107706:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80107709:	89 7d fc             	mov    %edi,-0x4(%ebp)
8010770c:	31 ff                	xor    %edi,%edi
8010770e:	66 90                	xchg   %ax,%ax
  if (*pde & PTE_P)
80107710:	8b 4d 08             	mov    0x8(%ebp),%ecx
  pde = &pgdir[PDX(va)];
80107713:	89 f8                	mov    %edi,%eax
80107715:	c1 e8 16             	shr    $0x16,%eax
  if (*pde & PTE_P)
80107718:	8b 04 81             	mov    (%ecx,%eax,4),%eax
8010771b:	a8 01                	test   $0x1,%al
8010771d:	75 11                	jne    80107730 <copyuvm+0x50>
  {
    if ((pte = walkpgdir(pgdir, (void *)i, 0)) == 0)
      panic("copyuvm: pte should exist");
8010771f:	83 ec 0c             	sub    $0xc,%esp
80107722:	68 0c 7e 10 80       	push   $0x80107e0c
80107727:	e8 74 8c ff ff       	call   801003a0 <panic>
8010772c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  return &pgtab[PTX(va)];
80107730:	89 fa                	mov    %edi,%edx
    pgtab = (pte_t *)P2V(PTE_ADDR(*pde));
80107732:	25 00 f0 ff ff       	and    $0xfffff000,%eax
  return &pgtab[PTX(va)];
80107737:	c1 ea 0a             	shr    $0xa,%edx
8010773a:	81 e2 fc 0f 00 00    	and    $0xffc,%edx
80107740:	8d 84 10 00 00 00 80 	lea    -0x80000000(%eax,%edx,1),%eax
    if ((pte = walkpgdir(pgdir, (void *)i, 0)) == 0)
80107747:	85 c0                	test   %eax,%eax
80107749:	74 d4                	je     8010771f <copyuvm+0x3f>
    if (!(*pte & PTE_P))
8010774b:	8b 30                	mov    (%eax),%esi
8010774d:	f7 c6 01 00 00 00    	test   $0x1,%esi
80107753:	0f 84 a8 00 00 00    	je     80107801 <copyuvm+0x121>
      panic("copyuvm: page not present");
    pa = PTE_ADDR(*pte);
    flags = PTE_FLAGS(*pte);
    if ((mem = kalloc()) == 0)
80107759:	e8 b2 b0 ff ff       	call   80102810 <kalloc>
8010775e:	89 c3                	mov    %eax,%ebx
80107760:	85 c0                	test   %eax,%eax
80107762:	74 64                	je     801077c8 <copyuvm+0xe8>
    pa = PTE_ADDR(*pte);
80107764:	89 f0                	mov    %esi,%eax
      goto bad;
    memmove(mem, (char *)P2V(pa), PGSIZE);
80107766:	83 ec 04             	sub    $0x4,%esp
    flags = PTE_FLAGS(*pte);
80107769:	81 e6 ff 0f 00 00    	and    $0xfff,%esi
    pa = PTE_ADDR(*pte);
8010776f:	25 00 f0 ff ff       	and    $0xfffff000,%eax
    memmove(mem, (char *)P2V(pa), PGSIZE);
80107774:	68 00 10 00 00       	push   $0x1000
80107779:	05 00 00 00 80       	add    $0x80000000,%eax
8010777e:	50                   	push   %eax
8010777f:	53                   	push   %ebx
80107780:	e8 7b d3 ff ff       	call   80104b00 <memmove>
    if (mappages(d, (void *)i, PGSIZE, V2P(mem), flags) < 0)
80107785:	58                   	pop    %eax
80107786:	8d 83 00 00 00 80    	lea    -0x80000000(%ebx),%eax
8010778c:	5a                   	pop    %edx
8010778d:	56                   	push   %esi
8010778e:	b9 00 10 00 00       	mov    $0x1000,%ecx
80107793:	89 fa                	mov    %edi,%edx
80107795:	50                   	push   %eax
80107796:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80107799:	e8 82 f7 ff ff       	call   80106f20 <mappages>
8010779e:	83 c4 10             	add    $0x10,%esp
801077a1:	83 f8 ff             	cmp    $0xffffffff,%eax
801077a4:	74 4a                	je     801077f0 <copyuvm+0x110>
  for (i = 0; i < sz; i += PGSIZE)
801077a6:	81 c7 00 10 00 00    	add    $0x1000,%edi
801077ac:	3b 7d 0c             	cmp    0xc(%ebp),%edi
801077af:	0f 82 5b ff ff ff    	jb     80107710 <copyuvm+0x30>
801077b5:	8b 55 e4             	mov    -0x1c(%ebp),%edx
801077b8:	8b 5d f4             	mov    -0xc(%ebp),%ebx
801077bb:	8b 75 f8             	mov    -0x8(%ebp),%esi
801077be:	8b 7d fc             	mov    -0x4(%ebp),%edi
  return d;

bad:
  freevm(d);
  return 0;
}
801077c1:	c9                   	leave
801077c2:	89 d0                	mov    %edx,%eax
801077c4:	c3                   	ret
801077c5:	8d 76 00             	lea    0x0(%esi),%esi
801077c8:	8b 55 e4             	mov    -0x1c(%ebp),%edx
  freevm(d);
801077cb:	83 ec 0c             	sub    $0xc,%esp
801077ce:	52                   	push   %edx
801077cf:	e8 9c fd ff ff       	call   80107570 <freevm>
    return 0;
801077d4:	31 d2                	xor    %edx,%edx
801077d6:	8b 5d f4             	mov    -0xc(%ebp),%ebx
801077d9:	8b 75 f8             	mov    -0x8(%ebp),%esi
801077dc:	8b 7d fc             	mov    -0x4(%ebp),%edi
  return 0;
801077df:	83 c4 10             	add    $0x10,%esp
}
801077e2:	89 d0                	mov    %edx,%eax
801077e4:	c9                   	leave
801077e5:	c3                   	ret
801077e6:	66 90                	xchg   %ax,%ax
801077e8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801077ef:	00 
      kfree(mem);
801077f0:	83 ec 0c             	sub    $0xc,%esp
801077f3:	53                   	push   %ebx
801077f4:	e8 47 ae ff ff       	call   80102640 <kfree>
      goto bad;
801077f9:	8b 55 e4             	mov    -0x1c(%ebp),%edx
801077fc:	83 c4 10             	add    $0x10,%esp
801077ff:	eb ca                	jmp    801077cb <copyuvm+0xeb>
      panic("copyuvm: page not present");
80107801:	83 ec 0c             	sub    $0xc,%esp
80107804:	68 26 7e 10 80       	push   $0x80107e26
80107809:	e8 92 8b ff ff       	call   801003a0 <panic>
8010780e:	66 90                	xchg   %ax,%ax

80107810 <uva2ka>:

// PAGEBREAK!
//  Map user virtual address to kernel address.
char *
uva2ka(pde_t *pgdir, char *uva)
{
80107810:	55                   	push   %ebp
80107811:	89 e5                	mov    %esp,%ebp
80107813:	8b 45 0c             	mov    0xc(%ebp),%eax
  if (*pde & PTE_P)
80107816:	8b 55 08             	mov    0x8(%ebp),%edx
  pde = &pgdir[PDX(va)];
80107819:	89 c1                	mov    %eax,%ecx
8010781b:	c1 e9 16             	shr    $0x16,%ecx
  if (*pde & PTE_P)
8010781e:	8b 14 8a             	mov    (%edx,%ecx,4),%edx
80107821:	f6 c2 01             	test   $0x1,%dl
80107824:	0f 84 fb 00 00 00    	je     80107925 <uva2ka.cold>
  return &pgtab[PTX(va)];
8010782a:	c1 e8 0c             	shr    $0xc,%eax
    pgtab = (pte_t *)P2V(PTE_ADDR(*pde));
8010782d:	81 e2 00 f0 ff ff    	and    $0xfffff000,%edx
  if ((*pte & PTE_P) == 0)
    return 0;
  if ((*pte & PTE_U) == 0)
    return 0;
  return (char *)P2V(PTE_ADDR(*pte));
}
80107833:	5d                   	pop    %ebp
  return &pgtab[PTX(va)];
80107834:	25 ff 03 00 00       	and    $0x3ff,%eax
  if ((*pte & PTE_P) == 0)
80107839:	8b 94 82 00 00 00 80 	mov    -0x80000000(%edx,%eax,4),%edx
  return (char *)P2V(PTE_ADDR(*pte));
80107840:	89 d0                	mov    %edx,%eax
80107842:	f7 d2                	not    %edx
80107844:	25 00 f0 ff ff       	and    $0xfffff000,%eax
80107849:	05 00 00 00 80       	add    $0x80000000,%eax
8010784e:	83 e2 05             	and    $0x5,%edx
80107851:	ba 00 00 00 00       	mov    $0x0,%edx
80107856:	0f 45 c2             	cmovne %edx,%eax
}
80107859:	c3                   	ret
8010785a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80107860 <copyout>:

// Copy len bytes from p to user address va in page table pgdir.
// Most useful when pgdir is not the current page table.
// uva2ka ensures this only works for PTE_U pages.
int copyout(pde_t *pgdir, uint va, void *p, uint len)
{
80107860:	55                   	push   %ebp
80107861:	89 e5                	mov    %esp,%ebp
80107863:	83 ec 18             	sub    $0x18,%esp
80107866:	8b 4d 0c             	mov    0xc(%ebp),%ecx
80107869:	8b 55 10             	mov    0x10(%ebp),%edx
8010786c:	89 7d fc             	mov    %edi,-0x4(%ebp)
8010786f:	8b 7d 14             	mov    0x14(%ebp),%edi
  char *buf, *pa0;
  uint n, va0;

  buf = (char *)p;
  while (len > 0)
80107872:	85 ff                	test   %edi,%edi
80107874:	0f 84 a4 00 00 00    	je     8010791e <copyout+0xbe>
8010787a:	89 5d f4             	mov    %ebx,-0xc(%ebp)
8010787d:	89 75 f8             	mov    %esi,-0x8(%ebp)
80107880:	eb 47                	jmp    801078c9 <copyout+0x69>
80107882:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  return (char *)P2V(PTE_ADDR(*pte));
80107888:	25 00 f0 ff ff       	and    $0xfffff000,%eax
  {
    va0 = (uint)PGROUNDDOWN(va);
    pa0 = uva2ka(pgdir, (char *)va0);
    if (pa0 == 0)
8010788d:	05 00 00 00 80       	add    $0x80000000,%eax
80107892:	74 6f                	je     80107903 <copyout+0xa3>
      return -1;
    n = PGSIZE - (va - va0);
80107894:	8d 9e 00 10 00 00    	lea    0x1000(%esi),%ebx
8010789a:	29 cb                	sub    %ecx,%ebx
    if (n > len)
8010789c:	39 fb                	cmp    %edi,%ebx
8010789e:	0f 47 df             	cmova  %edi,%ebx
      n = len;
    memmove(pa0 + (va - va0), buf, n);
801078a1:	81 e1 ff 0f 00 00    	and    $0xfff,%ecx
801078a7:	83 ec 04             	sub    $0x4,%esp
801078aa:	01 c8                	add    %ecx,%eax
801078ac:	53                   	push   %ebx
801078ad:	52                   	push   %edx
801078ae:	50                   	push   %eax
801078af:	89 55 10             	mov    %edx,0x10(%ebp)
801078b2:	e8 49 d2 ff ff       	call   80104b00 <memmove>
    len -= n;
    buf += n;
801078b7:	8b 55 10             	mov    0x10(%ebp),%edx
  while (len > 0)
801078ba:	83 c4 10             	add    $0x10,%esp
    buf += n;
801078bd:	01 da                	add    %ebx,%edx
  while (len > 0)
801078bf:	29 df                	sub    %ebx,%edi
801078c1:	74 55                	je     80107918 <copyout+0xb8>
801078c3:	8d 8e 00 10 00 00    	lea    0x1000(%esi),%ecx
  if (*pde & PTE_P)
801078c9:	8b 5d 08             	mov    0x8(%ebp),%ebx
  pde = &pgdir[PDX(va)];
801078cc:	89 c8                	mov    %ecx,%eax
    va0 = (uint)PGROUNDDOWN(va);
801078ce:	89 ce                	mov    %ecx,%esi
  pde = &pgdir[PDX(va)];
801078d0:	c1 e8 16             	shr    $0x16,%eax
    va0 = (uint)PGROUNDDOWN(va);
801078d3:	81 e6 00 f0 ff ff    	and    $0xfffff000,%esi
  if (*pde & PTE_P)
801078d9:	8b 04 83             	mov    (%ebx,%eax,4),%eax
801078dc:	a8 01                	test   $0x1,%al
801078de:	0f 84 48 00 00 00    	je     8010792c <copyout.cold>
  return &pgtab[PTX(va)];
801078e4:	89 f3                	mov    %esi,%ebx
    pgtab = (pte_t *)P2V(PTE_ADDR(*pde));
801078e6:	25 00 f0 ff ff       	and    $0xfffff000,%eax
  return &pgtab[PTX(va)];
801078eb:	c1 eb 0c             	shr    $0xc,%ebx
801078ee:	81 e3 ff 03 00 00    	and    $0x3ff,%ebx
  if ((*pte & PTE_P) == 0)
801078f4:	8b 84 98 00 00 00 80 	mov    -0x80000000(%eax,%ebx,4),%eax
801078fb:	a8 01                	test   $0x1,%al
801078fd:	74 04                	je     80107903 <copyout+0xa3>
  if ((*pte & PTE_U) == 0)
801078ff:	a8 04                	test   $0x4,%al
80107901:	75 85                	jne    80107888 <copyout+0x28>
80107903:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80107906:	8b 75 f8             	mov    -0x8(%ebp),%esi
      return -1;
80107909:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    va = va0 + PGSIZE;
  }
  return 0;
}
8010790e:	8b 7d fc             	mov    -0x4(%ebp),%edi
80107911:	c9                   	leave
80107912:	c3                   	ret
80107913:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80107918:	8b 5d f4             	mov    -0xc(%ebp),%ebx
8010791b:	8b 75 f8             	mov    -0x8(%ebp),%esi
8010791e:	8b 7d fc             	mov    -0x4(%ebp),%edi
  return 0;
80107921:	31 c0                	xor    %eax,%eax
}
80107923:	c9                   	leave
80107924:	c3                   	ret

80107925 <uva2ka.cold>:
  if ((*pte & PTE_P) == 0)
80107925:	a1 00 00 00 00       	mov    0x0,%eax
8010792a:	0f 0b                	ud2

8010792c <copyout.cold>:
8010792c:	a1 00 00 00 00       	mov    0x0,%eax
80107931:	0f 0b                	ud2
